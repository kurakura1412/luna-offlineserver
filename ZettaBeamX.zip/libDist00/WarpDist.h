#ifndef WARPDIST_H
#define WARPDIST_H

#ifndef API_EXPORT
#define API_EXPORT __attribute__((visibility("default")))
#endif
#include <vector>

class MoonBase;
class CServerSystem;
class API_EXPORT WarpDist 
{
public:
	WarpDist();
	~WarpDist();
	bool init();
	void Update();
	void start(int mapnum);
	void onFisrtConnect( int indexconn );
	void setNetData( MoonBase* zz);
	void parseIN(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength);
	void parseINSVR(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength);
	void end();
private:
	CServerSystem * svrdist;
};

#endif // WARPDIST_H
