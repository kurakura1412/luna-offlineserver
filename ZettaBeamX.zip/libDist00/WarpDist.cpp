#include "stdafx.h"

#if defined( _AGENT00_) || defined(_DIST00_) ||defined( _MAP00_ )
//#include "math.inl"
#include "yhlibrary.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "[Server]Distribute/ServerSystem.h"

#include "WarpDist.h"
#include "Network.h"
#include "DataBase.h"


char g_szMapName[64];
char g_szHeroIDName[17] = { 0, };

WarpDist::WarpDist()
{
	svrdist = nullptr;
}

WarpDist::~WarpDist()
{
	if(svrdist){
		//svrdist->End();
		delete svrdist;
		svrdist = nullptr;
		g_pServerSystem = nullptr;
	}
}

bool WarpDist::init()
{
	if( g_pServerSystem ) return false;
	svrdist = new (std::nothrow) CServerSystem;
	g_pServerSystem = svrdist;
	start(0);
	return true;
}

void WarpDist::start(int mapnum)
{
	if( svrdist ) svrdist->Start(mapnum);
}

void WarpDist::onFisrtConnect(int indexconn)
{
	OnAcceptUser(indexconn);
}
void WarpDist::setNetData(MoonBase* zz)
{
	g_Network.setLuna( zz);
	g_DB.setLuna( zz );
}
void WarpDist::parseIN(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength)
{
	ReceivedMsgFromUser(dwConnectionIndex,pMsg,dwLength  );
}
void WarpDist::Update()
{
	if( svrdist ) svrdist->Process();
}
void WarpDist::parseINSVR(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength)
{
	ReceivedMsgFromServer(dwConnectionIndex,pMsg,dwLength  );
}
void WarpDist::end()
{
	if( svrdist ) svrdist->End();
}
