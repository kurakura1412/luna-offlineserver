#ifndef __CDEBUFFSKILLUNIT_H__INCLUDED
#define __CDEBUFFSKILLUNIT_H__INCLUDED
#pragma once
#include "skillunit.h"

class cDeBuffSkillUnit :
	public cSkillUnit
{
public:
	cDeBuffSkillUnit(cActiveSkillObject&);
	virtual ~cDeBuffSkillUnit();
	virtual BOOL Excute();
};

#endif // __CDEBUFFSKILLUNIT_H__INCLUDED
