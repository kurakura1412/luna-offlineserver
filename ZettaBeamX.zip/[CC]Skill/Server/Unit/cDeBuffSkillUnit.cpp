#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "cdebuffskillunit.h"
#include "Object/ActiveSkillObject.h"
#include "Object/BuffSkillObject.h"
#include "Target/Target.h"

cDeBuffSkillUnit::cDeBuffSkillUnit(cActiveSkillObject& skillObject) :
cSkillUnit(skillObject)
{}

cDeBuffSkillUnit::~cDeBuffSkillUnit(void)
{
}

BOOL cDeBuffSkillUnit::Excute()
{
	mpParentSkill->GetTarget().SetPositionHead();

	while(CObject* const pTarget = mpParentSkill->GetTarget().GetData())
	{
		if( pTarget->GetState()  == eObjectState_Die )
		{
			continue;
		}		

		pTarget->GetBuffList().SetPositionHead();

		while(cBuffSkillObject* const pBuffSkill = pTarget->GetBuffList().GetData())
		{
			// 100601 ShinJS --- µð¹öÇÁÀÇ ·¹º§À» ½ºÅ©¸³Æ®ÀÇ UnitDataTypeÀ¸·Î ÀÌ¿ë
			const int skillUnitData			= (int)mAddDamage;
			const WORD skillUnitDataType	= mAddType;

			if(pBuffSkill->GetInfo().Status == skillUnitData )
			{
				if( skillUnitDataType >= pBuffSkill->GetSkillLevel() )
				{
					pBuffSkill->SetEndState();
					pBuffSkill->EndState();
				}
			}
		}
	}

	return TRUE;
}