#include "StdAfx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "SummonSkillUnit.h"
#include "Object/ActiveSkillObject.h"
#include "Target/Target.h"
#include "AISystem.h"
#include "RegenManager.h"
#include "Monster.h"
#include "StateMachinen.h"
#include "[CC]Header/GameResourceManager.h"

cSummonSkillUnit::cSummonSkillUnit(cActiveSkillObject& skillObject) :
cSkillUnit(skillObject)
{}

cSummonSkillUnit::~cSummonSkillUnit(void)
{}

BOOL cSummonSkillUnit::Excute()
{
	CObject* const ownerObject = mpParentSkill->GetOperator();

	if(0 == ownerObject)
	{
		return FALSE;
	}

	const int totalSize = mpParentSkill->GetInfo().UnitDataType;
	const int summonedSize = ownerObject->GetSummondSize(mpParentSkill->GetInfo());

	if(summonedSize > totalSize)
	{
		return FALSE;
	}

	int summoningSize = totalSize - summonedSize;

	// ÇÃ·¹ÀÌ¾î´Â 1°³¾¿ ¼ÒÈ¯ÇÑ´Ù
	if(eObjectKind_Player == ownerObject->GetObjectKind())
	{		
		if(summonedSize == totalSize)
		{
			ownerObject->RemoveSummonedOldest(
				mpParentSkill->GetInfo());
		}

		summoningSize = 1;
	}

	const WORD summonMonsterKind = WORD(mpParentSkill->GetInfo().UnitData);
	const BASE_MONSTER_LIST* const monsterList = GAMERESRCMNGR->GetMonsterListInfo(
		summonMonsterKind);

	if(0 ==	monsterList)
	{
		return FALSE;
	}

	mpParentSkill->GetTarget().SetPositionHead();
	size_t targetSize = mpParentSkill->GetTarget().GetSize();

	while(CObject* const targetObject = mpParentSkill->GetTarget().GetData())
	{
		VECTOR3 targetPosition = {0};
		targetObject->GetPosition(
			&targetPosition);

		if(0 >= summoningSize)
		{
			break;
		}

		/*
		ÀÌ ½ºÅ³À» ±¤¿ªÀ¸·Î ¾µ °æ¿ì¸¦ °¡Á¤ÇØº¸ÀÚ. ¼ÒÈ¯¼ö 5°³¸¦ ´ë»ó 7°÷¿¡ Àû¿ëÇÏ·Á¸é ¾î¶»°Ô ³ª´²¾ßÇÒ±î. ¶Ç´Â
		¼ÒÈ¯¼ö 11°³¸¦ ´ë»ó 5°÷¿¡ Àû¿ëÇÏ·Á¸é ¾î¶»°Ô ³ª´²¾ßÇÒ±î.

		ceil()À» »ç¿ëÇØ¼­ Á¶±ÝÀÌ¶óµµ ¼Ò¼öÁ¡ÀÌ ¹ß»ýÇÏ¸é 1À» ´õÁØ´Ù. Ç×»ó ¸Ç ³ªÁß¿¡´Â 1·Î ³ª´©±â ¶§¹®¿¡ ¸ðµç
		°³¼ö¸¦ ´Ù °¡Á®°£´Ù. ³ª´­ °³¼ö°¡ ¾øÀ¸¸é 0ÀÌ µÈ´Ù. ÀÌ·± ½ÄÀ¸·Î ¸ðÀÚ¶óµç ³²µç Ç×»ó °ñ°í·ç ºÐÇØÇÒ ¼ö ÀÖ´Ù
		*/
		const int eachSummoningSize = int(ceil(float(summoningSize) / targetSize--));
		summoningSize = summoningSize - eachSummoningSize;

		for(int i = 0; i < eachSummoningSize; ++i)
		{
			const float randomRateX = float(rand()) / RAND_MAX;
			const float randomRateZ = float(rand()) / RAND_MAX;
			const float randomAxisX = (randomRateX < 0.5f ? -1.0f : 1.0f) * (ownerObject->GetRadius() * (1.0f + randomRateX));
			const float randomAxisZ = (randomRateZ < 0.5f ? -1.0f : 1.0f) * (ownerObject->GetRadius() * (1.0f + randomRateZ));

			VECTOR3 summonPosition = {0};
			summonPosition.x = targetPosition.x + randomAxisX;
			summonPosition.z = targetPosition.z + randomAxisZ;

			CMonster* const monster = REGENMGR->RegenObject(
				g_pAISystem.GeneraterMonsterID(),
				0,
				ownerObject->GetGridID(),
				monsterList->ObjectKind,
				monsterList->MonsterKind,
				&summonPosition,
				0,
				0,
				0,
				FALSE,
				TRUE,
				ownerObject->GetID());

			if(0 == monster)
			{
				return FALSE;
			}
			else if(TRUE == monster->SetTObject(ownerObject->GetTObject()))
			{
				GSTATEMACHINE.SetState(
					monster,
					eMA_PERSUIT);
			}

			ownerObject->AddSummoned(
				mpParentSkill->GetInfo(),
				monster->GetID());
		}
	}

	return TRUE;
}