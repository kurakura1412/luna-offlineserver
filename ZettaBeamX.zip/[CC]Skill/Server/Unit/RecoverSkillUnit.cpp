#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "recoverskillunit.h"

#include "Target/Target.h"
#include "Object/ActiveSkillObject.h"
#include "Info/ActiveSkillInfo.h"

#include "AttackManager.h"
#include "PackedData.h"

cRecoverSkillUnit::cRecoverSkillUnit(cActiveSkillObject& skillObject) :
cSkillUnit(skillObject)
{}

cRecoverSkillUnit::~cRecoverSkillUnit(void)
{
}

BOOL cRecoverSkillUnit::Excute()
{
	MSG_SKILL_RESULT msg;

	msg.InitMsg( mpParentSkill->GetID() );
	msg.SkillDamageKind = false;

	CTargetListIterator iter(&msg.TargetList);

	mpParentSkill->GetTarget().SetPositionHead();

	while(CObject* const pTarget = mpParentSkill->GetTarget().GetData())
	{
		if( pTarget->GetState()  == eObjectState_Die )
		{
			continue;
		}

		RESULTINFO resultinfo = {0};
		resultinfo.mSkillIndex = mpParentSkill->GetSkillIdx();

		switch(mUnitType)
		{
		case UNITKIND_LIFE_RECOVER:
			{
				ATTACKMGR->RecoverLife(
					mpParentSkill->GetOperator(),
					pTarget,
					mAddDamage,
					&resultinfo);
				break;
			}
		case UNITKIND_MANA_RECOVER:
			{
				ATTACKMGR->RecoverMana(
					mpParentSkill->GetOperator(),
					pTarget,
					mAddDamage,
					&resultinfo);
				break;
			}
		}

		iter.AddTargetWithResultInfo( pTarget->GetID(), 1, &resultinfo);
		iter.Release();

		PACKEDDATA_OBJ->QuickSend( pTarget, &msg, msg.GetMsgLength() );
	}

	return TRUE;
}