#ifndef __SUMMONSKILLUNIT_H__INCLUDED
#define __SUMMONSKILLUNIT_H__INCLUDED
#pragma once

#include "skillunit.h"

class cSummonSkillUnit :
	public cSkillUnit
{
public:
	cSummonSkillUnit(cActiveSkillObject&);
	virtual ~cSummonSkillUnit(void);
	virtual BOOL Excute();
};
#endif // __SUMMONSKILLUNIT_H__INCLUDED
