#ifndef __RECOVERSKILLUNIT_H__INCLUDED
#define __RECOVERSKILLUNIT_H__INCLUDED
#pragma once
#include "skillunit.h"

class cRecoverSkillUnit :
	public cSkillUnit
{
public:
	cRecoverSkillUnit(cActiveSkillObject&);
	virtual ~cRecoverSkillUnit();
	virtual BOOL Excute();
};
#endif // __RECOVERSKILLUNIT_H__INCLUDED
