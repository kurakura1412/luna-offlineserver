#ifndef __TAMESKILLUNIT_H__INCLUDED
#define __TAMESKILLUNIT_H__INCLUDED
#pragma once

#include "skillunit.h"

class cTameSkillUnit :
	public cSkillUnit
{
public:
	cTameSkillUnit(cActiveSkillObject&);
	virtual ~cTameSkillUnit(void);
	virtual BOOL Excute();
};
#endif // __TAMESKILLUNIT_H__INCLUDED
