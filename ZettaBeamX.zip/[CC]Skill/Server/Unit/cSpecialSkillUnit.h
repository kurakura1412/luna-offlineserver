#ifndef __CSPECIALSKILLUNIT_H__INCLUDED
#define __CSPECIALSKILLUNIT_H__INCLUDED
#pragma once
#include "skillunit.h"

class cSpecialSkillUnit :
	public cSkillUnit
{
public:
	cSpecialSkillUnit(cActiveSkillObject&);
	virtual ~cSpecialSkillUnit();
	virtual BOOL Excute();
};

#endif // __CSPECIALSKILLUNIT_H__INCLUDED
