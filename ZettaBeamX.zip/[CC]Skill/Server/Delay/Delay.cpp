#include "stdafx.h"
#include "delay.h"
#include "[CC]Header/ServerGameDefine.h"

cDelay::cDelay(void)
{
	mStart = 0;
	mDelay = 0;
	mRemain = 0;
	mRate = 0.0f;
}

cDelay::~cDelay(void)
{
}

void cDelay::Init( DWORD time )
{
	mDelay = time;
	mStart = 0;
	mRemain = 0;
	mRate = 0.0f;
}

void cDelay::Start()
{
	mStart = gCurTime;

	mRemain = mDelay;
	mRate = 100.0f;

	mbStart = TRUE;
}

DWORD cDelay::Check()
{
	/// µô·¹ÀÌ Ä«¿îÆ®°¡ ½ÃÀÛµÇ¾ú´Ù¸é
	if( mbStart )
	{
		/// ½ÃÀÛºÎÅÍ ÇöÀç±îÁö °æ°ú½Ã°£
		DWORD spend = gCurTime - mStart;

		/// ¼³Á¤µÈ ½Ã°£º¸´Ù Å©°Å³ª °°´Ù¸é
		if( mDelay <= spend )
		{
			/// Ä«¿îÆ® Á¾·á
			End();
			return 0;
		}
		else
		{
			/// ³²Àº ½Ã°£ °è»ê
			mRemain = mDelay - spend;

			/// ³²Àº ½Ã°£ ºñÀ² °è»ê
			mRate = ( float )( mDelay / mRemain );

			/// ³²Àº½Ã°£À» µ¹·ÁÁØ´Ù
			return mRemain;
		}
	}
	else
	{
		return 0;	
	}
}

void cDelay::End()
{
	mbStart = FALSE;

	mStart = 0;
	mRemain = 0;
	mRate = 0.0f;
}

BOOL cDelay::IsStart()
{
	return mbStart;
}

DWORD cDelay::GetStartTime()
{
	return mStart;
}

DWORD cDelay::GetDelayTime()
{
	return mDelay;
}

DWORD cDelay::GetRemainTime()
{
	return mRemain;
}

float cDelay::GetRemainRate()
{
	return mRate;
}