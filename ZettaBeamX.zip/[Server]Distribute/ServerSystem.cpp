// ServerSystem.cpp: implementation of the CServerSystem class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#ifdef _DIST00_
#include <yhlibrary.h>
//#include "CommonHeader.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
//#include "ServerSystem.h"
//#include "UserTable.h"

#endif


#include "ServerSystem.h"
#include "Console.h"
#include "Network.h"
#include "DataBase.h"
#include "DistributeNetworkMsgParser.h"
#include "DistributeDBMsgParser.h"
//#include "BillConnector.h"
#include "Usertable.h"
#include "Servertable.h"
#include "MemoryPoolTempl.h"
#include "BootManager.h"
#include "UserManager.h"
#include "MHFile.h"
#include "MHTimeManager.h"
//#include "..\[CC]ServerModule\MiniDumper.h"

LPCTSTR g_SERVER_VERSION = "LTSV08070301";
extern int g_nServerSetNum;

void __stdcall ProcessDBMessage(DWORD dwEventIndex)
{
	g_DB.ProcessingDBMessage();
}


/* void ButtonProc1();
void ButtonProc2();
void ButtonProc3(); */
void OnCommand(char* szCommand);

HWND g_hWnd;
CServerSystem * g_pServerSystem = 0;
CPool<USERINFO> g_UserInfoPool;

typedef void (*MSGPARSER)(DWORD dwConnectionIndex, char* pMsg, DWORD dwLength);
MSGPARSER g_pServerMsgParser[MP_MAX];
MSGPARSER g_pUserMsgParser[MP_MAX];

CServerSystem::CServerSystem()// :
//mBillConnector(new CBillConnector)
{
	// servertable usertable ÃÊ±âÈ­ ---------------------
	g_UserInfoPool.Init(3000, 500,"USERINFO");
	g_pUserTable = new CUserTable;
	g_pUserTable->Init(3000/3);
	g_pServerTable = new CServerTable;
	g_pServerTable->Init(50);

	//CoInitialize(NULL);

	m_bUserFireWall = FALSE;
	ZeroMemory( m_strFireWallIP, sizeof(m_strFireWallIP) );
	
	m_Nation = eNATION_KOREA;
}

CServerSystem::~CServerSystem()
{
	//CoUninitialize();
}

extern DWORD g_dwMaxUser;

void CServerSystem::Start(WORD ServerNum)
{	
//AO¨öA ¡¤IAA
	SetNation();

	FILE* fpMC = fopen( "MaxUserCount.txt", "r" );
	if(fpMC)
	{
		fscanf( fpMC, "%d", &g_dwMaxUser );
		fclose( fpMC );
	}

	BOOTMNGR->AddSelfBootList(DISTRIBUTE_SERVER, ServerNum, g_pServerTable);
	gUserMGR.LoadDistributeDesc();	//ÀÌ°É ÀÐ±âÀ§ÇØ¼­ À§¿§ÁÙÀÌ ÇÊ¿äÇÑ°Å¶ó±¸.

	/* MENU_CUSTOM_INFO pMenu[3] = {0};
	strcpy(pMenu[0].szMenuName, "Open console");
	pMenu[0].cbMenuCommand = ButtonProc1;
	strcpy(pMenu[1].szMenuName, "Reconnect bill");
	pMenu[1].cbMenuCommand = ButtonProc2;
	strcpy(pMenu[2].szMenuName, "Toggle userLvl");
	pMenu[2].cbMenuCommand = ButtonProc3;

	if(FALSE == g_Console.Init(_countof(pMenu), pMenu, OnCommand))
		MessageBox(NULL,"Fail initialize Console",0,0); */

	char windowTitleMsg[64];
	sprintf(windowTitleMsg,"Distribute Server_%d", ServerNum);

	g_hWnd = GetActiveWindow();
	SetWindowText(g_hWnd, windowTitleMsg);

	g_pServerMsgParser[MP_SERVER]	= MP_DISTRIBUTESERVERMsgParser;
	g_pServerMsgParser[MP_POWERUP]	= MP_POWERUPMsgParser;
	g_pServerMsgParser[MP_USERCONN] = MP_USERCONNMsgParser;
	// 080408 LYW --- ServerSystem : Add a network message parser for chatroom system.
	g_pServerMsgParser[MP_CHATROOM]	= MP_CHATROOMMsgParser ;
	
	g_pServerMsgParser[MP_MORNITORMAPSERVER] = MP_MonitorMsgParser;
	g_pUserMsgParser[MP_USERCONN] = MP_USERCONNMsgParser;
	
	/* CUSTOM_EVENT customEvent[] = {
		{10, ProcessServer},
		{100, ProcessGame},
		{1000 * 30, ProcessCheck},
	};

	DESC_NETWORK desc = {0};
	desc.OnAcceptServer = OnAcceptServer;
	desc.OnDisconnectServer = OnDisconnectServer;
	desc.OnAcceptUser = OnAcceptUser;
	desc.OnDisconnectUser = OnDisconnectUser;
	desc.OnRecvFromServerTCP = ReceivedMsgFromServer;
	desc.OnRecvFromUserTCP = ReceivedMsgFromUser;
	desc.dwCustomDefineEventNum	= sizeof(customEvent) / sizeof(*customEvent);
	desc.pEvent = customEvent;
	desc.dwMainMsgQueMaxBufferSize = 20480000;
	desc.dwMaxServerNum = 100;
	desc.dwMaxUserNum = 3000;
	desc.dwServerBufferSizePerConnection = 512000;
	desc.dwServerMaxTransferSize = 65535;
	desc.dwUserBufferSizePerConnection = 128000;
	desc.dwUserMaxTransferSize = 65535;
	desc.dwConnectNumAtSameTime = 3000;
	desc.dwFlag = 0;//NETDDSC_DEBUG_LOG;

	g_Network.Init(&desc); */
	//g_Network.Start();

	// 080703 LYW --- ServerSystem : ¼­¹ö ÄÜ¼ÖÃ¢¿¡ Ã³À½À¸·Î ¼­¹ö ¹öÀüºÎÅÍ Ãâ·ÂÇÑ´Ù.
	//g_Console.LOG(4, "¡¡") ;
	g_Console.LOG(4, "[ Server Version : %s ]", g_SERVER_VERSION) ;
	//g_Console.LOG(4, "¡¡") ;
	
	// Booting
//	BOOTMNGR->AddSelfBootList(DISTRIBUTE_SERVER, ServerNum, g_pServerTable);//À§·Î ¿Å°Ü³õ±¸--;
	if(!BOOTMNGR->StartServer(&g_Network, g_pServerTable->GetSelfServer()))
	{
		//MessageBox(NULL,"Server Initialize Failed (StartServer)",NULL,NULL);
		MessageBox(NULL,"Server Initialize Failed (StartServer)",NULL,0);
		return;
	}

	BOOTMNGR->AddBootListINI(DISTRIBUTE_SERVER, 0, g_pServerTable);

	/*if(!BOOTMNGR->ConnectToMS(&g_Network, g_pServerTable))
	{
		SERVERINFO info;
		info.wServerKind = MONITOR_SERVER;
		OnConnectServerFail(&info);		
	}*/

	//////////////////////////////////////////////////////////////////////////
	// DB ¼³Á¤
	DWORD maxthread = 2;
	DWORD maxqueryinsametime = 1024;
	FILE* fp = fopen("DistributeDBInfo.txt","r");
	if(fp)
	{
		fscanf(fp,"%d %d",&maxthread,&maxqueryinsametime);
		fclose(fp);
	}
//	if(g_DB.Init(maxthread,maxqueryinsametime,TRUE) == FALSE)
//		MessageBox(NULL,"DataBase Initializing Failed",0,0);

	m_DBThreadTerminate = FALSE;
#ifdef _DBTHREAD
	CreateThread(0,0,ProcessDBMessageThread,0,0,&m_DBThreadID);
#endif
	
	
	// ·Î±×ÀÎ Ã¼Å© Å×ÀÌºí ÃÊ±âÈ­
	LoginCheckInit();
	
//	LoadFireWallIP();

	// Dump
	//MiniDumper md(MiniDumper::DUMP_LEVEL_0);

	// 100226 pdy ½ºÅ©¸³Æ®Ã¤Å©½Ã ¼­¹öÀÇ Å°°ªÀº ÇÑ¹ø¸¸ ÀÐµµ·Ï º¯°æ
	SetScriptCheckValue( m_ScriptCheckValue );


	g_Console.LOG(4, "-----------   DISTRIBUTE SERVER START  -----------------");
	// ÀÌ ºÎºÐÀº À©µµ¿ìÀÇ ¸Þ½ÃÁö ·çÇÁ.CONSOLEÀ» »ç¿ëÇÏµç À©µµ¿ì ¸Þ½ÃÁö ±â¹ÝÀ¸·Î Â¥µç ¾î¶²½ÄÀ¸·Îµç ÀÌº¥Æ®¸¦ ´ë±âÇØ¾ßÇÏ
	// ÇÏ¹Ç·Î ±ÍÂúÀº ¸Þ½ÃÁö ·çÇÁ ÀÛ¼ºÀ» ÇÏ°í ½ÍÁö ¾Ê´Ù¸é ÀÌ ¸Þ¼Òµå¸¦ »ç¿ëÇÑ´Ù.±× ´â°í ´âÀº ¸Þ½ÃÁö ·çÇÁ¿Í µ¿ÀÏÇÑ ±â´ÉÀ» 
	// ¼öÇàÇÑ´Ù.ÀÌ ¸Þ¼Òµå´Â I4DyuchiCONSOLE ´ÙÀÌ¾ó·Î±×ÀÇ x¹öÆ°À» ´©¸¦¶§±îÁö ¸®ÅÏÇÏÁö ¾Ê´Â´Ù.ÀÌ ¸Þ¼Òµå°¡ ¸®ÅÏÇÑ´Ù¸é ÇÁ
	// ·Î±×·¥ÀÌ Á¾·áÇÏ´Â °ÍÀÌ´Ù.
	
	g_bReady = TRUE;

	g_Console.WaitMessage();
}

void CServerSystem::LoadFireWallIP()
{
	CMHFile file;
	if( !file.Init( "firewallip.txt", "rt", MHFILE_FLAG_DONOTDISPLAY_NOTFOUNDERROR ) )
		return;

	while(FALSE == file.IsEOF())
	{
		if( file.GetInt() == g_nServerSetNum )
		{
			SafeStrCpy( m_strFireWallIP, file.GetString(), 16 );
			if( *m_strFireWallIP != 0 )
				m_bUserFireWall = TRUE;

			break;
		}
	}

	file.Release();	
}

void CServerSystem::ConnectionCheck()
{	// YH ÇöÀç 30ÃÊ¸¶´Ù ÇÑ¹ø¾¿ µé¾î¿È
	DWORD _60sec = 60*1000;
	USERINFO* pInfo;
	DWORD elapsedtime;

	if(g_bReady == FALSE)
		return;
	
	cPtrList removelist;

	g_pUserTable->SetPositionHead();
	while((pInfo = g_pUserTable->GetData()) != NULL)
	{
		if(pInfo->dwConnectionIndex != 0)
		{
			// ¾ÆÁ÷ Á¢¼ÓÀÌ Á¦´ë·Î ÀÌ·ïÁöÁö ¾ÊÀº °æ¿ì
			elapsedtime = gCurTime - pInfo->dwLastConnectionCheckTime;
			if( elapsedtime > _60sec * 2 )
			{
				if(pInfo->bConnectionCheckFailed)
				{
					//!!Å×½ºÆ® ÈÄ 30ÃÊ ¸¶´Ù µé¾î¿À°Ô ¹Ù²Ù°í Áö¿ï°Í~!
					//pInfo->dwLastConnectionCheckTime += 1000 * 10;	//OnDisconnectUser( ¸®ÅÏ ¹Þ±â Àü¿¡ ¹Ýº¹ ¹æÁö.
					removelist.AddTail(pInfo);
					continue;
				}
				else
				{
					pInfo->bConnectionCheckFailed = TRUE;
					SendConnectionCheckMsg(pInfo);
					pInfo->dwLastConnectionCheckTime = gCurTime;
				}
			}
		}
	}

	PTRLISTPOS pos = removelist.GetHeadPosition();
	while( pos )
	{
		USERINFO* p = (USERINFO*)removelist.GetNext(pos);
		ASSERT(p->dwConnectionIndex);
//		LoginCheckDelete(p->dwUserID);		// ·Î±×ÀÎÃ¼Å© Å×ÀÌºí¿¡¼­ »èÁ¦
//		g_pServerSystem->ReleaseAuthKey(p->dwUniqueConnectIdx);
//		g_pUserTable->RemoveUser(p->dwConnectionIndex);
//		memset(p,0,sizeof(USERINFO));
//		g_UserInfoPool.Free(p);
		DisconnectUser( p->dwConnectionIndex );
	}
	removelist.RemoveAll();
}

void CServerSystem::SendConnectionCheckMsg(USERINFO* pInfo)
{
	MSGBASE msg;
	msg.Category = MP_USERCONN;
	msg.Protocol = MP_USERCONN_CONNECTION_CHECK;
	g_Network.Send2User(pInfo->dwConnectionIndex,(char*)&msg,sizeof(msg));
}

void CServerSystem::Process()
{
	MHTIMEMGR_OBJ->Process();
	//GetBilling().Process();
}


void CServerSystem::End()
{
//	UnhookWindowsHookEx(hHook);
	m_DBThreadTerminate = TRUE;
//	ICRelease(m_IdxCreater);
	
	g_Network.Release();

	g_DB.Release();

	g_Console.Release();

//	if(g_pListCollect)
//	{
//		delete g_pListCollect;
//		g_pListCollect = NULL;
//	}
	if(g_pUserTable)
	{
		delete g_pUserTable;
		g_pUserTable = NULL;
	}
	if(g_pServerTable)
	{
		delete g_pServerTable;
		g_pServerTable = NULL;
	}
	//CoFreeUnusedLibraries();
}

DWORD CServerSystem::MakeAuthKey()
{
	//return ICAllocIndex(m_IdxCreater) + 1;
	static DWORD ID = 1;//GetTickCount()*GetTickCount();
	if(ID == 0)
		++ID;
	return ID++;
}
void CServerSystem::ReleaseAuthKey(DWORD key)
{
	//ICFreeIndex(m_IdxCreater,key-1);
}

void CServerSystem::SetNation()
{
	CMHFile file;
	if( !file.Init( "LocalizingInfo.txt", "rt", MHFILE_FLAG_DONOTDISPLAY_NOTFOUNDERROR ) )
		return;

	if( strcmp( file.GetString(), "*NATION" ) == 0 )
	{
		if( strcmp( file.GetString(), "CHINA" ) == 0 )
		{
			m_Nation = eNATION_CHINA;
		}
	}

	file.Release();
}


// global function

void __stdcall OnConnectServerSuccess(DWORD dwConnectionIndex, void* pVoid)
{
	SERVERINFO* info = (SERVERINFO*)pVoid;
	info->dwConnectionIndex = dwConnectionIndex;
	if(info->wServerKind == MONITOR_SERVER)
	{
		BOOTMNGR->NotifyBootUpToMS(&g_Network);
		g_Console.LOG(4, "Connected to the MS : %s, %d, (%d)", info->szIPForServer, info->wPortForServer, dwConnectionIndex);
	}
	else
	{
		BOOTMNGR->SendConnectSynMsg(&g_Network, dwConnectionIndex, g_pServerTable);
		g_Console.LOG(4, "Connected to the Server : %s, %d, (%d)", info->szIPForServer, info->wPortForServer, dwConnectionIndex);
	}

/*
	SERVERINFO* info = (SERVERINFO*)pVoid;
	if(!dwConnectionIndex) return;

	info->dwConnectionIndex = dwConnectionIndex;					// ÀÌ°Ô Á¦´ë·Î µ¿ÀÛÇÏ³ª? Ã¼Å©
	MSG_WORD msg;
	msg.Category = MP_SERVER;
	msg.Protocol = MP_SERVER_PWRUP;
	msg.wData = g_pServerTable->GetSelfServer()->wPortForServer;
	g_Network.Send2Server(dwConnectionIndex, (char*)&msg, sizeof(msg));*/

	//if(g_pServerTable->m_MaxServerConnectionIndex < dwIndex)			//??????
			//g_pServerTable->m_MaxServerConnectionIndex = dwIndex;	
}

void __stdcall OnDisconnectServer(DWORD dwConnectionIndex)
{
	g_Console.LOG(4, "Server Disconnected : ConnectionIndex %d", dwConnectionIndex);//pjslocal

	// ¼­¹öÁ¤º¸ Áö¿ò
	SERVERINFO * delInfo = g_pServerTable->RemoveServer(dwConnectionIndex);
	if(!delInfo)
	{
		//BootManagerÀÛµ¿ÀÌ ¿Ï·áÇÏÁö ¾Ê¾ÒÀ» ¶§ ¼­¹ö°¡ ²¨Áú °æ¿ì ¹ß»ý,(¿Ã¹Ù¸¥ ¿¡·¯)
		ASSERT(0);
		return;
	}
	delete delInfo;
}

void __stdcall OnConnectServerFail(void* pVoid)
{	
	SERVERINFO* info = (SERVERINFO*)pVoid;
	if(info->wServerKind == MONITOR_SERVER)
	{
//		BOOTMNGR->AddBootListINI(DISTRIBUTE_SERVER, 0, g_pServerTable);
		BOOTMNGR->BactchConnectToMap(&g_Network, g_pServerTable);
		g_Console.LOG(4, "Failed to Connect to the MS : %s, %d", info->szIPForServer, info->wPortForServer);
	}
	else
	{
		//not process
		g_Console.LOG(4, "Failed to Connect to the Server : %s, %d", info->szIPForServer, info->wPortForServer);
		BOOTMNGR->RemoveBootList(g_pServerTable, info->wPortForServer);
	}	
}
void __stdcall OnAcceptServer(DWORD dwConnectionIndex)
{// not used
	char strr[255];
	wsprintf(strr, "%d ¹ø connectionIndex ¼­¹ö Á¢¼Ó ", dwConnectionIndex);//pjslocal

	g_Console.LOG(4, strr);
}

void __stdcall OnAcceptUser(DWORD dwConnectionIndex)
{	
	if(g_bReady == FALSE)
	{
		// ÃÊ±âÈ­°¡ ¿ÏÀüÈ÷ ¾ÈµÆ´Âµ¥ µé¾î¿Â°æ¿ì.
		MSGBASE send;
		send.Category = MP_USERCONN;
		send.Protocol = MP_USERCONN_SERVER_NOTREADY;
		send.dwObjectID = 0;
		g_Network.Send2User(dwConnectionIndex, (char *)&send, sizeof(send));

		DisconnectUser(dwConnectionIndex);
		return;
	}

	USERINFO* pPreInfo = g_pUserTable->FindUser( dwConnectionIndex );
	if( pPreInfo )
	{
		g_pUserTable->RemoveUser( dwConnectionIndex );
		memset(pPreInfo, 0, sizeof(USERINFO));
		g_UserInfoPool.Free( pPreInfo );
	}

	DWORD authkey = g_pServerSystem->MakeAuthKey();
	USERINFO * info = g_UserInfoPool.Alloc();
	memset(info, 0, sizeof(USERINFO));
	info->dwConnectionIndex = dwConnectionIndex;
	info->dwUniqueConnectIdx = authkey;
	info->dwLastConnectionCheckTime = gCurTime;	//SW051107 Ãß°¡
	g_pUserTable->AddUser(info,dwConnectionIndex);

//---KES Distribute Encrypt 071003
/*
	MSGBASE send;
	send.Category = MP_USERCONN;
	send.Protocol = MP_USERCONN_DIST_CONNECTSUCCESS;
	send.dwObjectID = authkey;
	g_Network.Send2User(dwConnectionIndex, (char *)&send, sizeof(send));
*/
	MSG_DIST_CONNECTSUCCESS send = {}; 
	send.Category = MP_USERCONN;
	send.Protocol = MP_USERCONN_DIST_CONNECTSUCCESS;
	send.dwObjectID = authkey;

	info->crypto.Create();	// key »ý¼º
	send.eninit = *info->crypto.GetEnKey();
	send.deinit = *info->crypto.GetDeKey();

	g_Network.Send2User(dwConnectionIndex, (char *)&send, sizeof(send));

	info->crypto.SetInit( TRUE );		// init on	
//--------------------------------

//	g_Console.Log(eLogDisplay,4, "OnAcceptUser : Client Connected - Idx:%d, AuthKey:%d, Total(%d)",dwConnectionIndex,authkey, g_pUserTable->GetUserCount());
//	g_Console.Log(eLogFile,4, "OnAcceptUser : Client Connected - Idx:%d, AuthKey:%d, Total(%d)",dwConnectionIndex,authkey, g_pUserTable->GetUserCount());
}

void __stdcall OnDisconnectUser(DWORD dwConnectionIndex)
{
	g_pUserTable->OnDisconnectUser(dwConnectionIndex);
//	g_Console.Log(eLogDisplay,4, "OnAcceptUser : Client Disconnected - Idx:%d, Total(%d)",dwConnectionIndex, g_pUserTable->GetUserCount());
//	g_Console.Log(eLogFile,4, "OnAcceptUser : Client Disconnected - Idx:%d, Total(%d)",dwConnectionIndex, g_pUserTable->GetUserCount());
}

void __stdcall ReceivedMsgFromServer(DWORD dwConnectionIndex,char* pMsg,DWORD dwLength)
{
	MSGROOT* pTempMsg = reinterpret_cast<MSGROOT*>(pMsg);
	
	if( g_pServerMsgParser[pTempMsg->Category] == NULL ||
		pTempMsg->Category >= MP_MAX ||
		pTempMsg->Category == 0)
		return;

	g_pServerMsgParser[pTempMsg->Category](dwConnectionIndex, pMsg, dwLength);
}

void __stdcall ReceivedMsgFromUser(DWORD dwConnectionIndex,char* pMsg,DWORD dwLength)
{
	MSGROOT* pTempMsg = reinterpret_cast<MSGROOT*>(pMsg);
//	ServerTraffic * Msg = reinterpret_cast<ServerTraffic*>(pMsg);
	ASSERT(g_pUserMsgParser[pTempMsg->Category]);

//---KES Distribute Encrypt 071003
	USERINFO* pInfo = g_pUserTable->FindUser(dwConnectionIndex);

	if( pInfo )
	{
		if( pInfo->cbCheckSum == 0 )
		{
			pInfo->cbCheckSum = pTempMsg->CheckSum;
		}
		else if( pInfo->cbCheckSum != pTempMsg->CheckSum )
		{
			OnDisconnectUser( dwConnectionIndex );
			DisconnectUser( dwConnectionIndex );
			return;
		}

		++pInfo->cbCheckSum;
#ifdef _CRYPTCHECK_
		int headerSize = sizeof( MSGROOT );

		if( !pInfo->crypto.Decrypt( ( char * )pTempMsg +  headerSize, dwLength - headerSize ) )
		{
			ASSERTMSG(0,"Decrypt Error");
			OnDisconnectUser( dwConnectionIndex );
			DisconnectUser( dwConnectionIndex );
			return;
		}
		char aaa = pInfo->crypto.GetDeCRCConvertChar();
		if( pTempMsg->Code !=  aaa )
		{
			ASSERTMSG(0,"Decrypt CRC Error");
			OnDisconnectUser( dwConnectionIndex );
			DisconnectUser( dwConnectionIndex );
			return;
		}
#endif
	}

//--------------------------------

	if( g_pUserMsgParser[pTempMsg->Category] == NULL ||
		pTempMsg->Category >= MP_MAX ||
		pTempMsg->Category == 0)
		return;

	g_pUserMsgParser[pTempMsg->Category](dwConnectionIndex, pMsg, dwLength);
}

void __stdcall ProcessServer(DWORD)
{
	g_DB.ProcessingDBMessage();
}

void __stdcall ProcessGame(DWORD)
{
	g_pServerSystem->Process();
}

void __stdcall ProcessCheck(DWORD)
{
	g_pServerSystem->ConnectionCheck();
}

/* void ButtonProc1()
{
	static BOOL isUseConsole;

	if(isUseConsole)
	{
		FreeConsole();
	}
	else
	{
		// TODO: ÄÜ¼Ö¿¡ Ctrl+C ¸Þ½ÃÁö¸¦ º¸³»¸é ¾îÇÃ¸®ÄÉÀÌ¼ÇÀÌ Á¤ÁöÇÑ´Ù.. - -; ÄÜ¼Ö ÇÚµé·¯·Îµµ ¾ÈµÈ´Ù. ¿Ö ±×·²±î...
		AllocConsole();

		TCHAR windowTitle[MAX_PATH] = {0};
		GetWindowText(
			g_hWnd,
			windowTitle,
			_countof(windowTitle));
		TCHAR text[MAX_PATH] = {0};
		_stprintf(
			text,
			"%s: Console",
			windowTitle);
		SetConsoleTitle(
			text);
	}

	isUseConsole = ! isUseConsole;
} */

/* void ButtonProc2()
{
	OutputDebug(
		"Reconnect to billing server");

	g_pServerSystem->GetBilling().Reset();
} */

/* void ButtonProc3()
{
	static BOOL isToggle = FALSE;

	if(isToggle)
	{
		g_Console.LOG(
			4,
			"User level: super user (default)");
		gUserMGR.SetUserLevel(
			eUSERLEVEL_SUPERUSER);
	}
	else
	{
		g_Console.LOG(
			4,
			"User level: sub user (service)");
		gUserMGR.SetUserLevel(
			eUSERLEVEL_SUBUSER);
	}

	isToggle = (FALSE == isToggle);
} */

void OnCommand(char* szCommand)
{

}

BOOL CServerSystem::IsInvalidCharInclude( char* pStr )
{
	while( *pStr )
	{
		BOOL bOk = FALSE;

		if( IsDBCSLeadByte( *pStr ) )
		{
			++pStr;
		}
		else
		{
			//¿µ¹®
			if( ( *pStr >= 'A' && *pStr <= 'Z' ) || ( *pStr >= 'a' && *pStr <= 'z' ) )
				bOk = TRUE;
			//¼ýÀÚ
			else if( *pStr >= '0' && *pStr <= '9' )
				bOk = TRUE;
		}

		++pStr;

		if( bOk == FALSE )
		{
			return TRUE;
		}
	}

	return FALSE;
}

