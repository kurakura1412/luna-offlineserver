//=================================================================================================
//	FILE		: CChatRoomMgr.cpp
//	DESC		: Ã¤ÆÃ¹æ ¸Å´ÏÁ® ±¸ÇöºÎ.
//	DATE		: APRIL 2, 2008 LYW
//				:
//	DESC		: FEBRUARY 25, 2009 - ±âÁ¸ À¯Àú°ü¸® µîÀ» STL MAPÀ¸·Î °ü¸® ÇÏ´ø °ÍÀ» CYHHashTable
//				: °ü¸® ¹æ½ÄÀ¸·Î ¼öÁ¤ ÇÔ.
//=================================================================================================





//-------------------------------------------------------------------------------------------------
//		Çì´õÆÄÀÏ Æ÷ÇÔ.
//-------------------------------------------------------------------------------------------------
//#include "[Server]Distribute/stdafx.h"

//#include "[CC]ServerModule/Network.h"

#include "StdAfx.h"

#ifdef _DIST00_
#include <yhlibrary.h>
//#include "CommonHeader.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
//#include "ServerSystem.h"
#include "UserTable.h"
#endif

#include "Network.h"
#include "ChatRoomMgr.h"






//-------------------------------------------------------------------------------------------------
//	NAME : CChatRoomMgr
//	DESC : »ý¼ºÀÚ ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
CChatRoomMgr::CChatRoomMgr( void) 
{
	// À¯Àú °ü¸®¸¦ ÇÏ´Â ÇØ½¬ Å×ÀÌºíÀ» ÃÊ±âÈ­ÇÑ´Ù.
	m_htUser.Initialize( MAX_USER_BUCKETCNT ) ;



	// °Ë»ö¿ë ÀÌ¸§À» °ü¸®ÇÏ´Â ÇØ½¬ Å×ÀÌºíÀ» ÃÊ±âÈ­ÇÑ´Ù.
	m_htSearchName.Initialize( MAX_USER_BUCKETCNT ) ;

    

	// Ã¤ÆÃ¹æ ÀÎµ¦½º °ü¸® ¹è¿­ ÃÊ±âÈ­.
	memset( m_byRoomIdx, 0, sizeof(BYTE)*MAX_ROOM_COUNT ) ;

	m_byRoomIdx[0] = 1 ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : ~CChatRoomMgr
//	DESC : ¼Ò¸êÀÚ ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
CChatRoomMgr::~CChatRoomMgr( void )
{
	// Ã¤ÆÃ¹æ/ °Ë»ö¿ë Ã¤ÆÃ¹æ ÇØÁ¦.
	ReleaseRoom() ;



	// °Ë»ö¿ë ÀÌ¸§ Á¤º¸ ÇØ½¬ Å×ÀÌºíÀ» ÇØÁ¦ÇÑ´Ù.
	ST_SEARCH_NAME* pNameInfo = NULL ;
	m_htSearchName.SetPositionHead() ;
	while( (pNameInfo = m_htSearchName.GetData()) != NULL )
	{
		delete pNameInfo ;
		pNameInfo = NULL ;
	}
	m_htSearchName.RemoveAll() ;



	// À¯Àú °ü¸®¿ë ÇØ½¬ Å×ÀÌºíÀ» ÇØÁ¦ÇÑ´Ù.
	ST_CR_USER* pUserInfo = NULL ;
	m_htUser.SetPositionHead() ;
	while( (pUserInfo = m_htUser.GetData()) != NULL )
	{
		delete pUserInfo ;
		pUserInfo = NULL;
	}
	m_htUser.RemoveAll() ;
}




//-------------------------------------------------------------------------------------------------
//	NAME		: GetInstance()
//	DESC		: The function that returns this class's instance to static type.
//	PROGRAMMER	: Yongs Lee
//	DATE		: February 25, 2009
//-------------------------------------------------------------------------------------------------
CChatRoomMgr* CChatRoomMgr::GetInstance()
{
	// ÂüÁ¶: http://www.codeproject.com/useritems/VC2003MeyersSingletonBug.asp
	//
	// Á¤Àû ÀÎ¶óÀÎ ÇÔ¼ö´Â ÂüÁ¶½Ã¸¶´Ù »ý¼ºµÈ´Ù(ÀÎ¶óÀÎ ÇÔ¼ö´Â Á÷Á¢ ´ëÄ¡µÉ »Ó ¸µÅ©µÇÁö ¾Ê´Â´Ù). 
	// ÀÌ·Î ÀÎÇØ ½Ì±ÛÅÏ º¯¼ö±îÁö ÂüÁ¶½Ã¸¶´Ù »ý¼ºµÈ´Ù!
	// ÀÌ¸¦ ¸·À¸·Á¸é ´ÜÀÏÇÑ ¸µÅ© ÁöÁ¡À» ¸¸µé¾îÁà¾ßÇÑ´Ù. C ÆÄÀÏ¿¡ Á÷Á¢ ±¸ÇöÇÏ¸é ÇØ°áµÈ´Ù.



	static CChatRoomMgr instance ;

	return &instance ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : ReleaseRoom
//	DESC : Ã¤ÆÃ¹æ ¸®¼Ò½º ÇØÁ¦ ÇÔ¼ö.
//  DATE : APRIL 22, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::ReleaseRoom()
{
	// ¹æ »èÁ¦.
	ST_CR_ROOM_SRV* pInfo = NULL ;
	PTRLISTPOS pos = NULL ;

	pos = m_pRoomList.GetHeadPosition() ;

	while( pos )
	{
		pInfo = (ST_CR_ROOM_SRV*)m_pRoomList.GetNext( pos ) ;

		if( !pInfo ) continue ;

		m_pRoomList.Remove( pInfo ) ;

		delete pInfo ;
		pInfo = NULL ;
	}

	m_pRoomList.RemoveAll() ;



	// °Ë»ö¿ë ¹æ »èÁ¦.
	ST_CR_ROOM_CLT* pTitle = NULL ;
	pos = m_pRoomList.GetHeadPosition() ;

	while( pos )
	{
		pTitle = (ST_CR_ROOM_CLT*)m_pTitleList.GetNext( pos ) ;

		if( !pTitle ) continue ;

		m_pTitleList.Remove( pTitle ) ;

		delete pTitle ;
		pTitle = NULL ;
	}

	m_pTitleList.RemoveAll() ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : IsInRoomList
//	DESC : ¹æ ¸®½ºÆ®¿¡, ¹æ Á¤º¸°¡ ÀÖ´ÂÁö Ã¼Å©ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 22, 2008 LYW
//-------------------------------------------------------------------------------------------------
BYTE CChatRoomMgr::IsInRoomList( BYTE byRoomIdx ) 
{
	ST_CR_ROOM_SRV* pItem ;

	PTRLISTPOS pos = NULL ;
	pos = m_pRoomList.GetHeadPosition() ;

	while( pos )
	{
		pItem = (ST_CR_ROOM_SRV*)m_pRoomList.GetNext( pos ) ;

		if( !pItem ) continue ;

		if( pItem->byIdx == byRoomIdx ) return TRUE ;
	}

	return FALSE ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : AddRoom
//	DESC : Ã¤ÆÃ¹æ Á¤º¸¸¦ Ãß°¡ÇÏ´Â ÇÔ¼ö.
//		 : Ã¤ÆÃ¹æ Á¤º¸ »Ó ¾Æ´Ï¶ó, °Ë»ö¿ë Ã¤ÆÃ¹æ Á¤º¸µµ °°ÀÌ Ãß°¡¸¦ ÇÑ´Ù.
//  DATE : APRIL 22, 2008 LYW
//-------------------------------------------------------------------------------------------------
BYTE CChatRoomMgr::AddRoom( ST_CR_ROOM_SRV* pInfo )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return FALSE ;
	}



	// ¹æÃß°¡.
	m_pRoomList.AddTail( pInfo ) ;



	// ¹æ ÀÎµ¦½º ¼¼ÆÃ.
	m_byRoomIdx[ pInfo->byIdx ] = pInfo->byIdx ;



	// °Ë»ö ¿ë ¹æ Ãß°¡.
	ST_CR_ROOM_CLT* pTitle = NULL ;
	pTitle = new ST_CR_ROOM_CLT ;

	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( "Failed to create title room!!", __FUNCTION__ ) ;
		return FALSE ;
	}

	pTitle->byIdx				= pInfo->byIdx ;
	pTitle->bySecretMode		= pInfo->bySecretMode ;
	pTitle->byRoomType			= pInfo->byRoomType ;
	pTitle->byCurGuestCount		= pInfo->byCurGuestCount ;
	pTitle->byTotalGuestCount	= pInfo->byTotalGuestCount ;

	SafeStrCpy( pTitle->title, pInfo->title, TITLE_SIZE ) ;

	m_pTitleList.AddTail( pTitle ) ;

	return TRUE ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : DeleteRoom
//	DESC : Ã¤ÆÃ¹æ Á¤º¸¸¦ »èÁ¦ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 22, 2008 LYW
//-------------------------------------------------------------------------------------------------
BYTE CChatRoomMgr::DeleteRoom( BYTE byRoomIdx )
{
	// ¹æ »èÁ¦ Ã³¸®.
	ST_CR_ROOM_SRV* pItem = NULL ;

	PTRLISTPOS pos = NULL ;
	pos = m_pRoomList.GetHeadPosition() ;

	while( pos )
	{
		pItem = (ST_CR_ROOM_SRV*)m_pRoomList.GetNext( pos ) ;

		if( !pItem ) continue ;

		if( pItem->byIdx != byRoomIdx ) continue ;

		m_pRoomList.Remove( pItem ) ;

		delete pItem ;
		pItem = NULL ;

		m_byRoomIdx[ byRoomIdx ] = 0 ;

		break ;
	}



	// °Ë»ö¿ë ¹æ »èÁ¦ Ã³¸®.
	ST_CR_ROOM_CLT* pTitle ;
	pos = m_pTitleList.GetHeadPosition() ;

	while( pos )
	{
		pTitle = NULL ;
		pTitle = (ST_CR_ROOM_CLT*)m_pTitleList.GetNext( pos ) ;

		if( !pTitle ) continue ;

		if( pTitle->byIdx != byRoomIdx ) continue ;

		m_pTitleList.Remove( pTitle ) ;

		delete pTitle ;
		pTitle = NULL ;

		break ;
	}

	return TRUE ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : GetRoomInfo
//	DESC : Ã¤ÆÃ¹æ Á¤º¸¸¦ ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 22, 2008 LYW
//-------------------------------------------------------------------------------------------------
ST_CR_ROOM_SRV* CChatRoomMgr::GetRoomInfo( BYTE byRoomIdx ) 
{
	ST_CR_ROOM_SRV* pItem ;

	PTRLISTPOS pos = NULL ;
	pos = m_pRoomList.GetHeadPosition() ;

	while( pos )
	{
		pItem = (ST_CR_ROOM_SRV*)m_pRoomList.GetNext( pos ) ;

		if( !pItem ) continue ;

		if( pItem->byIdx != byRoomIdx ) continue ;

		return pItem ;
	}

	return NULL ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : GetRoomCountByType
//
//	DESC : Ã¤ÆÃ¹æ ºÐ·ù¿¡ µû¶ó¼­, ¸®½ºÆ®¿¡ ¸î°³³ª ´ã°Ü ÀÖ´ÂÁö ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : * ¹æ °³¼ö´Â ÃÖ´ë 250°³ ÀÌ¹Ç·Î BYTEÇüÀ» »ç¿ëÇÑ´Ù.
//		 : 
//  DATE : APRIL 22, 2008 LYW
//-------------------------------------------------------------------------------------------------
BYTE CChatRoomMgr::GetRoomCountByType( BYTE byType )
{
	BYTE byRoomCount = 0 ;

	ST_CR_ROOM_SRV* pItem ;

	PTRLISTPOS pos = NULL ;
	pos = m_pRoomList.GetHeadPosition() ;

	while( pos )
	{
		pItem = NULL ;
		pItem = (ST_CR_ROOM_SRV*)m_pRoomList.GetNext( pos ) ;

		if( !pItem ) continue ;

		if( pItem->byRoomType != byType ) continue ;

		++byRoomCount ;
	}

	return byRoomCount ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : SendErrors
//	DESC : ¿¡·¯ ¸Þ½ÃÁö¸¦ Àü¼ÛÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 7, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::SendErrors( DWORD dwIndex, DWORD dwPlayerID, BYTE byProtocol, BYTE byErr ) 
{
	MSG_BYTE msg ;
	memset( &msg, 0, sizeof(MSG_BYTE) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= byProtocol ;
	msg.dwObjectID	= dwPlayerID ;

	msg.bData		= byErr ;
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_BYTE) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_BYTE) ) ;
#endif
}





//-------------------------------------------------------------------------------------------------
//	NAME : NetworkMsgParser
//	DESC : Ã¤ÆÃ¹æ°ú °ü·ÃÇÑ, Dist ¼­¹ö·Î ³Ñ¾î¿À´Â ¸Þ½ÃÁö¸¦ Ã³¸®ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::NetworkMsgParser( DWORD dwIndex, char* pMsg, DWORD dwLength )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ±âº» ¸Þ½ÃÁö º¯È¯.
	MSGBASE* pmsg = NULL ;
	pmsg = (MSGBASE*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTB, __FUNCTION__ ) ;
		return ;
	}



	// ÇÁ·ÎÅäÄÝ Ã¼Å©.
	switch( pmsg->Protocol )
	{
	case MP_CHATROOM_ADD_USER_SYN :			Add_User_Syn( dwIndex, pMsg, dwLength ) ;		break ;
	case MP_CHATROOM_FORCE_ADD_USER_SYN :	Force_Add_User_Syn( dwIndex, pMsg, dwLength ) ;	break ;
	case MP_CHATROOM_DEL_USER_SYN :			Del_User_Syn( dwIndex, pMsg, dwLength ) ;		break ;
	case MP_CHATROOM_ROOM_SYN :				Room_Syn( dwIndex, pMsg, dwLength ) ;			break ;
	case MP_CHATROOM_CREATE_ROOM_SYN :		Create_Room_Syn( dwIndex, pMsg, dwLength ) ;	break ;
	case MP_CHATROOM_JOIN_ROOM_SYN :		Join_Room_Syn( dwIndex, pMsg, dwLength ) ;		break ;
	case MP_CHATROOM_OUT_ROOM_SYN :			Out_Room_Syn( dwIndex, pMsg, dwLength ) ;		break ;
	case MP_CHATROOM_CHANGE_OPTION_SYN :	Option_Syn( dwIndex, pMsg, dwLength ) ;			break ;	
	case MP_CHATROOM_CHANGE_OWNER_SYN :		Owner_Syn( dwIndex, pMsg, dwLength ) ;			break ;	
	case MP_CHATROOM_KICK_GUEST_SYN :		Kick_Syn( dwIndex, pMsg, dwLength ) ;			break ;	
	case MP_CHATROOM_REQUEST_FRIEND_SYN :	Friend_Syn( dwIndex, pMsg, dwLength ) ;			break ;	
	case MP_CHATROOM_UPDATE_USERINFO_SYN :	UpdateUserInfo( dwIndex, pMsg, dwLength ) ;		break ;	
	case MP_CHATROOM_SEARCH_FOR_NAME_SYN :	SearchName_Syn( dwIndex, pMsg, dwLength ) ;		break ;	
	case MP_CHATROOM_SEARCH_FOR_TITLE_SYN :	SearchTitle_Syn( dwIndex, pMsg, dwLength ) ;	break ;	
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : Add_GuestInfo_Syn
//		 : 
//	DESC : À¯Àú Á¤º¸¸¦ µî·ÏÇÏ´Â ÇÔ¼ö.
//		 :
//		 : 1. Ã¤ÆÃÁßÀÎ À¯ÀúÀÎÁö Ã¼Å©.
//		 : 2. À¯Àú µî·Ï.
//		 : 3. °Ë»ö¿ë ÀÌ¸§ µî·Ï.
//		 : 4. °á°ú Àü¼Û.
//		 :
//  DATE : APRIL 4, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Add_User_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength ) 
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_USER* pmsg = NULL ;
	pmsg = (MSG_CR_USER*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// Ã¤ÆÃÁßÀÎÁö Ã¼Å©.
	ST_CR_USER* pUserInfo = m_htUser.GetData( pmsg->user.dwPlayerID ) ;
	if( pUserInfo ) return ;



	// À¯Àú Á¤º¸ µî·Ï.
	ST_CR_USER* pNewUser = new ST_CR_USER ;
	ASSERT( pNewUser ) ;
	if( !pNewUser ) return ;

	memcpy( pNewUser, &pmsg->user, sizeof(ST_CR_USER) ) ;
	pNewUser->dwConnectionIdx = dwIndex ;

	m_htUser.Add( pNewUser, pNewUser->dwPlayerID ) ;



	// °á°ú Àü¼Û.
	MSGBASE msg ;
	memset(&msg, 0, sizeof(MSGBASE)) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_ADD_USER_ACK ;
	msg.dwObjectID	= pmsg->dwObjectID ;
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSGBASE) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSGBASE) ) ;
#endif
}





//-------------------------------------------------------------------------------------------------
//	NAME : Force_Add_User_Syn
//		 : 
//	DESC : ÀÌ¹Ì µî·ÏµÇ¾î ÀÖ´Â À¯Àú Á¤º¸°¡ ÀÖ´ø¸»´ø, °­Á¦·Î À¯Àú¸¦ µî·ÏÇÏ°í, Ã¤ÆÃ¹æ ¸®½ºÆ®¸¦ Àü¼ÛÇÑ´Ù.
//		 : 
//		 : 1. µî·Ï µÈ À¯ÀúÀÎÁö Ã¼Å©.
//		 :    1-1. Ã¤ÆÃÁßÀÎÁö Ã¼Å©.
//		 :	  1-2. Ã¤ÆÃ¹æ ¹Þ±â.
//		 :    1-3. À¯Àú ¾Æ¿ô Ã³¸®.
//		 :    1-4. °Ë»ö¿ë ÀÌ¸§ »èÁ¦.
//		 :    1-5. À¯Àú Á¤º¸ »èÁ¦.
//		 : 2. À¯Àú µî·Ï.
//		 : 3. °Ë»ö¿ë ÀÌ¸§ µî·Ï.
//		 : 
//  DATE : APRIL 22, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Force_Add_User_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength ) 
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_USER* pmsg = NULL ;
	pmsg = (MSG_CR_USER*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// À¯Àú ¹Þ±â.
	ST_CR_USER* pUserInfo = m_htUser.GetData( pmsg->user.dwPlayerID ) ;
	if( pUserInfo )
	{
		// ¹æ ¹Þ±â.
		ST_CR_ROOM_SRV* pRoom = NULL ;
		pRoom = GetRoomInfo( pUserInfo->byIdx ) ;

		// ¹æ ÀÖÀ¸¸é,
		if( pRoom )
		{
			// ¾Æ¿ô Ã³¸®.
			MSGBASE msg ;
			memset( &msg, 0, sizeof(MSGBASE) ) ;

			msg.Category	= MP_CHATROOM ;
			msg.Protocol	= MP_CHATROOM_OUT_ROOM_SYN ;
			msg.dwObjectID	= pmsg->dwObjectID ;

			Out_Room_Syn( dwIndex, (char*)&msg, sizeof(MSGBASE) ) ;
		}

		// À¯Àú Á¤º¸ »èÁ¦.
		m_htUser.Remove( pUserInfo->dwPlayerID ) ;
	}



	// À¯Àú µî·Ï.
	ST_CR_USER* pNewUser = new ST_CR_USER ;
	ASSERT( pNewUser ) ;
	if( !pNewUser ) return ;

	memcpy( pNewUser, &pmsg->user, sizeof(ST_CR_USER) ) ;
	pNewUser->dwConnectionIdx = dwIndex ;

	m_htUser.Add( pNewUser, pNewUser->dwPlayerID ) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : Del_GuestInfo_SynDWORD
//		 : 
//	DESC : Ä³¸¯ÅÍ°¡ ·Î±× ¾Æ¿ôÀ» ÇßÀ» ¶§, À¯Àú Á¤º¸¸¦ ¿ÏÀüÈ÷ »èÁ¦ ½ÃÅ°´Â ÇÔ¼ö.
//		 : 
//		 : 1. µî·Ï µÈ À¯ÀúÀÎÁö Ã¼Å©.
//		 :    1-1. Ã¤ÆÃÁßÀÎÁö Ã¼Å©.
//		 :	  1-2. Ã¤ÆÃ¹æ ¹Þ±â.
//		 :    1-3. À¯Àú ¾Æ¿ô Ã³¸®.
//		 : 2. À¯Àú »èÁ¦.
//		 : 3. °Ë»ö¿ë ÀÌ¸§ »èÁ¦.
//		 : 
//  DATE : APRIL 22, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Del_User_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength ) 
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSGBASE* pmsg = NULL ;
	pmsg = (MSGBASE*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// À¯Àú ¹Þ±â.
	ST_CR_USER* pUserInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( pUserInfo )
	{
		// ¹æ ¹Þ±â.
		ST_CR_ROOM_SRV* pRoom = NULL ;
		pRoom = GetRoomInfo( pUserInfo->byIdx ) ;

		// ¹æ ÀÖÀ¸¸é,
		if( pRoom )
		{
			// ¾Æ¿ô Ã³¸®.
			MSGBASE msg ;
			memset( &msg, 0, sizeof(MSGBASE) ) ;

			msg.Category	= MP_CHATROOM ;
			msg.Protocol	= MP_CHATROOM_OUT_ROOM_SYN ;
			msg.dwObjectID	= pmsg->dwObjectID ;

			Out_Room_Syn( dwIndex, (char*)&msg, sizeof(MSGBASE) ) ;
		}

		// °Ë»ö¿ë À¯Àú ÀÌ¸§ »èÁ¦.
		EraseUserName( pUserInfo->name ) ;

		// À¯Àú Á¤º¸ »èÁ¦.
		m_htUser.Remove( pUserInfo->dwPlayerID ) ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : RoomList_Syn
//		 : 
//	DESC : ¿äÃ»ÀÌ µé¾î¿Â ÆäÀÌÁö¿¡ ÇØ´çÇÏ´Â ¹æ Á¤º¸¸¦ ´ã¾Æ¼­ Agent·Î Àü¼ÛÇÑ´Ù.
//		 : 
//		 : 1. ¸®½ºÆ® Çì´õ ¼¼ÆÃ.
//		 : 2. Ã¤ÆÃ¹æ ºÐ·ù¿¡ µû¶ó ¹æÁ¤º¸¸¦ ´ã´Â´Ù.
//		 : 3. ÆäÀÌÁö ¼¼ÆÃ.
//		 : 4. Àü¼ÛÇÏ´Â ¸®½ºÆ® ºÐ·ù ¼¼ÆÃ.
//		 : 5. °á°ú Àü¼Û.
//		 : 
//  DATE : APRIL 22, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Room_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength ) 
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ.
	// 0 = err_Empty_Room,
	// 1 = err_Delay_Time,



	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_BYTE2* pmsg = NULL ;
	pmsg = (MSG_BYTE2*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_CR_ROOMLIST msg ;
	memset( &msg, 0, sizeof(MSG_CR_ROOMLIST) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_ROOMLIST_ACK ;
	msg.dwObjectID	= pmsg->dwObjectID ;



	// ¹æÁ¤º¸¸¦ ´ãÀ» ¹üÀ§ ÀÎµ¦½º ¼¼ÆÃ.
	BYTE byIndex = 0 ;
	BYTE byStartIdx = 0 ;
	byStartIdx = pmsg->bData2 * ROOM_COUNT_PER_PAGE ;



	// ¸®½ºÆ® Çì´õ ¼¼ÆÃ.
	ST_CR_ROOM_SRV* pInfo = NULL ;
	PTRLISTPOS pos = NULL ;
	pos = m_pRoomList.GetHeadPosition() ;

	while( pos )
	{
		// ¹æÁ¤º¸ ¹Þ±â.
		pInfo = (ST_CR_ROOM_SRV*)m_pRoomList.GetNext( pos ) ;
		if( !pInfo ) continue ;

		// ÀÎµ¦½º À¯È¿ Ã¼Å©.
		if( byIndex < byStartIdx )
		{
			++byIndex ;
			continue ;
		}

		// Àü¼Û ÇÒ °³¼ö Ã¼Å©.
		if( msg.byCount >= ROOM_COUNT_PER_PAGE ) break ;

		if( pmsg->bData1 != e_RTM_AllLooK )
		{
			if( pInfo->byRoomType != pmsg->bData1-1 ) continue ;
		}

		// ¹æ Á¤º¸ ´ã±â.
		msg.room[ msg.byCount ].byIdx				= pInfo->byIdx ;
		msg.room[ msg.byCount ].bySecretMode		= pInfo->bySecretMode ;
		msg.room[ msg.byCount ].byRoomType			= pInfo->byRoomType ;
		msg.room[ msg.byCount ].byCurGuestCount		= pInfo->byCurGuestCount ;
		msg.room[ msg.byCount ].byTotalGuestCount	= pInfo->byTotalGuestCount ;

		SafeStrCpy( msg.room[ msg.byCount ].title, pInfo->title, TITLE_SIZE ) ;

		++msg.byCount ;
	}



	// ÆäÀÌÁö ¼¼ÆÃ.
	msg.byCurPage	= pmsg->bData2 ;
	if( pmsg->bData1 != e_RTM_AllLooK )
	{
		msg.byTotalPage	= GetRoomCountByType( pmsg->bData1-1 ) / ROOM_COUNT_PER_PAGE ;
	}
	else
	{
		msg.byTotalPage	= (BYTE)(m_pRoomList.GetCount() / ROOM_COUNT_PER_PAGE);
	}



	// ´ãÀº Ã¤ÆÃ¹æ ºÐ·ù ¼¼ÆÃ.
	msg.byRoomType	= pmsg->bData1 ;
	// °á°ú Àü¼Û.
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_ROOMLIST) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_ROOMLIST) ) ;
#endif
}





//-------------------------------------------------------------------------------------------------
//	NAME : Create_Room_Syn
//		 : 
//	DESC : Ã¤ÆÃ¹æ »ý¼º ¿äÃ»ÀÌ ¿ÔÀ» ¶§ Ã³¸®ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. Ã¤ÆÃ¹æ °³¼ö Ã¼Å©.
//		 : 2. µî·Ï µÈ À¯ÀúÀÎÁö Ã¼Å©.
//		 : 3. Ã¤ÆÃÁßÀÎÁö Ã¼Å©.
//		 : 4. Ã¤ÆÃ¹æ »ý¼º.
//		 : 5. °ü¸® ¸®½ºÆ®¿¡ ¹æ Ãß°¡.
//		 : 6. À¯ÀúÀÇ Ã¤ÆÃ¹æ ¹øÈ£ ¼¼ÆÃ.
//		 : 7. °á°ú Àü¼Û.
//		 :
//  DATE : APRIL 4, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Create_Room_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength ) 
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ.
	// 0 = err_Already_Chatting,
	// 1 = err_RoomCount_Over,
	// 2 = err_User_Is_Not_In_Lobby,
	// 3 = err_Registed_But_Not_Found_Room,
	// 4 = err_Registed_But_Not_Found_User,



	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_ELEMENT* pmsg = NULL ;
	pmsg = (MSG_CR_ELEMENT*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// Ã¤ÆÃ¹æ °³¼ö Ã¼Å©.
	if( m_pRoomList.GetCount() >= MAX_ROOM_COUNT )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CREATE_ROOM_NACK, 1 ) ;
		return ;
	}



	// µî·Ï µÈ À¯ÀúÀÎÁö Ã¼Å©.
	ST_CR_USER* pUserInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( !pUserInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CREATE_ROOM_NACK, 2 ) ;
		return ;
	}



	// Ã¤ÆÃÁßÀÎÁö Ã¼Å©.
	if( pUserInfo->byIdx != 0 )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CREATE_ROOM_NACK, 0 ) ;
		return ;
	}



	// Ã¤ÆÃ¹æ »ý¼º.
	ST_CR_ROOM_SRV* pRoom = NULL ;
	pRoom = new ST_CR_ROOM_SRV ;

	ASSERT( pRoom ) ;

	if( !pRoom )
	{
		Throw_Error( "Failed to create chatroom !!", __FUNCTION__ ) ;
		return ;
	}



	// ±âº» ¹æ Á¤º¸ ¼¼ÆÃ.
	pRoom->byIdx			= GetEmptyRoomIdx() ;
	pRoom->dwOwnerIdx		= pmsg->dwObjectID ;

	pRoom->bySecretMode		= pmsg->bySecretMode ;
	pRoom->byRoomType		= pmsg->byRoomType ;
	pRoom->byCurGuestCount	= 1 ;

	SafeStrCpy( pRoom->code, pmsg->code, SECRET_CODE_SIZE ) ;



	// ÃÖ´ë Âü¿© ÀÎ¿ø ¼¼ÆÃ.
	BYTE byTotalGuest = e_GC_20 ;

	switch( pmsg->byTotalGuestCount )
	{
	case e_GC_20 :	byTotalGuest = e_GC_20 ;	break ;
	case e_GC_15 :	byTotalGuest = e_GC_15 ;	break ;
	case e_GC_10 :	byTotalGuest = e_GC_10 ;	break ;
	case e_GC_5 :	byTotalGuest = e_GC_5 ;		break ;
	default :									break ;
	}

	pRoom->byTotalGuestCount	= byTotalGuest ;



	// ¹æ Á¦¸ñ ¼¼ÆÃ.
	SafeStrCpy( pRoom->title, pmsg->title, TITLE_SIZE ) ;



	// Âü¿©ÀÚ ¾ÆÀÌµð ¼¼ÆÃ.
	pRoom->dwUser[ 0 ] = pUserInfo->dwPlayerID ;



	// °ü¸® ¸®½ºÆ®¿¡ ¹æ Ãß°¡.
	AddRoom( pRoom ) ;



	// À¯ÀúÀÇ Ã¤ÆÃ¹æ ¹øÈ£ ¼¼ÆÃ.
	pUserInfo->byIdx = pRoom->byIdx ;



	// °Ë»ö¿ë ÀÌ¸§ µî·Ï.
	InsertUserName( pUserInfo->name ) ;



	// °Ë»ö¿ë Âü¿© Á¤º¸ ¼¼ÆÃ.
	UpdateNameRoomIdx( pUserInfo->name, pRoom->byIdx ) ;



	// °á°ú Àü¼Û.
	MSG_CR_ROOMINFO msg ;
	memset( &msg, 0, sizeof(MSG_CR_ROOMINFO) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_CREATE_ROOM_ACK ;
	msg.dwObjectID	= pmsg->dwObjectID ;

	msg.room		= *pRoom ;
	msg.user[ 0 ]	= *pUserInfo ;
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_ROOMINFO) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_ROOMINFO) ) ;
#endif


	// ´Ù¸¥ À¯Àúµé¿¡°Ô ¹æÀÌ º¯°æµÇ¾úÀ½À» °øÁöÇÑ´Ù.
	UpdateInfo_Created_Room( pRoom ) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : Join_Room_Syn
//		 : 
//	DESC : Ã¤ÆÃ¹æ Âü¿© ¿äÃ»ÀÌ µé¾î¿ÔÀ» ¶§ Ã³¸®ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. µî·Ï µÈ À¯ÀúÀÎÁö Ã¼Å©.
//		 : 2. Ã¤ÆÃÁßÀÎÁö Ã¼Å©.
//		 : 3. Ã¤ÆÃ¹æ ¹Þ±â.
//		 : 4. ºñ¹Ð ¹øÈ£ Ã¼Å©.
//		 : 5. Ã¤ÆÃ¹æÀÇ ¼ö¿ë ÀÎ¿ø Ã¼Å©.
//		 : 6. ÇöÀç Âü¿©ÀÚ ¼ö Ã¼Å©.
//		 : 7. Ã¤ÆÃ¹æÀÇ Âü¿©ÀÚ ¼ö Áõ°¡.
//		 : 8. À¯ÀúÀÇ Ã¤ÆÃ¹æ ÀÎµ¦½º ¼¼ÆÃ.
//		 : 9. Âü¿© ¼º°ø ¸Þ½ÃÁö Ã³¸®.
//		 :10. Âü¿© °øÁö ¸Þ½ÃÁö Ã³¸®.
//		 : 
//  DATE : APRIL 4, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Join_Room_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength ) 
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ
    // 0 = err_Already_Chatting,
	// 1 = err_Invalid_Room_Info,
	// 2 = err_Invalid_Secret_Code,
	// 3 = err_Guest_Count_Is_Over,
	// 4 = err_Invalid_User_Info,



	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_JOIN_SYN* pmsg = NULL ;
	pmsg = (MSG_CR_JOIN_SYN*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// µî·Ï µÈ À¯ÀúÀÎÁö Ã¼Å©.
	ST_CR_USER* pUserInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( !pUserInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_JOIN_ROOM_NACK, 4 ) ;
		return ;
	}



	// Ã¤ÆÃÁßÀÎÁö Ã¼Å©.
	if( pUserInfo->byIdx != 0 )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_JOIN_ROOM_NACK, 0 ) ;
		return ;
	}



	// Ã¤ÆÃ¹æ ¹Þ±â.
	if( pmsg->byRoomIdx == 0 )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_JOIN_ROOM_NACK, 1 ) ;
		return ;
	}

	ST_CR_ROOM_SRV* pRoom = NULL ;
	pRoom = GetRoomInfo( pmsg->byRoomIdx ) ;
	if( !pRoom )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_JOIN_ROOM_NACK, 1 ) ;
		return ;
	}



	// ºñ¹Ð ¹øÈ£ Ã¼Å©.
	if( pRoom->bySecretMode == e_RM_Close )
	{
		if( strcmp( pRoom->code, pmsg->code) != 0 )
		{
			SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_JOIN_ROOM_NACK, 2 ) ;
			return ;
		}
	}



	// Ã¤ÆÃ¹æÀÇ ¼ö¿ë ÀÎ¿ø Ã¼Å©.
	BYTE byTotalCount = 0 ;
	switch( pRoom->byTotalGuestCount )
	{
	case e_GC_20 :	byTotalCount = 20 ; break ;
	case e_GC_15 :	byTotalCount = 15 ; break ;
	case e_GC_10 :	byTotalCount = 10 ; break ;
	case e_GC_5 :	byTotalCount =  5 ; break ;
	default :							break ;
	}



	// ÇöÀç Âü¿©ÀÚ ¼ö Ã¼Å©.
	if( pRoom->byCurGuestCount >= byTotalCount )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_JOIN_ROOM_NACK, 3 ) ;
		return ;
	}



	// Âü¿©ÀÚ ÀÎµ¦½º ¼¼ÆÃ.
	pRoom->dwUser[ pRoom->byCurGuestCount ] = pUserInfo->dwPlayerID ;



	// Ã¤ÆÃ¹æÀÇ Âü¿©ÀÚ ¼ö Áõ°¡.
	++pRoom->byCurGuestCount ;



	// À¯ÀúÀÇ Ã¤ÆÃ¹æ ÀÎµ¦½º ¼¼ÆÃ.
	pUserInfo->byIdx = pRoom->byIdx ;



	// °Ë»ö¿ë ÀÌ¸§ µî·Ï.
	InsertUserName( pUserInfo->name ) ;



	// À¯Àú°¡ Âü¿©ÇÏ´Â ¹æ ÀÎµ¦½º ¾÷µ¥ÀÌÆ®.
	UpdateNameRoomIdx( pUserInfo->name, pRoom->byIdx ) ;



	// Âü¿© ¼º°ø ¸Þ½ÃÁö Ã³¸®.
	MSG_CR_ROOMINFO msg ;
	memset( &msg, 0, sizeof(MSG_CR_ROOMINFO) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_JOIN_ROOM_ACK ;
	msg.dwObjectID	= pmsg->dwObjectID ;

	msg.room		= *pRoom ;



	// Âü¿©ÀÚ Á¤º¸ ´ã±â.
	ST_CR_USER* pMemberInfo = NULL ;
	for( BYTE count = 0 ; count < MAX_USER_PER_ROOM ; ++count )
	{
		pMemberInfo = m_htUser.GetData( pRoom->dwUser[ count ] ) ;
		if( !pMemberInfo ) continue ;

		msg.user[ msg.byCount ] = *pMemberInfo ;

		++msg.byCount ;
	}



	// °á°ú Àü¼Û.
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_ROOMINFO) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_ROOMINFO) ) ;
#endif


	// Âü¿© °øÁö ¸Þ½ÃÁö Ã³¸®.
	MSG_CR_JOIN_NOTICE msg2 ;
	memset( &msg2, 0, sizeof(MSG_CR_JOIN_NOTICE) ) ;

	msg2.Category	= MP_CHATROOM ;
	msg2.Protocol	= MP_CHATROOM_JOIN_ROOM_NOTICE ;
	msg2.dwObjectID	= pmsg->dwObjectID ;

	msg2.user		= *pUserInfo ;



	// Âü¿©ÀÚ ÀÎµ¦½º ´ã±â.
	for( BYTE count = 0 ; count < pRoom->byCurGuestCount ; ++count )
	{
		pMemberInfo = m_htUser.GetData( pRoom->dwUser[ count ] ) ;
		if( !pMemberInfo ) continue ;

		if( pMemberInfo->dwPlayerID == pUserInfo->dwPlayerID ) continue ;

		msg2.dwUser[ msg2.byCount ] = pMemberInfo->dwPlayerID ;

		++msg2.byCount ;
	}

	// °á°ú Àü¼Û.
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg2, sizeof(MSG_CR_JOIN_NOTICE) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg2, sizeof(MSG_CR_JOIN_NOTICE) ) ;
#endif
	// ´Ù¸¥ À¯Àúµé¿¡°Ô ¹æÀÌ º¯°æµÇ¾úÀ½À» °øÁöÇÑ´Ù.
	UpdateInfo_Changed_Current_GuestCount( pRoom ) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : Out_Room_Syn
//		 : 
//	DESC : À¯Àú°¡ Ã¤ÆÃ¹æÀ» ³ª°¡´Â Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. µî·Ï µÈ À¯ÀúÀÎÁö Ã¼Å©.
//		 : 2. ¹æÁ¤º¸ ¹Þ±â.
//		 : 3. ¹æ¿¡ ³²¾ÆÀÖ´Â À¯Àú ¼ö Ã¼Å©.
//		 :	  3-1. ¹æ »èÁ¦.
//		 :	  3-2. À¯ÀúÀÇ ¹æ ÀÎµ¦½º »èÁ¦.
//		 :	  3-3. °á°ú Àü¼Û.
//		 : 4. ¸¶Áö¸·ÀÌ ¾Æ´Ï¸é,
//		 :    4-1. Ã¤ÆÃ¹æÀÇ Âü¿©ÁßÀÎ À¯Àú¼ö¸¦ °¨¼Ò½ÃÅ²´Ù.
//		 :	  4-2. ³ª°¡´Â À¯ÀúÀÇ ¹æ ÀÎµ¦½º¸¦ ÃÊ±âÈ­.
//		 :	  4-3. ³ª°¡±â ¼º°ø ¸Þ½ÃÁö Ã³¸®.
//		 :    4-4. °á°ú¸¦ °øÁöÇÑ´Ù.
//		 :	  4-5. ¹æÀåÀÌ ³ª°¬´Ù¸é, ¹æÀå ¹Ù²ñ °øÁö.
//		 : 
//  DATE : APRIL 4, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Out_Room_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength ) 
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ.
	// 0 = err_CanNot_Found_Room,
	// 1 = err_CanNot_Found_Outer,



	// ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_DWORD* pmsg = NULL ;
	pmsg = (MSG_DWORD*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// À¯Àú Á¤º¸ ¹Þ±â.
	ST_CR_USER* pUserInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( !pUserInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_OUT_ROOM_NACK, 1 ) ;
		return ;
	}



	// ¹æÁ¤º¸ ¹Þ±â.
	if( pUserInfo->byIdx == 0 )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_OUT_ROOM_NACK, 0 ) ;
		return ;
	}

	ST_CR_ROOM_SRV* pRoom = NULL ;
	pRoom = GetRoomInfo( pUserInfo->byIdx ) ;
	if( !pRoom )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_OUT_ROOM_NACK, 0 ) ;
		return ;
	}



	// À¯ÀúÀÇ ¹æ ÀÎµ¦½º »èÁ¦.
	pUserInfo->byIdx = 0 ;



	// °Ë»ö¿ë À¯Àú ÀÌ¸§ »èÁ¦.
	EraseUserName( pUserInfo->name ) ;



	// ¹æ¿¡ ³²¾ÆÀÖ´Â À¯Àú ¼ö Ã¼Å©.
	if( pRoom->byCurGuestCount == 1 )
	{
		// ´Ù¸¥ À¯Àúµé¿¡°Ô ¹æÀÌ »èÁ¦µÇ¾úÀ½À» °øÁöÇÑ´Ù.
		UpdateInfo_Deleted_Room( pRoom ) ;

		// ¹æ »èÁ¦.
		DeleteRoom( pRoom->byIdx ) ;

		// ¹æÀÌ ºñ¾ú´Ù°í, ±×³É ¿¡·¯ ¸Þ½ÃÁö º¸³»Áö ¾Ê°í, Å¬¶óÀÌ¾ðÆ®ÀÇ Ã¤ÆÃ¹æ ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿ìµµ·Ï ÇÏÀÚ.
		if( m_pRoomList.GetCount() == 0 )
		{
			MSGBASE msg ;
			memset(&msg, 0, sizeof(MSGBASE)) ;

			msg.Category	= MP_CHATROOM ;
			msg.Protocol	= MP_CHATROOM_OUT_ROOM_EMPTYROOM ;
			msg.dwObjectID	= pmsg->dwObjectID ;
#ifdef _MYLUNA_
			g_Network.Send2Server( 1, (char*)&msg, sizeof(MSGBASE) ) ;
#else
			g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSGBASE) ) ;
#endif
			return ;
		}
		else
		{
			// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
			MSG_CR_ROOMLIST msg ;
			memset( &msg, 0, sizeof(MSG_CR_ROOMLIST) ) ;

			msg.Category	= MP_CHATROOM ;
			msg.Protocol	= MP_CHATROOM_OUT_ROOM_LAST_MAN ;
			msg.dwObjectID	= pmsg->dwObjectID ;

			// ¸®½ºÆ® Çì´õ ¼¼ÆÃ.
			ST_CR_ROOM_SRV* pInfo ;
			PTRLISTPOS pos = NULL ;

			pos = m_pRoomList.GetHeadPosition() ;

			// ¹æÁ¤º¸¸¦ ´ãÀ» ¹üÀ§ ÀÎµ¦½º ¼¼ÆÃ.
			BYTE byStartIdx = 0 ;
			byStartIdx = byStartIdx * ROOM_COUNT_PER_PAGE ;

			BYTE byIndex = 0 ;

			// ¸®½ºÆ® °Ë»ö.
			while( pos )
			{
				// ¹æÁ¤º¸ ¹Þ±â.
				pInfo = NULL ;
				pInfo = (ST_CR_ROOM_SRV*)m_pRoomList.GetNext( pos ) ;

				if( !pInfo ) continue ;

				// ÀÎµ¦½º À¯È¿ Ã¼Å©.
				if( byIndex < byStartIdx ) continue ;

				// Àü¼Û ÇÒ °³¼ö Ã¼Å©.
				if( msg.byCount >= ROOM_COUNT_PER_PAGE ) break ;

				// ¹æ Á¤º¸ ´ã±â.
				msg.room[ msg.byCount ].byIdx				= pInfo->byIdx ;
				msg.room[ msg.byCount ].bySecretMode		= pInfo->bySecretMode ;
				msg.room[ msg.byCount ].byRoomType			= pInfo->byRoomType ;
				msg.room[ msg.byCount ].byCurGuestCount		= pInfo->byCurGuestCount ;
				msg.room[ msg.byCount ].byTotalGuestCount	= pInfo->byTotalGuestCount ;

				SafeStrCpy( msg.room[ msg.byCount ].title, pInfo->title, TITLE_SIZE ) ;

				++msg.byCount ;
			}

			// ÆäÀÌÁö ¼¼ÆÃ.
			msg.byCurPage	= 0 ;
			msg.byTotalPage	= (BYTE)(m_pRoomList.GetCount() / ROOM_COUNT_PER_PAGE) ;

			// ´ãÀº Ã¤ÆÃ¹æ ºÐ·ù ¼¼ÆÃ.
			msg.byRoomType	= e_RTM_AllLooK ;

			// °á°ú Àü¼Û.
#ifdef _MYLUNA_
			g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_ROOMLIST) ) ;
#else
			g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_ROOMLIST) ) ;
#endif
		}
	}
	else
	{
		// ¹æÀåÀÌ ÈÄÀÓ ¹æÀå À§ÀÓ¾øÀÌ Æ¨±â°Å³ª, Ã¤ÆÃÀ» Á¾·áÇß´ÂÁö Ã¼Å©.
		BYTE byChangedOwner = FALSE ;
		if( pRoom->dwOwnerIdx == pUserInfo->dwPlayerID ) byChangedOwner = TRUE ;

		// À¯Àú ÀÎµ¦½º¸¦ ÀÓ½Ã º¸°üÇÑ´Ù.
		BYTE byCheckCount = 0 ;
		DWORD dwPlayerID[ MAX_USER_PER_ROOM ] = {0, } ;
		for( BYTE count = 0 ; count < pRoom->byCurGuestCount ; ++count )
		{
			if( pRoom->dwUser[ count ] == pUserInfo->dwPlayerID ) continue ;

			dwPlayerID[ byCheckCount ] = pRoom->dwUser[ count ] ;
			++byCheckCount ;
		}

		// Ã¤ÆÃ¹æÀÇ Âü¿©ÀÚ ¼ö °¨¼Ò.
		--pRoom->byCurGuestCount ;

		// À¯Àú ÀÎµ¦½º º¹¿ø
		for( BYTE count = 0 ; count  < pRoom->byCurGuestCount ; ++count )
		{
			pRoom->dwUser[ count ] = dwPlayerID[ count ] ;
		}

		// ÈÄÀÓ ¹æÀå °áÁ¤.
		if( byChangedOwner )
		{
			pRoom->dwOwnerIdx = dwPlayerID[ 0 ] ;
		}

		// ´Ù¸¥ À¯Àúµé¿¡°Ô ¹æÀÌ º¯°æµÇ¾úÀ½À» °øÁöÇÑ´Ù.
		UpdateInfo_Changed_Current_GuestCount( pRoom ) ;


		// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
		MSG_CR_ROOMLIST msg ;
		memset( &msg, 0, sizeof(MSG_CR_ROOMLIST) ) ;

		msg.Category	= MP_CHATROOM ;
		msg.Protocol	= MP_CHATROOM_OUT_ROOM_ACK ;
		msg.dwObjectID	= pmsg->dwObjectID ;

		// ¸®½ºÆ® Çì´õ ¼¼ÆÃ.
		ST_CR_ROOM_SRV* pInfo ;
		PTRLISTPOS pos = NULL ;

		pos = m_pRoomList.GetHeadPosition() ;

		// ¹æÁ¤º¸¸¦ ´ãÀ» ¹üÀ§ ÀÎµ¦½º ¼¼ÆÃ.
		BYTE byStartIdx = 0 ;
		byStartIdx = byStartIdx * ROOM_COUNT_PER_PAGE ;

		BYTE byIndex = 0 ;

		// ¸®½ºÆ® °Ë»ö.
		while( pos )
		{
			// ¹æÁ¤º¸ ¹Þ±â.
			pInfo = NULL ;
			pInfo = (ST_CR_ROOM_SRV*)m_pRoomList.GetNext( pos ) ;

			if( !pInfo ) continue ;

			// ÀÎµ¦½º À¯È¿ Ã¼Å©.
			if( byIndex < byStartIdx ) continue ;

			// Àü¼Û ÇÒ °³¼ö Ã¼Å©.
			if( msg.byCount >= ROOM_COUNT_PER_PAGE ) break ;

			// ¹æ Á¤º¸ ´ã±â.
			msg.room[ msg.byCount ].byIdx				= pInfo->byIdx ;
			msg.room[ msg.byCount ].bySecretMode		= pInfo->bySecretMode ;
			msg.room[ msg.byCount ].byRoomType			= pInfo->byRoomType ;
			msg.room[ msg.byCount ].byCurGuestCount		= pInfo->byCurGuestCount ;
			msg.room[ msg.byCount ].byTotalGuestCount	= pInfo->byTotalGuestCount ;

			SafeStrCpy( msg.room[ msg.byCount ].title, pInfo->title, TITLE_SIZE ) ;

			++msg.byCount ;
		}

		// ÆäÀÌÁö ¼¼ÆÃ.
		msg.byCurPage	= 0 ;
		msg.byTotalPage	= (BYTE)(m_pRoomList.GetCount() / ROOM_COUNT_PER_PAGE) ;

		// ´ãÀº Ã¤ÆÃ¹æ ºÐ·ù ¼¼ÆÃ.
		msg.byRoomType	= e_RTM_AllLooK ;

		// °á°ú Àü¼Û.
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_ROOMLIST) ) ;
#else
		g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_ROOMLIST) ) ;
#endif
		// Âü¿©ÀÚ ³ª°¨ °øÁö Ã³¸®.
		MSG_CR_IDNAME msg2 ;
		memset( &msg2, 0, sizeof(MSG_CR_IDNAME) ) ;

		msg2.Category	= MP_CHATROOM ;
		msg2.Protocol	= MP_CHATROOM_OUT_ROOM_NOTICE ;
		msg2.dwObjectID	= pmsg->dwObjectID ;

		msg2.dwID		= pUserInfo->dwPlayerID ;

		SafeStrCpy( msg2.name, pUserInfo->name, MAX_NAME_LENGTH + 1 ) ;

		ST_CR_USER* pMemberInfo = NULL ;
		for( BYTE count = 0 ; count < pRoom->byCurGuestCount ; ++count )
		{
			pMemberInfo = m_htUser.GetData( pRoom->dwUser[ count ] ) ;
			if( !pMemberInfo ) continue ;

			msg2.dwUser[ msg2.byCount ] = pMemberInfo->dwPlayerID ;

			++msg2.byCount ;
		}
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg2, sizeof(MSG_CR_IDNAME) ) ;
#else
		g_Network.Send2Server( dwIndex, (char*)&msg2, sizeof(MSG_CR_IDNAME) ) ;
#endif
		// ¹æÀå ¹Ù²ñ °øÁö Ã³¸®.
		if( !byChangedOwner ) return ;

		MSG_CR_IDNAME msg3 ;
		memset( &msg3, 0, sizeof(MSG_CR_IDNAME) ) ;

		msg3.Category	= MP_CHATROOM ;
		msg3.Protocol	= MP_CHATROOM_OUT_ROOM_CHANGE_OWNER_NOTICE ;
		msg3.dwObjectID	= pmsg->dwObjectID ;

		pMemberInfo = NULL ;
		for( BYTE count = 0 ; count < pRoom->byCurGuestCount ; ++count )
		{
			pMemberInfo = m_htUser.GetData( pRoom->dwUser[ count ] ) ;
			if( !pMemberInfo ) continue ;

			if( pMemberInfo->dwPlayerID == pRoom->dwOwnerIdx )
			{
				msg3.dwID = pMemberInfo->dwPlayerID ;
				SafeStrCpy( msg3.name, pMemberInfo->name, MAX_NAME_LENGTH + 1 ) ;
			}

			msg3.dwUser[ msg3.byCount ] = pMemberInfo->dwPlayerID ;

			++msg3.byCount ;
		}
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg3, sizeof(MSG_CR_IDNAME) ) ;
#else
		g_Network.Send2Server( dwIndex, (char*)&msg3, sizeof(MSG_CR_IDNAME) ) ;
#endif
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : Option_Syn
//		 : 
//	DESC : The function to change option of selected room.
//		 : 
//		 : 1. µî·Ï µÈ À¯ÀúÀÎÁö Ã¼Å©.
//		 : 2. ¹æ Á¤º¸ ¹Þ±â.
//		 : 3. ¹æÀåÀÎÁö °Ë»ç.
//		 : 4. ¹æ ¿É¼Ç º¯°æ.
//		 : 5. °á°ú °øÁö.
//		 : 
//  DATE : APRIL 4, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Option_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength ) 
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ.
	// 0 = err_You_Are_Not_In_ChatRoom,
	// 1 = err_CanNot_Found_Room,
	// 2 = err_You_Are_Not_Owner,



	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_ELEMENT* pmsg = NULL ;
	pmsg = (MSG_CR_ELEMENT*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// µî·Ï µÈ À¯ÀúÀÎÁö Ã¼Å©.
	ST_CR_USER* pUserInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( !pUserInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CHANGE_OPTION_NACK, 0 ) ;
		return ;
	}



	// ¹æÁ¤º¸ ¹Þ±â.
	ST_CR_ROOM_SRV* pRoom = NULL ;
	pRoom = GetRoomInfo( pUserInfo->byIdx ) ;
	if( !pRoom )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CHANGE_OPTION_NACK, 1 ) ;
		return ;
	}



    // ¹æÀåÀÎÁö °Ë»ç.
	if( pUserInfo->dwPlayerID != pRoom->dwOwnerIdx )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CHANGE_OPTION_NACK, 2 ) ;
		return ;
	}


	
	// Ã¤ÆÃ¹æ º¯°æ ³»¿ë °øÁö Ã³¸®.
	// ´Ù¸¥ À¯Àúµé¿¡°Ô ¹æÀÌ º¯°æµÇ¾úÀ½À» °øÁöÇÑ´Ù.
	BYTE byChangedSecretMode = FALSE ;
	if( pRoom->bySecretMode != pmsg->bySecretMode )
	{
		byChangedSecretMode = TRUE ;
	}

	BYTE byChangedRoomType = FALSE ;
	if( pRoom->byRoomType != pmsg->byRoomType )
	{
		byChangedRoomType = TRUE ;
	}

	BYTE byChangedGuestCount = FALSE ;
	if( pRoom->byTotalGuestCount != pmsg->byTotalGuestCount )
	{
		byChangedGuestCount = TRUE ;
	}

	BYTE byChangedTitle = FALSE ;
	if( strcmp( pRoom->title, pmsg->title ) != 0 )
	{
		byChangedTitle = TRUE ;
	}



	// ¹æ ¿É¼Ç º¯°æ.
	pRoom->bySecretMode			= pmsg->bySecretMode ;
	pRoom->byRoomType			= pmsg->byRoomType ;
	pRoom->byTotalGuestCount	= pmsg->byTotalGuestCount ;

	SafeStrCpy( pRoom->code, pmsg->code, SECRET_CODE_SIZE ) ;

	SafeStrCpy( pRoom->title, pmsg->title, TITLE_SIZE ) ;



	// °Ë»ö¿ë ¹æ Á¤º¸ ¾÷µ¥ÀÌÆ®.
	UpdateSearchRoomInfo( pRoom ) ;



	// °á°ú °øÁö.
	MSG_CR_ROOM_NOTICE msg ;
	memset( &msg, 0, sizeof(MSG_CR_ROOM_NOTICE) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_CHANGE_OPTION_NOTICE ;
	msg.dwObjectID	= pmsg->dwObjectID ;

	msg.room		= *pRoom ;

	ST_CR_USER* pMemberInfo = NULL ;
	for( BYTE count = 0 ; count < pRoom->byCurGuestCount ; ++count )
	{
		pMemberInfo = m_htUser.GetData( pRoom->dwUser[ count ] ) ;
		if( !pMemberInfo ) continue ;

		msg.dwUser[ msg.byCount ] = pMemberInfo->dwPlayerID ;

		++msg.byCount ;
	}
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_ROOM_NOTICE) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_ROOM_NOTICE) ) ;
#endif
	// º¯°æ µÈ Á¤º¸¸¦ °øÁö Ã³¸®.
	if( byChangedSecretMode )
	{
		UpdateInfo_Changed_SecretMode( pRoom ) ;
	}
	
	if( byChangedRoomType )
	{
		UpdateInfo_Changed_RoomType( pRoom ) ;
	}
	
	if( byChangedGuestCount )
	{
		UpdateInfo_Changed_Total_GuestCount( pRoom ) ;
	}
	
	if( byChangedTitle )
	{
		UpdateInfo_Changed_Title( pRoom ) ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : Owner_Syn
//		 : 
//	DESC : The function to change owner of chatroom.
//		 : 
//		 : 1. ÇöÀç ¹æÀå ¹Þ±â.
//		 : 2. ÈÄÀÓ ¹æÀå ¹Þ±â.
//		 : 3. ¹æÁ¤º¸ ¹Þ±â.
//		 : 4. ÇöÀç ¹æÀåÀÌ ¹æÀåÀÎÁö Ã¼Å©.
//		 : 5. ÇöÀç Âü¿©ÁßÀÎ À¯Àú ¼ö Ã¼Å©.
//		 : 6. Ã¤ÆÃ¹æÀÇ ¹æÀåÀÎµ¦½º º¯°æ.
//		 : 7. °á°ú °øÁö.
//		 : 
//  DATE : APRIL 4, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Owner_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength )
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ.
	// 0 = err_Invalid_Current_Owner,
	// 1 = err_Invalid_Next_Owner,
	// 2 = err_CanNot_Found_RoomInfo,
	// 3 = err_You_Are_Not_Owner,
	// 4 = err_You_Alone,



	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_DWORD* pmsg = NULL ;
	pmsg = (MSG_DWORD*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// ÇöÀç ¹æÀå ¹Þ±â.
	ST_CR_USER* pOwnerInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( !pOwnerInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CHANGE_OWNER_NACK, 0 ) ;
		return ;
	}



	// ÈÄÀÓ ¹æÀå ¹Þ±â.
	ST_CR_USER* pNewOwnerInfo = m_htUser.GetData( pmsg->dwData ) ;
	if( !pNewOwnerInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CHANGE_OWNER_NACK, 1 ) ;
		return ;
	}



	// ¹æÁ¤º¸ ¹Þ±â.
	ST_CR_ROOM_SRV* pRoom = NULL ;
	pRoom = GetRoomInfo( pOwnerInfo->byIdx ) ;
	if( !pRoom )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CHANGE_OWNER_NACK, 2 ) ;
		return ;
	}



	// ÇöÀç ¹æÀåÀÌ ¹æÀåÀÎÁö Ã¼Å©.
	if( pRoom->dwOwnerIdx != pOwnerInfo->dwPlayerID )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CHANGE_OWNER_NACK, 3 ) ;
		return ;
	}



	// ÇöÀç Âü¿©ÁßÀÎ À¯Àú ¼ö Ã¼Å©.
	if( pRoom->byCurGuestCount <= 1 )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_CHANGE_OWNER_NACK, 4 ) ;
		return ;
	}



	// Ã¤ÆÃ¹æÀÇ ¹æÀå ¾ÆÀÌµð º¯°æ.
	pRoom->dwOwnerIdx = pNewOwnerInfo->dwPlayerID ;



	// °á°ú °øÁö.
	MSG_CR_IDNAME msg ;
	memset( &msg, 0, sizeof(MSG_CR_IDNAME) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_CHANGE_OWNER_NOTICE ;
	msg.dwObjectID	= pmsg->dwObjectID ;

	msg.dwID		= pNewOwnerInfo->dwPlayerID ;

	SafeStrCpy( msg.name, pNewOwnerInfo->name, MAX_NAME_LENGTH + 1 ) ;

	ST_CR_USER* pMemberInfo = NULL ;
	for( BYTE count = 0 ; count < pRoom->byCurGuestCount ; ++count )
	{
		pMemberInfo = m_htUser.GetData( pRoom->dwUser[count] ) ;
		if( !pMemberInfo ) continue ;

		msg.dwUser[ msg.byCount ] = pMemberInfo->dwPlayerID ;

		++msg.byCount ;
	}
	// °á°ú Àü¼Û.
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_IDNAME) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_IDNAME) ) ;
#endif
}





//-------------------------------------------------------------------------------------------------
//	NAME : Kick_Syn
//		 : 
//	DESC : The function to kick selected user from chatroom.
//		 : 
//		 : 1. ¹æÀå ¹Þ±â.
//		 : 2. ¹æÁ¤º¸ ¹Þ±â.
//		 : 3. ¹æÀåÀÎÁö Ã¼Å©.
//		 : 4. °­Á¦ ÅðÀå ´ë»ó ¹Þ±â.
//		 : 5. ´ë»óÀÇ ¹æ ÀÎµ¦½º ÃÊ±âÈ­.
//		 : 6. Ã¤ÆÃ¹æÀÇ Á¢¼Ó À¯Àú¼ö °¨¼Ò.
//		 : 7. °­Åð Ã³¸®.
//		 : 8. °­Åð °øÁö Ã³¸®.
//		 : 
//  DATE : APRIL 4, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Kick_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength )
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ.
	// 0 = err_CanNot_Found_RoomInfo,
	// 1 = err_Invalid_OwnerInfo,
	// 2 = err_You_Are_Not_Owner,
	// 3 = err_Invalid_Target,



	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_DWORD* pmsg = NULL ;
	pmsg = (MSG_DWORD*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// ¹æÀå ¹Þ±â.
	ST_CR_USER* pOwnerInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( !pOwnerInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_KICK_GUEST_NACK, 1 ) ;
		return ;
	}



	// ¹æÁ¤º¸ ¹Þ±â.
	ST_CR_ROOM_SRV* pRoom = NULL ;
	pRoom = GetRoomInfo( pOwnerInfo->byIdx ) ;
	if( !pRoom )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_KICK_GUEST_NACK, 0 ) ;
		return ;
	}



	// ¹æÀåÀÎÁö Ã¼Å©.
	if( pOwnerInfo->dwPlayerID != pRoom->dwOwnerIdx )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_KICK_GUEST_NACK, 2 ) ;
		return ;
	}



	// °­Á¦ ÅðÀå ´ë»ó ¹Þ±â.
	ST_CR_USER* pPurgeeInfo = m_htUser.GetData( pmsg->dwData ) ;
	if( !pPurgeeInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_KICK_GUEST_NACK, 3 ) ;
		return ;
	}



	// ´ë»óÀÇ ¹æÀÎµ¦½º ÃÊ±âÈ­.
	pPurgeeInfo->byIdx = 0 ;



	// °Ë»ö¿ë À¯Àú ÀÌ¸§ »èÁ¦.
	EraseUserName( pPurgeeInfo->name ) ;



	// À¯Àú ÀÎµ¦½º¸¦ ÀÓ½Ã º¸°üÇÑ´Ù.
	BYTE byCheckCount = 0 ;
	DWORD dwPlayerID[ MAX_USER_PER_ROOM ] = {0, } ;
	for( BYTE count = 0 ; count < pRoom->byCurGuestCount ; ++count )
	{
		if( pRoom->dwUser[ count ] == pPurgeeInfo->dwPlayerID ) continue ;

		dwPlayerID[ byCheckCount ] = pRoom->dwUser[ count ] ;
		++byCheckCount ;
	}



	// Ã¤ÆÃ¹æÀÇ Âü¿©ÀÚ ¼ö °¨¼Ò.
	--pRoom->byCurGuestCount ;



	// À¯Àú ÀÎµ¦½º º¹¿ø
	for( BYTE count = 0 ; count  < pRoom->byCurGuestCount ; ++count )
	{
		pRoom->dwUser[ count ] = dwPlayerID[ count ] ;
	}



	// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_CR_KICK_ACK msg ;
	memset( &msg, 0, sizeof(MSG_CR_KICK_ACK) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_KICK_GUEST_ACK ;
	msg.dwObjectID	= pmsg->dwObjectID ;

	msg.dwKickPlayer = pmsg->dwData ;



	// ¹æÁ¤º¸¸¦ ´ãÀ» ¹üÀ§ ÀÎµ¦½º ¼¼ÆÃ.
	BYTE byIndex = 0 ;
	BYTE byStartIdx = 0 ;
	byStartIdx = byStartIdx * ROOM_COUNT_PER_PAGE ;



	// ¸®½ºÆ® Çì´õ ¼¼ÆÃ.
	ST_CR_ROOM_SRV* pInfo ;
	PTRLISTPOS pos = NULL ;
	pos = m_pRoomList.GetHeadPosition() ;

	while( pos )
	{
		// ¹æÁ¤º¸ ¹Þ±â.
		pInfo = NULL ;
		pInfo = (ST_CR_ROOM_SRV*)m_pRoomList.GetNext( pos ) ;

		if( !pInfo ) continue ;

		// ÀÎµ¦½º À¯È¿ Ã¼Å©.
		if( byIndex < byStartIdx ) continue ;

		// Àü¼Û ÇÒ °³¼ö Ã¼Å©.
		if( msg.byCount >= ROOM_COUNT_PER_PAGE ) break ;

		// ¹æ Á¤º¸ ´ã±â.
		msg.room[ msg.byCount ].byIdx				= pInfo->byIdx ;
		msg.room[ msg.byCount ].bySecretMode		= pInfo->bySecretMode ;
		msg.room[ msg.byCount ].byRoomType			= pInfo->byRoomType ;
		msg.room[ msg.byCount ].byCurGuestCount		= pInfo->byCurGuestCount ;
		msg.room[ msg.byCount ].byTotalGuestCount	= pInfo->byTotalGuestCount ;

		SafeStrCpy( msg.room[ msg.byCount ].title, pInfo->title, TITLE_SIZE ) ;

		++msg.byCount ;
	}



	// ÆäÀÌÁö ¼¼ÆÃ.
	msg.byCurPage	= 0 ;
	msg.byTotalPage	= (BYTE)(m_pRoomList.GetCount() / ROOM_COUNT_PER_PAGE) ;



	// ´ãÀº Ã¤ÆÃ¹æ ºÐ·ù ¼¼ÆÃ.
	msg.byRoomType	= e_RTM_AllLooK ;
	// °á°ú Àü¼Û.
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_KICK_ACK) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_KICK_ACK) ) ;
#endif
	// °­Åð °øÁö Ã³¸®.
	MSG_CR_IDNAME msg2 ;
	memset( &msg2, 0, sizeof(MSG_CR_IDNAME) ) ;

	msg2.Category	= MP_CHATROOM ;
	msg2.Protocol	= MP_CHATROOM_KICK_GUEST_NOTICE ;
	msg2.dwObjectID	= pmsg->dwObjectID ;



	// °­Åð ´ë»óÀÚ Á¤º¸ ¼¼ÆÃ.
	msg2.dwID		= pPurgeeInfo->dwPlayerID ;
	SafeStrCpy( msg2.name, pPurgeeInfo->name, MAX_NAME_LENGTH + 1 ) ;



	// °øÁö ´ë»óÀÚ ´ã±â.
	ST_CR_USER* pMemberInfo = NULL ;
	for( BYTE count = 0 ; count < MAX_USER_PER_ROOM ; ++count )				
	{
		pMemberInfo = m_htUser.GetData( pRoom->dwUser[ count ] ) ;
		if( !pMemberInfo ) continue ;

		// °øÁö ´ë»ó¿¡¼­ °­ÅðÀÚ´Â »«´Ù.
		if( pMemberInfo->dwPlayerID == pmsg->dwData ) continue ;	

		msg2.dwUser[ msg2.byCount ] = pMemberInfo->dwPlayerID ;

		++msg2.byCount ;
	}
	// °á°ú Àü¼Û.
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg2, sizeof(MSG_CR_IDNAME) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg2, sizeof(MSG_CR_IDNAME) ) ;
#endif
	// ´Ù¸¥ À¯Àúµé¿¡°Ô ¹æÀÌ º¯°æµÇ¾úÀ½À» °øÁöÇÑ´Ù.
	UpdateInfo_Changed_Current_GuestCount( pRoom ) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : Friend_Syn
//		 : 
//	DESC : The function to check user info for add friend.
//		 : 
//		 : 1. ¿äÃ»ÀÚ ¹Þ±â.
//		 : 2. ´ë»ó ¹Þ±â.
//		 : 3. °°Àº Ã¤ÆÃ¹æÀÎÁö Ã¼Å©.
//		 : 4. °á°ú Àü¼Û.
//		 : 
//  DATE : APRIL 4, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Friend_Syn( DWORD dwIndex, char* pMsg, DWORD dwLength )
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ.
	// 0 = err_Invalid_Requester_Info,
	// 1 = err_Invalid_Target_Info.
	// 2 = err_You_Are_Not_In_SameRoom,



	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_DWORD* pmsg = NULL ;
	pmsg = (MSG_DWORD*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// ¿äÃ»ÀÚ ¹Þ±â.
	ST_CR_USER* pApplicantInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( !pApplicantInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_REQUEST_FRIEND_NACK, 0 ) ;
		return ;
	}



	// ´ë»ó ¹Þ±â.
	ST_CR_USER* pAcceptantInfo = m_htUser.GetData( pmsg->dwData ) ;
	if( !pAcceptantInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_REQUEST_FRIEND_NACK, 1 ) ;
		return ;
	}



	// °°Àº Ã¤ÆÃ¹æÀÎÁö Ã¼Å©.
	if( pApplicantInfo->byIdx != pAcceptantInfo->byIdx )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_REQUEST_FRIEND_NACK, 2 ) ;
		return ;
	}



	// °á°ú ¸Þ½ÃÁö Àü¼Û.
	MSG_NAME msg ;
	memset( &msg, 0, sizeof(MSG_NAME) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_REQUEST_FRIEND_ACK ;
	msg.dwObjectID	= pmsg->dwObjectID ;

	SafeStrCpy( msg.Name, pAcceptantInfo->name, MAX_NAME_LENGTH+1 ) ;
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_NAME) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_NAME) ) ;
#endif
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateUserInfo
//	DESC : À¯ÀúÀÇ Á¤º¸°¡ ¾÷µ¥ÀÌÆ® µÇ¾úÀ» ¶§, Á¤º¸¸¦ ¾÷µ¥ÀÌÆ® ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateUserInfo( DWORD dwIndex, char*pMsg, DWORD dwLength )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_USER* pmsg = NULL ;
	pmsg = (MSG_CR_USER*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// À¯Àú Á¤º¸ ¾÷µ¥ÀÌÆ®.
	ST_CR_USER* pUserInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( pUserInfo )
	{
		// °Ë»ö¿ë ÀÌ¸§ Ã¼Å©.
		if( strcmp( pUserInfo->name, pmsg->user.name ) != 0 )
		{
			EraseUserName( pUserInfo->name ) ;

			pUserInfo->byLevel	= pmsg->user.byLevel ;
			pUserInfo->byMapNum	= pmsg->user.byMapNum ;

			SafeStrCpy( pUserInfo->name, pmsg->user.name, MAX_NAME_LENGTH + 1 ) ;

			InsertUserName( pUserInfo->name ) ;
			UpdateNameRoomIdx( pUserInfo->name, pUserInfo->byIdx ) ;
		}
		else
		{
			pUserInfo->byLevel  = pmsg->user.byLevel ;
			pUserInfo->byMapNum	= pmsg->user.byMapNum ;

			SafeStrCpy( pUserInfo->name, pmsg->user.name, MAX_NAME_LENGTH + 1 ) ;

			UpdateNameRoomIdx( pUserInfo->name, pUserInfo->byIdx ) ;
		}
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : SearchName_Syn
//	DESC : ÀÌ¸§À¸·Î Ã¤ÆÃ¹æ Á¤º¸¸¦ °Ë»öÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 23, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::SearchName_Syn( DWORD dwIndex, char*pMsg, DWORD dwLength ) 
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ.
	// 0 = err_CanNot_Found_User,
	// 1 = err_CanNot_Found_Name,
	// 2 = err_ChatRoom_Destroyed,



	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;

	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_SEARCH_NAME* pmsg = NULL ;
	pmsg = (MSG_CR_SEARCH_NAME*)pMsg ;

	ASSERT( pmsg ) ;

	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}



	// À¯Àú °Ë»ö.
	ST_CR_USER* pUserInfo = m_htUser.GetData( pmsg->dwObjectID ) ;
	if( !pUserInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_SEARCH_FOR_NAME_NACK, 0 ) ;
		return ;
	}



	// ÀÌ¸§ °Ë»ö.
	const char* name = pmsg->name ;
	ST_SEARCH_NAME* pNameInfo = m_htSearchName.GetData( GetHashCode( name ) ) ;
	if( !pNameInfo )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_SEARCH_FOR_NAME_NACK, 1 ) ;
		return ;
	}



	// ¹æ °Ë»ö.
	ST_CR_ROOM_SRV* pRoom = NULL ;
	pRoom = GetRoomInfo( pNameInfo->byRoomIdx ) ;

	if( !pRoom )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_SEARCH_FOR_NAME_NACK, 2 ) ;
		return ;
	}



	// °á°ú Àü¼Û.
	MSG_CR_SEARCH_NAME msg ;
	memset( &msg, 0, sizeof(MSG_CR_SEARCH_NAME) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_SEARCH_FOR_NAME_ACK ;
	msg.dwObjectID	= pmsg->dwObjectID ;

	msg.byRoomIdx	= pRoom->byIdx ;

	SafeStrCpy( msg.name, pmsg->name, MAX_NAME_LENGTH + 1 ) ;
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_SEARCH_NAME) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_SEARCH_NAME) ) ;
#endif
}





//-------------------------------------------------------------------------------------------------
//	NAME : SearchTitle_Syn
//	DESC : Á¦¸ñÀ¸·Î Ã¤ÆÃ¹æ Á¤º¸¸¦ °Ë»öÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 23, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::SearchTitle_Syn( DWORD dwIndex, char*pMsg, DWORD dwLength )
{
	// ¿¡·¯ ¸Þ½ÃÁö Á¤ÀÇ.
	// 0 = err_CanNot_Found_Room,
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pMsg ) ;
	if( !pMsg )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}
	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_SEARCH_TITLE* pmsg = NULL ;
	pmsg = (MSG_CR_SEARCH_TITLE*)pMsg ;
	ASSERT( pmsg ) ;
	if( !pmsg )
	{
		Throw_Error( err_FCMTO, __FUNCTION__ ) ;
		return ;
	}
	// °á°ú ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_CR_ROOMLIST msg ;
	memset( &msg, 0, sizeof(MSG_CR_ROOMLIST) ) ;
	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_SEARCH_FOR_TITLE_ACK ;
	msg.dwObjectID	= pmsg->dwObjectID ;
	// Á¦¸ñÀ¸·Î Ã¤ÆÃ¹æ °Ë»ö.
	ST_CR_ROOM_CLT* pInfo ;
	PTRLISTPOS pos = NULL ;
	pos = m_pTitleList.GetHeadPosition() ;
	BYTE byCount = 0 ;
	while( pos )
	{
		pInfo = NULL ;
		pInfo = (ST_CR_ROOM_CLT*)m_pTitleList.GetNext( pos ) ;
		if( !pInfo ) continue ;
		if( strstr( pInfo->title, pmsg->title ) == NULL ) continue ;
		++byCount ;
		if( msg.byCount >= MAX_USER_PER_ROOM ) continue ;
		msg.room[ msg.byCount ] = *pInfo ;
		++msg.byCount ;
	}
	// °Ë»ö µÈ °³¼ö Ã¼Å©.
	if( msg.byCount == 0 )
	{
		SendErrors( dwIndex, pmsg->dwObjectID, MP_CHATROOM_SEARCH_FOR_TITLE_NACK, 0 ) ;
		return ;
	}
	// °Ë»ö¸ðµå·Î ¼¼ÆÃ.
	msg.byRoomType = e_RTM_Searched ;
	// ÆäÀÌÁö ¼¼ÆÃ.
	msg.byCurPage	= 0 ;
	msg.byTotalPage = byCount / ROOM_COUNT_PER_PAGE ;
	// °á°ú Àü¼Û.
#ifdef _MYLUNA_
	g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_ROOMLIST) ) ;
#else
	g_Network.Send2Server( dwIndex, (char*)&msg, sizeof(MSG_CR_ROOMLIST) ) ;
#endif
}





//-------------------------------------------------------------------------------------------------
//	NAME : GetEmptyRoomIdx
//	DESC : Ã¤ÆÃ¹æÀ» °ü¸®ÇÏ´Â ¸Ê¿¡¼­, ¾Õ¿¡¼­ ºÎÅÍ ºñ¾îÀÖ´Â ¹æ ÀÎµ¦½º¸¦ ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö. 0¹øÀº Á¦¿Ü.
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
BYTE CChatRoomMgr::GetEmptyRoomIdx()
{
	for( BYTE count = 1 ; count < MAX_ROOM_COUNT ; ++count )
	{
		if( m_byRoomIdx[ count ] == 0 ) return count ;
	}

	ASSERT( TRUE ) ;

	Throw_Error( "Cant found empty room index!!", __FUNCTION__ ) ;

	return 0 ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : GetHashCode
//	DESC : ÀÎÀÚ·Î ÁÖ¾îÁø ½ºÆ®¸µÀ» ÇØ½¬¸Ê¿¡ »ç¿ëÇÒ ÄÚµå °ªÀ¸·Î º¯È¯ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 24, 2008 LYW
//-------------------------------------------------------------------------------------------------
DWORD CChatRoomMgr::GetHashCode( const char* pName )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pName ) ;

	if( !pName || strlen( pName ) == 0 )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return 5381 ;
	}

	DWORD dwCount	= 0 ;
	DWORD dwLength	= 0 ;
	DWORD dwCh		= 0 ;
	DWORD dwResult	= 0 ;

	dwLength = strlen( pName ) ;
	dwResult = 5381 ;

	for( dwCount = 0 ; dwCount < dwLength ; dwCount++ )
	{
		dwCh = (DWORD)pName[ dwCount ] ;
		dwResult = ( (dwResult << 5) + dwResult ) + dwCh ; // hash * 33 + ch
	}	  

	return dwResult ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : InsertUserName
//	DESC : °Ë»ö¿ë ÇØ½¬¸Ê¿¡ À¯Àú ÀÌ¸§À» Ãß°¡ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 24, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::InsertUserName( char* pName ) 
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pName ) ;

	if( !pName || strlen( pName ) == 0 )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// Á¤º¸¸¦ Ãß°¡ÇÑ´Ù.
	const char* name = pName ;
	DWORD dwNameCode = GetHashCode( name ) ;

	ST_SEARCH_NAME* pNameInfo = new ST_SEARCH_NAME ;
	ASSERT( pNameInfo ) ;

	if( !pNameInfo ) return ;

	ZeroMemory( pNameInfo, sizeof(pNameInfo) );
	SafeStrCpy( pNameInfo->name, name, MAX_NAME_LENGTH + 1 ) ;

	m_htSearchName.Add( pNameInfo, dwNameCode ) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : EraseUserName
//	DESC : °Ë»ö¿ë ÇØ½¬¸ÊÀÇ À¯Àú ÀÌ¸§À» »èÁ¦ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 24, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::EraseUserName( char* pName )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pName ) ;

	if( !pName || strlen( pName ) == 0 )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// °Ë»öÀ» ÇÑ´Ù.
	const char* name = pName ;
	DWORD dwNameCode = GetHashCode( name ) ;

	ST_SEARCH_NAME* pNameInfo = m_htSearchName.GetData( dwNameCode ) ;
	if( pNameInfo )
	{
		delete pNameInfo ;
		pNameInfo = NULL ;
	}

	m_htSearchName.Remove( dwNameCode ) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateNameRoomIdx
//	DESC : °Ë»ö¿ë ÇØ½¬¸ÊÀÇ À¯Àú°¡ Âü¿©ÇÑ ¹æ ¹øÈ£¸¦ ¾÷µ¥ÀÌÆ® ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 24, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateNameRoomIdx( char* pName, BYTE byRoomIdx )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pName ) ;

	if( !pName || strlen( pName ) == 0 )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// ¹æ ÀÎµ¦½º¸¦ ¾÷µ¥ÀÌÆ® ÇÑ´Ù.
	const char* name = pName ;
	DWORD dwNameCode = GetHashCode( name ) ;

	ST_SEARCH_NAME* pNameInfo = m_htSearchName.GetData( dwNameCode ) ;
	if( pNameInfo )
	{
		pNameInfo->byRoomIdx = byRoomIdx ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateSearchRoomInfo
//	DESC : °Ë»ö¿ë ¹æÀÇ Á¤º¸¸¦ ¾÷µ¥ÀÌÆ® ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 24, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateSearchRoomInfo( ST_CR_ROOM_SRV* pInfo )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// °Ë»ö ¿ë ¹æ ¾÷µ¥ÀÌÆ®.
	ST_CR_ROOM_CLT* pTitle = NULL ;
	PTRLISTPOS pos = NULL ;

	pos = m_pTitleList.GetHeadPosition() ;

	while( pos )
	{
		pTitle = NULL ;
		pTitle = (ST_CR_ROOM_CLT*)m_pTitleList.GetNext( pos ) ;

		if( !pInfo ) continue ;

		if( pInfo->byIdx != pTitle->byIdx ) continue ;

		pTitle->byIdx				= pInfo->byIdx ;
		pTitle->bySecretMode		= pInfo->bySecretMode ;
		pTitle->byRoomType			= pInfo->byRoomType ;
		pTitle->byCurGuestCount		= pInfo->byCurGuestCount ;
		pTitle->byTotalGuestCount	= pInfo->byTotalGuestCount ;

		SafeStrCpy( pTitle->title, pInfo->title, TITLE_SIZE ) ;

		return ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateInfo_Created_Room
//	DESC : ¼­¹ö ³», Ã¤ÆÃ¹æÀÌ Ãß°¡µÇ¾úÀ½À» Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateInfo_Created_Room( ST_CR_ROOM_SRV* pInfo )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// Ã¤ÆÃ Âü¿©ÁßÀÎ À¯Àú°¡ ÀÖ´ÂÁö È®ÀÎÇÑ´Ù.
	if( m_htUser.GetDataNum() == 0 )
	{
		Throw_Error( "Failed to notice add room!!", __FUNCTION__ ) ;
		return ;
	}



	// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_CR_ROOMINFO_TO_NOTICE msg ;
	memset( &msg, 0, sizeof(MSG_CR_ROOMINFO_TO_NOTICE) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_UPDATEINFO_CREATED_ROOM ;

	msg.room		= *pInfo ;	



	// À¯Àú¿¡°Ô ¸Þ½ÃÁö Àü¼Û.
	ST_CR_USER* pUserInfo = NULL ;
	while( (pUserInfo = m_htUser.GetData()) != NULL )
	{
		msg.dwObjectID = pUserInfo->dwPlayerID ;
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_CR_ROOMINFO_TO_NOTICE) ) ;
#else
		g_Network.Send2Server( pUserInfo->dwConnectionIdx, (char*)&msg, sizeof(MSG_CR_ROOMINFO_TO_NOTICE) ) ;
#endif
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateInfo_Deleted_Room
//	DESC : ¼­¹ö ³», Ã¤ÆÃ¹æÀÌ »èÁ¦µÇ¾úÀ½À» Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateInfo_Deleted_Room( ST_CR_ROOM_SRV* pInfo )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// Ã¤ÆÃ Âü¿©ÁßÀÎ À¯Àú°¡ ÀÖ´ÂÁö È®ÀÎÇÑ´Ù.
	if( m_htUser.GetDataNum() == 0 )
	{
		Throw_Error( "Failed to notice add room!!", __FUNCTION__ ) ;
		return ;
	}



	// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_BYTE msg ;
	memset( &msg, 0, sizeof(MSG_BYTE) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_UPDATEINFO_DELETED_ROOM ;

	msg.bData		= pInfo->byIdx ;



	// À¯Àú¿¡°Ô ¸Þ½ÃÁö Àü¼Û.
	ST_CR_USER* pUserInfo = NULL ;
	while( (pUserInfo = m_htUser.GetData()) != NULL )
	{
		msg.dwObjectID = pUserInfo->dwPlayerID ;
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_BYTE) ) ;
#else
		g_Network.Send2Server( pUserInfo->dwConnectionIdx, (char*)&msg, sizeof(MSG_BYTE) ) ;
#endif
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateInfo_Changed_SecretMode
//	DESC : ¼­¹ö ³», Ã¤ÆÃ¹æÀÇ °ø°³/ºñ°ø°³°¡ º¯°æµÇ¾úÀ½À» °øÁöÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateInfo_Changed_SecretMode( ST_CR_ROOM_SRV* pInfo )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// Ã¤ÆÃ Âü¿©ÁßÀÎ À¯Àú°¡ ÀÖ´ÂÁö È®ÀÎÇÑ´Ù.
	if( m_htUser.GetDataNum() == 0 )
	{
		Throw_Error( "Failed to notice add room!!", __FUNCTION__ ) ;
		return ;
	}



	// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_BYTE2 msg ;
	memset( &msg, 0, sizeof(MSG_BYTE2) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_UPDATEINFO_SECRETMODE ;

	msg.bData1		= pInfo->byIdx ;
	msg.bData2		= pInfo->bySecretMode ;	

	

	// À¯Àú¿¡°Ô ¸Þ½ÃÁö Àü¼Û.
	ST_CR_USER* pUserInfo = NULL ;
	while( (pUserInfo = m_htUser.GetData()) != NULL )
	{
		msg.dwObjectID = pUserInfo->dwPlayerID ;
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#else
		g_Network.Send2Server( pUserInfo->dwConnectionIdx, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#endif
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateInfo_Changed_RoomType
//	DESC : ¼­¹ö ³», Ã¤ÆÃ¹æºÐ·ù°¡ º¯°æµÇ¾úÀ½À» °øÁöÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateInfo_Changed_RoomType( ST_CR_ROOM_SRV* pInfo )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// Ã¤ÆÃ Âü¿©ÁßÀÎ À¯Àú°¡ ÀÖ´ÂÁö È®ÀÎÇÑ´Ù.
	if( m_htUser.GetDataNum() == 0 )
	{
		Throw_Error( "Failed to notice add room!!", __FUNCTION__ ) ;
		return ;
	}



	// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_BYTE2 msg ;
	memset( &msg, 0, sizeof(MSG_BYTE2) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_UPDATEINFO_ROOMTYPE ;

	msg.bData1		= pInfo->byIdx ;
	msg.bData2		= pInfo->byRoomType ;	

	

	// À¯Àú¿¡°Ô ¸Þ½ÃÁö Àü¼Û.
	ST_CR_USER* pUserInfo = NULL ;
	while( (pUserInfo = m_htUser.GetData()) != NULL )
	{
		msg.dwObjectID = pUserInfo->dwPlayerID ;
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#else
		g_Network.Send2Server( pUserInfo->dwConnectionIdx, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#endif
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateInfo_Changed_Title
//	DESC : ¼­¹ö ³», Ã¤ÆÃ¹æÀÇ Á¦¸ñÀÌ º¯°æµÇ¾úÀ½À» °øÁöÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateInfo_Changed_Title( ST_CR_ROOM_SRV* pInfo )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// Ã¤ÆÃ Âü¿©ÁßÀÎ À¯Àú°¡ ÀÖ´ÂÁö È®ÀÎÇÑ´Ù.
	if( m_htUser.GetDataNum() == 0 )
	{
		Throw_Error( "Failed to notice add room!!", __FUNCTION__ ) ;
		return ;
	}



	// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_CR_SEARCH_TITLE msg ;
	memset( &msg, 0, sizeof(MSG_CR_SEARCH_TITLE) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_UPDATEINFO_TITLE ;

	msg.byRoomIdx	= pInfo->byIdx ;
	SafeStrCpy( msg.title, pInfo->title, TITLE_SIZE ) ;	

	

	// À¯Àú¿¡°Ô ¸Þ½ÃÁö Àü¼Û.
	ST_CR_USER* pUserInfo = NULL ;
	while( (pUserInfo = m_htUser.GetData()) != NULL )
	{
		msg.dwObjectID = pUserInfo->dwPlayerID ;
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#else
		g_Network.Send2Server( pUserInfo->dwConnectionIdx, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#endif
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateInfo_Changed_Current_GuestCount
//	DESC : Ã¤ÆÃ¹æÀÇ Âü¿©ÀÚ ÀÎ¿øÀÌ º¯°æµÇ¾úÀ½À» °øÁöÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateInfo_Changed_Current_GuestCount( ST_CR_ROOM_SRV* pInfo )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// Ã¤ÆÃ Âü¿©ÁßÀÎ À¯Àú°¡ ÀÖ´ÂÁö È®ÀÎÇÑ´Ù.
	if( m_htUser.GetDataNum() == 0 )
	{
		Throw_Error( "Failed to notice add room!!", __FUNCTION__ ) ;
		return ;
	}



	// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_BYTE2 msg ;
	memset( &msg, 0, sizeof(MSG_BYTE2) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_UPDATEINFO_CUR_GUESTCOUNT ;



	// À¯Àú¿¡°Ô ¸Þ½ÃÁö Àü¼Û.
	ST_CR_USER* pUserInfo = NULL ;
	while( (pUserInfo = m_htUser.GetData()) != NULL )
	{
		msg.bData1		= pInfo->byIdx ;
		msg.bData2		= pInfo->byCurGuestCount ;	

		msg.dwObjectID = pUserInfo->dwPlayerID ;
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#else
		g_Network.Send2Server( pUserInfo->dwConnectionIdx, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#endif
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : UpdateInfo_Changed_Total_GuestCount
//	DESC : Ã¤ÆÃ¹æÀÇ ÃÖ´ë Âü¿©ÀÚ ÀÎ¿øÀÌ º¯°æµÇ¾úÀ½À» °øÁöÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdateInfo_Changed_Total_GuestCount( ST_CR_ROOM_SRV* pInfo )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( pInfo ) ;

	if( !pInfo )
	{
		Throw_Error( err_IMP, __FUNCTION__ ) ;
		return ;
	}



	// Ã¤ÆÃ Âü¿©ÁßÀÎ À¯Àú°¡ ÀÖ´ÂÁö È®ÀÎÇÑ´Ù.
	if( m_htUser.GetDataNum() == 0 )
	{
		Throw_Error( "Failed to notice add room!!", __FUNCTION__ ) ;
		return ;
	}



	// Àü¼Û ¸Þ½ÃÁö ¼¼ÆÃ.
	MSG_BYTE2 msg ;
	memset( &msg, 0, sizeof(MSG_BYTE2) ) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_UPDATEINFO_TOTAL_GUESTCOUNT ;

	msg.bData1		= pInfo->byIdx ;
	msg.bData2		= pInfo->byTotalGuestCount ;	

	

	// À¯Àú¿¡°Ô ¸Þ½ÃÁö Àü¼Û.
	ST_CR_USER* pUserInfo = NULL ;
	while( (pUserInfo = m_htUser.GetData()) != NULL )
	{
		msg.dwObjectID = pUserInfo->dwPlayerID ;
#ifdef _MYLUNA_
		g_Network.Send2Server( 1, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#else
		g_Network.Send2Server( pUserInfo->dwConnectionIdx, (char*)&msg, sizeof(MSG_BYTE2) ) ;
#endif
	}
}

void CChatRoomMgr::Throw_Error( BYTE errType,const  char* szCaption )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( szCaption ) ;

	if( !szCaption || strlen( szCaption ) <= 1 )
	{
#ifdef _USE_ERR_MSGBOX_
		MessageBox( NULL, "Invalid Caption!!", "Throw_Error", MB_OK ) ;
#else
		char tempStr[ 257 ] = {0, } ;

		SafeStrCpy( tempStr, __FUNCTION__, 256 ) ;
		strcat( tempStr, " - " ) ;
		strcat( tempStr, "Invalid Caption!!" ) ;
		WriteLog(tempStr) ;
#endif //_USE_ERR_MSGBOX_
		return ;
	}

	char tempErr[ 257 ] = {0, } ;

	switch(errType)
	{
	case err_IMP :		SafeStrCpy( tempErr, "Invalid a message parameter!!", 256 ) ;					break ;
	case err_FCMTB :	SafeStrCpy( tempErr, "Failed to convert a message to base!!", 256 ) ;			break ;
	case err_FCMTO :	SafeStrCpy( tempErr, "Failed to convert a message to original!!", 256 ) ;		break ;
	default : break ;
	}

	// ¿¡·¯ Ãâ·Â/·Î±×.
#ifdef _USE_ERR_MSGBOX_
	MessageBox( NULL, tempErr, szCaption, MB_OK ) ;
#else
	char tempStr[ 257 ] = {0, } ;

	SafeStrCpy( tempStr, szCaption, 256 ) ;
	strcat( tempStr, " - " ) ;
	strcat( tempStr, tempErr ) ;
	WriteLog( tempStr ) ;
#endif //_USE_ERR_MSGBOX_
}





//-------------------------------------------------------------------------------------------------
//	NAME : Throw_Error
//	DESC : Ã¤ÆÃ¹æ ³», ¿¡·¯ ¸Þ½ÃÁö °ü·Ã ·Î±×¸¦ ³²±â´Â ÇÔ¼ö.
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Throw_Error(const  char* szErr,const  char* szCaption )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( szCaption ) ;

	if( !szErr || strlen( szErr ) <= 1 )
	{
#ifdef _USE_ERR_MSGBOX_
		MessageBox( NULL, "Invalid err message!!", "Throw_Error", MB_OK ) ;
#else
		char tempStr[ 257 ] = {0, } ;

		SafeStrCpy( tempStr, __FUNCTION__, 256 ) ;
		strcat( tempStr, " - " ) ;
		strcat( tempStr, "Invalid err message!!" ) ;
		WriteLog( tempStr ) ;
#endif //_USE_ERR_MSGBOX_
		return ;
	}

	if( !szCaption || strlen( szCaption ) <= 1 )
	{
#ifdef _USE_ERR_MSGBOX_
		MessageBox( NULL, "Invalid Caption!!", "Throw_Error", MB_OK ) ;
#else
		char tempStr[ 257 ] = {0, } ;

		SafeStrCpy( tempStr, __FUNCTION__, 256 ) ;
		strcat (tempStr, " - " ) ;
		strcat( tempStr, "Invalid Caption!!")  ;
		WriteLog( tempStr ) ;
#endif //_USE_ERR_MSGBOX_
		return ;
	}

	// ¿¡·¯ Ãâ·Â/·Î±×.
#ifdef _USE_ERR_MSGBOX_
	MessageBox( NULL, szErr, szCaption, MB_OK ) ;
#else
	char tempStr[ 257 ] = {0, } ;

	SafeStrCpy( tempStr, szCaption, 256 ) ;
	strcat( tempStr, " - " ) ;
	strcat( tempStr, szErr ) ;
	WriteLog( tempStr ) ;
#endif //_USE_ERR_MSGBOX_
}





//-------------------------------------------------------------------------------------------------
//	NAME : Throw_Error
//	DESC : Ã¤ÆÃ¹æ ³», ¿¡·¯ ¸Þ½ÃÁö °ü·Ã ·Î±×¸¦ ³²±â´Â ÇÔ¼ö.
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Throw_Error( char* szCommonErr, char* szErr, char* szCaption )
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT( szCaption ) ;

	if( !szErr || strlen( szErr ) <= 1 )
	{
#ifdef _USE_ERR_MSGBOX_
		MessageBox( NULL, "Invalid err message!!", "Throw_Error", MB_OK ) ;
#else
		char tempStr[ 257 ] = {0, } ;

		SafeStrCpy( tempStr, __FUNCTION__, 256 ) ;
		strcat( tempStr, " - " ) ;
		strcat( tempStr, "Invalid err message!!" ) ;
		WriteLog( tempStr ) ;
#endif //_USE_ERR_MSGBOX_
		return ;
	}

	if( !szCaption || strlen( szCaption ) <= 1 )
	{
#ifdef _USE_ERR_MSGBOX_
		MessageBox( NULL, "Invalid Caption!!", "Throw_Error", MB_OK ) ;
#else
		char tempStr[ 257 ] = {0, } ;

		SafeStrCpy( tempStr, __FUNCTION__, 256 ) ;
		strcat( tempStr, " - " ) ;
		strcat( tempStr, "Invalid Caption!!" ) ;
		WriteLog( tempStr ) ;
#endif //_USE_ERR_MSGBOX_
		return ;
	}

	// ¿¡·¯ Ãâ·Â/·Î±×.
#ifdef _USE_ERR_MSGBOX_
	MessageBox( NULL, szErr, szCaption, MB_OK ) ;
#else
	char tempStr[ 257 ] = {0, } ;

	SafeStrCpy( tempStr, szCaption, 256) ;
	strcat( tempStr, " - " ) ;
	strcat( tempStr, szErr ) ;
	WriteLog( tempStr ) ;
#endif //_USE_ERR_MSGBOX_
}





//-------------------------------------------------------------------------------------------------
//	NAME : WriteLog
//	DESC : Ã¤ÆÃ¹æ ³», ¿¡·¯ ¸Þ½ÃÁö °ü·Ã ·Î±×¸¦ ³²±â´Â ÇÔ¼ö.
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::WriteLog( char* pMsg )
{
	SYSTEMTIME time ;
	GetLocalTime( &time ) ;

	TCHAR szTime[_MAX_PATH ] = {0, } ;
	sprintf( szTime, "%04d-%02d-%02d %02d:%02d:%02d", time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute, time.wSecond ) ;

	FILE *fp = fopen( "Log/Dist-ChatRoomErr.log", "a+" ) ;
	if ( fp )
	{
		fprintf( fp, "%s [%s]\n", pMsg,  szTime ) ;
		fclose( fp ) ;
	}
}












