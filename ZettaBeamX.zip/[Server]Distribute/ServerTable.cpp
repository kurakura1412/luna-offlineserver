// ServerTable.cpp: implementation of the CServerTable class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"


#ifdef _DIST00_
#include <yhlibrary.h>
//#include "CommonHeader.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "ServerSystem.h"
//#include "UserTable.h"
#endif

#include "ServerTable.h"
#include "ServerSystem.h"
#include "ServerListManager.h"

#define DISTPORT 3333
#define AGENTPORT 6666
#define MAPPORT 9999

CServerTable * g_pServerTable = 0;

CServerTable::CServerTable()
{
	//m_dwMaxBucketNum = 0;
	m_MaxServerConnectionIndex = 0;
	m_pSelfServerInfo = NULL;
	m_pMSServerInfo = NULL;

	ZeroMemory( m_nDisableAgent, sizeof(m_nDisableAgent) );
}

CServerTable::~CServerTable()
{
	SAFE_DELETE(
		m_pSelfServerInfo);

	Release();
}

void CServerTable::Release()
{
	RemoveAllServer();
}

void CServerTable::Init(DWORD dwBucketNum)
{
	CYHHashTable<SERVERINFO>::Initialize(dwBucketNum);
#ifdef _MYLUNA_
	svrAgn = SERVERINFO(SERVER_KIND::AGENT_SERVER, 0, "127.0.0.1",
		17001, "127.0.0.1", 14500);
	svrAgn.dwConnectionIndex = 1;
	svrDis = SERVERINFO(SERVER_KIND::DISTRIBUTE_SERVER, 0, "127.0.0.1",
		16001, "127.0.0.1", 14700);
	svrDis.dwConnectionIndex = 2;
	svrMap = SERVERINFO(SERVER_KIND::DISTRIBUTE_SERVER, 0, "127.0.0.1",
		18019, "127.0.0.1", 0);
	svrMap.dwConnectionIndex = 3;
#endif
}

SERVERINFO * CServerTable::FindServer(WORD Port)
{
#ifdef _MYLUNA_
	SERVERINFO * pInfo = SERVERLISTMGR->GetServerInfoByPort(eSERVER_KIND::eSK_MAP, Port);
	return pInfo;
#else
	return CYHHashTable<SERVERINFO>::GetData(Port);
#endif
}
SERVERINFO* CServerTable::GetNextServer()
{
	SERVERINFO* pRt = CYHHashTable<SERVERINFO>::GetData();
	if(pRt == NULL)
		return NULL;

	if(pRt->dwConnectionIndex == 0)
		return GetNextServer();
	else
		return pRt;
}
SERVERINFO* CServerTable::GetNextDistServer()
{
	SERVERINFO* pRt = GetNextServer();
	if(pRt == NULL)
		return NULL;

	if(pRt->wServerKind != DISTRIBUTE_SERVER)
		return GetNextDistServer();
	else
		return pRt;
}

SERVERINFO* CServerTable::GetNextMapServer()
{
	SERVERINFO* pRt = GetNextServer();
	if(pRt == NULL)
		return NULL;

	if(pRt->wServerKind != MAP_SERVER)
		return GetNextMapServer();
	else
		return pRt;
}
SERVERINFO* CServerTable::GetNextAgentServer()
{
	SERVERINFO* pRt = GetNextServer();
	if(pRt == NULL)
		return NULL;

	if(pRt->wServerKind != AGENT_SERVER)
		return GetNextAgentServer();
	else
		return pRt;
}


void CServerTable::AddServer(SERVERINFO * info, WORD Port)
{
	if( info == (SERVERINFO *)GetData(Port) )
	{
		return;
	}

	CYHHashTable<SERVERINFO>::Add(info, Port);
}
void CServerTable::AddSelfServer(SERVERINFO * info)
{
	//CYHHashTable<SERVERINFO>::Add(info, key);
	ASSERT(!m_pSelfServerInfo);
	m_pSelfServerInfo = info;
}
void CServerTable::AddMSServer(SERVERINFO * info)
{
	ASSERT(!m_pMSServerInfo);
	m_pMSServerInfo = info;
}

SERVERINFO* CServerTable::FindServerForConnectionIndex(DWORD dwConnectionIndex)
{
	SetPositionHead();
	SERVERINFO* info = NULL;
	while((info = (SERVERINFO*)GetData()) != NULL)
	{
		if(info->dwConnectionIndex == dwConnectionIndex)
		{
			return info;
		}
	}
	return NULL;
}

SERVERINFO * CServerTable::RemoveServer(DWORD dwConnectionIndex)
{
	SetPositionHead();
	
	while(SERVERINFO* const info = GetData())
	{
		if(info->dwConnectionIndex == dwConnectionIndex)
		{
			Remove(info->wPortForServer);
			return info;
		}
	}
	return NULL;
}

SERVERINFO * CServerTable::RemoveServer(WORD wKey)
{
	SERVERINFO * info = (SERVERINFO *)GetData(wKey);
	if( info->wServerKind == AGENT_SERVER &&
		info->wServerNum >= 100 )
		return NULL;
	Remove(wKey);
	return info;
}
// HASH¿¡ ¹°·ÁÀÖ´Â SERVERINFO(Èü¸Þ¸ð¸®)±îÁö ´Ù Áö¿ò
void CServerTable::RemoveAllServer()
{
	SetPositionHead();
	SERVERINFO * info = NULL;
	while((info = (SERVERINFO *)GetData()) != NULL)
	{
//		Remove(info->wPortForServer);
		delete info;
		info = NULL;
	}
	RemoveAll();
}

WORD CServerTable::GetServerPort(WORD ServerKind, WORD ServerNum)
{
#ifdef _MYLUNA_
	if( ServerKind == eSERVER_KIND::eSK_AGENT ) return svrAgn.wPortForServer;
	if( ServerKind == eSERVER_KIND::eSK_DIST ) return svrDis.wPortForServer;
	if( ServerKind == eSERVER_KIND::eSK_MAP ){
		SERVERINFO* pInfo = SERVERLISTMGR->GetServerInfoByNum(eSK_MAP, ServerNum);
		if(pInfo) return pInfo->wPortForServer;
	}
	return 0;
#else
	SERVERINFO* pInfo = GetServer(ServerKind,ServerNum);
	return pInfo ? pInfo->wPortForServer : 0;
#endif
}

SERVERINFO* CServerTable::GetServer(WORD ServerKind, WORD ServerNum)
{
#ifdef _MYLUNA_
	if( ServerKind == AGENT_SERVER ) return &(svrAgn);
	if( ServerKind == DISTRIBUTE_SERVER ) return &(svrDis);
	if( ServerKind == MAP_SERVER ) return &(svrMap);
#else
	SetPositionHead();
	SERVERINFO * info = NULL;
	while((info = (SERVERINFO *)GetData()) != NULL)
	{
		if(info->wServerKind == ServerKind && info->wServerNum == ServerNum)
		{
			return info;
		}
	}
#endif
	return NULL;
}

WORD CServerTable::GetServerNum(WORD ServerPort)
{
	SetPositionHead();
	SERVERINFO * info = NULL;
	while((info = (SERVERINFO *)GetData()) != NULL)
	{
		if(info->wPortForServer == ServerPort)
		{
			return info->wServerNum;
		}
	}
	return 0;
}
SERVERINFO* CServerTable::GetFastServer(WORD ServerKind)
{
#ifdef _MYLUNA_
	if( ServerKind == AGENT_SERVER ) return &(svrAgn);
	if( ServerKind == DISTRIBUTE_SERVER ) return &(svrDis);
	if( ServerKind == MAP_SERVER ) return &(svrMap);
	return NULL;
#else
	SetPositionHead();
	SERVERINFO * info = NULL;
	WORD min_cnt = 65535;
	SERVERINFO * min_info = 0;
	while((info = (SERVERINFO *)g_pServerTable->GetData()) != NULL)
	{
		// Á¢¼ÓµÈ ¿¡ÀÌÀüÆ® Áß¿¡¼­ 
		if(info->dwConnectionIndex != 0 && info->wServerKind == ServerKind )
		{
			if( info->wServerKind == AGENT_SERVER )
			if( info->wServerNum >=0 && info->wServerNum < 8 )
			{
				if(m_nDisableAgent[info->wServerNum]==TRUE)//AAA
					continue;
			}

			if(info->wAgentUserCnt < min_cnt)
			{
				min_cnt = info->wAgentUserCnt;
				min_info = info;
			}
		}
	}
	
	if(min_info == NULL)
		return 0;
	
	return min_info;
#endif
}
BOOL CServerTable::GetFastServer(WORD ServerKind, char* pOutIP,WORD* pOutPort)
{
#ifndef _MYLUNA_
	SetPositionHead();
	SERVERINFO * info = NULL;
	WORD min_cnt = 65535;
	SERVERINFO * min_info = 0;
	while((info = (SERVERINFO *)g_pServerTable->GetData()) != NULL)
	{
		// Á¢¼ÓµÈ ¿¡ÀÌÀüÆ® Áß¿¡¼­ 
		if(info->dwConnectionIndex != 0 && info->wServerKind == ServerKind )
		{
			if( info->wServerKind == AGENT_SERVER )
			if( info->wServerNum >=0 && info->wServerNum < 8 )
			{
				if(m_nDisableAgent[info->wServerNum]==TRUE)//AAA
					continue;
			}

			if(info->wAgentUserCnt < min_cnt)
			{
				min_cnt = info->wAgentUserCnt;
				min_info = info;
			}
		}
	}
	
	if(min_info == NULL)
		return FALSE;
	sprintf(pOutIP, "%s", min_info->szIPForServer);
	*pOutPort = min_info->wPortForUser;
#endif
	return TRUE;
}
