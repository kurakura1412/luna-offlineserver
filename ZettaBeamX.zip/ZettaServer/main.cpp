#include <stdio.h>
#ifdef _WIN32
#include <winsock2.h>
#else
#include <netinet/in.h>
# ifdef _XOPEN_SOURCE_EXTENDED
#  include <arpa/inet.h>
# endif
#include <sys/socket.h>
#endif
#include <event.h>
//#include <event2/bufferevent.h>
//#include <event2/buffer.h>
#include <event2/listener.h>
//#include <event2/util.h> 
//#include <event2/event.h>
#include <signal.h>
#include "libMoonSvr/MoonLigh.h"

#define LUNA_PORT 14700
#define BUFFLEN 8196
struct Meawa
{
	bool _alive= false;
	evutil_socket_t client_fd;// = -1;
	char mbuff[BUFFLEN];
	event* timeout_e;
	event *signal_e;
	event_base *base_e;
	bufferevent *bev_e;
	MoonLigh* Moon;
	event ev_read;
	event ev_write;
};
void on_free( Meawa* mydata){
	if( mydata->client_fd != -1){
		//evutil_closesocket(mydata->client_fd);
		mydata->client_fd = -1;
	}
	event_del(mydata->timeout_e);
	event_del(mydata->signal_e);
	timeval delay = { 1, 0 };
	event_base_loopexit(mydata->base_e, &delay);
	mydata->_alive = false;
}
void signal_cb(evutil_socket_t sig, short events, void *user_data)
{
	Meawa * mydata = (Meawa *)user_data;
	event_base *base = mydata->base_e;
	timeval delay = { 2, 0 };

	printf("Caught an interrupt signal; exiting cleanly in two seconds.\n");
	if( mydata->client_fd != -1){
		bufferevent_free(mydata->bev_e);
		//evutil_closesocket(mydata->client_fd);
		mydata->client_fd = -1;
	}
	mydata->Moon->EndofWorld();
	mydata->_alive = false;
	event_del(mydata->timeout_e);
	event_base_loopexit(base, &delay);
}

void conn_eventcb(bufferevent *bev, short events, void *user_data)
{
	if (events & BEV_EVENT_EOF) {
		printf("Connection closed.\n");
	} else if (events & BEV_EVENT_ERROR) {
		printf("Got an error on the connection: %s\n",
		    strerror(errno));/*XXX win32*/
	}
	printf("closing server...\n");
	/* None of the other events can happen here, since we haven't enabled
	 * timeouts */
	bufferevent_free(bev);
	Meawa * mydata = (Meawa *)user_data;
	mydata->client_fd = -1;
	mydata->Moon->EndofWorld();
	mydata->_alive = false;
	event_del(mydata->timeout_e);
	event_del(mydata->signal_e);
	timeval delay = { 1, 0 };
	event_base_loopexit(mydata->base_e, &delay);
}

void conn_readcb(bufferevent *bev, void *user_data)
{
	int zlen = 0;
	Meawa * misds = (Meawa *)user_data;
	zlen = bufferevent_read(bev, misds->mbuff, BUFFLEN - 1);
	if( zlen > 0  ){
		std::vector<char> to_moon( misds->mbuff, &(misds->mbuff[zlen ]) );
		short wlen = *(short*)&(to_moon.at(0));
		wlen -= 2;
		if( wlen > 0 && wlen > BUFFLEN ){
			Sleep(1);
#ifdef _WIN32
			zlen = recv(misds->client_fd, misds->mbuff, BUFFLEN - 1,0);
#else
			zlen = read(misds->client_fd, misds->mbuff, BUFFLEN - 1);
#endif
			while( zlen > 0){
			to_moon.reserve(to_moon.size() + zlen );
			to_moon.insert(to_moon.end(), misds->mbuff, &(misds->mbuff[zlen ]) );
						Sleep(1);
#ifdef _WIN32
			zlen = recv(misds->client_fd, misds->mbuff, BUFFLEN - 1,0);
#else
			zlen = read(misds->client_fd, misds->mbuff, BUFFLEN - 1);
#endif
			}
		}
		misds->Moon->onrecvdata( to_moon );
	}
}
void readclosed( Meawa* mydata )
{
	evutil_closesocket(mydata->client_fd);
	mydata->client_fd = -1;
	event_del(&(mydata->ev_read));
	event_del(mydata->signal_e);
	event_del(mydata->timeout_e);
	timeval delay = { 1, 0 };
	event_base_loopexit(mydata->base_e, &delay);
	
}
void on_read(int fd, short ev, void *user_data)
{
	Meawa * misds = (Meawa *)user_data;
	int len;
#ifdef _WIN32
	len = recv(fd, misds->mbuff, BUFFLEN,0);
#else
	len = read(fd, misds->mbuff, BUFFLEN);
#endif
	if (len == 0) {
		/* Client disconnected, remove the read event and the
		 * free the client structure. */
		printf("Client disconnected.\n");
    readclosed(misds);
		return;
	} else if (len < 0) {
		/* Some other error occurred, close the socket, remove
		 * the event and free the client structure. */
		printf("Socket failure, disconnecting client.\n");
		readclosed(misds);
		return;
	}
	
}
void on_accept(int fd, short ev, void *user_data)
{
	Meawa * misds = (Meawa *)user_data;
	if( misds->client_fd != -1 ){
		// ignore it
		printf("client has set. e:0001\n");
	} else {
		sockaddr_in client_addr;
		int client_len = sizeof(client_addr);
		misds->client_fd = accept(fd, (struct sockaddr *)&client_addr, &client_len);
		if (misds->client_fd == -1) {
			printf("accept failed\n");
			return;
		}
		if( evutil_make_socket_nonblocking(misds->client_fd) < 0)
		{
			printf("failed to set client socket to non-blocking\n");
		}
		event_set(&misds->ev_read, misds->client_fd, EV_READ|EV_PERSIST, on_read, 
	    user_data);
		event_add(&misds->ev_read, NULL);
		unsigned short ishort = client_addr.sin_port;
		unsigned char * iport = (unsigned char *)&ishort;
		unsigned char tempc;
		tempc = *(iport +  0);
		*(iport + 0) = *(iport  + 1);
		*(iport + 1) = tempc;
		printf("Accepted connection from %s:%u\n",
               inet_ntoa(client_addr.sin_addr),
							 ishort );
		misds->Moon->onfirst();
	}
}

void listener_cb(evconnlistener *listener, evutil_socket_t fd,
    sockaddr *sa, int socklen, void *user_data)
{
	Meawa * misds = (Meawa *)user_data;
	if( misds->client_fd != -1 ){
		// ignore it
		printf("client has set. e:0001\n");
	} else {
	event_base *base = misds->base_e;
	bufferevent *bev;

	bev = bufferevent_socket_new(base, fd, BEV_OPT_CLOSE_ON_FREE);
	if (!bev) {
		fprintf(stderr, "Error constructing bufferevent!");
		event_base_loopbreak(base);
		misds->_alive = false;
		return;
	}
	bufferevent_setcb(bev, conn_readcb,NULL, conn_eventcb, user_data);
	bufferevent_enable(bev, EV_READ);
	bufferevent_disable(bev, EV_WRITE);

	//bufferevent_write(bev, MESSAGE, strlen(MESSAGE));
	misds->bev_e = bev;
	misds->client_fd = fd;
	unsigned short ishort = 0;
	unsigned char * iport = (unsigned char *)&ishort;
	*iport = sa->sa_data[1];
	*(iport + 1) = sa->sa_data[0];
	unsigned int z1 = (unsigned int)sa->sa_data[2];
	unsigned int z2 = (unsigned int)sa->sa_data[3];
	unsigned int z3 = (unsigned int)sa->sa_data[4];
	unsigned int z4 = (unsigned int)sa->sa_data[5];
	printf("---- accept client-> %u.%u.%u.%u:%u\n",z1,z2,z3,z4,ishort);
	misds->Moon->onfirst();
	}
}

void timeout_cb(evutil_socket_t fd, short event, void *user_data)
{
	Meawa * misds = (Meawa *)user_data;
	if( misds->_alive )
		misds->Moon->gprocess();
}

void tosend( std::vector< unsigned char> & mdata, void* userdta)
{
	Meawa * misds = (Meawa *)userdta;
	if( misds->client_fd == -1){
		return;
	}
	int n, zlen = mdata.size();
	char * p = (char*)&(mdata[0]);
#ifdef _WIN32
	n = send(misds->client_fd, p, zlen, 0);
#else 
	n = write(misds->client_fd, p, zlen);
#endif
	if( n < 0 ){
		printf("sendingerror...\n");
		//misds->_alive = false;
	}
}

int main(int argc, char **argv)
{
	printf("hello world\n");
#if defined( _WIN32)
	WSADATA wsaData;
	(void)WSAStartup(0x201, &wsaData);
#endif
	event_base *base;
	sockaddr_in sin;
	event_init();
#ifdef _USINGBUFFEREVENT_
	evconnlistener *listener; 
#else
	event ev_accept;
	evutil_socket_t listen_fd;
	//int reuseaddr_on;
#endif
	event *signal_event;
	event timeout;
	timeval tv;
	Meawa myMeaw = {};
	MoonLigh myMoon;
	if( !myMoon.init() ){
		printf("error Moon init.\n");
		return 1;
	}
	myMoon.setsendcb(tosend, (void*)&myMeaw );
	myMeaw.client_fd = -1;
	//myMeaw.mbuff = {0};
	myMeaw.Moon = &myMoon;

	base = event_base_new();
	if (!base) {
		fprintf(stderr, "Could not initialize libevent!\n");
		return 1;
	}
	myMeaw.base_e = base;
#ifndef _USINGBUFFEREVENT_
	listen_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (listen_fd < 0){
		printf("listen failed. e:A\n");
		return 1;
	}
#endif
	memset(&sin, 0, sizeof(sin));
	sin.sin_family = AF_INET;
	sin.sin_addr.s_addr = htonl(0x7f000001); /* 127.0.0.1 */
	sin.sin_port = htons(LUNA_PORT);
#ifdef _USINGBUFFEREVENT_
	listener = evconnlistener_new_bind(base, listener_cb, (void *)&myMeaw,
	    LEV_OPT_REUSEABLE|LEV_OPT_CLOSE_ON_FREE, -1,
	    (sockaddr*)&sin,
	    sizeof(sin));
	if (!listener) {
		fprintf(stderr, "Could not create a listener!\n");
		return 1;
	}
#else
	
	if (bind(listen_fd, (struct sockaddr *)&sin,
		sizeof(sin)) < 0){
		printf("bind failed\n");
		return 1;
		}
	if (listen(listen_fd, 5) < 0){
		printf("listen failed. e:B\n");
		return 1;
	}
	//reuseaddr_on = 1;
	evutil_make_listen_socket_reuseable( listen_fd );
	//setsockopt(listen_fd, SOL_SOCKET, SO_REUSEADDR, &reuseaddr_on, sizeof(reuseaddr_on));
	if( evutil_make_socket_nonblocking(listen_fd) < 0)
	{
		printf("failed to set server socket to non-blocking\n");
		return 1;
	}
	event_assign(&ev_accept, base, listen_fd, EV_READ, 
	  on_accept,  (void *)&myMeaw);
	event_add(&ev_accept, NULL);
#endif
	signal_event = evsignal_new(base, SIGINT, signal_cb, (void *)&myMeaw);
	if (!signal_event || event_add(signal_event, NULL)<0) {
		fprintf(stderr, "Could not create/add a signal event!\n");
		return 1;
	}
	myMeaw.signal_e = signal_event;
	event_assign(&timeout, base, -1, EV_PERSIST, timeout_cb, (void*)&myMeaw);
	evutil_timerclear(&tv);
	tv.tv_sec = 1;
	event_add(&timeout, &tv);
	myMeaw.timeout_e = &timeout;
	myMeaw._alive =  true;
	printf("---- Luna Server is Ready: 127.0.0.1:14700\n");
	event_base_dispatch(base);
#ifdef _USINGBUFFEREVENT_
	evconnlistener_free(listener);
#endif
	event_free(signal_event);
	
	event_base_free(base);
#if defined( _WIN32)
	WSACleanup();
#endif
	printf("done\n");
	
	return 0;
}
