#include <stdio.h>
#include "RNGmt.h"

#define DEFAULT_SEED 4537U //For original implementation, default seed is 4357
/* Period parameters */  
#define N 624
#define M 397
#define K 0x9908B0DFU
#define MATRIX_A 0x9908b0df   /* constant vector a */
#define UPPER_MASK 0x80000000 /* most significant w-r bits */
#define LOWER_MASK 0x7fffffff /* least significant r bits */
/* Tempering parameters */   
#define TEMPERING_MASK_B 0x9d2c5680
#define TEMPERING_MASK_C 0xefc60000
#define TEMPERING_SHIFT_U(y)  (y >> 11)
#define TEMPERING_SHIFT_S(y)  (y << 7)
#define TEMPERING_SHIFT_T(y)  (y << 15)
#define TEMPERING_SHIFT_L(y)  (y >> 18)

//#define loBit(u) ((u) & 0x00000001U)   // mask all but lowest    bit of u

RNGmt::RNGmt()
{
	_mti = N+1;
}

RNGmt::~RNGmt()
{
}

void RNGmt::sgenrand(int seed)
{
	if( _mt.size() < N ) 
		_mt.resize( N );
	_mt[0]= seed & 0xffffffff;
  for (_mti=1; _mti<N; _mti++)
   _mt[_mti] = (69069 * _mt[_mti-1]) & 0xffffffff;
}

unsigned int RNGmt::genrand()
{
	unsigned int y;
	unsigned int mag01[2]={0x0, MATRIX_A};
	/* mag01[x] = x * MATRIX_A  for x=0,1 */
	
	if (_mti >= N) { /* generate N words at one time */
			int kk;
	
			if (_mti == N+1)   /* if sgenrand() has not been called, */
					sgenrand(DEFAULT_SEED); /* a default initial seed is used   */
	
			for (kk=0;kk<N-M;kk++) {
					y = (_mt[kk]&UPPER_MASK)|(_mt[kk+1]&LOWER_MASK);
					_mt[kk] = _mt[kk+M] ^ (y >> 1) ^ mag01[y & 0x1];
			}
			for (;kk<N-1;kk++) {
					y = (_mt[kk]&UPPER_MASK)|(_mt[kk+1]&LOWER_MASK);
					_mt[kk] = _mt[kk+(M-N)] ^ (y >> 1) ^ mag01[y & 0x1];
			}
			y = (_mt[N-1]&UPPER_MASK)|(_mt[0]&LOWER_MASK);
			_mt[N-1] = _mt[M-1] ^ (y >> 1) ^ mag01[y & 0x1];
	
			_mti = 0;
	}
	
	y = _mt[_mti++];
	y ^= (y >> 11);
	y ^= (y <<  7) & 0x9D2C5680U;
	y ^= (y << 15) & 0xEFC60000U;
	y ^= (y >> 18);
	
	return y; 
}

unsigned int RNGmt::randUINT()
{
	return genrand();
}

unsigned int RNGmt::randUINTrr(int loww, int higg)
{
	if( loww > higg ){
		int tt = higg;
		higg = loww;
		loww = tt;
	}
	unsigned int __urngmin = 0;
	unsigned int __urngmax = 0xffffffff;
	unsigned int __urngrange = __urngmax - __urngmin;
	unsigned int __urange = higg - loww;
	unsigned int __ret;
	//if (__urngrange > __urange){
		unsigned int __uerange = __urange + 1; // __urange can be zero
		unsigned int __scaling = __urngrange / __uerange;
	//	unsigned int __past = __uerange * __scaling;
		//__ret = randUINT() - __urngmin;
		//__ret = __ret / __scaling + loww;
		__ret = randUINT() / __scaling + loww;
	//}
	//else if (__urngrange < __urange){
	//}
	//else {
	//}
	return __ret;
}

float RNGmt::randFLOAT()
{
	double y = (double)genrand() * 2.3283064365386963e-10;
	return (float)y;
}

float RNGmt::randFLOATrr(float loww, float higg)
{
	if( loww > higg ){
		float tt = higg;
		higg = loww;
		loww = tt;
	}
	float __range = higg - loww;
	return randFLOAT() * __range + loww;
}

bool RNGmt::randBOOL()
{
	return (genrand() & UPPER_MASK) != 0;
}
