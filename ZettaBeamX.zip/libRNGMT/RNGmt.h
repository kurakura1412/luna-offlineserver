#ifndef __RNGmt__h__
#define __RNGmt__h__

#include <vector>

class RNGmt
{
public:
	RNGmt();
	~RNGmt();
	unsigned int randUINT();
	unsigned int randUINTrr(int loww, int higg);
	int randINT(){return (int)randUINT();}
	int randINTrr(int loww, int higg){ return (int)randUINTrr(loww, higg);} // [0..0xffffffff]
	float randFLOAT(); // [0..1]
	float randFLOATrr(float loww, float higg);
	bool randBOOL(); // (genrand() & 0x80000000) != 0;
private:
	void sgenrand(int seed);
	unsigned int genrand();
	
	std::vector< unsigned int > _mt;
	int _mti;
};

#endif // __RNGmt__h__
