#ifndef WARPMAP_H
#define WARPMAP_H

class MoonBase;
class CServerSystem;

class WarpMap
{
public:
	WarpMap();
	~WarpMap();
	bool init(int mapnum);
	void Update();
	void start(int mapnum);
	void setNetData( MoonBase* zz);
	void parseIN(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength);
	void parseINSVR(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength);
	void AskChannel(unsigned int mapnum);
	void ChangeMap(unsigned int mapnum);
	void ondisconnectuser(unsigned int connidx);
	void end();
	void updatemove();
private:
	CServerSystem * svrmap;
	unsigned int _currentmap;
	unsigned int _nextmap;
};

#endif // WARPMAP_H
