#include "stdafx.h"


#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h" 
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h" 
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
#include "ServerSystem.h"
#endif


#include "WarpMap.h"
#include "Network.h"
#include "DataBase.h"
#include "..\[CC]Header\GameResourceManager.h"
#include "PartyManager.h"
#include "ChannelSystem.h"

char g_szHeroIDName[17] = { 0, };
char g_szMapName[64] = { 0, };

WarpMap::WarpMap()
{
	svrmap = nullptr;
	_currentmap = 0;
	_nextmap = 0;
}

WarpMap::~WarpMap() 
{
	if( svrmap ){ 
		//svrmap->End();
		delete svrmap;
		svrmap = nullptr;
		g_pServerSystem = nullptr;
	}
}


bool WarpMap::init(int mapnum)
{
	if( g_pServerSystem ) return false;
	svrmap = new (std::nothrow) CServerSystem;
	g_pServerSystem = svrmap;
	GAMERESRCMNGR->SetLoadMapNum(mapnum);
	GAMERESRCMNGR->LoadRevivePoint();
	start(mapnum);
	_currentmap = _nextmap = mapnum;
	return true;
}

void WarpMap::start(int mapnum)
{
	if( svrmap) svrmap->Start(mapnum);
}

void WarpMap::setNetData(MoonBase* zz)
{
	g_Network.setLuna( zz);
	g_DB.setLuna( zz );
}

void WarpMap::parseIN(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength)
{
	ReceivedMsgFromUser(dwConnectionIndex,pMsg,dwLength  );
}
void WarpMap::Update()
{
	if( svrmap ) svrmap->Process();
}
void WarpMap::parseINSVR(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength)
{
	ReceivedMsgFromServer(dwConnectionIndex,pMsg,dwLength  );
}
void WarpMap::AskChannel(unsigned int mapnum)
{
	CHANNELSYSTEM->setAskCh(mapnum);
}
void WarpMap::ChangeMap(unsigned int mapnum)
{
	if( mapnum != _currentmap){
			_currentmap = mapnum;
			GAMERESRCMNGR->SetLoadMapNum(mapnum);
			svrmap->StartRE(mapnum);
		}
}
void WarpMap::ondisconnectuser(unsigned int connidx)
{
	//svrmap->RemovePlayer( userid );
}
void WarpMap::end()
{
	if( svrmap ) svrmap->End();
}
void WarpMap::updatemove()
{
}
