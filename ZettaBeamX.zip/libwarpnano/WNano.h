#ifndef WNANO_H
#define WNANO_H

#include <string>
#include <vector>
#include <functional>
namespace nanodbc {
	class result;
	class connection;
};

struct MYquery
{
	nanodbc::result* resl;
	unsigned int dwcoll;
	unsigned int getDataUINT(int coll);
	int getDataINT(int coll);
	int64_t getDataINT64(int coll);
	std::string getSTR(int coll);
	std::vector<char> getVCHAR(int coll);
	float getFloat(int coll);
	bool isnextOK();
	MYquery()
	:resl(0),dwcoll(0)
	{}
};
/*
  pData->getDataINT(0);//
	std::string aabb = pData->getSTR(0);//
	pData->getSTR(0);//
	pData->getFloat(0);//
	&(pData->getSTR(0)[0]),//
  if( !pData->isnextOK() ) return;
	coun++;
	if( !pData->isnextOK() ) break;
	MapDBMsgParser.cpp:4205
*/
struct mydbmessage
{
	unsigned int dwID;
};

class WNano
{
public:
	WNano();
	~WNano();

};


#define LPQUERY MYquery*
#define LPDBMESSAGE mydbmessage*
#define LPMIDDLEQUERY MYquery*
#define MIDDLEQUERYST MYquery
#define LPLARGEQUERY MYquery*


typedef std::function<void(LPQUERY,LPDBMESSAGE)> CB_func;


#endif // WNANO_H


