#include <windows.h>
#include <sqlext.h>
#include "WNano.h"
#include "nanodbc/nanodbc.h"

int naive_atoi( char* khj){
	char *ptt = khj;
	int ret = 0;
	bool isneg = false;
	while( *ptt != '\0'){
		char poa = *ptt;
		if( poa == '.' || poa == ',') break;
		if( poa == '-' && ret == 0){
			isneg = true;
			++ptt;
			continue;
		}
		if( poa >= '0' && poa <= '9'){
			ret *= 10;
			ret += ( poa - '0' );
			++ptt;
			continue;
		}
		++ptt;
	}
	if(isneg) ret = -(ret);
	return ret;
}
int64_t naive_atoi64( char* khj){
	char *ptt = khj;
	int64_t ret = 0;
	bool isneg = false;
	while( *ptt != '\0'){
		char poa = *ptt;
		if( poa == '.' || poa == ',') break;
		if( poa == '-' && ret == 0){
			isneg = true;
			++ptt;
			continue;
		}
		if( poa >= '0' && poa <= '9'){
			ret *= 10;
			ret += ( poa - '0' );
			++ptt;
			continue;
		}
		++ptt;
	}
	if(isneg) ret = -(ret);
	return ret;
}

unsigned int MYquery::getDataUINT(int coll)
{
	if( coll < resl->columns() && !resl->is_null(coll) ){
		bool isstring = false;
		int coltype = resl->column_datatype(coll);
		if(coltype == SQL_CHAR || 
			coltype == SQL_VARCHAR || 
			//coltype == SQL_NVARCHAR || 
			coltype == SQL_WCHAR || 
			coltype == SQL_WVARCHAR || 
			coltype == SQL_WVARCHAR || 
			coltype == SQL_LONGVARCHAR
			){ isstring = true; }
		if( isstring ){
			std::string jkl = getSTR(coll);
			//return std::stoi(getSTR(coll));
			return naive_atoi( &(jkl[0]));
		}
		return resl->get<unsigned int>(coll);
	}
	return 0;
}
int MYquery::getDataINT(int coll)
{
	int coloumd = resl->columns();
//	if(coll < coloumd && resl->is_null(coll)){
//		printf("getDataINT is null\n");
//		return 0;
//	}
	
	if( coll < coloumd && !resl->is_null(coll)){
		bool isstring = false;
		int coltype = resl->column_datatype(coll);
		if(coltype == SQL_CHAR || 
			coltype == SQL_VARCHAR || 
			//coltype == SQL_NVARCHAR || 
			coltype == SQL_WCHAR || 
			coltype == SQL_WVARCHAR || 
			coltype == SQL_WVARCHAR || 
			coltype == SQL_LONGVARCHAR
			){ isstring = true; }
		if( isstring ){
			std::string jkl = getSTR(coll);
			//return std::stoi(getSTR(coll));
			return naive_atoi(&(jkl[0]));
		}
		return resl->get<int>(coll);
	}
	return 0;
}
int64_t MYquery::getDataINT64(int coll)
{
	int coloumd = resl->columns();
	if( coll < coloumd && !resl->is_null(coll) ){
		bool isstring = false;
		int coltype = resl->column_datatype(coll);
		if(coltype == SQL_CHAR || 
			coltype == SQL_VARCHAR || 
			//coltype == SQL_NVARCHAR || 
			coltype == SQL_WCHAR || 
			coltype == SQL_WVARCHAR || 
			coltype == SQL_WVARCHAR || 
			coltype == SQL_LONGVARCHAR
			){ isstring = true; }
		if( isstring ){
			std::string jkl = getSTR(coll);
			return naive_atoi64(&(jkl[0]));
		}
		return resl->get<int64_t>(coll);
	}
	return 0;
}

std::string MYquery::getSTR(int coll)
{
	if( coll < resl->columns() && !resl->is_null(coll) ){
		std::string ret = resl->get<std::string>(coll);
		return ret;
	}
	return "";
}

float MYquery::getFloat(int coll)
{
	if( coll < resl->columns() ){
		float ret = atof( getSTR(coll).c_str() );
		return ret;
	}
	return 0.f;
}
bool MYquery::isnextOK()
{
  bool ret = false;
  if( resl->columns() != 0 ) ret = resl->next();
	return ret;
}
std::vector<char> MYquery::getVCHAR(int coll)
{
	std::vector<char> ret;
	if( coll < resl->columns() && !resl->is_null(coll)){
		std::vector<std::uint8_t> ret0 = resl->get< std::vector< std::uint8_t > >(coll); 
		ret.assign(ret0.begin(),ret0.end() );
	}
	return ret;
}

WNano::WNano()
{
}

WNano::~WNano()
{
}
