#include <stdio.h>
#include <string>
#include <time.h>
#include <inttypes.h>
#include <fstream>
#include <map>

int main(int argc, char **argv)
{
	std::map<int, int> _mmtest;
	_mmtest[0] = 99;
	_mmtest[1] = 99;
	printf("%u %u\n",_mmtest[0],_mmtest[1]);
	_mmtest.clear();
	if( _mmtest.find(0) != _mmtest.end()){
		printf("%u %u\n",_mmtest[0],_mmtest[1]);
	} else {
		printf("cleared.\n");
	}
	
	printf("hello world\n");
	__time64_t mytime = 0;
	_time64(&mytime);
	printf("0x%X size time_t:%u %u \n",__MSVCRT_VERSION__,sizeof(time_t),
		sizeof(__time64_t)
	);
	printf("mytime %I64u\n", mytime);
	__time64_t atime = 0xffffffff;
	mytime += atime * 0xf;
	uint64_t aaa = mytime;
	printf( "0x%I64x %I64u\n",aaa,aaa);
	std::string aa = "aaaaaaaaaaa";
	aa = "zzzz";
	printf("%s\n",&(aa[0]));
	int yuu = -727861;
	unsigned int xaa = yuu;
	
	printf("%u\n",xaa);
	std::ifstream ifs("zconf.txt", std::ifstream::in);
	if( ifs.good() ) {
	std::string key,values,tempstr,gamedsn, gameusr, gamepwd, logdsn, logusr, logpwd, 
		memberdsn, memberusr, memberpwd;
	unsigned int nmn = 0;
	while( !ifs.eof() ){
		ifs >> tempstr;
		printf("%s\n",tempstr.c_str());
		nmn = tempstr.find("=");
		if( nmn != tempstr.npos){
			key.clear();
			values.clear();
			key.assign(&(tempstr[0]),&(tempstr[nmn])  );
			values = &(tempstr[nmn + 1]);
			for( char& cc : values){
				printf("%X", cc);
			}
			printf("\n");
		}
	}
	}
	
	 
	
	
	return 0;
}

