#ifndef __NETWORK_GUID_H__INCLUDED
#define __NETWORK_GUID_H__INCLUDED
#pragma once

//#include "stdafx.h"
// {11C02A88-8BF9-4863-A7DE-1BF66D60CBA3}
DEFINE_GUID(CLSID_4DyuchiNET, 
0x11c02a88, 0x8bf9, 0x4863, 0xa7, 0xde, 0x1b, 0xf6, 0x6d, 0x60, 0xcb, 0xa3);

// {D41BD0F8-07BF-4dbc-8AD3-A3524CC43E5E}
DEFINE_GUID(IID_4DyuchiNET, 
0xd41bd0f8, 0x7bf, 0x4dbc, 0x8a, 0xd3, 0xa3, 0x52, 0x4c, 0xc4, 0x3e, 0x5e);

#endif // __NETWORK_GUID_H__INCLUDED
