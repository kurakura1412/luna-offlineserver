#ifndef __ICONSOLE_GUID_H__INCLUDED
#define __ICONSOLE_GUID_H__INCLUDED
#pragma once

#include "stdafx.h"

// {DB6175A7-1DD7-40f2-BDFB-D5964CFA8157}
DEFINE_GUID(CLSID_4DyuchiCONSOLE, 
0xdb6175a7, 0x1dd7, 0x40f2, 0xbd, 0xfb, 0xd5, 0x96, 0x4c, 0xfa, 0x81, 0x57);



// {6DDB7E78-5C0A-4b5c-9427-3DDFF6068D59}
DEFINE_GUID(IID_4DyuchiCONSOLE, 
0x6ddb7e78, 0x5c0a, 0x4b5c, 0x94, 0x27, 0x3d, 0xdf, 0xf6, 0x6, 0x8d, 0x59);

#endif // __ICONSOLE_GUID_H__INCLUDED
