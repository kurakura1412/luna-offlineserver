// Network.h: interface for the CNetwork class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_NETWORK_H__19C7FECD_93EA_4809_9B83_4E0330849642__INCLUDED_)
#define AFX_NETWORK_H__19C7FECD_93EA_4809_9B83_4E0330849642__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// 

extern BOOL g_bReady;

// 080813 LUJ, ¼öÁ¤µÈ inetwork.dll ÂüÁ¶À§ÇØ ¼öÁ¤
//#include "..\4DYUCHINET_COMMON\inetwork.h"
//#include "ServerSystem.h"
#ifndef _MAPSERVER_
#ifdef _AGENT00_
struct MSGBASE;
#endif
#include "UserTable.h"
#endif

class MoonBase;

class CNetwork  
{
	//I4DyuchiNET* m_pINet;
	//friend class CDataBase;
	MoonBase * _lunasvr;
public:
	void setLuna( MoonBase * zz){ _lunasvr = zz;}
	CNetwork();
	virtual ~CNetwork();
	
	//I4DyuchiNET* GetINet()	{	return m_pINet;	}

	//void Init(DESC_NETWORK * desc);
	void Release();

	//void Start();
	//void BatchConnectToOtherServer();

	BOOL StartServerServer(char * szIP, int port);
	BOOL StartUserServer(char * szIP, int port);
	BOOL ConnectToServer(char * szIP, int port, void * pParam);

	void GetUserAddress(DWORD dwConnectionIndex, char* ip, WORD * port);
	
	//--------- send, recv process --------------------------------
	// map port
	void Send2Server(DWORD dwConnectionIndex, char * msg, DWORD size);
	void Send2AgentServer(char * msg, DWORD size);
	// desc_hseos_ÁÖ¹Îµî·Ï_01
	// S ÁÖ¹Îµî·Ï Ãß°¡ added by hseos 2007.12.31
	// ..Æ¯Á¤ ¿¡ÀÌÀüÆ® ¼­¹ö¿¡ º¸³»±â
	void Send2SpecificAgentServer(char * msg, DWORD size);
	// E ÁÖ¹Îµî·Ï Ãß°¡ added by hseos 2007.12.31

	// 080407 LYW --- Network : Add function to send message to distribute server.
	void Send2DistributeServer(char* pMsg, DWORD dwLength) ;
	void Send2AgentExceptThis(char* pMsg, DWORD dwLength) ;
	
	void Send2User(DWORD dwConnectionIndex, char * msg, DWORD size);
#ifdef _AGENTSERVER
	void Send2User(MSGBASE * msg, DWORD size);
#endif
#ifndef _MAPSERVER_
	void EnCrypt(USERINFO * userInfo, char* msg,DWORD size);
#endif
	void Broadcast2Server(char * msg, DWORD size);
	void Broadcast2User(MSGBASE * msg, DWORD size);
	void Broadcast2MapServer(char * msg, DWORD size);
	void Broadcast2MapServerExceptOne(DWORD dwConnectionIndex, char * msg, DWORD size);
	void Broadcast2AgentServer(char* msg, DWORD size);
	void Broadcast2AgentServerExceptOne(DWORD dwConnectionIndex, char* msg, DWORD size);
	void Broadcast2AgentServerExceptSelf(char* msg, DWORD size);
	//-------------------------------------------------------------
	
	void DisconnectUser(DWORD dwConnectionIndex);
	void OnMapChange(DWORD dwmapnum);
	void AskChannel(DWORD dwmapnum);
};

extern CNetwork g_Network;
#endif // !defined(AFX_NETWORK_H__19C7FECD_93EA_4809_9B83_4E0330849642__INCLUDED_)
