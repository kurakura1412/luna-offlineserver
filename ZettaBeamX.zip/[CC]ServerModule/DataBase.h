// DataBase.h: interface for the CDataBase class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DATABASE_H__D0B26A3A_97A2_4DBE_A14F_4C60C09FD809__INCLUDED_)
#define AFX_DATABASE_H__D0B26A3A_97A2_4DBE_A14F_4C60C09FD809__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// 090923 ONS ¸Þ¸ð¸®Ç® ±³Ã¼
#include <functional>
#include "[CC]Header/Pool.h"
//#include "DBThreadInterface.h"
#include <PtrList.h>
#include "db.h"
#if defined( _AGENT00_ ) || defined( _DIST00_ ) || defined( _MAP00_ )
#include "libwarpnano/WNano.h"
#endif
///////////////////////////////////////////////////////////////////////
// ÁÖÀÇ!!!
// MiddleQuery ÄÃ·³ °³¼ö : 20°³
//
///////////////////////////////////////////////////////////////////////

enum
{
	eQueryType_Update = 4,
	eQueryType_Insert = 2,
	eQueryType_Delete = 3,
	eQueryType_ExecuteIUD = 1,
	eQueryType_Bind = 7,
	eQueryType_ResultSet = 9,
	eQueryType_Login = 5,
	eQueryType_SimpleLogin = 6,
	eQueryType_FreeQuery = 101,
	eQueryType_SingleQuery = 102,
	eQueryType_SingleQueryDA = 103,
	eQueryType_FreeLargeQuery = 104,
	eQueryType_FreeMiddleQuery = 105,
};

class MoonBase;

class CDataBase  
{
	MoonBase * _lunasvr;
	DWORD m_MaxDBThreadNum;
	DWORD m_SameTimeQueryPerThread;

	//DBTH* m_pDB;
	
	/// 071222 DB Thread ºÐ¸®
	//DBTH* m_pLoginDB;
	//DBTH* m_pLogDB;
	/////////////////////////

//	friend void ReadDBResultMessage(int ThreadNum,DWORD ret, LPDBMESSAGE pMessage);
	// 081118 LUJ, Äõ¸® Ã³¸®°¡ ºÒ°¡´ÉÇÑ °æ¿ì Ç×»ó Å¥¿¡ ³Öµµ·Ï ¼öÁ¤
//	BOOL AddQueryQueue(DBQUERY* pQuery, DWORD index = 0);

	//---KES DB Process Fix 071114
	int m_curDBNum;
	//----------------------------

	BOOL m_bInit;

public:
	void setLuna( MoonBase *  zz){_lunasvr = zz;}
	//DBTH* GetCurDB(DWORD index = 0);

	//int GetQueryQueueCount() { return m_QueryQueue.GetCount(); }


	void ProcessingDBMessage();
	BOOL AllCleared();
	
	CDataBase();
	virtual ~CDataBase();

//	BOOL Init(DWORD MaxDBThread,DWORD MaxSameTimeQuery,BOOL bUsingLoginDB);
	void Release();

	BOOL LogQuery( BYTE QueryType, DWORD dwMessageID, DWORD ID, const char*, ... );
	//BOOL LogMiddleQuery(void* pReturnFunc, DWORD ID, const char*, ... );
	BOOL LogMiddleQuery(CB_func pReturnFunc, DWORD ID, const char*, ... );
	BOOL LoginQuery(BYTE QueryType,DWORD dwMessageID,DWORD ID,char* strQuery);
	//BOOL LoginMiddleQuery(void* pReturnFunc,DWORD ID,char* strQuery,...);
	BOOL LoginMiddleQuery(CB_func pReturnFunc,DWORD ID,char* strQuery,...);
	BOOL Query(BYTE QueryType,DWORD dwMessageID,DWORD ID,char* strQuery, DWORD index = 0);
	BOOL FreeQuery(DWORD dwMessageID,DWORD ID,char* strQuery,...);
	//BOOL FreeLargeQuery(void* pReturnFunc,DWORD ID,char* strQuery,...);
	BOOL FreeLargeQuery(CB_func pReturnFunc,DWORD ID,char* strQuery,...);
	//BOOL FreeMiddleQuery(void* pReturnFunc,DWORD ID,char* strQuery,...);
	BOOL FreeMiddleQuery(CB_func pReturnFunc,DWORD ID,char* strQuery,...);
	
	void ProcessingQueue();
};
typedef std::function<void(LPQUERY, LPDBMESSAGE)> DBMsgFunc;
extern DBMsgFunc g_DBMsgFunc[];
extern CDataBase g_DB;

#endif // !defined(AFX_DATABASE_H__D0B26A3A_97A2_4DBE_A14F_4C60C09FD809__INCLUDED_)
