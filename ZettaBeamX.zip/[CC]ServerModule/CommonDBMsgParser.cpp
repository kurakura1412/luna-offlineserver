//#include "stdafx.h"
#include "CommonDBMsgParser.h"
#include "DataBase.h"

void	ASSERTQuery(LPQUERY pData, LPDBMESSAGE pMessage)
{
	ASSERT(0);
}
