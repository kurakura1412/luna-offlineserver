// DataBase.cpp: implementation of the CDataBase class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#if defined( _AGENT00_ ) || defined( _DIST00_ ) || defined( _MAP00_ )
//#include "math.inl"
#include "yhlibrary.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "DataBase.h"

//#include "Console.h"
#include "Network.h"
//#include "CommonDBMsgParser.h"

// desc_hseos_DBÁ¢¼Ó01
// S DBÁ¢¼Ó Ãß°¡ added by hseos 2007.06.15
#include "MHFile.h"
// E DBÁ¢¼Ó Ãß°¡ added by hseos 2007.06.15

BOOL g_bWriteQuery = FALSE;

#define	WM_DB_MESSAGE  WM_USER+231

#ifdef _AGENTSERVER
#define THEDBA 11
#elif defined(_DISTRIBUTESERVER_)
#define THEDBA 13
#elif defined(_MAPSERVER_)
#define THEDBA 15
#endif
#define DBMEMBER 99
#define DBGAME 44
#define DBLOG	101
// desc_hseos_DBÁ¢¼Ó01
// S DBÁ¢¼Ó Ãß°¡ added by hseos 2007.06.15
// ..SQL Á¢¼Ó Á¤º¸¸¦ ÆÄÀÏ¿¡¼­ ÀÐ´Â´Ù. ÆÄÀÏÀÌ ¾øÀ¸¸é ¿ø·¡ ¼Ò½º¿¡¼­ ÀÐ´ø´ë·Î..
/*char	LOGINDBNAME[256]		= "LUNA_MEMBERDB";
char	LOGINDBID[256]			= "GameSrv";
char	LOGINDBPASSWORD[256]	= "luna";
char	LOGDBNAME[256]			= "LUNA_LOGDB";
char	LOGDBID[256]			= "GameSrv";
char	LOGDBPASSWORD[256]		= "luna";
char	GAMEDBNAME[256]			= "LUNA_GAMEDB";
char	GAMEDBID[256]			= "GameSrv";
char	GAMEDBPASSWORD[256]		= "luna";*/

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CDataBase g_DB;

extern HWND g_hWnd;

//////////////////////////////////////////////////////////////////////////
#include "LunaInterface.h"

CDataBase::CDataBase()
{
	//m_pDB		= NULL;
	/// 071222 DB Thread ºÐ¸®
	//m_pLoginDB	= NULL;
	//m_pLogDB	= NULL;
	/////////////////////////
	m_curDBNum	= 0;

	m_bInit		= FALSE;
	_lunasvr = nullptr;
}

CDataBase::~CDataBase()
{
	Release();
}
BOOL CDataBase::AllCleared()
{

	return TRUE;
}
void CDataBase::Release()
{

}


BOOL CDataBase::LoginQuery(BYTE QueryType,DWORD dwMessageID,DWORD ID,char* strQuery)
{
/* 	if(m_pDB == NULL)	return FALSE; // ÀÌ¹Ì ReleaseµÈ °æ¿ì

	DBQUERY* pQuery = m_QueryPool.Alloc();	//
	ASSERT(pQuery);
	pQuery->SetQuery(DBTH::eDBCON_LOGIN,QueryType,dwMessageID,strQuery,ID);

	return AddQueryQueue(pQuery); */
	if( !_lunasvr ) return FALSE;
	std::string stds = strQuery;
	_lunasvr->PushQuery(DBMEMBER, THEDBA,ID,g_DBMsgFunc[dwMessageID],stds  );
	return TRUE;
}

//BOOL CDataBase::LoginMiddleQuery(void* pReturnFunc,DWORD ID,char* strQuery,...)
BOOL CDataBase::LoginMiddleQuery(CB_func pReturnFunc,DWORD ID,char* strQuery,...)
{
/* 	static char temp[4096];
	va_list vl;
	va_start(vl, strQuery);
	vsprintf(temp, strQuery, vl);
	va_end(vl);
	
	DBQUERY* pQuery = m_QueryPool.Alloc();
	ASSERT(pQuery);
	pQuery->SetQuery(DBTH::eDBCON_LOGIN,eQueryType_FreeMiddleQuery,(DWORD)pReturnFunc,temp,ID);

	AddQueryQueue(pQuery); */
	if( !_lunasvr ) return FALSE;
	std::string sdfs;
	{
		char temp[4096] = {0};
		va_list vl;
		va_start(vl, strQuery);
		vsprintf(temp, strQuery, vl);
		va_end(vl);
		sdfs = &(temp[0]);
	}
	_lunasvr->PushQuery(DBMEMBER, THEDBA,ID, pReturnFunc,sdfs  );
	
	return TRUE;
}

BOOL CDataBase::Query(BYTE QueryType,DWORD dwMessageID,DWORD ID,char* strQuery, DWORD index)
{
/* 	if(m_pDB == NULL)	return FALSE; // ÀÌ¹Ì ReleaseµÈ °æ¿ì

	DBQUERY* pQuery = m_QueryPool.Alloc();
	ASSERT(pQuery);
	pQuery->SetQuery(DBTH::eDBCON_ADMIN,QueryType,dwMessageID,strQuery,ID);

	AddQueryQueue(pQuery, index); */
	if( !_lunasvr ) return FALSE;
	std::string sdfs = strQuery;
	_lunasvr->PushQuery(DBGAME, THEDBA,ID, g_DBMsgFunc[dwMessageID],sdfs  );
	return TRUE;
}

BOOL CDataBase::LogQuery( BYTE QueryType, DWORD dwMessageID, DWORD ID, const char* strQuery, ... )
{
/* 	if(m_pDB == NULL)	return FALSE; // ÀÌ¹Ì ReleaseµÈ °æ¿ì

	static char temp[4096];
	va_list vl;
	va_start(vl, strQuery);
	vsprintf(temp, strQuery, vl);
	va_end(vl);

	DBQUERY* pQuery = m_QueryPool.Alloc();
	ASSERT(pQuery);
	pQuery->SetQuery(DBTH::eDBCON_LOG,QueryType,dwMessageID, temp,ID);

	AddQueryQueue(pQuery); */
	if( !_lunasvr ) return FALSE;
	std::string sdfs;
	{
		char temp[4096] = {0};
		va_list vl;
		va_start(vl, strQuery);
		vsprintf(temp, strQuery, vl);
		va_end(vl);
		sdfs = &(temp[0]);
	}
	_lunasvr->PushQuery(DBLOG, THEDBA,ID, NULL,sdfs  );
	return TRUE;
}


//BOOL CDataBase::LogMiddleQuery( void* pReturnFunc, DWORD ID, const char* strQuery, ... )
BOOL CDataBase::LogMiddleQuery( CB_func pReturnFunc, DWORD ID, const char* strQuery, ... )
{
/* 	static char temp[4096];
	va_list vl;
	va_start(vl, strQuery);
	vsprintf(temp, strQuery, vl);
	va_end(vl);

	DBQUERY* pQuery = m_QueryPool.Alloc();
	ASSERT(pQuery);
	pQuery->SetQuery(DBTH::eDBCON_LOG,eQueryType_FreeMiddleQuery,(DWORD)pReturnFunc,temp,ID);

	AddQueryQueue(pQuery); */
	if( !_lunasvr ) return FALSE;
	std::string sdfs;
	{
		char temp[4096] = {0};
		va_list vl;
		va_start(vl, strQuery);
		vsprintf(temp, strQuery, vl);
		va_end(vl);
		sdfs = &(temp[0]);
	}
	_lunasvr->PushQuery(DBLOG, THEDBA,ID, NULL,sdfs  );
	return TRUE;
}


BOOL CDataBase::FreeQuery(DWORD dwMessageID, DWORD ID, char* strQuery,...)
{
/* 	if(m_pDB == NULL)	return FALSE; // ÀÌ¹Ì ReleaseµÈ °æ¿ì

	static char temp[4096];
	va_list vl;
	va_start(vl, strQuery);
	vsprintf(temp, strQuery, vl);
	va_end(vl);
	
	
	DBQUERY* pQuery = m_QueryPool.Alloc();
	ASSERT(pQuery);
	pQuery->SetQuery(DBTH::eDBCON_ADMIN,eQueryType_FreeQuery,dwMessageID,temp,ID);
	// 081118 LUJ, ÀÎÀÚ¿¡ µû¶ó Ã³¸®ÇÒ ½º·¹µå°¡ Á¤ÇØÁöµµ·Ï ÇÑ´Ù
	AddQueryQueue(pQuery, ID); */
	if( !_lunasvr ) return FALSE;
	std::string sdfs;
	{
		char temp[4096] = {0};
		va_list vl;
		va_start(vl, strQuery);
		vsprintf(temp, strQuery, vl);
		va_end(vl);
		sdfs = &(temp[0]);
	}
	_lunasvr->PushQuery(DBGAME, THEDBA,ID, g_DBMsgFunc[dwMessageID],sdfs  );
	return TRUE;
}

//BOOL CDataBase::FreeLargeQuery(void* pReturnFunc,DWORD ID,char* strQuery,...)
BOOL CDataBase::FreeLargeQuery(CB_func pReturnFunc,DWORD ID,char* strQuery,...)
{
/* 	if(m_pDB == NULL)	return FALSE; // ÀÌ¹Ì ReleaseµÈ °æ¿ì

	static char temp[4096];
	va_list vl;
	va_start(vl, strQuery);
	vsprintf(temp, strQuery, vl);
	va_end(vl);
	
	DBQUERY* pQuery = m_QueryPool.Alloc();
	ASSERT(pQuery);
	pQuery->SetQuery(DBTH::eDBCON_ADMIN,eQueryType_FreeLargeQuery,(DWORD)pReturnFunc,temp,ID);
	// 081118 LUJ, ÀÎÀÚ¿¡ µû¶ó Ã³¸®ÇÒ ½º·¹µå°¡ Á¤ÇØÁöµµ·Ï ÇÑ´Ù
	AddQueryQueue(pQuery, ID); */
	if( !_lunasvr ) return FALSE;
	std::string sdfs;
	{
		char temp[4096] = {0};
		va_list vl;
		va_start(vl, strQuery);
		vsprintf(temp, strQuery, vl);
		va_end(vl);
		sdfs = &(temp[0]);
	}
	_lunasvr->PushQuery(DBGAME, THEDBA,ID, pReturnFunc,sdfs  );
	return TRUE;
}

//BOOL CDataBase::FreeMiddleQuery(void* pReturnFunc,DWORD ID,char* strQuery,...)
BOOL CDataBase::FreeMiddleQuery(CB_func pReturnFunc,DWORD ID,char* strQuery,...)
{
/* 	if(m_pDB == NULL)	return FALSE; // ÀÌ¹Ì ReleaseµÈ °æ¿ì
	
	static char temp[4096];
	va_list vl;
	va_start(vl, strQuery);
	vsprintf(temp, strQuery, vl);
	va_end(vl);
	
	DBQUERY* pQuery = m_QueryPool.Alloc();
	ASSERT(pQuery);
	pQuery->SetQuery(DBTH::eDBCON_ADMIN,eQueryType_FreeMiddleQuery,(DWORD)pReturnFunc,temp,ID);
	// 081118 LUJ, ÀÎÀÚ¿¡ µû¶ó Ã³¸®ÇÒ ½º·¹µå°¡ Á¤ÇØÁöµµ·Ï ÇÑ´Ù
	AddQueryQueue(pQuery, ID); */
	if( !_lunasvr ) return FALSE;
	std::string sdfs;
	{
		char temp[4096] = {0};
		va_list vl;
		va_start(vl, strQuery);
		vsprintf(temp, strQuery, vl);
		va_end(vl);
		sdfs = &(temp[0]);
	}
	_lunasvr->PushQuery(DBGAME, THEDBA,ID, pReturnFunc,sdfs  );
	return TRUE;
}

// Ç×»ó È£ÃâµÇ¾î¾ß ÇÏ´Â °Í
void CDataBase::ProcessingDBMessage()
{

}

void CDataBase::ProcessingQueue()
{

}
