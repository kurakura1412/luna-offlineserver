#include "stdafx.h"

#if defined( _AGENT00_ ) || defined( _DIST00_ ) || defined( _MAP00_ )
//#include "math.inl"
#include "yhlibrary.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "Network.h"
//#include "Network_guid.h"
#include "ServerTable.h"

#ifdef _AGENTSERVER
//#include "TrafficLog.h"
#include "UserTable.h"
#endif

#include "hseos/Debug/SHDebug.h"
#include "LunaInterface.h"
#include "CommonGameFunc.h"

BOOL g_bReady = FALSE;

// ³×Æ®¿öÅ©¿Í °ü·Ã µÈ Ã³¸®µéÀº ¿©±â¼­ ´ÙÇÔ.
// send, recv, get info
CNetwork g_Network;

CNetwork::CNetwork()
{
//	m_pINet = NULL;
_lunasvr = nullptr;
}

CNetwork::~CNetwork()
{}

void CNetwork::Release()
{
	//SAFE_RELEASE(		m_pINet);
}


/* void CNetwork::Init(DESC_NETWORK * desc)
{
	if(!g_pServerTable) return;
	
	HRESULT hr;
	hr = CoCreateInstance( CLSID_4DyuchiNET, NULL, CLSCTX_INPROC_SERVER, IID_4DyuchiNET, (void**)&m_pINet);
	if (FAILED(hr))
		return;
	// 080813 LUJ, ¼öÁ¤µÈ inetwork.dllÀº 4°³ÀÇ ÀÎÀÚ °ªÀ» ¹Þ´Â´Ù
	if(!m_pINet->CreateNetwork(desc,0,0,0))
		return;
} */

BOOL CNetwork::StartServerServer(char * szIP, int port)
{
	//return m_pINet->StartServerWithServerSide(szIP,(WORD)port);
	return TRUE;
}
BOOL CNetwork::StartUserServer(char * szIP, int port)
{
	//return m_pINet->StartServerWithUserSide(szIP, (WORD)port);
	return TRUE;
}
BOOL CNetwork::ConnectToServer(char * szIP, int port, void * pParam)
{
	//return m_pINet->ConnectToServerWithServerSide(szIP,(WORD)port, OnConnectServerSuccess, OnConnectServerFail, pParam);
	return TRUE;
}

void CNetwork::Send2Server(DWORD dwConnectionIndex, char * msg, DWORD size)
{
	if(_lunasvr) _lunasvr->Send2Server(dwConnectionIndex, msg, size);

}

void CNetwork::Send2AgentServer(char * msg, DWORD size)
{
	if(_lunasvr) _lunasvr->Send2AgentServer( msg, size);

}

void CNetwork::Send2SpecificAgentServer(char * msg, DWORD size)
{
	if(_lunasvr) _lunasvr->Send2SpecificAgentServer( msg, size);

}
// E ÁÖ¹Îµî·Ï Ãß°¡ added by hseos 2007.12.31

void CNetwork::Send2User(DWORD dwConnectionIndex, char * msg, DWORD size)
{
	if(_lunasvr) _lunasvr->Send2User(dwConnectionIndex, msg, size);
}


#ifdef _AGENTSERVER

void CNetwork::Send2User(MSGBASE * msg, DWORD size)
{
	if(_lunasvr) _lunasvr->Send2User(4,(char*)msg,size );
}

#endif

#ifndef _MAPSERVER_	//¸Ê¼­¹ö¸¸ ¾ÏÈ£È­ ¾ÈÇÑ´Ù.

void CNetwork::EnCrypt(USERINFO * userInfo, char* msg,DWORD size)
{

}
#endif

void CNetwork::Broadcast2Server(char * msg, DWORD size)
{

	if(_lunasvr) _lunasvr->Broadcast2Server( msg, size);
}

void CNetwork::Broadcast2User(MSGBASE * msg, DWORD size)
{

	if(_lunasvr) _lunasvr->Broadcast2User( (char*)msg, size);
}

void CNetwork::Broadcast2MapServer(char * msg, DWORD size)
{

	if(_lunasvr) _lunasvr->Broadcast2MapServer( msg, size);
}

void CNetwork::Broadcast2MapServerExceptOne(DWORD dwConnectionIndex, char * msg, DWORD size)
{
	if(_lunasvr) _lunasvr->Broadcast2MapServerExceptOne(dwConnectionIndex, msg, size);
}

void CNetwork::Broadcast2AgentServer(char* msg, DWORD size)
{

	if(_lunasvr) _lunasvr->Broadcast2AgentServer( msg, size);
}

void CNetwork::Broadcast2AgentServerExceptSelf(char* msg, DWORD size)
{

	if(_lunasvr) _lunasvr->Broadcast2AgentServerExceptSelf( msg, size);
}

void CNetwork::Broadcast2AgentServerExceptOne(DWORD dwConnectionIndex, char* msg, DWORD size)
{
	if(_lunasvr) _lunasvr->Broadcast2AgentServerExceptOne(dwConnectionIndex, msg, size);
}
void CNetwork::GetUserAddress(DWORD dwConnectionIndex, char* ip, WORD * port)
{
//	m_pINet->GetUserAddress(dwConnectionIndex, ip, port);
	SafeStrCpy(ip, "127.0.0.1",16 );
	//*port = 0;
}

void CNetwork::DisconnectUser(DWORD dwConnectionIndex)
{
//	m_pINet->CompulsiveDisconnectUser(dwConnectionIndex);
	if(_lunasvr) _lunasvr->DisconnectUser(dwConnectionIndex);
}

// 080407 LYW --- Network : Add function to send message to distribute server.
void CNetwork::Send2DistributeServer(char* pMsg, DWORD dwLength)
{
	if(_lunasvr) _lunasvr->Send2DistributeServer( pMsg, dwLength);
}

void CNetwork::Send2AgentExceptThis(char* pMsg, DWORD dwLength)
{
	if(_lunasvr) _lunasvr->Send2AgentExceptThis( pMsg, dwLength);
}

void CNetwork::OnMapChange(DWORD dwmapnum)
{
	if(_lunasvr) _lunasvr->ChangeMap(dwmapnum);
}
void CNetwork::AskChannel(DWORD dwmapnum)
{
	if(_lunasvr) _lunasvr->AskedChannelMap(dwmapnum);
}