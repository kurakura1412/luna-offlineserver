// Console.cpp: implementation of the CConsole class.
// ���ڿ���
//////////////////////////////////////////////////////////////////////

#ifdef _DIST00_
#include "[Server]Distribute/stdafx.h"
#elif defined(_AGENT00_)
#include "[Server]Agent/stdafx.h"
#elif defined(_MAP00_)
#include "[Server]Map/stdafx.h"
#endif 
#include "Console.h"
#include <stdio.H>

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CConsole g_Console;

CConsole::CConsole()
{
//	m_pIConsole = NULL;
//	CoInitialize(NULL);
}

CConsole::~CConsole()
{
//	CoUninitialize();
}

/*
BOOL CConsole::Init(int MaxButton,CUSTOM_BUTTON* pButtonInfo, void (*CommandFunc)(char* szCommand))
{	

	// ¿ì¼± I4DyuchiCOSOLE÷³® »ý¼º
	HRESULT hr;
    
	hr = CoCreateInstance(
           CLSID_4DyuchiCONSOLE,
           NULL,
           CLSCTX_INPROC_SERVER,
           IID_4DyuchiCONSOLE,
           (void**)&m_pIConsole);

	
	if(FAILED(hr))
		return FALSE;


	//
	DISPLAY_INFO	display;
	display.dwMaxAccessibleThreadNum = 5;		//  
	display.dwMaxStringBufferNum = 10000;		// ´ë 10000
	display.dwMinMaintainBufferNum = 5000;		// 10000-5000
	display.dwDisplayRefreshRate = 1000;		// 500ms
	display.dwFilteredLevel = LOG_DEBUG;		// LOG_DEBUG
	
	
	WRITE_FILE_INFO	file;
	file.dwMaxAccessibleThreadNum = 5;			//  
	file.dwLimitedBufferSizeToWriteFile = 8192;	//
	file.dwFilteredLevel = LOG_DEBUG;			// 

	DESC_CONSOLE	desc;

	desc.OnCommandFunc = CommandFunc;				//  parsing 
	desc.dwCustomButtonNum = MaxButton;			// 
	desc.pCustomButton = pButtonInfo;			// 
	desc.szFileName = "log.txt";				// write  NULL
	desc.pDisplayInfo = &display;				//
	desc.pWriteFileInfo = &file;				//  WRITE_FILE_INFO  NULL

	m_pIConsole->CreateConsole(&desc);			// 

	return true;
}
*/

/* BOOL CConsole::Init(int MaxButton,MENU_CUSTOM_INFO* pMenuInfo, cbRetrnFunc commandFunc)
{
	HRESULT hr;
	
	hr = CoCreateInstance(
           CLSID_ULTRA_TCONSOLE,
           NULL,
           CLSCTX_INPROC_SERVER,
           IID_ITConsole,
           (void**)&m_pIConsole);

	
	if(FAILED(hr))
		return FALSE;

	LOGFONT logFont;
	logFont.lfHeight		= 14; 
	logFont.lfWidth			= 0; 
	logFont.lfEscapement	= 0; 
	logFont.lfOrientation	= 0; 
	logFont.lfWeight		= 600; 
	logFont.lfItalic		= 0; 
	logFont.lfUnderline		= 0; 
	logFont.lfStrikeOut		= 0; 
	logFont.lfCharSet		= DEFAULT_CHARSET; 
	logFont.lfOutPrecision	= 0; 
	logFont.lfClipPrecision	= 0; 
	logFont.lfQuality		= 0; 
	logFont.lfPitchAndFamily	= 0; 
	strcpy(logFont.lfFaceName, "Arial"); 

	HWND hWnd;
	MHTCONSOLE_DESC	desc;
	desc.szConsoleName = "Darkstory";
	desc.dwRefreshRate = 1000;
	desc.wLogFileType = LFILE_DESTROYLOGFILEOUT;//0;//LFILE_LOGOVERFLOWFILEOUT;
	desc.szLogFileName = "./Log/ConsoleLog.txt";
	desc.dwFlushFileBufferSize = 10000;
	desc.dwDrawTimeOut	= 1000*60*3;
	desc.wMaxLineNum = 1000;
	desc.dwListStyle = TLO_NOTMESSAGECLOSE|TLO_LINENUMBER|TLO_SCROLLTUMBTRACKUPDATE;
	desc.Width	= 800;
	desc.Height = 400;
	desc.pFont = &logFont;

	desc.nCustomMunuNum = MaxButton;
	desc.cbReturnFunc = commandFunc;
	desc.pCustomMenu = pMenuInfo;
	m_pIConsole->CreateConsole(&desc, &hWnd);

	return TRUE;
} */

void CConsole::Release()
{
/* 	if(m_pIConsole)
	{
		m_pIConsole->Release();
		m_pIConsole = NULL;
	} */
	
}

void CConsole::Log(int LogType,int MsgLevel,char* LogMsg,...)
{
	static char   va_Temp_Buff[1024];
	
	va_list vl;

	va_start(vl, LogMsg);
	vsprintf(va_Temp_Buff, LogMsg, vl);
	va_end(vl);


	switch(LogType) 
	{
	case eLogDisplay:
		{
		//	080130 LUJ, 	���ڿ��� NULL�� ������ ���� ��� �ܼ��� �������鼭
		//					�������� ����Ǵ� ���� �����ϱ� ���� �ִ� ���ڿ� ����
		//					ũ�⸸ŭ�� ����ϵ��� ��
		//	m_pIConsole->OutputFile(va_Temp_Buff, sizeof( va_Temp_Buff ) );
		printf( "%s\n",va_Temp_Buff );
			break;
		}		
	case eLogFile:
		{
			//m_pIConsole->WriteFile(va_Temp_Buff,strlen(va_Temp_Buff),MsgLevel);
		}
		break;
	default:
		MessageBox(NULL,"Not Defined LogType",0,0);
	}
}

void CConsole::LOG(int MsgLevel,char* LogMsg,...)
{
	static char   va_Temp_Buff[1024];
	
	va_list vl;

	va_start(vl, LogMsg);
	vsprintf(va_Temp_Buff, LogMsg, vl);
	va_end(vl);

	//if( m_pIConsole )
	//{
		// 080130 LUJ, 	���ڿ��� NULL�� ������ ���� ��� �ܼ��� �������鼭
		//				�������� ����Ǵ� ���� �����ϱ� ���� �ִ� ���ڿ� ����
		//				ũ�⸸ŭ�� ����ϵ��� ��
		//m_pIConsole->OutputDisplay(va_Temp_Buff, sizeof( va_Temp_Buff ) );
		printf( "%s\n",va_Temp_Buff );
	//}
	
}

void CConsole::WaitMessage()
{
	//m_pIConsole->MessageLoop();
}
