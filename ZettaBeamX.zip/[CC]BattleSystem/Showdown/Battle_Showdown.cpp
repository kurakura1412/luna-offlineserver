#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "Battle_Showdown.h"
#include "BattleTeam_Showdown.h"
#include "Object.h"
#include "ObjectStateManager.h"
#include "PartyManager.h"
#include "Party.h"
#include "PKManager.h"
#include "pet.h"
#ifdef _MAPSERVER_
#include "ObjectStateManager.h"
#include "UserTable.h"
#include "Player.h"
#include "PackedData.h"
#include "[cc]skill/server/manager/skillmanager.h"
#include "[cc]skill/server/object/skillobject.h"
#else
#include "interface/cWindowManager.h"
#include "Interface/cScriptManager.h"
#include "ObjectManager.h"
#include "TileManager.h"
#include "MHMap.h"
#include "ChatManager.h"
#endif

// 070201 LYW --- Include game resorce manager.
#include "[CC]Header/GameResourceManager.h"

CBattle_Showdown::CBattle_Showdown()
{
	m_BattleFlag = BATTLE_FLAG_NONE;
#ifndef _MAPSERVER_
	m_pCurShowImage	= NULL;
#endif
}

CBattle_Showdown::~CBattle_Showdown()
{

}

void CBattle_Showdown::Initialize(BATTLE_INFO_BASE* pCreateInfo, CBattleTeam* pTeam1, CBattleTeam* pTeam2)
{
	CBattle::Initialize(pCreateInfo,&m_Team[0],&m_Team[1]);
}


//////////////////////////////////////////////////////////////////////////
// { start virtual func ¹Ýµå½Ã ¿À¹ö¶óÀÌµù ÇØ¾ßÇÔ




// Battle Á¤º¸ °ü·Ã
#ifdef _MAPSERVER_
void CBattle_Showdown::GetBattleInfo(char* pInfo,WORD* size)
{
	BATTLE_INFO_SHOWDOWN* info = (BATTLE_INFO_SHOWDOWN*)pInfo;

	memcpy(info,&m_ShowdownInfo,sizeof(BATTLE_INFO_SHOWDOWN));
	
	ToEachTeam(pTeam)
		CBattleTeam_Showdown* pTeamVM	= (CBattleTeam_Showdown*)pTeam;
		info->Character[TeamNumber] = pTeamVM->GetCharacterID();
	EndToEachTeam
	
	*size = sizeof(BATTLE_INFO_SHOWDOWN);
}
/*
void CBattle_Showdown::GetBattleInfo(BATTLE_INFO_BASE*& pInfo,int& size)
{
	pInfo = &m_ShowdownInfo;
	size = sizeof(BATTLE_INFO_BASE);
}
*/
#endif



// Àû,¾Æ±º ±¸º°
BOOL CBattle_Showdown::IsEnemy(CObject* pOperator,CObject* pTarget)
{
	if( pOperator->GetObjectKind() == eObjectKind_Player )
	{
		if( pTarget->GetObjectKind() & eObjectKind_Monster )	// ¸ó½ºÅÍ´Â ÀûÀÌ´Ù
		{
			return TRUE;
		}
		else if( pTarget->GetObjectKind() == eObjectKind_Player )	//Å¸°ÙÀÌ ÇÃ·¹ÀÌ¾î ÀÏ°æ¿ì
		{
			/////¿©±â Á¤¸®ÇÏ°í!!!!!!!!!
			/////ºñ¹«·Î Á×°í ´Ù½Ã µÇ»ì¾Æ ³¯¶§! ±×¶§ ºñ¹«·Î Á×¾ú´ÂÁö PK·Î Á×¾ú´ÂÁö È®ÀÎÇÒ°Í!

			if( pOperator->GetBattleID() == pTarget->GetBattleID() &&
				pOperator->GetBattleTeam() != pTarget->GetBattleTeam() &&
				GetBattleState() == eBATTLE_STATE_FIGHT )
				return TRUE;	// º£Æ²¾ÆÀÌµð°¡ °°°í ÆÀÀÌ ´Ù¸£´Ù¸é ÀûÀÌ´Ù.	//ºñ¹«»ó Àû

#ifdef _MAPSERVER_
			if( ((CPlayer*)pOperator)->GetPartyIdx() != 0 )
			{
				CParty* pParty = PARTYMGR->GetParty( ((CPlayer*)pOperator)->GetPartyIdx() );
				if( pParty )
				if( pParty->IsPartyMember( pTarget->GetID() ) )
				{
					return FALSE;	//ÆÄÆ¼¿øÀº ÀûÀÌ ¾Æ´Ï´Ù.
				}
			}
#else
			if( pOperator == HERO )
			{
				if( PARTYMGR->IsPartyMember( pTarget->GetID() ) )
				{
//					if( OBJECTMGR->GetSelectedObjectID() == pTarget->GetID() )
//					{ //¹üÀ§°ø°ÝÀ¸·Î ÆÄÆ¼¿øÀ» °ø°ÝÇÒ¶§´Â ¸Þ¼¼Áö ¾ø°Ô ÇÏ±â À§ÇØ
//						CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(630) );
//					}
					return FALSE;	//ÆÄÆ¼¿øÀº ÀûÀÌ ¾Æ´Ï´Ù.
				}
			}
#endif
//---KES CHEAT PKEVENT ¾Æ·¡ ÁÖ¼®Ã³¸®ÇÏ¿© Çã¿ëÁö¿ª ¾Æ´Ï¶óµµ ÀÌº¥Æ® °¡´ÉÇÏµµ·Ï
//			if( PKMGR->IsPKAllow() )
			{
				if( ((CPlayer*)pOperator)->IsPKMode() )				
				{
					if(pOperator == pTarget )
						return FALSE;
					else
						return TRUE;	//ÀÚ½ÅÀÌ PK¸ðµåÀÌ¸é ÀÚ½ÅÀ» »« ³ª¸ÓÁö´Â ÀûÀÌ´Ù.
				}
				if( ((CPlayer*)pTarget)->IsPKMode() )
					return TRUE;	//»ó´ë°¡ PK¸ðµåÀÌ¸é ÀûÀÌ´Ù.
			}

			return FALSE;
		}
		else if( pOperator->GetObjectKind() & eObjectKind_Monster )
		{	// Operator °¡ ¸ó½ºÅÍÀÏ°æ¿ì	//»ç½Ç ¿©±â °É¸± ÀÏÀÌ ¾ø´Ù. ¸ó½ºÅÍ´Â ºñ¹«¸¦ ¸øÇÏ¹Ç·Î
			if( pTarget->GetObjectKind() & eObjectKind_Monster )	// ¸ó½ºÅÍ´Â ÀûÀÌ ¾Æ´Ô
				return FALSE;
		}
		else if(pTarget->GetObjectKind() == eObjectKind_SkillObject)
		{
			return TRUE;
		}
else if(pTarget->GetObjectKind() == eObjectKind_Pet )
		{
#ifdef _MAPSERVER_
			CObject* const ownerObject = g_pUserTable->FindUser(
				pTarget->GetOwnerIndex());

			if(0 == ownerObject)
			{
				return FALSE;
			}

			return IsEnemy(
				pOperator,
				ownerObject);
#else
			if( ( ( CPet* )pTarget )->GetMaster() )
			{
				return IsEnemy( pOperator, ( ( CPet* )pTarget )->GetMaster() );
			}
			else
				return FALSE;
#endif
		}
		else	//³ª¸ÓÁö´Â ÀûÀÌ ¾Æ´Ï´Ù.
		{
			return FALSE;
		}
	}
	else if(pOperator->GetObjectKind() == eObjectKind_Pet )
	{
#ifdef _MAPSERVER_
		CObject* const ownerObject = g_pUserTable->FindUser(
			pTarget->GetOwnerIndex());

		if(0 == ownerObject)
		{
			return FALSE;
		}

		return IsEnemy(
			ownerObject,
			pTarget);
#else
		if( ( ( CPet* )pOperator )->GetMaster() )
		{
			return IsEnemy( ( ( CPet* )pOperator )->GetMaster(), pTarget );
		}
		else
			return FALSE;
#endif
	}
	return TRUE;
}


BOOL CBattle_Showdown::IsFriend(CObject* pOperator,CObject* pTarget)
{
	if(pOperator->GetBattleID() != pTarget->GetBattleID())
		return FALSE;
	
	if(pOperator->GetBattleTeam() != pTarget->GetBattleTeam())
		return FALSE;
	
	return TRUE;
}

// event func
void CBattle_Showdown::OnCreate(BATTLE_INFO_BASE* pCreateInfo, CBattleTeam* pTeam1, CBattleTeam* pTeam2)
{
	CBattle::OnCreate(pCreateInfo,pTeam1,pTeam2);

	memcpy(&m_ShowdownInfo,pCreateInfo,sizeof(BATTLE_INFO_SHOWDOWN));

	m_Team[0].SetCharacterID(m_ShowdownInfo.Character[SHOWDOWNTEAM_BLUE]);	
	m_Team[1].SetCharacterID(m_ShowdownInfo.Character[SHOWDOWNTEAM_RED]);

#ifndef _MAPSERVER_	
	m_ImageNumber.Init( 32, 0 );
	m_ImageNumber.SetFillZero( FALSE );
	m_ImageNumber.SetLimitCipher( 2 );
	//m_ImageNumber.SetPosition( 640 - 16, 80 );
	m_ImageNumber.SetScale( 3.0f, 3.0f );
	const DISPLAY_INFO& dispInfo2 = GAMERESRCMNGR->GetResolution();
	m_ImageNumber.SetPosition( (dispInfo2.dwWidth-16)/2, 150 );

	m_dwFadeOutStartTime = 0;
	m_bFadeOut	 = FALSE;

//	SCRIPTMGR->GetImage( 59, &m_ImageReady, PFT_HARDPATH );
	SCRIPTMGR->GetImage( 59, &m_ImageStart, PFT_HARDPATH );
	SCRIPTMGR->GetImage( 60, &m_ImageWin, PFT_HARDPATH );
	SCRIPTMGR->GetImage( 61, &m_ImageLose, PFT_HARDPATH );
	SCRIPTMGR->GetImage( 62, &m_ImageDraw, PFT_HARDPATH );
	
	const DISPLAY_INFO &dispInfo = GAMERESRCMNGR->GetResolution();
	m_vTitlePos.x = (float)(dispInfo.dwWidth - 512)/2;
	m_vTitlePos.y = 32;
	m_vTitleScale.x = 1.0f;
	m_vTitleScale.y = 1.0f;
	
	CTileManager* pTileManager = MAP->GetTileManager();

	//ºñ¹«ÀåÀ» ¸¸µéÀÚ...
	VECTOR3 vPos	= m_ShowdownInfo.vStgPos;
	VECTOR3 vStgPos;

	float fx, fz = vPos.z;
//	RECT rc = { -100.0f, -50.0f, -50.0f, 0.0f };
	float fAdd = -50.0f;

	for( fx = vPos.x - 1000.0f ; fx <= vPos.x + 1000.0f + fAdd ; fx += 50.0f )//
	{
		vStgPos.x = fx;
		vStgPos.z = fz - 1000.0f;
		pTileManager->AddTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
		vStgPos.z = fz + 1000.0f + fAdd;
		pTileManager->AddTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
	}

	fx = vPos.x;
	for( fz = vPos.z - 1000.0f ; fz <= vPos.z + 1000.0f + fAdd; fz += 50.0f )
	{
		vStgPos.x = fx - 1000.0f;
		vStgPos.z = fz;
		pTileManager->AddTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
		vStgPos.x = fx + 1000.0f + fAdd;
		vStgPos.z = fz;
		pTileManager->AddTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
	}

//---ÀÓ½Ã	
	fz = vPos.z;
	for( fx = vPos.x - 1050.0f ; fx <= vPos.x + 1050.0f + fAdd ; fx += 50.0f )//
	{
		vStgPos.x = fx;
		vStgPos.z = fz - 1050.0f;
		pTileManager->AddTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
		vStgPos.z = fz + 1050.0f + fAdd;
		pTileManager->AddTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
	}

	fx = vPos.x;
	for( fz = vPos.z - 1050.0f ; fz <= vPos.z + 1050.0f + fAdd ; fz += 50.0f )
	{
		vStgPos.x = fx - 1050.0f;
		vStgPos.z = fz;
		pTileManager->AddTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
		vStgPos.x = fx + 1050.0f + fAdd;
		vStgPos.z = fz;
		pTileManager->AddTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
	}
//------------------

	//°Å¸®¾È¿¡ ÀÖ³ª? ¾øÀ¸¸é? confirm
	
	CPlayer* pPlayer1 = (CPlayer*)OBJECTMGR->GetObject( m_ShowdownInfo.Character[0] );
	CPlayer* pPlayer2 = (CPlayer*)OBJECTMGR->GetObject( m_ShowdownInfo.Character[1] );
	if( pPlayer1 )
	if( pPlayer1->GetState() == eObjectState_BattleReady )
		OBJECTSTATEMGR->EndObjectState(pPlayer1, eObjectState_BattleReady );
	if( pPlayer2 )
	if( pPlayer2->GetState() == eObjectState_BattleReady )
		OBJECTSTATEMGR->EndObjectState(pPlayer2, eObjectState_BattleReady );

#else

//	m_bDieByOp = FALSE;
	m_bDieByOp[0] = FALSE;
	m_bDieByOp[1] = FALSE;

	CPlayer* pPlayer1 = (CPlayer*)g_pUserTable->FindUser(m_ShowdownInfo.Character[0]);
	CPlayer* pPlayer2 = (CPlayer*)g_pUserTable->FindUser(m_ShowdownInfo.Character[1]);
	if( pPlayer1 )
	if( pPlayer1->GetState() == eObjectState_BattleReady )
		OBJECTSTATEMGR_OBJ->EndObjectState(pPlayer1, eObjectState_BattleReady);

	if( pPlayer2 )
	if( pPlayer2->GetState() == eObjectState_BattleReady )
		OBJECTSTATEMGR_OBJ->EndObjectState(pPlayer2, eObjectState_BattleReady);

#endif


//°¢Á¾ Ã³¸®....
//-ÀÌÆåÆ®¸¦ Ã³¸®ÇÑ´Ù.
//-ÄÁÆ®·Ñ ´©¸£Áö ¾Ê°íµµ »ó´ë¸¦ °ø°Ý°¡´ÉÇÏµµ·Ï ÇÑ´Ù.
//-´Ù¸¥ Ä³¸¯ÅÍÀÇ PK¸¦ ¸·´Â´Ù.

}

void CBattle_Showdown::OnFightStart()
{
	CBattle::OnFightStart();

#ifndef _MAPSERVER_
	m_pCurShowImage = &m_ImageStart;
	m_ImageNumber.SetFillZero( TRUE );
	m_ImageNumber.SetFadeOut( 0 );	//fadeout off
	m_ImageNumber.SetScale( 1.0f, 1.0f );
	const DISPLAY_INFO& dispInfo2 = GAMERESRCMNGR->GetResolution();
	m_ImageNumber.SetPosition( (dispInfo2.dwWidth-32)/2, 150 );
#endif
	
}

void CBattle_Showdown::OnDestroy()
{

#ifndef _MAPSERVER_	

	CTileManager* pTileManager = MAP->GetTileManager();
	//ºñ¹«ÀåÀ» ÇØÃ¼
	VECTOR3 vPos	= m_ShowdownInfo.vStgPos;
	VECTOR3 vStgPos;

	float fx, fz = vPos.z;
	float fAdd = -50.0f;
	
	for( fx = vPos.x - 1000.0f ; fx <= vPos.x + 1000.0f + fAdd ; fx += 50.0f )
	{
		vStgPos.x = fx;
		vStgPos.z = fz - 1000.0f;
		pTileManager->RemoveTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
		vStgPos.z = fz + 1000.0f + fAdd;
		pTileManager->RemoveTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
	}
	fx = vPos.x;
	for( fz = vPos.z - 1000.0f ; fz <= vPos.z + 1000.0f + fAdd ; fz += 50.0f )
	{
		vStgPos.x = fx - 1000.0f;
		vStgPos.z = fz;
		pTileManager->RemoveTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
		vStgPos.x = fx + 1000.0f + fAdd;
		vStgPos.z = fz;
		pTileManager->RemoveTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
	}

//---ÀÓ½Ã	
	fz = vPos.z;
	for( fx = vPos.x - 1050.0f ; fx <= vPos.x + 1050.0f + fAdd ; fx += 50.0f )//
	{
		vStgPos.x = fx;
		vStgPos.z = fz - 1050.0f;
		pTileManager->RemoveTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
		vStgPos.z = fz + 1050.00f + fAdd;
		pTileManager->RemoveTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
	}

	fx = vPos.x;
	for( fz = vPos.z - 1050.0f ; fz <= vPos.z + 1050.0f + fAdd; fz += 50.0f )
	{
		vStgPos.x = fx - 1050.0f;
		vStgPos.z = fz;
		pTileManager->RemoveTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
		vStgPos.x = fx + 1050.0f + fAdd;
		vStgPos.z = fz;
		pTileManager->RemoveTileAttrByAreaData( NULL, &vStgPos, SKILLAREA_ATTR_BLOCK );
	}
//------------------

#else

	CPlayer* pPlayer1 = (CPlayer*)g_pUserTable->FindUser(m_ShowdownInfo.Character[0]);
	CPlayer* pPlayer2 = (CPlayer*)g_pUserTable->FindUser(m_ShowdownInfo.Character[1]);
	if( pPlayer1 )
	{
		pPlayer1->SetBattleID(pPlayer1->GetGridID());
		pPlayer1->SetShowdown( FALSE );

		/////////////////////////////////////////////////////////////////////////////////
		// 06. 06. µ¿½Ã¿¡ Á×À»½Ã 2¹ø Player´Â ºñ¹« Á×À½ Ã³¸® ¾ÈµÇ´Â ¹®Á¦ ÇØ°á - ÀÌ¿µÁØ
		// m_bDieByOp -> m_bDieByOp[0]
		if( pPlayer1->GetState() == eObjectState_Die && m_bDieByOp[0] )
		{
			pPlayer1->ReviveAfterShowdown();
			m_bDieByOp[0] = FALSE;
		}
	}
	if( pPlayer2 )
	{
		pPlayer2->SetBattleID(pPlayer2->GetGridID());
		pPlayer2->SetShowdown( FALSE );
		
		/////////////////////////////////////////////////////////////////////////////////
		// 06. 06. µ¿½Ã¿¡ Á×À»½Ã 2¹ø Player´Â ºñ¹« Á×À½ Ã³¸® ¾ÈµÇ´Â ¹®Á¦ ÇØ°á - ÀÌ¿µÁØ
		// m_bDieByOp -> m_bDieByOp[1]
		if( pPlayer2->GetState() == eObjectState_Die && m_bDieByOp[1] )
		{
			pPlayer2->ReviveAfterShowdown();
			m_bDieByOp[1] = FALSE;
		}
	}

#endif

	CBattle::OnDestroy();
	
}

void CBattle_Showdown::OnTeamMemberAdd( int Team, DWORD MemberID, char* Name )
{
#ifdef _MAPSERVER_
/*
	if( Team == eBattleTeam1 )
	{
		CObject* pObject = g_pUserTable->FindUser(MemberID);
		ASSERT(pObject);

		MSG_BATTLE_SHOWDOWN_CREATESTAGE msg;
		msg.Category = MP_BATTLE;
		msg.Protocol = MP_BATTLE_SHOWDOWN_CREATESTAGE;
		msg.dwObjectID = pObject->GetID();
		msg.dwBattleID = pObject->GetBattleID();
		msg.vPosStage = m_ShowdownInfo.vStgPos;
		
		PACKEDDATA_OBJ->QuickSend( pObject, &msg, sizeof(msg) );
	}
*/
	CObject* pObject = g_pUserTable->FindUser(MemberID);
	ASSERT(pObject);

	MSG_BATTLE_SHOWDOWN_CREATESTAGE msg;
	msg.Category = MP_BATTLE;
	msg.Protocol = MP_BATTLE_SHOWDOWN_CREATESTAGE;
	msg.dwObjectID = pObject->GetID();
	msg.dwBattleID = pObject->GetBattleID();
	msg.vPosStage = m_ShowdownInfo.vStgPos;
	pObject->SendMsg( &msg, sizeof(msg) );

//#else
	
#endif
	//ºñ¹«Àå ÀÌÆåÆ® º¸³»ÀÚ.
}

BOOL CBattle_Showdown::OnTeamMemberDie(int Team,DWORD VictimMemberID,DWORD KillerID)
{
	ASSERT(Team < eBattleTeam_Max);
	
#ifdef _MAPSERVER_
	CObject* pVictimMember = g_pUserTable->FindUser(VictimMemberID);
	CObject* pKiller = g_pUserTable->FindUser(KillerID);
	if(pVictimMember == NULL || pKiller == NULL)
	{
		ASSERT(0);
		return FALSE;
	}
	
	ASSERT(pVictimMember->GetBattleID() == GetBattleID());

	if( pVictimMember->GetObjectKind() != eObjectKind_Player )
	{
		return FALSE;
	}
	
	//°á°ú·Î.....
	((CBattleTeam_Showdown*)m_TeamArray[Team])->AddTeamDieNum();

	//Å¸Ä³¸¯ÀÌ³ª ¸ó½ºÅÍÇÑÅ× Á×¾ú´Ù.
	//
	if(pKiller->GetBattleID() != GetBattleID())	//Â÷ÈÄ PK°í·Á
	{
		if( pKiller->GetObjectKind() == eObjectKind_SkillObject )
		{
			CObject* pOperator = ((cSkillObject*)pKiller)->GetOperator();

			if( !pOperator )
				return FALSE;

			if( pOperator->GetBattleID() != GetBattleID() )
				return FALSE;

			ASSERT(0);	//debug.. ¿À¹ö·¹ÀÌÅÍ º£Æ²¾ÆÀÌµð¿Í ½ºÅ³º£Æ²¾ÆÀÌµð°¡ Æ²¸®´Ù!!
		}
		else if( pKiller->GetObjectKind() == eObjectKind_Pet )
		{
			CObject* pOperator = g_pUserTable->FindUser(
				pKiller->GetOwnerIndex());

			if( !pOperator )
				return FALSE;

			if( pOperator->GetBattleID() != GetBattleID() )
				return FALSE;

			ASSERT(0);	

		}
		else
		{
			return FALSE;
		}
	}

	/////////////////////////////////////////////////////////////////////////////////
	// 06. 06. µ¿½Ã¿¡ Á×À»½Ã 2¹ø Player´Â ºñ¹« Á×À½ Ã³¸® ¾ÈµÇ´Â ¹®Á¦ ÇØ°á - ÀÌ¿µÁØ
	// ºñ¹«·Î Á×¾ú´ÂÁö ÆÇ´ÜÇÏ´Â º¯¼ö°¡ ÇÏ³ª ¹Û¿¡ ¾ø¾î¼­
	// µ¿½Ã¿¡ Á×À»½Ã 2¹ø ÄÉ¸¯ÅÍ´Â È®ÀÎÀÌ ¾ÈµÇ¾î ÀÏ¹Ý Á×À½Ã³¸®°¡ µÇ´Â ¹®Á¦ ÇØ°á
	//	m_bDieByOp = TRUE; //»ó´ëÄ³¸¯ÇÑÅ× Á×¾ú´Ù.
	if(m_ShowdownInfo.Character[0] == VictimMemberID)
		m_bDieByOp[0] = TRUE; 
	else
		m_bDieByOp[1] = TRUE;

	((CPlayer*)pVictimMember)->m_bNeedRevive = FALSE;		//ºÎÈ°Ã¢ÀÌ ÇÊ¿ä¾ø´Ù.
	
	MSG_DWORD3 msg;
	SetProtocol(&msg,MP_BATTLE,MP_BATTLE_TEAMMEMBER_DIE_NOTIFY);
	msg.dwData1 = Team;
	msg.dwData2 = VictimMemberID;
	msg.dwData3 = KillerID;
	ToEachTeam(pTeam)
		pTeam->SendTeamMsg(&msg,sizeof(msg));
	EndToEachTeam

	
#endif


//	return TRUE;

//	FALSE¸¦ ¸®ÅÏÇÏ¸é ¿ø·¡ÀÇ Ã³¸®¸¦ ÇÑ´Ù. CPlayer(CMonster)::DoDie ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
	return FALSE;
	
}

BOOL CBattle_Showdown::OnTeamMemberDelete(int Team,DWORD MemberID,char* Name)
{
	return TRUE;
}


//server¿¡¼­¸¸ »ç¿ë
void CBattle_Showdown::OnTick()
{
	ySWITCH(m_BattleInfo.BattleState)
		yCASE(eBATTLE_STATE_READY)

			DWORD ElapTime = gCurTime - m_BattleInfo.BattleTime;
			if( ElapTime > BATTLE_SHOWDOWN_READYTIME )
			{
				for( int n = 0; n < eBattleTeam_Max; ++n )
				{
					if( m_TeamArray[n]->GetAliveTeamMemberNum() == 0 )
					{
						Draw();
						return;
					}
				}

				StartBattle();
			}

		yCASE(eBATTLE_STATE_FIGHT)
			Judge();

		yCASE(eBATTLE_STATE_RESULT)
			DWORD ElapTime = gCurTime - m_BattleInfo.BattleTime;
			if( ElapTime > BATTLE_SHOWDOWN_RESULTTIME)
			{
				SetDestroyFlag();
				
			}
	
	yENDSWITCH
}

// ½ÂÆÐ ÆÇÁ¤

BOOL CBattle_Showdown::JudgeOneTeamWinsOtherTeam(int TheTeam,int OtherTeam)
{
	CBattleTeam_Showdown* pTheTeam = (CBattleTeam_Showdown*)m_TeamArray[TheTeam];
	CBattleTeam_Showdown* pOtherTeam = (CBattleTeam_Showdown*)m_TeamArray[OtherTeam];

//	if(pOtherTeam->GetAliveTeamMemberNum() == 0)
	if( pTheTeam->GetTeamDieNum() == 0 )				//KKK
	if( pOtherTeam->GetTeamDieNum() != 0 )
	{
		Victory( TheTeam, OtherTeam );
		return TRUE;
	}

	return FALSE;
}

 
BOOL CBattle_Showdown::Judge()
{

	if(JudgeOneTeamWinsOtherTeam(eBattleTeam1,eBattleTeam2) == TRUE)
		return TRUE;

	if(JudgeOneTeamWinsOtherTeam(eBattleTeam2,eBattleTeam1) == TRUE)
		return TRUE;

	if( ((CBattleTeam_Showdown*)m_TeamArray[eBattleTeam1])->GetTeamDieNum()
		&& ((CBattleTeam_Showdown*)m_TeamArray[eBattleTeam2])->GetTeamDieNum() )
		Draw();


	DWORD ElapsedTime = gCurTime - m_BattleInfo.BattleTime;
	if(ElapsedTime > BATTLE_SHOWDOWN_FIGHTTIME)
		Draw();

	return FALSE;
}


void CBattle_Showdown::Victory(int WinnerTeamNum,int LoserTeamNum)
{
	CBattle::Victory(WinnerTeamNum,LoserTeamNum);

#ifndef _MAPSERVER_
	if( HERO->GetBattleTeam() == WinnerTeamNum )
	{
		m_pCurShowImage = &m_ImageWin;
	}
	else if( HERO->GetBattleTeam() == LoserTeamNum )
	{
		m_pCurShowImage = &m_ImageLose;
	}


	m_vTitleScale.x = 1.0f;
	m_vTitleScale.y = 1.0f;

	const DISPLAY_INFO& dispInfo = GAMERESRCMNGR->GetResolution();
	m_vTitlePos.x = (float)(dispInfo.dwWidth - 512)/2;
	m_vTitlePos.y = 100;

	//AutoAttack¸ØÃã
	HERO->DisableAutoAttack();					//°ø°ÝÁß ÀÌ´ø°Å Ãë¼ÒµÇ³ª?
	HERO->SetNextAction(NULL);			//½ºÅ³ ¾²´ø°Íµµ Ãë¼ÒµÇ³ª?

#else
	CPlayer* pPlayer1 = (CPlayer*)g_pUserTable->FindUser(m_ShowdownInfo.Character[0]);
	CPlayer* pPlayer2 = (CPlayer*)g_pUserTable->FindUser(m_ShowdownInfo.Character[1]);
	CPlayer* pWinner = NULL;
	CPlayer* pLoser = NULL;

	if( WinnerTeamNum == 0 )
	{
		pWinner = pPlayer1;
		pLoser = pPlayer2;
	}
	else if( WinnerTeamNum == 1 )
	{
		pWinner = pPlayer2;
		pLoser = pPlayer1;
	}

	if( pPlayer1 == NULL || pPlayer2 == NULL || pWinner == NULL )
		return;

	//	char buf[128];
//	sprintf( buf, "%s´Ô°ú %s´ÔÀÇ ºñ¹«¿¡¼­ %s´ÔÀÌ ½Â¸®ÇÏ¼Ì½À´Ï´Ù.",
//			 pPlayer1->GetObjectName(),
//			 pPlayer2->GetObjectName(),
//			 pWinner->GetObjectName() );

	MSG_DWORD2 resultMsg;
	resultMsg.Category		= MP_SIGNAL;
	resultMsg.Protocol		= MP_SIGNAL_SHOWDOWN_RESULT;
	resultMsg.dwObjectID	= pWinner->GetID();
	resultMsg.dwData1		= pWinner->GetID();		//winner
	resultMsg.dwData2		= pLoser->GetID();		//loser
	PACKEDDATA_OBJ->QuickSend( pWinner, &resultMsg, sizeof(resultMsg) );
/*
	TESTMSG resultMsg;
	resultMsg.Category		= MP_SIGNAL;
	resultMsg.Protocol		= MP_SIGNAL_SHOWDOWN_RESULT;
	resultMsg.dwObjectID	= pWinner->GetID();
	//strcpy( resultMsg.Msg, buf );
	SafeStrCpy( resultMsg.Msg, buf, MAX_CHAT_LENGTH+1);
	//PACKEDDATA_OBJ->QuickSend( pWinner, (MSGBASE*)&resultMsg, sizeof(TESTMSG) );
	PACKEDDATA_OBJ->QuickSend( pWinner, (MSGBASE*)&resultMsg, resultMsg.GetMsgLength() );	//CHATMSG 040324
*/	

#endif
}

void CBattle_Showdown::Draw()
{
	CBattle::Draw();	

#ifndef _MAPSERVER_
	m_pCurShowImage = &m_ImageDraw;

	m_vTitleScale.x = 1.0f;
	m_vTitleScale.y = 1.0f;

	const DISPLAY_INFO& dispInfo = GAMERESRCMNGR->GetResolution();
	m_vTitlePos.x = (float)(dispInfo.dwWidth - 512)/2;
	m_vTitlePos.y = 100;
	
	//AutoAttack¸ØÃã
	HERO->DisableAutoAttack();					//°ø°ÝÁß ÀÌ´ø°Å Ãë¼ÒµÇ³ª?
	HERO->SetNextAction(NULL);			//½ºÅ³ ¾²´ø°Íµµ Ãë¼ÒµÇ³ª?
#endif
}



#ifdef _CLIENT_

#include "interface/cFont.h"
//#include "interface/cImage.h"
#include "ImageNumber.h"

void CBattle_Showdown::Render()
{
	DWORD ElapsedTime = gCurTime-m_BattleInfo.BattleTime;


	switch(m_BattleInfo.BattleState )
	{
	case eBATTLE_STATE_READY:
		{
			//È­¸éÁß°£¿¡
			DWORD RemainTime = BATTLE_SHOWDOWN_READYTIME > ElapsedTime ? BATTLE_SHOWDOWN_READYTIME - ElapsedTime : 0;
			//sprintf( temp, "Battle Start in %d sec", RemainTime / 1000 );
			m_ImageNumber.SetNumber( RemainTime / 1000 );
			if( m_ImageNumber.IsNumberChanged() )
				m_ImageNumber.SetFadeOut( 500 );

			m_ImageNumber.Render();
			
//			if( m_pCurShowImage )
//				m_pCurShowImage->RenderSprite( &m_vTitleScale, NULL, 0.0f, &m_vTitlePos, 0xffffffff );
		}
		break;

	case eBATTLE_STATE_FIGHT:
		{
			if( m_pCurShowImage )
				m_pCurShowImage->RenderSprite( &m_vTitleScale, NULL, 0.0f, &m_vTitlePos, 0xffffffff );

			//È­¸éÁß°£¿¡ ³ª¿Ô´Ù°¡ À§·Î?
			DWORD RemainTime = BATTLE_SHOWDOWN_FIGHTTIME > ElapsedTime ? BATTLE_SHOWDOWN_FIGHTTIME - ElapsedTime : 0;
			//sprintf( temp, "Battle End in %d sec", RemainTime / 1000 );
			m_ImageNumber.SetNumber( RemainTime / 1000 );

//			m_ImageNumber.SetPosition( 512 + 32, 130 ); //130
//			m_ImageNumber.SetPosition( 512 + 32, 30 ); //130
			m_ImageNumber.Render();			

		}
		break;

	case eBATTLE_STATE_RESULT:
		{
			DWORD dwAlpha = 255;
			if( !m_bFadeOut )
			{
				if( ElapsedTime > 5500 )
				{
					m_dwFadeOutStartTime = gCurTime;
					m_bFadeOut = TRUE;
				}
			}
			else
			{
				DWORD dwElapsed = gCurTime - m_dwFadeOutStartTime;
				DWORD dwMinusAlpha = 255 * dwElapsed / 1000;
				if( dwMinusAlpha < 255 )
				{
					dwAlpha = 255 - dwMinusAlpha;
				}
				else
				{
					dwAlpha = 0;
				}
			}

			if(m_WinnerTeam == eBattleTeam_Max)
			{				
				if( m_pCurShowImage )
					m_pCurShowImage->RenderSprite( &m_vTitleScale, NULL, 0.0f, &m_vTitlePos, 0x00ffffff | (dwAlpha << 24) );
			}
			else
			{
				if(ElapsedTime > 2500)
				{
					if( m_pCurShowImage )
						m_pCurShowImage->RenderSprite( &m_vTitleScale, NULL, 0.0f, &m_vTitlePos, 0x00ffffff | (dwAlpha << 24) );
				}
			}
		}
		break;
	}

	//CFONT_OBJ->RenderFont(0,temp,strlen(temp),&rect,0xffffffff);	

}

#endif
// } end virtual func
//////////////////////////////////////////////////////////////////////////
