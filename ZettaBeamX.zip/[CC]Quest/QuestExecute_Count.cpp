// QuestExecute_Count.cpp: implementation of the CQuestExecute_Count class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"															// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "QuestExecute_Count.h"												// Äù½ºÆ® ½ÇÇà Ä«¿îÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"												// Äù½ºÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#ifdef _MAPSERVER_															// ¸Ê¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

#include "QuestGroup.h"														// Äù½ºÆ® ±×·ì Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "Player.h"															// ÇÃ·¹ÀÌ¾î Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// »ý¼ºÀÚ ÇÔ¼ö.
CQuestExecute_Count::CQuestExecute_Count( DWORD dwExecuteKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
: CQuestExecute( dwExecuteKind, pTokens, dwQuestIdx, dwSubQuestIdx )
{
	m_dwMaxCount = m_dwWeaponKind = m_dwParam1 = 0;							// ÃÖ´ë Ä«¿îÆ®, ¹«±â Á¾·ù, ÆÄ¶ó¸ÞÅÍ 1À» 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	GetScriptParam( m_dwRealSubQuestIdx, pTokens );							// ¸®¾ó ¼­ºê Äù½ºÆ® ÀÎµ¦½º¸¦ ¹Þ´Â´Ù.
	GetScriptParam( m_dwMaxCount, pTokens );								// ÃÖ´ë Ä«¿îÆ®¸¦ ¹Þ´Â´Ù.

	if( m_dwExecuteKind == eQuestExecute_AddCountFQW						// ½ÇÇà Å¸ÀÔÀÌ Æ¯Á¤ ¹«±â·Î Ä«¿îÆ®¸¦ Ãß°¡ÇÏ´Â °ÍÀÌ¶ó¸é,
		|| m_dwExecuteKind == eQuestExecute_AddCountFW )
	{
		GetScriptParam( m_dwWeaponKind, pTokens );							// ¹«±â Å¸ÀÔÀ» ¹Þ´Â´Ù.
	}

	else if( m_dwExecuteKind == eQuestExecute_LevelGap ||						// ½ÇÇà Å¸ÀÔÀÌ ·¹º§Â÷ÀÌ ¶ó¸é,
		m_dwExecuteKind == eQuestExecute_MonLevel )
	{
		GetScriptParam( m_dwWeaponKind, pTokens );							// ¹«±â Å¸ÀÔÀ» ¹Þ´Â´Ù.
		GetScriptParam( m_dwParam1, pTokens );								// ÆÄ¶ó¸ÞÅÍ 1À» ¹Þ´Â´Ù.
	}
}

// ¼Ò¸êÀÚ ÇÔ¼ö.
CQuestExecute_Count::~CQuestExecute_Count()									
{
}

// ½ÇÇà ÇÔ¼ö.
BOOL CQuestExecute_Count::Execute( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )
{
#ifdef _MAPSERVER_															// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch( m_dwExecuteKind )												// ½ÇÇà Å¸ÀÔÀ» È®ÀÎÇÑ´Ù.
	{
	case eQuestExecute_AddCount:											// Ä«¿îÆ® Ãß°¡¶ó¸é,
		{
			// Äù½ºÆ® ±×·ìÀÇ Ä«¿îÆ®¸¦ Áõ°¡ ½ÃÅ°´Â ÇÔ¼ö È£Ãâ.
			pQuestGroup->AddCount( m_dwQuestIdx, m_dwRealSubQuestIdx, m_dwMaxCount );
		}
		break;

	case eQuestExecute_AddCountFQW:											// Æ¯Á¤ ¹«±â Ä«¿îÆ® Áõ°¡ ¶ó¸é,
		{
			// Äù½ºÆ® ±×·ìÀÇ Æ¯Á¤ ¹«±â·Î ºÎÅÍ Ä«¿îÆ®¸¦ Áõ°¡ ½ÃÅ°´Â ÇÔ¼ö È£Ãâ.
			pQuestGroup->AddCountFromQWeapon( m_dwQuestIdx, m_dwRealSubQuestIdx, m_dwMaxCount, m_dwWeaponKind );
		}
		break;

	case eQuestExecute_AddCountFW:											// Æ¯Á¤ ¹«±â Ä«¿îÆ® Áõ°¡¶ó¸é,
		{
			// Äù½ºÆ® ±×·ìÀÇ Æ¯Á¤ ¹«±â·Î ºÎÅÍ Ä«¿îÆ®¸¦ Áõ°¡ ½ÃÅ°´Â ÇÔ¼ö È£Ãâ.
			pQuestGroup->AddCountFromWeapon( m_dwQuestIdx, m_dwRealSubQuestIdx, m_dwMaxCount, m_dwWeaponKind );
		}
		break;
	case eQuestExecute_LevelGap:											// ·¹º§ Â÷ÀÌ¶ó¸é,
		{
			// Äù½ºÆ® ±×·ìÀÇ ·¹º§ Â÷ÀÌ·Î ºÎÅÍ Ä«¿îÆ®¸¦ Áõ°¡ ½ÃÅ°´Â ÇÔ¼ö È£Ãâ.
			pQuestGroup->AddCountFromLevelGap( m_dwQuestIdx, m_dwRealSubQuestIdx, m_dwMaxCount, m_dwWeaponKind, m_dwParam1 );
		}
		break;
	case eQuestExecute_MonLevel:											// ¸ó½ºÅÍ ·¹º§ ÀÌ¶ó¸é,
		{
			// Äù½ºÆ® ±×·ìÀÇ ¸ó½ºÅÍ ·¹º§·Î ºÎÅÍ Ä«¿îÆ®¸¦ Áõ°¡ ½ÃÅ°´Â ÇÔ¼ö È£Ãâ.
			pQuestGroup->AddCountFromMonLevel( m_dwQuestIdx, m_dwRealSubQuestIdx, m_dwMaxCount, m_dwWeaponKind, m_dwParam1 );
		}
		break;
	}
#endif

	return TRUE;															// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
}

int CQuestExecute_Count::CheckCondition( PLAYERTYPE* pPlayer,					// Äù½ºÆ® ÀÌº¥Æ®¸¦ ½ÇÇàÇÏ±â À§ÇÑ Á¶°ÇÀ» ¸¸Á·ÇÏ´ÂÁö Ã¼Å©ÇÏ´Â ÇÔ¼ö.
							CQuestGroup* pQuestGroup, CQuest* pQuest )			
{
	int nErrorCode = e_EXC_ERROR_NO_ERROR ;										// ¿¡·¯ ÄÚµå¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í e_EXE_ERROR_NO_ERROR·Î ¼¼ÆÃÇÑ´Ù.

	if( !pPlayer )																// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, 
	{
		nErrorCode = e_EXC_ERROR_NO_PLAYERINFO ;								// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;														// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuestGroup )															// Äù½ºÆ® ±×·ì Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUESTGROUP ;								// Äù½ºÆ® ±×·ì Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;														// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuest )																// Äù½ºÆ® Á¤º¸°¡ À¯È¿ÇÏÁö ¾Ê´Ù¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUEST ;										// Äù½ºÆ® Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;														// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

#ifdef _MAPSERVER_																// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch( m_dwExecuteKind )													// ½ÇÇà Å¸ÀÔÀ» È®ÀÎÇÑ´Ù.
	{
	case eQuestExecute_AddCount:												// Ä«¿îÆ® Ãß°¡¶ó¸é,
		{
			return nErrorCode ;													// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
		}
		break;

	case eQuestExecute_AddCountFQW:												// Æ¯Á¤ ¹«±â¸¦ Ã¼Å©ÇØ¼­ Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			if( pPlayer->GetWearedWeapon() != m_dwWeaponKind )					// ÇÃ·¹ÀÌ¾î°¡ Âø¿ëÇÏ°í ÀÖ´Â ¹«±â¿Í ºñ±³´ë»ó ¹«±â°¡ °°Áö ¾ÊÀ¸¸é,
			{
				nErrorCode = e_EXC_ERROR_NOT_SAME_WEAPONKIND_COUNT ;			// ¹«±â Á¾·ù°¡ ´Þ¶ó¼­ Äù½ºÆ® Ä«¿îÆ® Ãß°¡¸¦ ¸øÇÑ´Ù´Â ¿¡·¯ ¸Þ½ÃÁö¸¦ ¼¼ÆÃÇÑ´Ù.
				return nErrorCode ;												// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			}
		}
		break;

	case eQuestExecute_AddCountFW:												// ¹«±â °è¿­À» Ã¼Å©ÇØ¼­ Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			return nErrorCode ;													// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.

			// ÀÌ Ã³¸®´Â »ç¿ëÇÏÁö ¾Ê±â·Î °áÁ¤.
		}
		break;
	case eQuestExecute_LevelGap:												// ·¹º§ Â÷ÀÌ¶ó¸é,
		{
			return nErrorCode ;													// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			/*int nMin = pPlayer->GetLevel() - pPlayer->GetKillMonsterLevel();
			int nMax = pPlayer->GetKillMonsterLevel() - pPlayer->GetLevel();
			if( nMin > 0 && nMin > (int)dwMinLevel )	return;
			if( nMax > 0 && nMax > (int)dwMaxLevel )	return;*/
		}
		break;
	case eQuestExecute_MonLevel:												// ¸ó½ºÅÍ ·¹º§ ÀÌ¶ó¸é,
		{
			return nErrorCode ;													// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			/*WORD wMonLevel = pPlayer->GetKillMonsterLevel();

			if( wMonLevel < dwMinLevel )	return;
			if( wMonLevel > dwMaxLevel )	return;*/
		}
		break;
	}

#endif //_MAPSERVER_

	return nErrorCode ;															// ±âº» °ªÀ» ¸®ÅÏÇÑ´Ù.
}
