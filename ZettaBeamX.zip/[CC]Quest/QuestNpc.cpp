// QuestNpc.cpp: implementation of the CQuestNpc class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"																			// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.
#include "[lib]yhlibrary/PtrList.h"
#include "QuestNpc.h"																		// Äù½ºÆ® NPC Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"																// Äù½ºÆ® ½ºÅ©¸³ÅÍ ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestNpcData.h"																	// Äù½ºÆ® NPC µ¥ÀÌÅÍ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CQuestNpc::CQuestNpc( CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )		// »ý¼ºÀÚ ÇÔ¼ö.
{
	m_dwQuestIdx = dwQuestIdx;																// Äù½ºÆ® ÀÎµ¦½º¸¦ ¼¼ÆÃÇÑ´Ù.
	m_dwSubQuestIdx = dwSubQuestIdx;														// ¼­ºê Äù½ºÆ® ÀÎµ¦½º¸¦ ¼¼ÆÃÇÑ´Ù.
	ReadNpcData( pTokens, dwQuestIdx, dwSubQuestIdx );										// NPC µ¥ÀÌÅÍ¸¦ ÀÐ¾îµéÀÎ´Ù.
}

CQuestNpc::~CQuestNpc()																		// ¼Ò¸êÀÚ ÇÔ¼ö.
{
	Release();																				// ÇØÁ¦ ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
}

void CQuestNpc::Release()																	// ÇØÁ¦ ÇÔ¼ö.
{
	CQuestNpcData* pNpcData = NULL;															// Äù½ºÆ® NPC µ¥ÀÌÅÍ Á¤º¸¸¦ ´ãÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í NULL Ã³¸®¸¦ ÇÑ´Ù.

	PTRLISTPOS pos = m_NpcDataList.GetHeadPosition();										// NPC µ¥ÀÌÅÍ ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	while( pos )																			// À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑµ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pNpcData = (CQuestNpcData*)m_NpcDataList.GetNext( pos );							// À§Ä¡¿¡ ÇØ´çÇÏ´Â npc µ¥ÀÌÅÍ¸¦ ¹Þ´Â´Ù.

		if( pNpcData )																		// npc µ¥ÀÌÅÍ Á¤º¸°¡ À¯È¿ÇÏ¸é,
		{
			delete pNpcData;																// npc µ¥ÀÌÅÍ Á¤º¸¸¦ »èÁ¦ÇÑ´Ù.
		}
	}
}

BOOL CQuestNpc::ReadNpcData( CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )	// npc µ¥ÀÌÅÍ Á¤º¸¸¦ ÀÐ´Â ÇÔ¼ö.
{
	char* OneToken;																				// ÅäÅ« Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.

	while( (OneToken = pTokens->GetNextTokenUpper()) != NULL )									// ÅäÅ« Á¤º¸°¡ À¯È¿ÇÑµ¿¾È while¹®À» µ¹¸°´Ù.
	{
		if( OneToken[0] == '@' )																// ÅäÅ«ÀÌ @¿Í °°´Ù¸é,
		{
			m_NpcDataList.AddTail( CQuestScriptLoader::LoadQuestNpcData( OneToken, pTokens, dwQuestIdx, dwSubQuestIdx ) );	// npc µ¥ÀÌÅÍ ¸®½ºÆ®¿¡ npcµ¥ÀÌÅÍ·² ·ÎµåÇØ
		}																													// Ãß°¡ÇÑ´Ù.
	}
	return TRUE;																				// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
}