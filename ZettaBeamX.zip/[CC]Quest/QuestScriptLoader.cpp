// QuestScriptLoader.cpp: implementation of the CQuestScriptLoader class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"																	// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "QuestScriptLoader.h"														// Äù½ºÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "MHFile.h"																	// ¹¬Çâ ÆÄÀÏ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestInfo.h"																// Äù½ºÆ® Á¤º¸ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "SubQuestInfo.h"															// ¼­ºê Äù½ºÆ® Á¤º¸ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestString.h"															// Äù½ºÆ® ½ºÆ®¸µ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestEvent.h"																// Äù½ºÆ® ÀÌº¥Æ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestLimit.h"																// Äù½ºÆ® ¸®¹ÌÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestLimitKind.h"															// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestLimitKind_Level.h"													// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Áß ·¹º§ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestLimitKind_Quest.h"													// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Áß Äù½ºÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestLimitKind_Stage.h"													// Äù½ºÆ® ¸®¹ÌÁö Á¾·ù Áß ½ºÅ×ÀÌÁö Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestTrigger.h"															// Äù½ºÆ® Æ®¸®°Å Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestCondition.h"															// Äù½ºÆ® »óÅÂ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestExecute.h"															// Äù½ºÆ® ½ÇÇà Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestExecute_Quest.h"														// Äù½ºÆ® ½ÇÇà Äù½ºÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestExecute_Count.h"														// Äù½ºÆ® ½ÇÇà Ä«¿îÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestExecute_Item.h"														// Äù½ºÆ® ½ÇÇà ¾ÆÀÌÅÛ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestExecute_RandomItem.h"												// Äù½ºÆ® ½ÇÇà ·£´ý ¾ÆÀÌÅÛ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestExecute_Time.h"														// Äù½ºÆ® ½ÇÇà ½Ã°£ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestExecute_SelectItem.h"												// 100414 ONS Äù½ºÆ® ½ÇÇà ¼±ÅÃº¸»ó ¾ÆÀÌÅÛ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestNpcScript.h"															// Äù½ºÆ® NPC ½ºÅ©¸³Æ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestNpc.h"																// Äù½ºÆ® NPC Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestNpcData.h"															// Äù½ºÆ® NPC µ¥ÀÌÅÍ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

//#include "interface/cWindowDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
#define LOADUNIT(ekind,strkind,classname,questidx,subquestidx)	\
		if( strcmp(strKind,strkind) == 0 )						\
			return new classname(ekind,pTokens,questidx,subquestidx);

CQuestScriptLoader::CQuestScriptLoader()											// »ý¼ºÀÚ ÇÔ¼ö.
{
}

CQuestScriptLoader::~CQuestScriptLoader()											// ¼Ò¸êÀÚ ÇÔ¼ö.
{
}

CQuestInfo* CQuestScriptLoader::LoadQuestInfo( CMHFile* pFile, DWORD dwQuestIdx )	// Äù½ºÆ® Á¤º¸¸¦ ·ÎµùÇÏ´Â ÇÔ¼ö.
{
	CQuestInfo* pQuestInfo = new CQuestInfo( dwQuestIdx );							// Äù½ºÆ® Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í, Äù½ºÆ® Á¤º¸ Å¬·¡½º ¸¸Å­ ¸Þ¸ð¸®¸¦ ÇÒ´çÇØ ¹Þ´Â´Ù.

	CSubQuestInfo* pSub;															// ¼­ºê Äù½ºÆ® Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.

	char tok[256];																	// ÀÓ½Ã ¹öÆÛ¸¦ ¼±¾ðÇÑ´Ù.

	DWORD dwSubQuestIdx = 0;														// ¼­ºê Äù½ºÆ® ÀÎµ¦½º¸¦ ¹ÞÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	while( !pFile->IsEOF() )														// ÆÄÀÏ Æ÷ÀÎÅÍ°¡ ÆÄÀÏÀ» ³¡¿¡ µµ´ÞÇÏÁö ¾ÊÀ» µ¿¾È	while¹®À» µ¹¸°´Ù.
	{
		pFile->GetString( tok );													// ÀÓ½Ã ¹öÆÛ¿¡ ½ºÆ®¸µÀ» ÀÐ¾îµéÀÎ´Ù.

		if( tok[0] == '}' )															// }¿Í °°À¸¸é,
		{
			break;																	// while¹®À» Å»ÃâÇÑ´Ù.
		}		
		else if( stricmp( tok, "$REPEAT" ) == 0 )										
		{
			pQuestInfo->SetRepeat();
		}
		// 100401 ShinJS --- Äù½ºÆ® ½Ã°£Á¦ÇÑ ¼³Á¤.
		else if( stricmp( tok, "$DATELIMIT" ) == 0 )
		{
			char buf[MAX_PATH]={0,};
			pFile->GetLine( buf, MAX_PATH );

			typedef std::pair< struct tm, struct tm > QuestDateLimitData;
			QuestDateLimitData dateLimit;

			struct tm& timeStart = dateLimit.first;
			struct tm& timeEnd = dateLimit.second;

			BOOL bDaily = FALSE, bHasEndTime = FALSE;
			ParseDateInfo( buf, timeStart, timeEnd, bDaily, bHasEndTime );

			// ÀÏÀÏ Äù½ºÆ®ÀÎ °æ¿ì
			if( bDaily )
			{
				// Á¾·á½Ã°¢ÀÌ ÁÖ¾îÁöÁö ¾ÊÀº °æ¿ì ´ÙÀ½³¯Â¥ÀÇ 1ºÐÀü¿¡ Á¾·á½ÃÅ²´Ù.
				if( !bHasEndTime )
				{
					timeEnd = timeStart;
					timeEnd.tm_hour = ( timeEnd.tm_hour + 23 ) % 24;
					timeEnd.tm_min = (timeEnd.tm_min + 59 ) % 60;
				}

				timeStart.tm_wday = 0;		timeEnd.tm_wday = 1;		// ÀÏ~¿ù
				pQuestInfo->AddDateLimit( dateLimit );

				timeStart.tm_wday = 1;		timeEnd.tm_wday = 2;		// ¿ù~È­
				pQuestInfo->AddDateLimit( dateLimit );

				timeStart.tm_wday = 2;		timeEnd.tm_wday = 3;		// È­~¼ö
				pQuestInfo->AddDateLimit( dateLimit );

				timeStart.tm_wday = 3;		timeEnd.tm_wday = 4;		// ¼ö~¸ñ
				pQuestInfo->AddDateLimit( dateLimit );

				timeStart.tm_wday = 4;		timeEnd.tm_wday = 5;		// ¸ñ~±Ý
				pQuestInfo->AddDateLimit( dateLimit );

				timeStart.tm_wday = 5;		timeEnd.tm_wday = 6;		// ±Ý~Åä
				pQuestInfo->AddDateLimit( dateLimit );

				timeStart.tm_wday = 6;		timeEnd.tm_wday = 0;		// Åä~ÀÏ
				pQuestInfo->AddDateLimit( dateLimit );
			}
			else
			{
				// °á°ú ÀúÀå
				pQuestInfo->AddDateLimit( dateLimit );
			}

			

		}
		else if( stricmp( tok, "$SUBQUEST" ) == 0 )										// $SUBQUEST¿Í °°À¸¸é,
		{
			dwSubQuestIdx = pFile->GetDword();										// ¼­ºê Äù½ºÆ® ÀÎµ¦½º¸¦ ÀÐ¾îµéÀÎ´Ù.

			pSub = LoadSubQuestInfo( pFile, dwQuestIdx, dwSubQuestIdx, pQuestInfo );// ¼­ºê Äù½ºÆ® Á¤º¸¸¦ ·ÎµùÇÏ¿©, Æ÷ÀÎÅÍ·Î ¹Þ´Â´Ù.

			ASSERT(pSub);															// ASSERT Ã¼Å©¸¦ ÇÑ´Ù.

			pQuestInfo->AddSubQuestInfo( dwSubQuestIdx, pSub );						// Äù½ºÆ® Á¤º¸ÀÇ ¼­ºê Äù½ºÆ® Á¤º¸·Î Ãß°¡ÇÑ´Ù.
		}
	}

	return pQuestInfo;																// Äù½ºÆ® Á¤º¸¸¦ ¸®ÅÏÇÑ´Ù.
}

CSubQuestInfo* CQuestScriptLoader::LoadSubQuestInfo( 
	CMHFile* pFile, DWORD dwQuestIdx, DWORD dwSubQuestIdx, CQuestInfo* pQuestInfo ) // ¼­ºê Äù½ºÆ®¸¦ ·ÎµùÇÏ´Â ÇÔ¼ö.
{
	CSubQuestInfo* pSub = new CSubQuestInfo( dwQuestIdx, dwSubQuestIdx );			// ¼­ºê Äù½ºÆ® ¸¸Å­ ¸Þ¸ð¸®¸¦ ÇÒ´çÇÏ°í Æ÷ÀÎÅÍ·Î ¹Þ´Â´Ù.
	
	char buf[1024];																	// ÀÓ½Ã ¹öÆÛ¸¦ ¼±¾ðÇÑ´Ù.

	char Token[1024];																// ÅäÅ« ¹öÆÛ¸¦ ¼±¾ðÇÑ´Ù.

	while( !pFile->IsEOF() )														// ÆÄÀÏ Æ÷ÀÎÅÍ°¡ ÆÄÀÏÀÇ ³¡¿¡ µµ´ÞÇÏÁö ¾ÊÀ» µ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pFile->GetString( Token );													// ÅäÅ« ¹öÆÛ¿¡ ½ºÆ®¸µÀ» ÀÐ¾îµéÀÎ´Ù.

		if( Token[0] == '}' )														// }¿Í °°À¸¸é,
		{
			break;																	// while¹®À» Å»ÃâÇÑ´Ù.
		}

		if( strcmp(Token,"#LIMIT") == 0 )											// #LIMIT¿Í °°À¸¸é,
		{
			pFile->GetLine( buf, 1024 );											// ÀÓ½Ã¹öÆÛ·Î ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.

			CStrTokenizer tok( buf, " \t\n" );										// ÅÇ°ú ´º¶óÀÎÀ¸·Î ÅäÅ« ¼¼ÆÃÇÏ¿© ¼±¾ðÇÑ´Ù.

			//pSub->AddQuestLimit(new CQuestLimit(&tok,dwQuestIdx,dwSubQuestIdx));	// ¼­ºê Äù½ºÆ®¿¡ Äù½ºÆ® ¸®¹ÌÆ®¸¦ Ãß°¡ÇÑ´Ù.
			
			CQuestLimit* pQuestLimit = new CQuestLimit(&tok,dwQuestIdx,dwSubQuestIdx);
			if(pQuestLimit)
				pSub->AddQuestLimit(pQuestLimit);
		}

//#ifdef _MAPSERVER_																	// ¸Ê¼­¹ö°¡ ¼±¾ðµÇ¾ú´Ù¸é,

		else if( strcmp(Token,"#TRIGGER") == 0 )									// ÀÐ¾îµéÀÎ ÅäÅ«ÀÌ #TRIGGER¿Í °°À¸¸é,
		{
			pFile->GetLine( buf, 1024 );											// ÀÓ½Ã ¹öÆÛ·Î ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.

			CStrTokenizer tok( buf, " \t\n" );										// ÅÇ°ú ´º¶óÀÎÀ¸·Î ÅäÅ« ¼¼ÆÃÇÏ¿© ¼±¾ðÇÑ´Ù.
			// ¹Ýº¹Äù½ºÆ®ÀÇ È®ÀÎÀ» À§ÇØ¼­ Ãß°¡ RaMa - 04.10.26
			CQuestTrigger* pQuestTrigger = new CQuestTrigger( &tok, dwQuestIdx, dwSubQuestIdx );	// Æ®¸®°Å Æ÷ÀÎÅÍ·Î ¸Þ¸ð¸®¸¦ ÇÒ´çÇØ ¹Þ´Â´Ù.

			if(pQuestTrigger)														// Æ®¸®°Å Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
			{
				pQuestInfo->SetEndParam( pQuestTrigger->GetEndParam() );			// Á¾·á ÆÄ¶ó¸ÞÅÍ¸¦ ¼¼ÆÃÇÑ´Ù.
			}

			pSub->AddQuestTrigger( pQuestTrigger );									// ¼­ºê Äù½ºÆ®ÀÇ Æ®¸®°Å·Î Ãß°¡ÇÑ´Ù.
		}		
//#else																				// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇÁö ¾Ê¾Ò´Ù¸é,

		else if( strcmp(Token,"#NPCSCRIPT") == 0 )									// #NPCSCRIPT ¿Í °°´Ù¸é,
		{
			pFile->GetLine( buf, 1024 );											// ÀÓ½Ã¹öÆÛ·Î ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.

			CStrTokenizer tok( buf, " \t\n" );										// ÅÇ°ú ´º¶óÀÎÀ¸·Î ÅäÅ« ¼¼ÆÃÇÏ¿© ¼±¾ðÇÑ´Ù.

			//pSub->AddQuestNpcScipt( new CQuestNpcScript( &tok, dwQuestIdx, dwSubQuestIdx ) );	// ¼­ºê Äù½ºÆ®¿¡ NPC ½ºÅ©¸³Æ®¸¦ Ãß°¡ÇÑ´Ù.

			CQuestNpcScript* pQuestNpcScript = new CQuestNpcScript( &tok, dwQuestIdx, dwSubQuestIdx );
			if(pQuestNpcScript)
				pSub->AddQuestNpcScipt(pQuestNpcScript);
		}
		else if( strcmp(Token,"#NPCADD") == 0 )										// #NPCADD¿Í °°´Ù¸é,
		{
			pFile->GetLine( buf, 1024 );											// ÀÓ½Ã¹öÆÛ·Î ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.

			CStrTokenizer tok( buf, " \t\n" );										// ÅÇ°ú ´º¶óÀÎÀ¸·Î ÅäÅ« ¼¼ÆÃÇÏ¿© ¼±¾ðÇÑ´Ù.

			//pSub->AddQuestNpc( new CQuestNpc( &tok, dwQuestIdx, dwSubQuestIdx ) );	// ¼­ºê Äù½ºÆ® NPC¸¦ Ãß°¡ÇÑ´Ù.
			CQuestNpc* pQuestNpc = new CQuestNpc( &tok, dwQuestIdx, dwSubQuestIdx );
			if(pQuestNpc)
				pSub->AddQuestNpc(pQuestNpc);
		}		
		else if( strcmp(Token, "#MAXCOUNT") == 0 )									// #MAXCOUNT¿Í °°´Ù¸é,
		{
			pSub->SetMaxCount( pFile->GetDword() );									// ¼­ºê Äù½ºÆ®ÀÇ ÃÖ°í Ä«¿îÆ®¸¦ ¼¼ÆÃÇÑ´Ù.
		}
//#endif
	}

	return pSub;																	// ¼­ºê Äù½ºÆ® Á¤º¸¸¦ ¸®ÅÏÇÑ´Ù.
}

CQuestString* CQuestScriptLoader::LoadQuestString(CMHFile* pFile)					// Äù½ºÆ® ½ºÆ®¸µÀ» ·ÎµùÇÏ¿© ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
{
	CQuestString* pQStr = new CQuestString;											// Äù½ºÆ® ½ºÆ®¸µ ¸¸Å­ ¸Þ¸ð¸®¸¦ ÇÒ´çÇÏ¿© Æ÷ÀÎÅÍ·Î ¹Þ´Â´Ù.

	char* pChekString = NULL;														// Ã¼Å© ½ºÆ®¸µ Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í NULL Ã³¸®¸¦ ÇÑ´Ù.

	char buf[1024];																	// ÀÓ½Ã ¹öÆÛ¸¦ ¼±¾ðÇÑ´Ù.
	char Token[1024];																// ÅäÅ« ¹öÆÛ¸¦ ¼±¾ðÇÑ´Ù.

	int	tline=0;																	// Å¸ÀÌÆ² ¶óÀÎ±æÀÌµé ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.
	int dline=0;																	// ¼³¸í ±æÀÌ¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	while( !pFile->IsEOF() )														// ÆÄÀÏ Æ÷ÀÎÅÍ°¡ ÆÄÀÏ ³¡ÀÌ ¾Æ´Òµ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pFile->GetString(Token);													// ÅäÅ« ¹öÆÛ¿¡ ½ºÆ®¸µÀ» ÀÐ¾îµéÀÎ´Ù.

		if( ( pChekString = strstr( Token, "}" ) ) != NULL)									// ÅäÅ«ÀÌ }¿Í °°À¸¸é,
		{
			break;																	// while¹®À» Å»ÃâÇÑ´Ù.
		}
		
		if(strcmp(Token,"#TITLE") == 0)												// ÅäÅ«ÀÌ #TITLE °ú °°´Ù¸é,
		{
			pFile->GetLine(buf, 1024);												// ÀÓ½Ã ¹öÆÛ¿¡ ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.

			pQStr->AddLine(buf, tline, TRUE);										// Äù½ºÆ® ½ºÆ®¸µ¿¡ ¶óÀÎÀ» Ãß°¡ÇÑ´Ù.
		}
		if(strcmp(Token,"#DESC") == 0)												// ÅäÅ«ÀÌ #DESC¿Í °°´Ù¸é,
		{
			while( !pFile->IsEOF() )												// ÆÄÀÏ Æ÷ÀÎÅÍ°¡ ÆÄÀÏ ³¡ÀÌ ¾Æ´Òµ¿¾È while¹®À» µ¹¸°´Ù.
			{
				pFile->GetLine(buf, 1024);											// ÀÓ½Ã ¹öÆÛ¿¡ ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.

				char * p = buf;														// ÀÓ½Ã ¹öÆÛ¸¦ Æ÷ÀÎÅÍ·Î ¹Þ´Â´Ù.

				int nRt = 0;														// °á°ú °ªÀ» ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.

				while( *p )															// Æ÷ÀÎÅÍ°¡ À¯È¿ÇÒ µ¿¾È while¹®À» µ¹¸°´Ù.
				{
					if( IsDBCSLeadByte( *p ) )										// ¸®µå ¹ÙÀÌÆ® ¶ó¸é,
					{
						++p;														// Æ÷ÀÎÅÍ¸¦ Áõ°¡½ÃÅ²´Ù.
					}
					else															// ¸®µå ¹ÙÀÌÆ®°¡ ¾Æ´Ï¶ó¸é,
					{
						if( *p == '{' )												// {¿Í °°´Ù¸é,
						{
							nRt = 1;												// °á°ú °ªÀ» 1·Î ¼¼ÆÃÇÑ´Ù.
							break;													// while¹®À» Å»ÃâÇÑ´Ù.
						}
						else if(  *p == '}' )										// }¿Í °°´Ù¸é,
						{
							nRt = 2;												// °á°ú °ªÀ» 2·Î ¼¼ÆÃÇÑ´Ù.
							break;													// while¹®À» Å»ÃâÇÑ´Ù.
						}
					}

					++p;															// Æ÷ÀÎÅÍ¸¦ Áõ°¡½ÃÅ²´Ù.
				}

				if( nRt == 1 )														// °á°ú °ªÀÌ 1°ú °°´Ù¸é, 
				{
					continue;														// °è¼Ó ÁøÇàÇÑ´Ù.
				}
				else if( nRt == 2 )													// °á°ú °ªÀÌ 2¿Í °°´Ù¸é,
				{
					break;															// while¹®À» Å»ÃâÇÑ´Ù.
				}

				pQStr->AddLine(buf, dline);											// ½ºÆ®¸µ Æ÷ÀÎÅÍ¿¡ ¶óÀÎÀ» Ãß°¡ÇÑ´Ù.

				++dline;															// ¶óÀÎ °ªÀ» Áõ°¡½ÃÅ²´Ù.
			}
		}
	}

	return pQStr;																	// ½ºÆ®¸µ Æ÷ÀÎÅÍ¸¦ ¸®ÅÏÇÑ´Ù.
}

//void CQuestScriptLoader::LoadQuestString(CMHFile* pFile, CQuestString* pQStr)		// Äù½ºÆ® ½ºÆ®¸µÀ» ·ÎµùÇÏ¿© ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
//{
//	char* pChekString = NULL;														// Ã¼Å© ½ºÆ®¸µ Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í NULL Ã³¸®¸¦ ÇÑ´Ù.
//
//	char buf[1024];																	// ÀÓ½Ã ¹öÆÛ¸¦ ¼±¾ðÇÑ´Ù.
//	char Token[1024];																// ÅäÅ« ¹öÆÛ¸¦ ¼±¾ðÇÑ´Ù.
//
//	int	tline=0;																	// Å¸ÀÌÆ² ¶óÀÎ±æÀÌµé ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.
//	int dline=0;																	// ¼³¸í ±æÀÌ¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.
//
//	while( !pFile->IsEOF() )														// ÆÄÀÏ Æ÷ÀÎÅÍ°¡ ÆÄÀÏ ³¡ÀÌ ¾Æ´Òµ¿¾È while¹®À» µ¹¸°´Ù.
//	{
//		pFile->GetString(Token);													// ÅäÅ« ¹öÆÛ¿¡ ½ºÆ®¸µÀ» ÀÐ¾îµéÀÎ´Ù.
//
//		if( pChekString = strstr( Token, "}" ) )									// ÅäÅ«ÀÌ }¿Í °°À¸¸é,
//		{
//			break;																	// while¹®À» Å»ÃâÇÑ´Ù.
//		}
//		
//		if(strcmp(Token,"#TITLE") == 0)												// ÅäÅ«ÀÌ #TITLE °ú °°´Ù¸é,
//		{
//			pFile->GetLine(buf, 1024);												// ÀÓ½Ã ¹öÆÛ¿¡ ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.
//
//			//pQStr->AddLine(buf, tline, TRUE);										// Äù½ºÆ® ½ºÆ®¸µ¿¡ ¶óÀÎÀ» Ãß°¡ÇÑ´Ù.
//
//			ITEM* pItem = new ITEM ;
//
//			strcpy(pItem->string, buf) ;
//			pItem->line = tline ;
//			pItem->rgb = RGB(0, 0, 64) ;
//
//			pQStr->GetTitle()->AddTail(pItem) ;
//		}
//		if(strcmp(Token,"#DESC") == 0)												// ÅäÅ«ÀÌ #DESC¿Í °°´Ù¸é,
//		{
//			while( !pFile->IsEOF() )												// ÆÄÀÏ Æ÷ÀÎÅÍ°¡ ÆÄÀÏ ³¡ÀÌ ¾Æ´Òµ¿¾È while¹®À» µ¹¸°´Ù.
//			{
//				pFile->GetLine(buf, 1024);											// ÀÓ½Ã ¹öÆÛ¿¡ ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.
//
//				char * p = buf;														// ÀÓ½Ã ¹öÆÛ¸¦ Æ÷ÀÎÅÍ·Î ¹Þ´Â´Ù.
//
//				int nRt = 0;														// °á°ú °ªÀ» ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.
//
//				while( *p )															// Æ÷ÀÎÅÍ°¡ À¯È¿ÇÒ µ¿¾È while¹®À» µ¹¸°´Ù.
//				{
//					if( IsDBCSLeadByte( *p ) )										// ¸®µå ¹ÙÀÌÆ® ¶ó¸é,
//					{
//						++p;														// Æ÷ÀÎÅÍ¸¦ Áõ°¡½ÃÅ²´Ù.
//					}
//					else															// ¸®µå ¹ÙÀÌÆ®°¡ ¾Æ´Ï¶ó¸é,
//					{
//						if( *p == '{' )												// {¿Í °°´Ù¸é,
//						{
//							nRt = 1;												// °á°ú °ªÀ» 1·Î ¼¼ÆÃÇÑ´Ù.
//							break;													// while¹®À» Å»ÃâÇÑ´Ù.
//						}
//						else if(  *p == '}' )										// }¿Í °°´Ù¸é,
//						{
//							nRt = 2;												// °á°ú °ªÀ» 2·Î ¼¼ÆÃÇÑ´Ù.
//							break;													// while¹®À» Å»ÃâÇÑ´Ù.
//						}
//					}
//
//					++p;															// Æ÷ÀÎÅÍ¸¦ Áõ°¡½ÃÅ²´Ù.
//				}
//
//				if( nRt == 1 )														// °á°ú °ªÀÌ 1°ú °°´Ù¸é, 
//				{
//					continue;														// °è¼Ó ÁøÇàÇÑ´Ù.
//				}
//				else if( nRt == 2 )													// °á°ú °ªÀÌ 2¿Í °°´Ù¸é,
//				{
//					break;															// while¹®À» Å»ÃâÇÑ´Ù.
//				}
//
//				pQStr->AddLine(buf, dline);											// ½ºÆ®¸µ Æ÷ÀÎÅÍ¿¡ ¶óÀÎÀ» Ãß°¡ÇÑ´Ù.
//
//				++dline;															// ¶óÀÎ °ªÀ» Áõ°¡½ÃÅ²´Ù.
//			}
//		}
//	}
//}

//CQuestString* CQuestScriptLoader::LoadQuestString(CMHFile* pFile)					// Äù½ºÆ® ½ºÆ®¸µÀ» ·ÎµùÇÏ¿© ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
//{
//	CQuestString* pQStr = new CQuestString;											// Äù½ºÆ® ½ºÆ®¸µ ¸¸Å­ ¸Þ¸ð¸®¸¦ ÇÒ´çÇÏ¿© Æ÷ÀÎÅÍ·Î ¹Þ´Â´Ù.
//
//	char* pChekString = NULL;														// Ã¼Å© ½ºÆ®¸µ Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í NULL Ã³¸®¸¦ ÇÑ´Ù.
//
//	char buf[1024];																	// ÀÓ½Ã ¹öÆÛ¸¦ ¼±¾ðÇÑ´Ù.
//	char Token[1024];																// ÅäÅ« ¹öÆÛ¸¦ ¼±¾ðÇÑ´Ù.
//
//	int	tline=0;																	// Å¸ÀÌÆ² ¶óÀÎ±æÀÌµé ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.
//	int dline=0;																	// ¼³¸í ±æÀÌ¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.
//
//	while( !pFile->IsEOF() )														// ÆÄÀÏ Æ÷ÀÎÅÍ°¡ ÆÄÀÏ ³¡ÀÌ ¾Æ´Òµ¿¾È while¹®À» µ¹¸°´Ù.
//	{
//		pFile->GetString(Token);													// ÅäÅ« ¹öÆÛ¿¡ ½ºÆ®¸µÀ» ÀÐ¾îµéÀÎ´Ù.
//
//		if( pChekString = strstr( Token, "}" ) )									// ÅäÅ«ÀÌ }¿Í °°À¸¸é,
//		{
//			break;																	// while¹®À» Å»ÃâÇÑ´Ù.
//		}
//		
//		if(strcmp(Token,"#TITLE") == 0)												// ÅäÅ«ÀÌ #TITLE °ú °°´Ù¸é,
//		{
//			pFile->GetLine(buf, 1024);												// ÀÓ½Ã ¹öÆÛ¿¡ ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.
//
//			pQStr->AddLine(buf, tline, TRUE);										// Äù½ºÆ® ½ºÆ®¸µ¿¡ ¶óÀÎÀ» Ãß°¡ÇÑ´Ù.
//		}
//		if(strcmp(Token,"#DESC") == 0)												// ÅäÅ«ÀÌ #DESC¿Í °°´Ù¸é,
//		{
//			while( !pFile->IsEOF() )												// ÆÄÀÏ Æ÷ÀÎÅÍ°¡ ÆÄÀÏ ³¡ÀÌ ¾Æ´Òµ¿¾È while¹®À» µ¹¸°´Ù.
//			{
//				pFile->GetLine(buf, 1024);											// ÀÓ½Ã ¹öÆÛ¿¡ ¶óÀÎÀ» ÀÐ¾îµéÀÎ´Ù.
//
//				char * p = buf;														// ÀÓ½Ã ¹öÆÛ¸¦ Æ÷ÀÎÅÍ·Î ¹Þ´Â´Ù.
//
//				int nRt = 0;														// °á°ú °ªÀ» ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.
//
//				while( *p )															// Æ÷ÀÎÅÍ°¡ À¯È¿ÇÒ µ¿¾È while¹®À» µ¹¸°´Ù.
//				{
//					if( IsDBCSLeadByte( *p ) )										// ¸®µå ¹ÙÀÌÆ® ¶ó¸é,
//					{
//						++p;														// Æ÷ÀÎÅÍ¸¦ Áõ°¡½ÃÅ²´Ù.
//					}
//					else															// ¸®µå ¹ÙÀÌÆ®°¡ ¾Æ´Ï¶ó¸é,
//					{
//						if( *p == '{' )												// {¿Í °°´Ù¸é,
//						{
//							nRt = 1;												// °á°ú °ªÀ» 1·Î ¼¼ÆÃÇÑ´Ù.
//							break;													// while¹®À» Å»ÃâÇÑ´Ù.
//						}
//						else if(  *p == '}' )										// }¿Í °°´Ù¸é,
//						{
//							nRt = 2;												// °á°ú °ªÀ» 2·Î ¼¼ÆÃÇÑ´Ù.
//							break;													// while¹®À» Å»ÃâÇÑ´Ù.
//						}
//					}
//
//					++p;															// Æ÷ÀÎÅÍ¸¦ Áõ°¡½ÃÅ²´Ù.
//				}
//
//				if( nRt == 1 )														// °á°ú °ªÀÌ 1°ú °°´Ù¸é, 
//				{
//					continue;														// °è¼Ó ÁøÇàÇÑ´Ù.
//				}
//				else if( nRt == 2 )													// °á°ú °ªÀÌ 2¿Í °°´Ù¸é,
//				{
//					break;															// while¹®À» Å»ÃâÇÑ´Ù.
//				}
//
//				pQStr->AddLine(buf, dline);											// ½ºÆ®¸µ Æ÷ÀÎÅÍ¿¡ ¶óÀÎÀ» Ãß°¡ÇÑ´Ù.
//
//				++dline;															// ¶óÀÎ °ªÀ» Áõ°¡½ÃÅ²´Ù.
//			}
//		}
//	}
//
//	return pQStr;																	// ½ºÆ®¸µ Æ÷ÀÎÅÍ¸¦ ¸®ÅÏÇÑ´Ù.
//}

// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù¸¦ ·ÎµùÇÏ´Â ÇÔ¼ö.
CQuestLimitKind* CQuestScriptLoader::LoadQuestLimitKind( char* strKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
	LOADUNIT( eQuestLimitKind_Level,	"&LEVEL",		CQuestLimitKind_Level, dwQuestIdx, dwSubQuestIdx );	// ·¹º§ Á¦ÇÑ Á¤º¸¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestLimitKind_Money,	"&MONEY",		CQuestLimitKind_Level, dwQuestIdx, dwSubQuestIdx );	// ¸Ó´Ï Á¦ÇÑ Á¤º¸¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestLimitKind_Quest,	"&QUEST",		CQuestLimitKind_Quest, dwQuestIdx, dwSubQuestIdx );	// Äù½ºÆ® Á¦ÇÑ Á¤º¸¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestLimitKind_SubQuest, "&SUBQUEST",	CQuestLimitKind_Quest, dwQuestIdx, dwSubQuestIdx );	// ¼­ºê Äù½ºÆ® Á¦ÇÑ Á¤º¸¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestLimitKind_Stage,	"&STAGE",		CQuestLimitKind_Stage, dwQuestIdx, dwSubQuestIdx );	// ½ºÅ×ÀÌÁö Á¦ÇÑ Á¤º¸¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	// 071011 LYW --- QuestScriptLoader : Add quest limit to check running quest.
	LOADUNIT( eQuestLimitKind_RunningQuest, "&RUNNING_QUEST", CQuestLimitKind_Quest, dwQuestIdx, dwSubQuestIdx ) ; // ÁøÇàÁßÀÎ Äù½ºÆ® Á¦ÇÑ Á¤º¸¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.

	return NULL;																							// NULLÀ» ¸®ÅÏÇÑ´Ù.
}

// Äù½ºÆ® »óÅÂ¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÏ´Â ÇÔ¼ö.
CQuestCondition* CQuestScriptLoader::LoadQuestCondition( char* strKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
	CQuestEvent* pEvent = LoadQuestEvent( strKind, pTokens, dwQuestIdx, dwSubQuestIdx );					// Äù½ºÆ® ÀÌº¥Æ® Á¤º¸¸¦ ·ÎµùÇÏ¿© ¹Þ´Â´Ù.

	ASSERT(pEvent);																							// ASSERT Ã¼Å©¸¦ Ãß°¡ÇÏ¿© ³Ö´Â´Ù.

	CQuestCondition* pCondition = new CQuestCondition( pEvent, dwQuestIdx, dwSubQuestIdx );					// Äù½ºÆ® »óÅÂ ¸Þ¸ð¸®¸¦ ÇÒ´çÇÏ¿© Æ÷ÀÎÅÍ·Î ¹Þ´Â´Ù.

	return pCondition;																						// Æ÷ÀÎÅÍ¸¦ ¸®ÅÏÇÑ´Ù.
}

// Äù½ºÆ® ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
CQuestEvent* CQuestScriptLoader::LoadQuestEvent( char* strKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
	LOADUNIT( eQuestEvent_NpcTalk,		"@TALKTONPC",	CQuestEvent, dwQuestIdx, dwSubQuestIdx );			// NPC ´ëÈ­ ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestEvent_Hunt,			"@HUNT",		CQuestEvent, dwQuestIdx, dwSubQuestIdx );			// »ç³É ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestEvent_Count,		"@COUNT",		CQuestEvent, dwQuestIdx, dwSubQuestIdx );			// Ä«¿îÆ® ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestEvent_GameEnter,	"@GAMEENTER",	CQuestEvent, dwQuestIdx, dwSubQuestIdx );			// °ÔÀÓ ¿£ÅÍ? ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestEvent_Level,		"@LEVEL",		CQuestEvent, dwQuestIdx, dwSubQuestIdx );			// ·¹º§ ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestEvent_UseItem,		"@USEITEM",		CQuestEvent, dwQuestIdx, dwSubQuestIdx );			// ¾ÆÀÌÅÛ »ç¿ë ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestEvent_MapChange,	"@MAPCHANGE",	CQuestEvent, dwQuestIdx, dwSubQuestIdx );			// ¸Ê Ã¼ÀÎÁö ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestEvent_Die,			"@DIE",			CQuestEvent, dwQuestIdx, dwSubQuestIdx );			// ´ÙÀÌ ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	LOADUNIT( eQuestEvent_HuntAll,		"@HUNTALL",		CQuestEvent, dwQuestIdx, dwSubQuestIdx );			// »ç³É ¿Ã~ ÀÌº¥Æ®¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.

	return NULL;																							// NULLÀ» ¸®ÅÏÇÑ´Ù.
}

// Äù½ºÆ® ½ÇÇàÀ» ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
CQuestExecute* CQuestScriptLoader::LoadQuestExecute( char* strKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
	LOADUNIT( eQuestExecute_EndQuest,			"*ENDQUEST",			CQuestExecute_Quest, dwQuestIdx, dwSubQuestIdx );	// Äù½ºÆ® Á¾·á.
	LOADUNIT( eQuestExecute_StartSub,			"*STARTSUB",			CQuestExecute_Quest, dwQuestIdx, dwSubQuestIdx );	// ¼­ºê Äù½ºÆ® ½ÃÀÛ.
	LOADUNIT( eQuestExecute_EndSub,				"*ENDSUB",				CQuestExecute_Quest, dwQuestIdx, dwSubQuestIdx );	// ¼­ºê Äù½ºÆ® Á¾·á.
	LOADUNIT( eQuestExecute_EndOtherSub,		"*ENDOTHERSUB",			CQuestExecute_Quest, dwQuestIdx, dwSubQuestIdx );	// ´Ù¸¥ ¼­ºê Äù½ºÆ® Á¾·á.
	
	LOADUNIT( eQuestExecute_AddCount,			"*ADDCOUNT",			CQuestExecute_Count, dwQuestIdx, dwSubQuestIdx );	// Ä«¿îÆ® Ãß°¡.
	LOADUNIT( eQuestExecute_AddCountFQW,		"*ADDCOUNTFQW",			CQuestExecute_Count, dwQuestIdx, dwSubQuestIdx );	// ¹«±â Ä«¿îÆ® Ãß°¡.
	LOADUNIT( eQuestExecute_AddCountFW,			"*ADDCOUNTFW",			CQuestExecute_Count, dwQuestIdx, dwSubQuestIdx );	// ¹«±â Ä«¿îÆ® Ãß°¡.
	LOADUNIT( eQuestExecute_LevelGap,			"*ADDCOUNTLEVELGAP",	CQuestExecute_Count, dwQuestIdx, dwSubQuestIdx );	// ·¹º§ Â÷ÀÌ Ä«¿îÆ® Ãß°¡.
	LOADUNIT( eQuestExecute_MonLevel,			"*ADDCOUNTMONLEVEL",	CQuestExecute_Count, dwQuestIdx, dwSubQuestIdx );	// ¸ó½ºÅÍ ·¹º§ Ä«¿îÆ® Ãß°¡.

	LOADUNIT( eQuestExecute_GiveQuestItem,		"*GIVEQUESTITEM",		CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// Äù½ºÆ® ¾ÆÀÌÅÛ ¹Ý³³.
	LOADUNIT( eQuestExecute_TakeQuestItem,		"*TAKEQUESTITEM",		CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// Äù½ºÆ® ¾ÆÀÌÅÛ È¹µæ.
	LOADUNIT( eQuestExecute_GiveItem,			"*GIVEITEM",			CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// ¾ÆÀÌÅÛ ¹Ý³³.
	LOADUNIT( eQuestExecute_GiveMoney,			"*GIVEMONEY",			CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// ¸Ó´Ï ¹Ý³³.
	LOADUNIT( eQuestExecute_TakeItem,			"*TAKEITEM",			CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// ¾ÆÀÌÅÛ È¹µæ.
	LOADUNIT( eQuestExecute_TakeMoney,			"*TAKEMONEY",			CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// ¸Ó´Ï È¹µæ.
	LOADUNIT( eQuestExecute_TakeExp,			"*TAKEEXP",				CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// °æÇèÄ¡ È¹µæ.
	LOADUNIT( eQuestExecute_TakeSExp,			"*TAKESEXP",			CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// SP È¹µæ.
	LOADUNIT( eQuestExecute_TakeQuestItemFQW,	"*TAKEQUESTITEMFQW",	CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// Äù½ºÆ® ¾ÆÀÌÅÛ ¹«±â È¹µæ.
	LOADUNIT( eQuestExecute_TakeQuestItemFW,	"*TAKEQUESTITEMFW",		CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// Äù½ºÆ® ¾ÆÀÌÅÛ ¹«±â È¹µæ.
	LOADUNIT( eQuestExecute_TakeMoneyPerCount,	"*TAKEMONEYPERCOUNT",	CQuestExecute_Item, dwQuestIdx, dwSubQuestIdx );	// Ä«¿îÆ® ´ç ¸Ó´Ï È¹µæ.
	LOADUNIT( eQuestExecute_TakeSelectItem,		"*SELECTITEM",			CQuestExecute_SelectItem, dwQuestIdx, dwSubQuestIdx );	// 100414 ONS ¼±ÅÃº¸»ó µî·Ï.
	
	LOADUNIT( eQuestExecute_RandomTakeItem,		"*RANDOMTAKEITEM",		CQuestExecute_RandomItem, dwQuestIdx, dwSubQuestIdx );	// ·£´ý È¹µæ ¾ÆÀÌÅÛ.

	LOADUNIT( eQuestExecute_RegenMonster,		"*REGENMONSTER",		CQuestExecute_Quest, dwQuestIdx, dwSubQuestIdx );		// ¸ó½ºÅÍ ¸®Á¨.
	LOADUNIT( eQuestExecute_MapChange,			"*MAPCHANGE",			CQuestExecute_Quest, dwQuestIdx, dwSubQuestIdx );		// ¸Ê Ã¼ÀÎÁö.
	
	LOADUNIT( eQuestExecute_ChangeStage,		"*CHANGESTAGE",			CQuestExecute_Quest, dwQuestIdx, dwSubQuestIdx );		// ½ºÅ×ÀÌÁö Ã¼ÀÎÁö.
	
	LOADUNIT( eQuestExecute_RegistTime,			"*REGISTTIME",			CQuestExecute_Time, dwQuestIdx, dwSubQuestIdx );		// ½Ã°£ µî·Ï.

	return NULL;	
}

// Äù½ºÆ® NPC µ¥ÀÌÅÍ¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÏ´Â ÇÔ¼ö.
CQuestNpcData* CQuestScriptLoader::LoadQuestNpcData( char* strKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
	LOADUNIT( 0, "@NPC", CQuestNpcData, dwQuestIdx, dwSubQuestIdx );		// NPC µ¥ÀÌÅÍ¸¦ ·ÎµùÇÏ¿© ¸®ÅÏÇÑ´Ù.
	return NULL;															// NULLÀ» ¸®ÅÏÇÑ´Ù.
}

void CQuestScriptLoader::ParseDateInfo( const char* buf, struct tm& timeStart, struct tm& timeEnd, BOOL& bDaily, BOOL& bHasEndTime )
{
	struct _StrDateParse{
		int GetValueAndDelete( std::string& str, const char* findStr )
		{
			const size_t findStrSize = strlen( findStr );
			size_t nPos = str.find( findStr );
			if( nPos == std::string::npos )
			{
				int val = atoi( str.c_str() );
				str = "";
				return val;
			}

			std::string substr = str.substr( 0, nPos );
			str = str.substr( nPos + findStrSize, str.length() );
			if( stricmp( "*", substr.c_str() ) == 0 )
				return 0;

			return atoi( substr.c_str() );
		}
		std::string& GetCutBlank( std::string& str )
		{			size_t blankPos = std::string::npos;
			while( (blankPos = str.find( " " ) ) != std::string::npos )
			{
				str.replace( blankPos, blankPos+1, "" );
			}

			return str;
		}
		int GetWeekDay( std::string& str )
		{
			str = GetCutBlank( str );
			if( stricmp( "Sun", str.c_str() ) == 0 )
				return 0;
			else if( stricmp( "Mon", str.c_str() ) == 0 )
				return 1;
			else if( stricmp( "Tus", str.c_str() ) == 0 )
				return 2;
			else if( stricmp( "Wed", str.c_str() ) == 0 )
				return 3;
			else if( stricmp( "Thu", str.c_str() ) == 0 )
				return 4;
			else if( stricmp( "Fri", str.c_str() ) == 0 )
				return 5;
			else if( stricmp( "Sat", str.c_str() ) == 0 )
				return 6;

			return -1;
		}

		void MakeUpperStr( std::string& str )
		{
			std::transform( str.begin(), str.end(), str.begin(), toupper );
		}

	}StrDateParse;

	try
	{
		timeEnd.tm_hour = 23;
		timeEnd.tm_min = 59;

		std::string strBuf( buf );
		StrDateParse.MakeUpperStr( strBuf );

		size_t afterPos = strBuf.find( "~", 0 );
		std::string strBefore = strBuf.substr( 0, afterPos );
		std::string strAfter = ( afterPos == std::string::npos ? "" : strBuf.substr( afterPos + 1, strBuf.length() ) );

		const char* monthDayChar = "/";
		const char* hourMinChar = ":";
		const char* nextDataChar = " ";

		timeStart.tm_mon = timeEnd.tm_mon = -1;

		// ÀÏÀÏ Äù½ºÆ®
		if( strBefore.find( "DAILY", 0 ) != std::string::npos )
		{
			StrDateParse.GetValueAndDelete( strBefore, "DAILY" );
			bDaily = TRUE;
		}

		// ¿ù/ÀÏ Parse
		if( strBefore.find( monthDayChar ) != std::string::npos )
		{
			timeStart.tm_mon	= StrDateParse.GetValueAndDelete( strBefore, monthDayChar ) - 1;		// Month (0 - 11, January = 0).
			timeStart.tm_mday	= StrDateParse.GetValueAndDelete( strBefore, nextDataChar );
		}

		// ½Ã:ºÐ Parse
		if( strBefore.find( hourMinChar ) != std::string::npos )
		{
			timeStart.tm_hour	= StrDateParse.GetValueAndDelete( strBefore, hourMinChar );
			timeStart.tm_min	= StrDateParse.GetValueAndDelete( strBefore, nextDataChar );
		}

		// ¿äÀÏ Parse
		timeStart.tm_wday	= StrDateParse.GetWeekDay( strBefore );


		// ¿ù/ÀÏ Parse
		if( strAfter.find( monthDayChar ) != std::string::npos )
		{
			timeEnd.tm_mon	= StrDateParse.GetValueAndDelete( strAfter, monthDayChar ) - 1;				// Month (0 - 11, January = 0).
			timeEnd.tm_mday	= StrDateParse.GetValueAndDelete( strAfter, nextDataChar );
		}

		// ½Ã:ºÐ Parse
		if( strAfter.find( hourMinChar ) != std::string::npos )
		{
			timeEnd.tm_hour	= StrDateParse.GetValueAndDelete( strAfter, hourMinChar );
			timeEnd.tm_min	= StrDateParse.GetValueAndDelete( strAfter, nextDataChar );
			bHasEndTime = TRUE;
		}

		// ¿äÀÏ Parse
		timeEnd.tm_wday	= StrDateParse.GetWeekDay( strAfter );
	}
	catch(...)
	{
	}
}