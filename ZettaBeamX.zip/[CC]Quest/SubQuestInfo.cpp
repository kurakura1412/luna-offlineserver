
// SubQuestInfo.cpp: implementation of the CSubQuestInfo class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"																			// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "SubQuestInfo.h"																	// ¼­ºê Äù½ºÆ® Á¤º¸ ÇØ´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestLimit.h"																		// Äù½ºÆ® Á¦ÇÑ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestTrigger.h"																	// Äù½ºÆ® Æ®¸®°Å Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestNpcScript.h"																	// Äù½ºÆ® npc ½ºÅ©¸³Æ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestNpc.h"																		// Äù½ºÆ® npc Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestExecute.h"
#include "QuestManager.h"

#ifdef _MAPSERVER_
	#include "Quest.h"
	#include "QuestGroup.h"
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSubQuestInfo::CSubQuestInfo( DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
	m_dwQuestIdx = dwQuestIdx;
	m_dwSubQuestIdx = dwSubQuestIdx;
	m_dwMaxCount = 0;																		// ÃÖ´ë Ä«¿îÆ®¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.
}

CSubQuestInfo::~CSubQuestInfo()																// ¼Ò¸êÀÚ ÇÔ¼ö.
{
	Release();																				// ÇØÁ¦ ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
}

void CSubQuestInfo::Release()																// ÇØÁ¦ ÇÔ¼ö.
{
	CQuestLimit* pLimit = NULL;																// Äù½ºÆ® Á¦ÇÑ Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ º¯¼ö¸¦ ¼±¾ðÇÏ°í null Ã³¸®¸¦ ÇÑ´Ù.

	PTRLISTPOS pos = m_QuestLimitList.GetHeadPosition();									// Äù½ºÆ® Á¦ÇÑ ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í À§Ä¡¸¦ ¹Þ´Â´Ù.

	while( pos )																			// À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑ µ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pLimit = (CQuestLimit*)m_QuestLimitList.GetNext( pos );								// À§Ä¡ Á¤º¸¿¡ ÇØ´çÇÏ´Â Äù½ºÆ® Á¦ÇÑ Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pLimit )																		// Äù½ºÆ® Á¦ÇÑ Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
		{
			delete pLimit;																	// Äù½ºÆ® Á¦ÇÑ Á¤º¸¸¦ »èÁ¦ÇÑ´Ù.
		}
	}

	m_QuestLimitList.RemoveAll();															// Äù½ºÆ® Á¦ÇÑ ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿î´Ù.

	CQuestTrigger* pTrigger = NULL;															// Å©¸®°Å Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í NULL Ã³¸®¸¦ ÇÑ´Ù.

	pos = m_QuestTriggerList.GetHeadPosition();												// Äù½ºÆ® Æ®¸®°¡ ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	while( pos )																			// À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑ µ¿¾È while ¹®À» µ¹¸°´Ù.
	{
		pTrigger = (CQuestTrigger*)m_QuestTriggerList.GetNext( pos );						// À§Ä¡¿¡ ÇØ´çÇÏ´Â Æ®¸®°Å Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pTrigger )																		// Æ®¸®°Å Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
		{
			delete pTrigger;																// Æ®¸®°Å Á¤º¸¸¦ »èÁ¦ÇÑ´Ù.
		}
	}

	m_QuestTriggerList.RemoveAll();															// Æ®¸®°Å ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿î´Ù.


	for( std::map< DWORD, CQuestNpcScript* >::iterator npcScriptIter = m_QuestNpcScript.begin() ; npcScriptIter != m_QuestNpcScript.end() ; ++npcScriptIter )
	{
		CQuestNpcScript* pNpcScript = npcScriptIter->second;
		SAFE_DELETE( pNpcScript );
	}
	m_QuestNpcScript.clear();

	CQuestNpc* pQuestNpc = NULL;															// Äù½ºÆ® npc Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í null Ã³¸®¸¦ ÇÑ´Ù.

	pos = m_QuestNpcList.GetHeadPosition();													// Äù½ºÆ® npc ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	while( pos )																			// À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑµ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pQuestNpc = (CQuestNpc*)m_QuestNpcList.GetNext( pos );								// Äù½ºÆ® npc Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pQuestNpc )																		// Äù½ºÆ® npc Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
		{
			delete pQuestNpc;																// Äù½ºÆ® npc Á¤º¸¸¦ »èÁ¦ÇÑ´Ù.
		}
	}

	m_QuestNpcList.RemoveAll();																// Äù½ºÆ® npc ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿î´Ù.
}

void CSubQuestInfo::AddQuestLimit( CQuestLimit* pQuestLimit )								// Äù½ºÆ® Á¦ÇÑ Á¤º¸¸¦ Ãß°¡ÇÏ´Â ÇÔ¼ö.
{
	if( !pQuestLimit ) return;																// Äù½ºÆ® Á¦ÇÑ Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.

	m_QuestLimitList.AddTail( pQuestLimit );												// Äù½ºÆ® Á¦ÇÑ ¸®½ºÆ®¿¡ Ãß°¡ÇÑ´Ù.
}

void CSubQuestInfo::AddQuestTrigger( CQuestTrigger* pQuestTrigger )							// Äù½ºÆ® Æ®¸®°Å¸¦ Ãß°¡ÇÏ´Â ÇÔ¼ö.
{
	if( !pQuestTrigger ) return;															// Äù½ºÆ® Æ®¸®°Å Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.

	m_QuestTriggerList.AddTail( pQuestTrigger );											// Äù½ºÆ® Æ®¸®°Å ¸®½ºÆ®¿¡ Ãß°¡ÇÑ´Ù.
}

void CSubQuestInfo::AddQuestNpcScipt( CQuestNpcScript* pQuestNpcScript )					// Äù½ºÆ® npc ½ºÅ©¸³Æ®¸¦ Ãß°¡ÇÏ´Â ÇÔ¼ö.
{
	if( !pQuestNpcScript ) return;															// Äù½ºÆ® npc ½ºÅ©¸³Æ® Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.

	m_QuestNpcScript.insert( std::make_pair( pQuestNpcScript->GetKind(), pQuestNpcScript ) );	// Äù½ºÆ® npc ½ºÅ©¸³Æ® ¸®½ºÆ®¿¡ Ãß°¡ÇÑ´Ù.
}

CQuestNpcScript* CSubQuestInfo::GetQuestNpcScript()
{
	// 100517 ShinJS --- Äù½ºÆ® ¿ä±¸»çÇ×À» ¿Ï·áÇß´ÂÁö °Ë»ç(ÀÏ¹Ý ¾ÆÀÌÅÛ µî)
	const DWORD dwNpcScriptState = ( QUESTMGR->IsCompletedDemandQuestExecute( m_dwQuestIdx ) == TRUE ? eQuest_NpcScript_Normal : eQuest_NpcScript_Lack );
	std::map< DWORD, CQuestNpcScript* >::const_iterator npcScriptIter = m_QuestNpcScript.find( dwNpcScriptState );
	if( npcScriptIter == m_QuestNpcScript.end() )
	{
		if( dwNpcScriptState != eQuest_NpcScript_Normal )
		{
			npcScriptIter = m_QuestNpcScript.find( eQuest_NpcScript_Normal );
			if( npcScriptIter == m_QuestNpcScript.end() )
				return NULL;
		}
		else
		{
			return NULL;
		}
	}

	return npcScriptIter->second;
}

void CSubQuestInfo::AddQuestNpc( CQuestNpc* pQuestNpc )										// Äù½ºÆ® npc ¸¦ Ãß°¡ÇÏ´Â ÇÔ¼ö.
{
	if( !pQuestNpc ) return;																// Äù½ºÆ® npc Á¤º¸°¡ À¯È¿ ÇÏÁö ¾ÊÀ¸¸é ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.

	m_QuestNpcList.AddTail(  pQuestNpc );													// Äù½ºÆ® npc ¸®½ºÆ®¿¡ Ãß°¡ÇÑ´Ù.
}

BOOL CSubQuestInfo::OnQuestEvent( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest, CQuestEvent* pQuestEvent )	// Äù½ºÆ® ÀÌº¥Æ®¸¦ Ã³¸®ÇÏ´Â ÇÔ¼ö.
{
	// 100405 ShinJS --- QuestEvent ½ÇÇà °¡´É ÆÇ´Ü
	if( !CanDoOnQuestEvent( pPlayer, pQuestGroup, pQuest ) )
		return FALSE;

	BOOL bIsExcuted = TRUE;
	
	// trigger
	PTRLISTPOS pos = m_QuestTriggerList.GetHeadPosition();									// Æ®¸®°Å ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	CQuestTrigger* pTrigger = NULL;															// Æ®¸®°Å Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í null Ã³¸®¸¦ ÇÑ´Ù.

	while( pos )																			// À§Ä¡ Á¤º¸°¡ ÀÖ´Âµ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pTrigger = (CQuestTrigger*)m_QuestTriggerList.GetNext( pos );						// À§Ä¡¿¡ ÇØ´çÇÏ´Â Æ®¸®°Å Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pTrigger )																		// Æ®¸®°Å Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
		{
			if( pTrigger->OnQuestEvent( pPlayer, pQuestGroup, pQuest, pQuestEvent ) == FALSE )
				bIsExcuted = FALSE;
		}
	}

	return bIsExcuted;
}

BOOL CSubQuestInfo::IsNpcRelationQuest( DWORD dwNpcIdx )									// npc °ü·Ã Äù½ºÆ®ÀÎÁö Ã¼Å©ÇÏ´Â ÇÔ¼ö.
{
	DWORD dwQuestIdx, dwSubQuestIdx;														// Äù½ºÆ® ÀÎµ¦½º¿Í ¼­ºê Äù½ºÆ® ÀÎµ¦½º¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÑ´Ù.

	dwQuestIdx = dwSubQuestIdx = 0;															// Äù½ºÆ® ÀÎµ¦½º¿Í ¼­ºê Äù½ºÆ® ÀÎµ¦½º¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	// 100517 ShinJS --- Äù½ºÆ® ¿ä±¸»çÇ×À» ¿Ï·áÇß´ÂÁö °Ë»ç(ÀÏ¹Ý ¾ÆÀÌÅÛ µî)
	const DWORD dwNpcScriptState = ( QUESTMGR->IsCompletedDemandQuestExecute( m_dwQuestIdx ) == TRUE ? eQuest_NpcScript_Normal : eQuest_NpcScript_Lack );
	std::map< DWORD, CQuestNpcScript* >::const_iterator npcScriptIter = m_QuestNpcScript.find( dwNpcScriptState );
	if( npcScriptIter == m_QuestNpcScript.end() )
	{
		if( dwNpcScriptState != eQuest_NpcScript_Normal )
		{
			npcScriptIter = m_QuestNpcScript.find( eQuest_NpcScript_Normal );
			if( npcScriptIter == m_QuestNpcScript.end() )
				return FALSE;
		}
		else
		{
			return FALSE;
		}
	}

	CQuestNpcScript* pNpcScript = npcScriptIter->second;
	if( !pNpcScript )
		return FALSE;

	if( pNpcScript->IsSameNpc( dwNpcIdx, &dwQuestIdx, &dwSubQuestIdx ) == 0 )
		return FALSE;

	// 100405 ShinJS --- QuestEvent ½ÇÇà °¡´É ÆÇ´Ü
	if( !CanDoOnQuestEvent( dwQuestIdx, dwSubQuestIdx ) )
		return FALSE;

	return TRUE;																			// TRUE ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.
}

DWORD CSubQuestInfo::GetNpcScriptPage( DWORD dwNpcIdx )										// NPC ½ºÅ©¸³Æ® ÆäÀÌÁö¸¦ ¸®ÅÏÇÏ´Â ÇÔ¼ö.
{
	// 100517 ShinJS --- Äù½ºÆ® ¿ä±¸»çÇ×À» ¿Ï·áÇß´ÂÁö °Ë»ç(ÀÏ¹Ý ¾ÆÀÌÅÛ µî)
	const DWORD dwNpcScriptState = ( QUESTMGR->IsCompletedDemandQuestExecute( m_dwQuestIdx ) == TRUE ? eQuest_NpcScript_Normal : eQuest_NpcScript_Lack );
	std::map< DWORD, CQuestNpcScript* >::const_iterator npcScriptIter = m_QuestNpcScript.find( dwNpcScriptState );
	if( npcScriptIter == m_QuestNpcScript.end() )
	{
		if( dwNpcScriptState != eQuest_NpcScript_Normal )
		{
			npcScriptIter = m_QuestNpcScript.find( eQuest_NpcScript_Normal );
			if( npcScriptIter == m_QuestNpcScript.end() )
				return 0;
		}
		else
		{
			return 0;
		}
	}

	CQuestNpcScript* pNpcScript = npcScriptIter->second;
	if( !pNpcScript )
		return 0;

	DWORD dwQuestIdx = 0, dwSubQuestIdx = 0;
	return pNpcScript->IsSameNpc( dwNpcIdx, &dwQuestIdx, &dwSubQuestIdx );
}

DWORD CSubQuestInfo::GetNpcMarkType( DWORD dwNpcIdx )										// npc ¸¶Å© Å¸ÀÔÀ» ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
{
	// 100517 ShinJS --- Äù½ºÆ® ¿ä±¸»çÇ×À» ¿Ï·áÇß´ÂÁö °Ë»ç(ÀÏ¹Ý ¾ÆÀÌÅÛ µî)
	const DWORD dwNpcScriptState = ( QUESTMGR->IsCompletedDemandQuestExecute( m_dwQuestIdx ) == TRUE ? eQuest_NpcScript_Normal : eQuest_NpcScript_Lack );
	std::map< DWORD, CQuestNpcScript* >::const_iterator npcScriptIter = m_QuestNpcScript.find( dwNpcScriptState );
	if( npcScriptIter == m_QuestNpcScript.end() )
	{
		if( dwNpcScriptState != eQuest_NpcScript_Normal )
		{
			npcScriptIter = m_QuestNpcScript.find( eQuest_NpcScript_Normal );
			if( npcScriptIter == m_QuestNpcScript.end() )
				return 0;
		}
		else
		{
			return 0;
		}
	}

	CQuestNpcScript* pNpcScript = npcScriptIter->second;
	if( !pNpcScript )
		return 0;

	// 100405 ShinJS --- QuestEvent ½ÇÇà °¡´É ÆÇ´Ü
	if( !CanDoOnQuestEvent( m_dwQuestIdx, m_dwSubQuestIdx ) )
		return 0;

	DWORD dwQuestIdx = 0, dwSubQuestIdx = 0;
	return pNpcScript->IsSameNpcMark( dwNpcIdx, &dwQuestIdx, &dwSubQuestIdx );
}
	
eQuestState CSubQuestInfo::IsQuestState( DWORD dwNpcIdx )											// Äù½ºÆ® »óÅÂ¸¦ ¸®ÅÏÇÏ´Â ÇÔ¼ö.
{
	// 100517 ShinJS --- Äù½ºÆ® ¿ä±¸»çÇ×À» ¿Ï·áÇß´ÂÁö °Ë»ç(ÀÏ¹Ý ¾ÆÀÌÅÛ µî)
	const DWORD dwNpcScriptState = ( QUESTMGR->IsCompletedDemandQuestExecute( m_dwQuestIdx ) == TRUE ? eQuest_NpcScript_Normal : eQuest_NpcScript_Lack );
	std::map< DWORD, CQuestNpcScript* >::const_iterator npcScriptIter = m_QuestNpcScript.find( dwNpcScriptState );
	if( npcScriptIter == m_QuestNpcScript.end() )
	{
		if( dwNpcScriptState != eQuest_NpcScript_Normal )
		{
			npcScriptIter = m_QuestNpcScript.find( eQuest_NpcScript_Normal );
			if( npcScriptIter == m_QuestNpcScript.end() )
				return eQuestState_ImPossible;
		}
		else
		{
			return eQuestState_ImPossible;
		}
	}

	CQuestNpcScript* pNpcScript = npcScriptIter->second;
	if( !pNpcScript )
		return eQuestState_ImPossible;

	DWORD dwQuestIdx = 0, dwSubQuestIdx = 0;
	DWORD dwPage = pNpcScript->IsSameNpc( dwNpcIdx, &dwQuestIdx, &dwSubQuestIdx );
	if( dwPage == 0 )																		// ÆäÀÌÁö°¡ 0°ú °°´Ù¸é,
	{
		return eQuestState_ImPossible;
	}

	// 100405 ShinJS --- QuestEvent ½ÇÇà °¡´É ÆÇ´Ü
	if( !CanDoOnQuestEvent( dwQuestIdx, dwSubQuestIdx ) )
		return eQuestState_ImPossible;

	if( dwSubQuestIdx == 0 )	return eQuestState_Possible;			// ¼öÇà°¡´ÉÇÑ ÇùÇà						// ¼­ºê Äù½ºÆ® ÀÎµ¦½º°¡ 0°ú °°À¸¸é, ¼öÇà°¡´ÉÇÑ ÇùÇà.
	else						return eQuestState_Executed;			// ¼öÇàÁßÀÎ ÇùÇà						// ¼­ºê Äù½ºÆ® ÀÎµ¦½º°¡ 0°ú °°Áö ¾ÊÀ¸¸é, ¼öÇàÁßÀÎ ÇùÇà.

}

BOOL CSubQuestInfo::CheckLimitCondition( DWORD dwQuestIdx )									// Äù½ºÆ® Á¦ÇÑ »óÅÂ¸¦ È®ÀÎÇÏ´Â ÇÔ¼ö.
{
	// 100405 ShinJS --- QuestEvent ½ÇÇà °¡´É ÆÇ´Ü
	if( !CanDoOnQuestEvent( dwQuestIdx, 0 ) )
		return FALSE;

	return TRUE;
}

BOOL CSubQuestInfo::CanDoOnQuestEvent( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )
{
#ifdef _MAPSERVER_
	// 100402 ShinJS --- ¼ö¶ô/¿Ï·á °¡´É ½Ã°£ÀÎÁö °Ë»ç
	if( !pQuestGroup->IsValidDateTime( pQuest->GetQuestIdx() ) )
		return FALSE;
#endif

	// Äù½ºÆ® Á¦ÇÑÁ¤º¸ °Ë»ç
	PTRLISTPOS pos = m_QuestLimitList.GetHeadPosition();
	CQuestLimit* pLimit = NULL;
	while( pos )
	{
		pLimit = (CQuestLimit*)m_QuestLimitList.GetNext( pos );
		if( pLimit && !pLimit->CheckLimit( pPlayer, pQuestGroup, pQuest ) )
		{
			return FALSE;
		}
	}

	return TRUE;
}

BOOL CSubQuestInfo::CanDoOnQuestEvent( DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
#ifdef _CLIENT_
	// 100402 ShinJS --- ¼ö¶ô/¿Ï·á °¡´É ½Ã°£ÀÎÁö °Ë»ç
	if( !QUESTMGR->IsValidDateTime( dwQuestIdx ) )
		return FALSE;
#endif

	// Äù½ºÆ® Á¦ÇÑÁ¤º¸ °Ë»ç
	PTRLISTPOS pos = m_QuestLimitList.GetHeadPosition();
	CQuestLimit* pLimit = NULL;
	while( pos )
	{
		pLimit = (CQuestLimit*)m_QuestLimitList.GetNext( pos );
		if( pLimit && !pLimit->CheckLimit( dwQuestIdx, dwSubQuestIdx ) )
		{
			return FALSE;
		}
	}

	return TRUE;
}

void CSubQuestInfo::StartLoopByQuestExecuteKind( DWORD dwExecuteKind )
{
	m_FoundQuestExecute.clear();

	// °°Àº Äù½ºÆ®½ÇÇà Á¤º¸¸¦ Ã£´Â´Ù.
	PTRLISTPOS pos = m_QuestTriggerList.GetHeadPosition();
	CQuestTrigger* pTrigger = NULL;
	while( pos )
	{
		pTrigger = (CQuestTrigger*)m_QuestTriggerList.GetNext( pos );
		if( !pTrigger )
			continue;

		cPtrList* pQuestExeList = pTrigger->GetExeList();
		if( !pQuestExeList )
			continue;

		PTRLISTPOS exePos = pQuestExeList->GetHeadPosition();
		while( exePos )
		{
			CQuestExecute* pQuestExecute = (CQuestExecute*)pQuestExeList->GetNext( exePos );
			if( !pQuestExecute )
				continue;

			if( pQuestExecute->GetQuestExecuteKind() == dwExecuteKind )
			{
				m_FoundQuestExecute.push_back( pQuestExecute );
			}
		}
	}

	m_FoundQuestExecuteIter = m_FoundQuestExecute.begin();
}

CQuestExecute* CSubQuestInfo::GetNextQuestExecute()
{
	if( m_FoundQuestExecute.empty() ||
		m_FoundQuestExecuteIter == m_FoundQuestExecute.end() )
		return NULL;

	CQuestExecute* pQuestExecute = *m_FoundQuestExecuteIter;
	++m_FoundQuestExecuteIter;

	return pQuestExecute;
}