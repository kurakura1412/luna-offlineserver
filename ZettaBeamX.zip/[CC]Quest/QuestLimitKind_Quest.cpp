// QuestLimitKind_Quest.cpp: implementation of the CQuestLimitKind_Quest class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"														// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "QuestLimitKind_Quest.h"										// Äù½ºÆ® ¸®¹ÌÆ® Äù½ºÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"											// Äù½ºÆ® ¸®¹ÌÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "Quest.h"														// Äù½ºÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#ifdef _MAPSERVER_														// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

#include "QuestGroup.h"													// Äù½ºÆ® ±×·ì Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#else																	// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖÁö ¾Ê´Ù¸é,

#include "QuestManager.h"												// Äù½ºÆ® ¸Å´ÏÁ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// »ý¼ºÀÚ ÇÔ¼ö.
CQuestLimitKind_Quest::CQuestLimitKind_Quest( DWORD dwLimitKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
: CQuestLimitKind( dwLimitKind, pTokens, dwQuestIdx, dwSubQuestIdx )
{
	GetScriptParam( m_dwIdx, pTokens );									// Äù½ºÆ® ÀÎµ¦½º¸¦ ¹Þ´Â´Ù.
}

// ¼Ò¸êÀÚ ÇÔ¼ö.
CQuestLimitKind_Quest::~CQuestLimitKind_Quest()							
{
}

// Äù½ºÆ® ¸®¹ÌÆ® Ã¼Å©ÇÔ¼ö.(¼­¹ö)
BOOL CQuestLimitKind_Quest::CheckLimit( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )
{
	// 071011 LYW --- QuestLimitKind_Quest : Check parameter info.
	if( !pPlayer || !pQuestGroup || !pQuest ) return FALSE ;			// ÀÎÀÚ·Î ³Ñ¾î¿Â Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, FALSE ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.

#ifdef _MAPSERVER_														// ¸Ê¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch( m_dwLimitKind )												// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestLimitKind_Quest:											// ¸®¹ÌÆ® Á¾·ù°¡ Äù½ºÆ®¶ó¸é,
		{
			if( pQuestGroup->GetQuest( m_dwIdx )->IsQuestComplete() )	// Äù½ºÆ® ÀÎµ¦½º·Î ¿Ï·áÇÑ Äù½ºÆ®ÀÎÁö Ã¼Å©ÇÑ´Ù.
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;

	case eQuestLimitKind_SubQuest:										// ¸®¹ÌÆ® Á¾·ù°¡ ¼­ºê Äù½ºÆ®¶ó¸é,
		{
			if( pQuest->IsSubQuestComplete( m_dwIdx ) )					// Äù½ºÆ® ÀÎµ¦½º·Î ¿Ï·áÇÑ ¼­ºê Äù½ºÆ® ÀÎÁö Ã¼Å©ÇÑ´Ù.
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;

	// 071011 LYW --- QuestLimitKind_Quest : Add quest limit to check running quest.
	case eQuestLimitKind_RunningQuest :									// ÁøÇàÁßÀÎ Äù½ºÆ®¸¦ Ã¼Å©ÇÏ´Â ¸®¹ÌÆ®¶ó¸é,
		{
			CQuest* pQuest = NULL ;										// Äù½ºÆ® Á¤º¸¸¦ ´ãÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.
			pQuest = pQuestGroup->GetQuest( m_dwIdx ) ;					// Äù½ºÆ® Á¤º¸¸¦ ¹Þ´Â´Ù.

			if( !pQuest ) return FALSE ;								// Äù½ºÆ® Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, false ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.

			if( pQuest->GetSubQuestFlag() == 0 ) return TRUE ;			// Äù½ºÆ®ÀÇ ¼­ºê Äù½ºÆ® ÇÃ·¡±×°¡ 0ÀÌ ¾Æ´Ï¸é, true ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.
		}
		break ;
	}
#endif

	return FALSE;														// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
}

// Äù½ºÆ® ¸®¹ÌÆ® Ã¼Å©ÇÔ¼ö.(Å¬¶óÀÌ¾ðÆ®)
BOOL CQuestLimitKind_Quest::CheckLimit( DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
#ifndef _MAPSERVER_														// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇÁö ¾Ê¾Ò´Ù¸é,

	switch( m_dwLimitKind )												// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestLimitKind_Quest:											// ¸®¹ÌÆ® Á¾·ù°¡ Äù½ºÆ®¶ó¸é,
		{
			if( QUESTMGR->GetQuest( m_dwIdx )->IsQuestComplete() )		// Äù½ºÆ® ÀÎµ¦½º·Î ¿Ï·áÇÑ Äù½ºÆ® ÀÎÁö Ã¼Å©ÇÑ´Ù.
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;

	case eQuestLimitKind_SubQuest:										// ¸®¹ÌÆ® Á¾·ù°¡ ¼­ºê Äù½ºÆ®¶ó¸é,
		{
			if( QUESTMGR->GetQuest( dwQuestIdx )->IsSubQuestComplete( m_dwIdx ) )	// Äù½ºÆ® ÀÎµ¦½º·Î ¿Ï·áÇÑ ¼­ºêÄù½ºÆ® ÀÎÁö Ã¼Å©ÇÑ´Ù.
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;
	// 071011 LYW --- QuestLimitKind_Quest : Add quest limit to check running quest.
	case eQuestLimitKind_RunningQuest :									// ÁøÇàÁßÀÎ Äù½ºÆ®¸¦ Ã¼Å©ÇÏ´Â ¸®¹ÌÆ®¶ó¸é,
		{
			CQuest* pQuest = NULL ;										// Äù½ºÆ® Á¤º¸¸¦ ´ãÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.
			pQuest = QUESTMGR->GetQuest( m_dwIdx ) ;					// Äù½ºÆ® Á¤º¸¸¦ ¹Þ´Â´Ù.

			if( !pQuest ) return FALSE ;								// Äù½ºÆ® Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, false ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.

			if( pQuest->GetSubQuestFlag() == 0 ) return TRUE ;			// Äù½ºÆ®ÀÇ ¼­ºê Äù½ºÆ® ÇÃ·¡±×°¡ 0ÀÌ ¾Æ´Ï¸é, true ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.
		}
		break ;
	}
#endif

	return FALSE;														// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
}