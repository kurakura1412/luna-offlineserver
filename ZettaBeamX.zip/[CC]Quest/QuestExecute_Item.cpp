// QuestExecute_Item.cpp: implementation of the CQuestExecute_Item class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"																// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif


#include "QuestExecute_Item.h"													// Äù½ºÆ® ½ÇÇà ¾ÆÀÌÅÛ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"													// Äù½ºÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#ifdef _MAPSERVER_																// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

#include "Player.h"																// ÇÃ·¹ÀÌ¾î Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestGroup.h"															// Äù½ºÆ® ±×·ì Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "ItemManager.h"														// ¾ÆÀÌÅÛ ¸Å´ÏÁ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "Quest.h"																// Äù½ºÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "SubQuestInfo.h"
#include "QuestTrigger.h"
#include "QuestManager.h"

#include "[CC]Header/GameResourceManager.h"
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// »ý¼ºÀÚ ÇÔ¼ö.
CQuestExecute_Item::CQuestExecute_Item( DWORD dwExecuteKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
: CQuestExecute( dwExecuteKind, pTokens, dwQuestIdx, dwSubQuestIdx )
{
	m_dwItemKind = m_dwItemNum = m_dwItemProbability = m_dwWeaponKind = 0;		// ¾ÆÀÌÅÛ Á¾·ù, ¾ÆÀÌÅÛ ¼ýÀÚ, ¾ÆÀÌÅÛ ¼Ó¼®, ¹«±â Å¸ÀÔ µîÀ» 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	switch( dwExecuteKind )														// ½ÇÇà Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestExecute_GiveItem:												// ¾ÆÀÌÅÛÀ» ÁÖ´Â ½ÇÇà ÀÌ°Å³ª,
	case eQuestExecute_GiveQuestItem:											// Äù½ºÆ® ¾ÆÀÌÅÛÀ» ÁÖ´Â ½ÇÇàÀÌ¶ó¸é,
		{
			GetScriptParam( m_dwItemKind, pTokens );							// ¾ÆÀÌÅÛ Á¾·ù¸¦ ¹Þ´Â´Ù.
			GetScriptParam( m_dwItemNum, pTokens );								// ¾ÆÀÌÅÛ ¼ö¸¦ ¹Þ´Â´Ù.
		}
		break;

	case eQuestExecute_GiveMoney:												// ¸Ó´Ï¸¦ ÁÖ´Â ½ÇÇàÀÌ°Å³ª,
	case eQuestExecute_TakeMoney:												// ¸Ó´Ï¸¦ ¹Þ´Â ½ÇÇàÀÌ°Å³ª,
	case eQuestExecute_TakeExp:													// °æÇèÄ¡¸¦ ¹Þ´Â ½ÇÇàÀÌ°Å³ª,
	case eQuestExecute_TakeSExp:												// SP¸¦ ¹Þ´Â ½ÇÇàÀÌ¶ó¸é,
		{
			GetScriptParam( m_dwItemNum, pTokens );								// ¾ÆÀÌÅÛ ¼ö¸¦ ¹Þ´Â´Ù.
		}
		break;

	case eQuestExecute_TakeQuestItem:											// Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ°Å³ª,
	case eQuestExecute_TakeItem:												// ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ¶ó¸é,
		{
			GetScriptParam( m_dwItemKind, pTokens );							// ¾ÆÀÌÅÛ Á¾·ù¸¦ ¹Þ´Â´Ù.
			GetScriptParam( m_dwItemNum, pTokens );								// ¾ÆÀÌÅÛ ¼ö¸¦ ¹Þ´Â´Ù.
			GetScriptParam( m_dwItemProbability, pTokens );						// ¾ÆÀÌÅÛ ¼Ó¼ºÀ» ¹Þ´Â´Ù.
		}
		break;

	case eQuestExecute_TakeQuestItemFQW:										// Äù½ºÆ® Æ¯Á¤ ¹«±â¸¦ ¹Þ´Â ½ÇÇàÀÌ°Å³ª,
	case eQuestExecute_TakeQuestItemFW:											// Äù½ºÆ® ¹«±â¸¦ ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			GetScriptParam( m_dwItemKind, pTokens );							// ¾ÆÀÌÅÛ Á¾·ù¸¦ ¹Þ´Â´Ù.
			GetScriptParam( m_dwItemNum, pTokens );								// ¾ÆÀÌÅÛ ¼ö¸¦ ¹Þ´Â´Ù.
			GetScriptParam( m_dwItemProbability, pTokens );						// ¾ÆÀÌÅÛ ¼Ó¼ºÀ» ¹Þ´Â´Ù.
			GetScriptParam( m_dwWeaponKind, pTokens );							// ¹«±â Á¾·ù¸¦ ¹Þ´Â´Ù.
		}
		break;
		
	case eQuestExecute_TakeMoneyPerCount:										// Ä«¿îÆ®´ç ¸Ó´Ï¸¦ ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			GetScriptParam( m_dwItemKind, pTokens );							// ¾ÆÀÌÅÛ Á¾·ù¸¦ ¹Þ´Â´Ù.
			GetScriptParam( m_dwItemNum, pTokens );								// ¾ÆÀÌÅÛ ¼ö¸¦ ¹Þ´Â´Ù.
		}
		break;
	}
}

// ¼Ò¸êÀÚ ÇÔ¼ö.
CQuestExecute_Item::~CQuestExecute_Item()										
{
}

// ½ÇÇà ÇÔ¼ö.
BOOL CQuestExecute_Item::Execute( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )
{
#ifdef _MAPSERVER_																// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch( m_dwExecuteKind )													// ½ÇÇà Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestExecute_TakeQuestItem:											// Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			pQuestGroup->TakeQuestItem( pPlayer, m_dwQuestIdx, m_dwSubQuestIdx, // Äù½ºÆ® ±×·ìÀÇ Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¹Þ´Â ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
				m_dwItemKind, m_dwItemNum, m_dwItemProbability );
		}
		break;

	case eQuestExecute_GiveQuestItem:											// Äù½ºÆ® ¾ÆÀÌÅÛÀ» ÁÖ´Â ½ÇÇàÀÌ¸é,
		{
			//pQuestGroup->GiveQuestItem( pPlayer, m_dwQuestIdx, m_dwItemKind,	// Äù½ºÆ® ±×·ìÀÇ Äù½ºÆ® ¾ÆÀÌÅÛÀ» ÁÖ´Â ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
			//	m_dwItemNum );

			if( !pQuestGroup->GiveQuestItem( pPlayer, m_dwQuestIdx, m_dwItemKind, m_dwItemNum )) return FALSE ;
		}
		break;

	case eQuestExecute_GiveItem:												// ¾ÆÀÌÅÛÀ» ÁÖ´Â ½ÇÇàÀÌ¸é,
		{
			//if( !pQuestGroup->GiveItem( pPlayer, m_dwItemKind, m_dwItemNum ) )	// ¾ÆÀÌÅÛ ¹Ý³³ÀÌ ½ÇÆÐÇÏ¸é,
			//{
			//	return FALSE ;													// false¸¦ ¸®ÅÏÇÑ´Ù.
			//}

			if( !pQuestGroup->GiveItem( pPlayer, m_dwItemKind, m_dwItemNum, pQuest->GetQuestIdx()) )
			{
				return FALSE ;
			}
		}
		break;

	case eQuestExecute_GiveMoney:												// ¸Ó´Ï¸¦ ÁÖ´Â ½ÇÇàÀÌ¸é,
		{
			pQuestGroup->GiveMoney( pPlayer, m_dwItemNum );						// Äù½ºÆ® ±×·ìÀÇ ¸Ó´Ï¸¦ ÁÖ´Â ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
		}
		break;

	case eQuestExecute_TakeItem:												// ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			return pQuestGroup->TakeItem( pPlayer, m_dwQuestIdx, m_dwSubQuestIdx, m_dwItemKind,			// Äù½ºÆ® ±×·ìÀÇ ¾ÆÀÌÅÛÀ» ¹Þ´Â ÇÔ¼ö¸¦ È£ÃâÇÏ¿© °á°ú¸¦ ¸®ÅÏÇÑ´Ù.
				m_dwItemNum, m_dwItemProbability );
		}
		break;

	case eQuestExecute_TakeMoney:												// ¸Ó´Ï¸¦ ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			pQuestGroup->TakeMoney( pPlayer, m_dwItemNum );						// Äù½ºÆ® ±×·ìÀÇ ¸Ó´Ï¸¦ ¹Þ´Â ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
		}
		break;

	case eQuestExecute_TakeExp:													// °æÇèÄ¡¸¦ ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			pQuestGroup->TakeExp( pPlayer, m_dwItemNum );						// Äù½ºÆ® ±×·ìÀÇ °æÇèÄ¡¸¦ ¹Þ´Â ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
		}
		break;

	case eQuestExecute_TakeSExp:												// SP¸¦ ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			pQuestGroup->TakeSExp( pPlayer, m_dwItemNum );						// Äù½ºÆ® ±×·ìÀÇ SP¸¦ ¹Þ´Â ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
		}
		break;

	case eQuestExecute_TakeQuestItemFQW:										// Äù½ºÆ® Æ¯Á¤ ¹«±â¸¦ ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			pQuestGroup->TakeQuestItemFromQWeapon( pPlayer, m_dwQuestIdx,		// Æ¯Á¤ ¹«±â·Î ºÎÅÍ Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¹Þ´Â ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
				m_dwSubQuestIdx, m_dwItemKind, m_dwItemNum, m_dwItemProbability, 
				m_dwWeaponKind );
		}
		break;
	case eQuestExecute_TakeMoneyPerCount:										// Ä«¿îÆ®´ç ¸Ó´Ï¸¦ ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			pQuestGroup->TakeMoneyPerCount( pPlayer, m_dwQuestIdx, m_dwSubQuestIdx, m_dwItemKind, m_dwItemNum );	// Ä«¿îÆ® ´ç ¸Ó´Ï¸¦ ¹Þ´Â ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
		}
		break;
	}
#endif
	return TRUE;
}





int CQuestExecute_Item::CheckCondition( PLAYERTYPE* pPlayer, 
							CQuestGroup* pQuestGroup, CQuest* pQuest )			// Äù½ºÆ® ÀÌº¥Æ®¸¦ ½ÇÇàÇÏ±â À§ÇÑ Á¶°ÇÀ» ¸¸Á·ÇÏ´ÂÁö Ã¼Å©ÇÏ´Â ÇÔ¼ö.
{
	int nErrorCode = e_EXC_ERROR_NO_ERROR ;										// ¿¡·¯ ÄÚµå¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í e_EXE_ERROR_NO_ERROR·Î ¼¼ÆÃÇÑ´Ù.

	if( !pPlayer )																// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, 
	{
		nErrorCode = e_EXC_ERROR_NO_PLAYERINFO ;								// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;														// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuestGroup )															// Äù½ºÆ® ±×·ì Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUESTGROUP ;								// Äù½ºÆ® ±×·ì Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;														// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuest )																// Äù½ºÆ® Á¤º¸°¡ À¯È¿ÇÏÁö ¾Ê´Ù¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUEST ;										// Äù½ºÆ® Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;														// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

#ifdef _MAPSERVER_																// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch(m_dwExecuteKind)														// ½ÇÇà Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestExecute_TakeQuestItem :											// Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¾ò´Â ½ÇÇà¹®ÀÌ¸é,
		{
			return nErrorCode ;													// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.

			// ÇöÀç ÇÃ·¹ÀÌ¾îÀÇ Äù½ºÆ® ¾ÆÀÌÅÛ ½½·ÔÀÇ Á¤º¸¸¦ ¹Þ¾Æ¿À´Â ºÎºÐÀÌ 
			// ¾øÀ¸¹Ç·Î, ¿ì¼±Àº ¿¡·¯ ¾øÀ½À¸·Î Ã³¸®¸¦ ÇÏÀÚ.

			//CItemSlot* pSlot = NULL ;											// ¾ÆÀÌÅÛ ½½·Ô Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í null Ã³¸®¸¦ ÇÑ´Ù.
			//pSlot = pPlayer->GetSlot(eItemTable_Inventory) ;					// ÇÃ·¹ÀÌ¾îÀÇ ÀÎº¥Åä¸® ½º·Ô Á¤º¸¸¦ ¹Þ´Â´Ù.

			//if( !pSlot )														// ÀÎº¥Åä¸® Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é,
			//{
			//	nErrorCode = e_EXC_ERROR_NO_INVENTORYINFO ;						// ÀÎº¥Åä¸® Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
			//	return nErrorCode ;												// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			//}

			//WORD EmptyCellPos[255];											// ºó ½½·Ô À§Ä¡¸¦ ¹ÞÀ» º¯¼ö¸¦ ¼±¾ðÇÑ´Ù.
			//WORD EmptyCellNum;												// ºó ½½·Ô °³¼ö¸¦ ¹ÞÀ» º¯¼ö¸¦ ¼±¾ðÇÑ´Ù.

			//WORD wResult = 0 ;												// ºó ½½·ÔÀÇ Ã¼Å© °á°ú °ªÀ» ¹ÞÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.

			//wResult = ITEMMGR->GetCanBuyNumInSpace(pPlayer, pSlot,			// ¾ÆÀÌÅÛÀ» ¹ÞÀ» °ø°£ÀÌ ÃæºÐÇÑÁö °á°ú °ªÀ» ¹Þ´Â´Ù.
			//	m_dwItemKind, m_dwItemNum, EmptyCellPos, EmptyCellNum) ;

			//if( wResult == 0 )												// °á°ú °ªÀÌ 0°ú °°À¸¸é,
			//{
			//	nErrorCode = e_EXC_ERROR_NO_EXTRASLOT ;							// ¿¡·¯ ÄÚµå¸¦ ÀÎº¥Åä¸® ¿©ºÐÀÌ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
			//	return nErrorCode ;												// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			//}
		}
		break ;

	case eQuestExecute_GiveQuestItem:											// Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¹Ý³³ ½ÇÇàÀÌ¸é,
		{
			QUESTITEM* pQuestItem = NULL ;										// Äù½ºÆ® ¾ÆÀÌÅÛ Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í null Ã³¸®¸¦ ÇÑ´Ù.
			pQuestItem = pQuestGroup->GetQuestItem(m_dwItemKind) ;				// Äù½ºÆ® ¾ÆÀÌÅÛ ÀÎµ¦½º·Î Äù½ºÆ® ¾ÆÀÌÅÛ Á¤º¸¸¦ ¹Þ´Â´Ù.

			if( !pQuestItem )													// Äù½ºÆ® ¾ÆÀÌÅÛ Á¤º¸°¡ À¯È¿ÇÏÁö ¾Ê´Ù¸é,
			{
				nErrorCode = e_EXC_ERROR_NO_QUESTITEM ;							// Äù½ºÆ® ¾ÆÀÌÅÛÀÌ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
				return nErrorCode ;												// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			}

			if( pQuestItem->dwItemNum < m_dwItemNum )							// ¾ÆÀÌÅÛÀÇ °³¼ö°¡, ¸ñÇ¥ ¼ö·®º¸´Ù ÀÛÀ¸¸é,
			{
				nErrorCode = e_EXC_ERROR_NOT_ENOUGH_QUESTITEM ;					// Äù½ºÆ® ¾ÆÀÌÅÛÀÌ ºÎÁ·ÇÏ´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
				return nErrorCode ;												// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			}
		}
		break;

	case eQuestExecute_GiveItem:												// ¾ÆÀÌÅÛÀ» ¹Ý³³ÇÏ´Â ½ÇÇàÀÌ¸é,
		{
			int count = 0;
			DWORD nGiveItemCount = 0;

			ITEM_TOTALINFO ItemInfo;
			ZeroMemory(
				&ItemInfo,
				sizeof(ItemInfo));
			pPlayer->GetItemtotalInfo(
				ItemInfo,
				GETITEM_FLAG_INVENTORY | GETITEM_FLAG_WEAR );

			int nTotalInvenCount = (int)(SLOT_INVENTORY_NUM + pPlayer->GetInventoryExpansionSize());
			BOOL bStackItem = ITEMMGR->IsDupItem( m_dwItemKind ) ;

			for( count = 0 ; count < nTotalInvenCount ; ++count )				
			{
				if( ItemInfo.Inventory[count].wIconIdx == m_dwItemKind )		// ÀÎÀÚ·Î ³Ñ¾î¿Â ¾ÆÀÌÅÛ ÀÎµ¦½º¿Í °°Àº ¾ÆÀÌÅÛÀÌ ÀÖ´Ù¸é,
				{
					if( bStackItem )											// ½ºÅÃ¾ÆÀÌÅÛÀÌ¸é, 
					{
						nGiveItemCount += ItemInfo.Inventory[count].Durability ;// ¹Ý³³ °¡´ÉÇÑ ¾ÆÀÌÅÛ ¼ö¸¦ Ãß°¡ÇÑ´Ù.
					}
					else														// ÀÏ¹Ý¾ÆÀÌÅÛÀÌ¸é, 
					{
						++nGiveItemCount ;										// ¹Ý³³ ¾ÆÀÌÅÛ ¼ö¸¦ Áõ°¡ÇÑ´Ù.
					}
					
				}
			}

			for( count = 0 ; count < SLOT_WEAR_NUM ; ++count )					// Àåºñ Ã¢ÀÇ ½½·Ô ¼ö ¸¸Å­ for¹®À» µ¹¸°´Ù.
			{
				if( ItemInfo.WearedItem[count].wIconIdx == m_dwItemKind )		// ÀÎÀÚ·Î ³Ñ¾î¿Â ¾ÆÀÌÅÛ ÀÎµ¦½º¿Í °°Àº ¾ÆÀÌÅÛÀÌ ÀÖ´Ù¸é,
				{
					if( bStackItem )											// ½ºÅÃ¾ÆÀÌÅÛÀÌ¸é, 
					{
						nGiveItemCount += ItemInfo.Inventory[count].Durability ;// ¹Ý³³ °¡´ÉÇÑ ¾ÆÀÌÅÛ ¼ö¸¦ Ãß°¡ÇÑ´Ù.
					}
					else														// ÀÏ¹Ý¾ÆÀÌÅÛÀÌ¸é, 
					{
						++nGiveItemCount ;										// ¹Ý³³ ¾ÆÀÌÅÛ ¼ö¸¦ Áõ°¡ÇÑ´Ù.
					}
				}
			}

			if( nGiveItemCount == 0 )											// ¹Ý³³ °¡´ÉÇÑ ¾ÆÀÌÅÛ ¼ö°¡ 0°³¸é,
			{
				nErrorCode = e_EXC_ERROR_NO_GIVEITEM ;							// ¹Ý³³ÇÒ ¾ÆÀÌÅÛÀÌ ¾ø´Ù´Â ¿¡·¯¸¦ ¼¼ÆÃÇÑ´Ù.
				return nErrorCode ;												// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			}

			if( nGiveItemCount < m_dwItemNum )
			{
				nErrorCode = e_EXC_ERROR_NOT_ENOUGH_GIVEITEM ;					// ¹Ý³³ÇÒ ¾ÆÀÌÅÛÀÌ ºÎÁ·ÇÏ´Ù´Â ¿¡·¯¸¦ ¼¼ÆÃÇÑ´Ù.
				return nErrorCode ;												// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			}
		}
		break;

	case eQuestExecute_GiveMoney:												// ¸Ó´Ï¸¦ ¹Ý³³ÇÏ´Â ½ÇÇàÀÌ¸é,
		{
			MONEYTYPE curMoney = pPlayer->GetMoney() ;							// ÇÃ·¹ÀÌ¾îÀÇ ÇöÀç ¸Ó´Ï¸¦ ¹Þ´Â´Ù.

			if( curMoney < m_dwItemNum )										// ÇöÀç ÇÃ·¹ÀÌ¾îÀÇ ¸Ó´Ï°¡ ¹Ý³³ ÇÒ ¸Ó´Ïº¸´Ù ºÎÁ·ÇÏ¸é,
			{
				nErrorCode = e_EXC_ERROR_NOT_ENOUGH_GIVEMONEY ;					// ¸Ó´Ï°¡ ºÎÁ·ÇÏ´Ù´Â ¿¡·¯¸¦ ¼¼ÆÃÇÑ´Ù.
				return nErrorCode ;												// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			}
		}
		break;

	case eQuestExecute_TakeItem :
		{
			// 080515 LYW --- QuestExecute_Item : ¾ÆÀÌÅÛ È¹µæ ¹ö±× ¼öÁ¤.
			// ±âÁ¸ Ã¼Å© ¹æ½ÄÀº, Æ®¸®°Å¿¡ ¹°·ÁÀÖ´Â ½ÇÇà Á¤º¸ ÇÏ³ª¸¦ °¢°¢ ¿©ºÐ ½½·ÔÀ» Ã¼Å© Çß±â ¶§¹®¿¡, 
			// Æ®¸®°Å ³»¿¡¼­, ¿©·¯°³ÀÇ ¾ÆÀÌÅÛÀ» ÁÙ¶§, (A, B, C, D)¾ÆÀÌÅÛÀ» ÇÏ³ª¾¿ º¸»óÇÑ´Ù°í ÇÏ¸é, 
			// ºó½½·Ô ÇÏ³ª¸¸ ÀÖÀ»°æ¿ì, ¿©ºÐ ½½·Ô Ã¼Å©°¡ ¼º°øµÇ¾ú´Ù.
			// Áö±ÝÀº Æ®¸®°Å¿¡ ¹°¸° ½ÇÇà Á¤º¸¸¦ ¸ðµå Ã¼Å©ÇÏµµ·Ï ¼öÁ¤.
			// ¿¡·¯ ÄÚµå ¼¼ÆÃ.
			nErrorCode = e_EXC_ERROR_NO_EXTRASLOT ;



			// Äù½ºÆ®¸¦ ¹Þ´Â´Ù.
			CQuest* pQuest = NULL ;
			pQuest = pQuestGroup->GetQuest(m_dwQuestIdx) ;

			if(!pQuest) return nErrorCode ;



			// ¼­ºê Äù½ºÆ® Á¤º¸¸¦ ¹Þ´Â´Ù.
			CSubQuestInfo* pSubQuestInfo = NULL ;
			pSubQuestInfo = pQuest->GetSubQuestInfo(m_dwSubQuestIdx) ;

			if(!pSubQuestInfo) return nErrorCode ;

			cPtrList& pTriggerList = pSubQuestInfo->GetTriggerList() ;

			// Äù½ºÆ® Æ®¸®°Å Á¤º¸¸¦ ¹Þ´Â´Ù.
			CQuestTrigger* pTrigger ;
			cPtrList* pExeList = NULL ;

			PTRLISTPOS triPos = pTriggerList.GetHeadPosition() ;
			while(triPos)
			{
				pTrigger = (CQuestTrigger*)pTriggerList.GetNext(triPos) ;

				if(!pTrigger) continue ;

				pExeList = pTrigger->GetExeList() ;
				break ;
			}

			if(!pExeList) return nErrorCode ;



			// ¾ÆÀÌÅÛ ½½·Ô Á¤º¸¸¦ ¹Þ´Â´Ù.
			CItemSlot* pSlot = NULL ;
			pSlot = pPlayer->GetSlot(eItemTable_Inventory) ;

			if( !pSlot )
			{
				nErrorCode = e_EXC_ERROR_NO_INVENTORYINFO ;
				return nErrorCode ;
			}



			// ºñ¾îÀÖ´Â ¾ÆÀÌÅÛ cell Ä«¿îÆ®¸¦ ¹Þ´Â´Ù.
			POSTYPE startPos = pSlot->GetStartPos() ;
			POSTYPE EndPos = startPos + pSlot->GetSlotNum() ;

			BYTE byEmptyCellCount = 0 ;
			for( WORD count = startPos ; count < EndPos ; ++count )
			{
				if(!pSlot->IsEmpty(count)) continue ;

				++byEmptyCellCount ;
			}



			// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ¹Þ´Â´Ù.
			CQuestExecute* pExecute ;
			PTRLISTPOS exePos = pExeList->GetHeadPosition() ;

			BYTE byDifferrentItemCount = 0 ;
			while(exePos)
			{
				pExecute = NULL ;
				pExecute = (CQuestExecute*)pExeList->GetNext(exePos) ;

				if(!pExecute) continue ;

				if(pExecute->GetQuestExecuteKind() != eQuestExecute_TakeItem) continue ;

				// ¾ÆÀÌÅÛ Á¤º¸¸¦ ¹Þ´Â´Ù.
				DWORD dwItemIdx		= ((CQuestExecute_Item*)pExecute)->GetItemKind() ;
				DURTYPE dwItemNum	= ((CQuestExecute_Item*)pExecute)->GetItemNum() ;

				ITEM_INFO* ItemInfo = NULL ;
				ItemInfo = ITEMMGR->GetItemInfo( dwItemIdx ) ;

				if(!ItemInfo)
				{
					// ¾ÆÀÌÅÛ Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, ·Î±× ³²±â±â.
					char tempMsg[128] = {0,} ;
					sprintf(tempMsg, "------ %s ----- TakeItem Failed!!", __FUNCTION__) ;
					QUESTMGR->WriteLog(tempMsg) ;

					memset(tempMsg, 0, strlen(tempMsg)) ;
					sprintf(tempMsg, "QuestID:%d, SubQuestID:%d, ItemID:%d PlayerID:%d", m_dwQuestIdx, m_dwSubQuestIdx, dwItemIdx, pPlayer->GetID()) ;
					QUESTMGR->WriteLog(tempMsg) ;

					return nErrorCode ;
				}

				// ¿©ºÐÀÇ ½½·Ô/°°Àº ¾ÆÀÌÅÛ µîÀ» Ã¼Å©ÇÑ´Ù.
				if(ITEMMGR->IsDupItem(dwItemIdx))
				{
					// 091215 ONS ¾ÆÀÌÅÛStackÃÖ´ë¼ö¸¦ ¾ÆÀÌÅÛº°·Î ÁöÁ¤µÈ °ªÀ¸·Î Ã³¸®ÇÑ´Ù.
					const WORD wItemStackNum = ITEMMGR->GetItemStackNum( dwItemIdx );
					for( WORD count = startPos ; count < EndPos ; ++count )
					{
						if( dwItemNum == 0 ) break ;

						const ITEMBASE * pItemBase = pSlot->GetItemInfoAbs(count) ;

						if( !pSlot->IsEmpty(count) && !pSlot->IsLock(count) && pItemBase->wIconIdx == dwItemIdx && pItemBase->Durability < wItemStackNum )
						{
							if( pItemBase->Durability + dwItemNum > wItemStackNum )
							{
								dwItemNum = dwItemNum + pItemBase->Durability - wItemStackNum;
							}
							else
							{
								dwItemNum = 0 ;
							}
						}
					}

					for( WORD count = startPos ; count < EndPos ; ++count )
					{
						if( dwItemNum == 0 ) break;

						if(pSlot->IsEmpty(count))
						{
							if( dwItemNum > wItemStackNum )
							{
								dwItemNum -= wItemStackNum;
							}
						}
					}

					if(dwItemNum != 0) ++byDifferrentItemCount ;
				}
				else ++byDifferrentItemCount ;
			}



			// ¾ÆÀÌÅÛ ºÐ¹è°¡ °¡´ÉÇÑÁö Ã¼Å©ÇÑ´Ù.
			if(byDifferrentItemCount > byEmptyCellCount) return nErrorCode ;
			else return e_EXC_ERROR_NO_ERROR;
		}
		break ;

	case eQuestExecute_TakeQuestItemFQW:										// Æ¯Á¤ ¹«±â¸¦ Ã¼Å©ÇØ¼­ Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			if( pPlayer->GetWearedWeapon() != m_dwWeaponKind )					// ÇÃ·¹ÀÌ¾î°¡ Âø¿ëÇÏ°í ÀÖ´Â ¹«±â¿Í ºñ±³´ë»ó ¹«±â°¡ °°Áö ¾ÊÀ¸¸é,
			{
				nErrorCode = e_EXC_ERROR_NOT_SAME_WEAPONKIND ;					// ¹«±â Á¾·ù°¡ ´Þ¶ó¼­ Äù½ºÆ® ¾ÆÀÌÅÛÀ» ¹ÞÀ» ¼ö ¾ø´Ù´Â ¿¡·¯¸¦ ¼¼ÆÃÇÑ´Ù.
				return nErrorCode ;												// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			}
		}
		break;
	case eQuestExecute_TakeMoney:												// ¸Ó´Ï¸¦ Áö±Þ¹Þ´Â ½ÇÇàÀÌ¸é,
	case eQuestExecute_TakeMoneyPerCount:										// Ä«¿îÆ®´ç ¸Ó´Ï¸¦ ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			MONEYTYPE curMoney = pPlayer->GetMoney() ;							// ÇÃ·¹ÀÌ¾îÀÇ ÇöÀç ¸Ó´Ï¸¦ ¹Þ´Â´Ù.

			if( curMoney >= 4200000000 )
			{
				nErrorCode = e_EXC_ERROR_CANT_RECEIVE_MONEY ;					// ÇÃ·¹ÀÌ¾î´Â ´õÀÌ»ó ¸Ó´Ï¸¦ ¹ÞÀ» ¼ö ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
				return nErrorCode ;													// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			}
		}
	}

#endif //_MAPSERVER_

	return nErrorCode ;															// ±âº» °ªÀ» ¸®ÅÏÇÑ´Ù.
}










