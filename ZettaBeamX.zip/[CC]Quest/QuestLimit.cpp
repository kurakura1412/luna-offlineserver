// QuestLimit.cpp: implementation of the CQuestLimit class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"																			// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.
#include "[lib]yhlibrary/PtrList.h"
#include "QuestLimit.h"																		// Äù½ºÆ® Á¦ÇÑ Çì´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"																// ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestLimitKind.h"																	// Äù½ºÆ® Á¦ÇÑ Á¾·ù Çì´õ¸¦ ºÒ·¯¿Â´Ù.
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CQuestLimit::CQuestLimit( CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )	// »ý¼ºÀÚ ÇÔ¼ö.
{
	ReadLimitKind( pTokens,  dwQuestIdx, dwSubQuestIdx );									// Äù½ºÆ® Á¦ÇÑ Á¾·ù¸¦ ÀÐ¾îµéÀÎ´Ù.
}

CQuestLimit::~CQuestLimit()																	// ¼Ò¸êÀÚ ÇÔ¼ö.
{
	Release();																				// ÇØÁ¦ ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
}

void CQuestLimit::Release()																	// ÇØÁ¦ ÇÔ¼ö.
{
	PTRLISTPOS pos = m_QuestLimitKindList.GetHeadPosition();								// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	CQuestLimitKind* pQuestLimitKind = NULL;												// Äù½ºÆ® ¸®¹ÌÆ® Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í null Ã³¸®¸¦ ÇÑ´Ù.

	while( pos )																			// À§Ä¡ Á¤º¸°¡ À¯È¿ÇÒ µ¿¾È whileÀ» µ¹¸°´Ù.
	{
		pQuestLimitKind = (CQuestLimitKind*)m_QuestLimitKindList.GetNext( pos );			// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pQuestLimitKind )																// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸°¡ À¯È¿ÇÏ¸é,
		{
			delete pQuestLimitKind;															// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸¸¦ »èÁ¦ÇÑ´Ù.
		}
	}
	m_QuestLimitKindList.RemoveAll();														// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸¸¦ ´ã´Â ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿î´Ù.
}

BOOL CQuestLimit::ReadLimitKind( CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )	// ¸®¹ÌÆ® Á¾·ù¸¦ ÀÐ¾îµéÀÌ´Â ÇÔ¼ö.
{
	char* OneToken;																					// ÅäÅ« Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.

	while( (OneToken = pTokens->GetNextTokenUpper()) != NULL )										// ÅäÅ« Æ÷ÀÎÅÍ°¡ NULLÀÌ ¾Æ´Ñ°æ¿ì while¹®À» µ¹¸°´Ù.
	{
		if( OneToken[0] == '&' )																	// ÅäÅ«ÀÌ &¿Í °°À¸¸é,
		{
			// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸¸¦ ´ã´Â ¸®½ºÆ®¿¡ Ãß°¡ÇÑ´Ù.
			m_QuestLimitKindList.AddTail( CQuestScriptLoader::LoadQuestLimitKind( OneToken, pTokens, dwQuestIdx, dwSubQuestIdx ) );
		}
	}
	return TRUE;																					// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
}

BOOL CQuestLimit::CheckLimit( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )		// Äù½ºÆ® ¸®¹ÌÆ®¸¦ Ã¼Å©ÇÑ´Ù.(¼­¹ö)
{
	PTRLISTPOS pos = m_QuestLimitKindList.GetHeadPosition();										// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸¸¦ ´ã´Â ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	CQuestLimitKind* pQuestLimitKind = NULL;														// Äù½ºÆ® ¸®¹ÌÆ® Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í null Ã³¸®¸¦ ÇÑ´Ù.

	while( pos )																					// À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑ µ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pQuestLimitKind = (CQuestLimitKind*)m_QuestLimitKindList.GetNext( pos );					// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pQuestLimitKind )																		// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸°¡ À¯È¿ÇÏ¸é,
		{
			if( !pQuestLimitKind->CheckLimit( pPlayer, pQuestGroup, pQuest ) )						// Äù½ºÆ® ¸®¹ÌÆ®¿¡ °É¸®´ÂÁö Ã¼Å©ÇÑ´Ù.
			{
				return FALSE;																		// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
	}
	return TRUE;																					// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
}

BOOL CQuestLimit::CheckLimit( DWORD dwQuestIdx, DWORD dwSubQuestIdx )								// Äù½ºÆ® ¸®¹ÌÆ®¸¦ Ã¼Å©ÇÑ´Ù. (Å¬¶óÀÌ¾ðÆ®)
{
	PTRLISTPOS pos = m_QuestLimitKindList.GetHeadPosition();										// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸¸¦ ´ã´Â ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	CQuestLimitKind* pQuestLimitKind = NULL;														// Äù½ºÆ® ¸®¹ÌÆ® Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.

	while( pos )																					// À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑµ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pQuestLimitKind = (CQuestLimitKind*)m_QuestLimitKindList.GetNext( pos );					// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pQuestLimitKind )																		// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù Á¤º¸°¡ À¯È¿ÇÏ¸é,
		{
			if( !pQuestLimitKind->CheckLimit( dwQuestIdx, dwSubQuestIdx ) )							// Äù½ºÆ® ¸®¹ÌÆ®¿¡ °É¸®´ÂÁö Ã¼Å©ÇÑ´Ù.
			{
				return FALSE;																		// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
	}
	return TRUE;																					// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
}
