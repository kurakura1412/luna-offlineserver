// QuestExecute_RandomItem.cpp: implementation of the CQuestExecute_RandomItem class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"																		// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "QuestExecute_SelectItem.h"													// Äù½ºÆ® ½ÇÇà ·£´ý ¾ÆÀÌÅÛ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"															// Äù½ºÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#ifdef _MAPSERVER_																		// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

#include "QuestGroup.h"																	// Äù½ºÆ® ±×·ì Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "ItemSlot.h"

#include "Player.h"

#include "ItemManager.h"

#include "Quest.h"																// Äù½ºÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// »ý¼ºÀÚ ÇÔ¼ö.
CQuestExecute_SelectItem::CQuestExecute_SelectItem( DWORD dwExecuteKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
: CQuestExecute( dwExecuteKind, pTokens, dwQuestIdx, dwSubQuestIdx )
{
	GetScriptParam( m_dwMaxItemCount, pTokens );										// ¾ÆÀÌÅÛ ÃÖ´ë ¼ö¸¦ ¹Þ´Â´Ù.

	m_pSelectItem = new SELECTITEM[m_dwMaxItemCount];

	m_dwQuestIdx = dwQuestIdx;
	m_dwSubQuestIdx = dwSubQuestIdx;

	for( DWORD i = 0; i < m_dwMaxItemCount; ++i )										// ÃÖ´ë ¾ÆÀÌÅÛ ¼ö ¸¸Å­ for¹°À» µ¹¸°´Ù.
	{
		GetScriptParam( m_pSelectItem[i].dwItemIdx, pTokens );							// ¾ÆÀÌÅÛ Á¾·ù¸¦ ¹Þ´Â´Ù.
		GetScriptParam( m_pSelectItem[i].dwItemNum, pTokens );							// ¾ÆÀÌÅÛ ¼ö¸¦ ¹Þ´Â´Ù.
	}
}

CQuestExecute_SelectItem::~CQuestExecute_SelectItem()									// ¼Ò¸êÀÚ ÇÔ¼ö.
{
	SAFE_DELETE_ARRAY(
		m_pSelectItem);
}

// ½ÇÇà ÇÔ¼ö.
BOOL CQuestExecute_SelectItem::Execute( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )
{
#ifdef _MAPSERVER_																		// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	if( eQuestExecute_TakeSelectItem == m_dwExecuteKind )															// ½ÇÇà Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
		return pQuestGroup->TakeSelectItem( pPlayer, pQuestGroup, m_dwQuestIdx, m_dwSubQuestIdx );
	}
	
#endif	

	return TRUE;																		// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
}

int CQuestExecute_SelectItem::CheckCondition( PLAYERTYPE* pPlayer,				
							CQuestGroup* pQuestGroup, CQuest* pQuest )					
{
	int nErrorCode = e_EXC_ERROR_NO_ERROR ;												// ¿¡·¯ ÄÚµå¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í e_EXE_ERROR_NO_ERROR·Î ¼¼ÆÃÇÑ´Ù.

	if( !pPlayer )																		// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, 
	{
		nErrorCode = e_EXC_ERROR_NO_PLAYERINFO ;										// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;																// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuestGroup )																	// Äù½ºÆ® ±×·ì Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUESTGROUP ;										// Äù½ºÆ® ±×·ì Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;																// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuest )																		// Äù½ºÆ® Á¤º¸°¡ À¯È¿ÇÏÁö ¾Ê´Ù¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUEST ;												// Äù½ºÆ® Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;																// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

#ifdef _MAPSERVER_																		// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch( m_dwExecuteKind )															// ½ÇÇà Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestExecute_TakeSelectItem:													// ·£´ý ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			// 1. Äù½ºÆ® ±×·ìÁ¤º¸¿¡¼­ º¸»ó¾ÆÀÌÅÛ Á¤º¸°¡ 
			const REQUITALINFO* pInfo = pQuestGroup->FindRequitalIndex( pQuest->GetQuestIdx() );
			if( !pInfo )
			{
				nErrorCode = e_EXC_ERROR_NOT_EXIST_REQUITAL;
				return nErrorCode;
			}

			nErrorCode = e_EXC_ERROR_NOT_EXIST_REQUITAL;
			for( DWORD n = 0; n < m_dwMaxItemCount; n++)
			{
				if( m_pSelectItem[n].dwItemIdx != pInfo->dwRequitalIndex )
					continue;
				if( m_pSelectItem[n].dwItemNum != pInfo->dwRequitalCount )
					continue;
	
				nErrorCode = e_EXC_ERROR_NO_ERROR;
			}
			if( nErrorCode == e_EXC_ERROR_NOT_EXIST_REQUITAL )
			{
				return nErrorCode;
			}

			// ¾ÆÀÌÅÛ ½½·Ô Á¤º¸¸¦ ¹Þ´Â´Ù.
			CItemSlot* pSlot = NULL ;
			pSlot = pPlayer->GetSlot(eItemTable_Inventory) ;

			if( !pSlot )
			{
				nErrorCode = e_EXC_ERROR_NO_INVENTORYINFO ;
				return nErrorCode ;
			}

			WORD EmptyCellPos[255];											
			WORD EmptyCellNum;												
			WORD wResult = 0 ;												
			wResult = ITEMMGR->CheckExtraSlot(pPlayer, pSlot, pInfo->dwRequitalIndex, pInfo->dwRequitalCount, EmptyCellPos, EmptyCellNum);
			if( wResult == 0 )								
			{
				nErrorCode = e_EXC_ERROR_NO_INVENTORYINFO ;	
				return nErrorCode ;							
			}
		}
		break;
	}

#endif //_MAPSERVER_

	return nErrorCode ;																	// ±âº» °ªÀ» ¸®ÅÏÇÑ´Ù.
}

