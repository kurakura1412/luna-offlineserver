#ifndef __QUESTDEFINES_H__
#define __QUESTDEFINES_H__

#include "[CC]Header/CommonGameDefine.h"

#pragma pack(push,1)

#ifdef _MAPSERVER_																	// ¸Ê¼­¹ö°¡ ¼±¾ðÀÌ µÇ¾îÀÖÀ¸¸é,
#define	PLAYERTYPE	CPlayer															// PLAYERTYPEÀ» CPlayer Å¬·¡½º·Î Á¤ÀÇÇÏ°í,
class CPlayer;																		// ÇÃ·¹ÀÌ¾î Å¬·¡½º¸¦ ¼±¾ðÇÑ´Ù.
#else																				// ¸Ê¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖÁö ¾ÊÀ¸¸é,
#define PLAYERTYPE	CHero															// PLAYERTYPEÀ» CHero Å¬·¡½º·Î Á¤ÀÇÇÏ°í,
class CHero;																		// È÷¾î·Î Å¬·¡½º¸¦ ¼±¾ðÇÑ´Ù.
#endif																				// ºÐ±â Ã³¸®¸¦ Á¾·áÇÑ´Ù.


#define MAX_QUEST_PROBABILITY		10000											// ÃÖ´ë Äù½ºÆ® º¯¼ö.

#define	MAX_QUEST					200												// ÃÖ´ë Äù½ºÆ® ¼ö.
#define	MAX_QUESTEVENT_MGR			1000											// ÃÖ´ë Äù½ºÆ® ÀÌº¥Æ® ¸Å´ÏÁ®?
#define MAX_QUESTEVENT_PLYER		100												// ÃÖ´ë Äù½ºÆ® ÀÌº¥Æ® ÇÃ·¹ÀÌ¾î¼ö.
#define	MAX_SUBQUEST				32												// ÃÖ´ë ¼­ºê Äù½ºÆ® ¼ö.

#define	MAX_ITEMDESC_LENGTH			255												// ÃÖ´ë ¾ÆÀÌÅÛ ¼³¸í ±æÀÌ.
#define	MAX_ITEMDESC_LINE			20												// ÃÖ´ë ¾ÆÀÌÅÛ ¼³¸í ¶óÀÎ.
#define MAX_PROCESSQUEST			100												// ÃÖ´ë Äù½ºÆ® ÇÁ·Î¼¼½º ¼ö.
#define VIEW_QUESTITEM_PERPAGE		12												// ÇÑ ÆäÀÌÁö ´ç º¸¿©Áö´Â ÃÖ´ë Äù½ºÆ® ¾ÆÀÌÅÛ ¼ö.
#define MAX_QUESTITEM				100												// ÃÖ´ë Äù½ºÆ® ¾ÆÀÌÅÛ ¼ö.
#define QUEST_DESC_COLOR			RGB(0, 0, 64)									// Äù½ºÆ® ¼³¸í »ö»ó.
#define QUEST_DESC_HIGHLIGHT		RGB(128, 0, 0)									// Äù½ºÆ® ¼³¸í ÇÏÀÌ¶óÀÌÆ® »ö»ó.
#define COMBINEKEY(a, b, c)				\
	if(b<100)			c=a*100+b;		\
	else if(b<1000)		c=a*1000+b;		\
	else if(b<10000)	c=a*10000+b;	


enum eQuestEvent																	// Äù½ºÆ® ÀÌº¥Æ®¸¦ ±¸ºÐÇÏ´Â ÀÌ³Ñ ÄÚµå.
{
	eQuestEvent_NpcTalk = 1,														// npc ´ëÈ­ ÀÌº¥Æ®.
	eQuestEvent_Hunt,																// »ç³É ÀÌº¥Æ®.
	eQuestEvent_EndSub,																// ¼­ºê Äù½ºÆ® Á¾·á ÀÌº¥Æ®.
	eQuestEvent_Count,																// Ä«¿îÆ® ÀÌº¥Æ®.
	eQuestEvent_GameEnter,															// °ÔÀÓ ¿£ÅÍ ÀÌº¥Æ®.
	eQuestEvent_Level,																// ·¹º§ ÀÌº¥Æ®.
	eQuestEvent_UseItem,															// ¾ÆÀÌÅÛ »ç¿ë ÀÌº¥Æ®.
	eQuestEvent_MapChange,															// ¸Ê º¯°æ ÀÌº¥Æ®.
	eQuestEvent_Die,																// ´ÙÀÌ ÀÌº¥Æ®.
	eQuestEvent_Time,																// ½Ã°£ ÀÌº¥Æ®.
	eQuestEvent_HuntAll,															// ¸ðµÎ »ç³É ÀÌº¥Æ®.
};

enum eQuestExecute																	// Äù½ºÆ® ½ÇÇàÀ» ±¸ºÐÇÏ±â À§ÇÑ ÀÌ³Ñ ÄÚµå.
{
	eQuestExecute_EndQuest,															// Äù½ºÆ® Á¾·á.
	eQuestExecute_StartQuest,														// Äù½ºÆ® ½ÃÀÛ.

	eQuestExecute_EndSub,															// ¼­ºê Äù½ºÆ® Á¾·á.
	eQuestExecute_EndOtherSub,														// ´Ù¸¥ ¼­ºê Äù½ºÆ® Á¾·á.
	eQuestExecute_StartSub,															// ¼­ºê Äù½ºÆ® ½ÃÀÛ.
	
	eQuestExecute_AddCount,															// Ä«¿îÆ® Ãß°¡.
	eQuestExecute_MinusCount,														// Ä«¿îÆ® °¨¼Ò.

	eQuestExecute_GiveQuestItem,													// Äù½ºÆ® ¾ÆÀÌÅÛÀ» ÁÖ´Â°Í. quest item Ã¢¿¡ µé¾î°¡´Â °Å
	eQuestExecute_TakeQuestItem,													// Äù½ºÆ® ¾ÆÀÌÅÛÀ» È¹µæÇÏ´Â °Í.
	
	eQuestExecute_GiveItem,															// Äù½ºÆ® ¾ÆÀÌÅÛÀ» ÁÖ´Â °Í.
	eQuestExecute_GiveMoney,														// Äù½ºÆ® ¸Ó´Ï¸¦ ÁÖ´Â °Í.
	eQuestExecute_TakeItem,															// Äù½ºÆ® ¾ÆÀÌÅÛÀ» È¹µæÇÏ´Â °Í.
	eQuestExecute_TakeMoney,														// Äù½ºÆ® ¸Ó´Ï¸¦ È¹µæÇÏ´Â °Í.
	eQuestExecute_TakeExp,															// Äù½ºÆ® °æÇèÄ¡¸¦ È¹µæÇÏ´Â °Í.
	eQuestExecute_TakeSExp,															// ÄùÀ sp Æ÷ÀÎÆ®¸¦ È¹µæÇÏ´Â °Í.

	eQuestExecute_RandomTakeItem,													// ·£´ýÇÏ°Ô ¾ÆÀÌÅÛÀ» È¹µæÇÏ´Â °Í.

	eQuestExecute_TakeQuestItemFQW,													// from Æ¯Á¤ ¹«±â·Î
	eQuestExecute_AddCountFQW,														// from Æ¯Á¤ ¹«±â·Î Ä«¿îÆ®¸¦ Ãß°¡ÇÏ´Â °Í.
	eQuestExecute_TakeQuestItemFW,													// from ¹«±â·ù·Î Äù½ºÆ® ¾ÆÀÌÅÛÀ» È¹µæÇÏ´Â °Í.
	eQuestExecute_AddCountFW,														// Äù½ºÆ® ¾ÆÀÌÅÛ Ä«¿îÆ®¸¦ Ãß°¡ÇÏ´Â °Í.
	
	eQuestExecute_TakeMoneyPerCount,												// Ä«¿îÆ® º°, Äù½ºÆ® ¸Ó´Ï¸¦ È¹µæÇÏ´Â °Í.
	
	eQuestExecute_RegenMonster,														// ¸ó½ºÅÍ¸¦ ¸®Á¨ÇÏ´Â °Í.
	eQuestExecute_MapChange,														// ¸ÊÀ» ±³Ã¼ÇÏ´Â °Í.

	eQuestExecute_ChangeStage,														// ½ºÅ×ÀÌÁö¸¦ ¼öÁ¤ÇÏ´Â °Í.
	
	eQuestExecute_ChangeSubAttr,													// ¼­ºê Attr¸¦ ¼öÁ¤ÇÏ´Â °Í.

	eQuestExecute_RegistTime,														// ½Ã°£À» µî·ÏÇÏ´Â °Í.

	eQuestExecute_LevelGap,															// ·¹º§ Â÷ÀÌ¸¦ Àû¿ëÇÏ´Â °Í.
	eQuestExecute_MonLevel,															// ¸ó½ºÅÍ ·¹º§À» Àû¿ëÇÏ´Â °Í

	eQuestExecute_TakeSelectItem,													// 100414 ONS Äù½ºÆ®º¸»ó ¼±ÅÃ¾ÆÀÌÅÛÀ» È¹µæ Ãß°¡	
};

enum eQuestLimitKind																// Äù½ºÆ® Á¦ÇÑ ¼³Á¤À» À§ÇÑ ÀÌ³Ñ ÄÚµå.
{
	eQuestLimitKind_Level,															// ·¹º§ Á¦ÇÑ.
	eQuestLimitKind_Money,															// ¸Ó´Ï Á¦ÇÑ.
	eQuestLimitKind_Quest,															// Äù½ºÆ® Á¦ÇÑ.
	eQuestLimitKind_SubQuest,	
	// 070415 LYW --- QuestDefine : Active quest limit kine enum stage.
	eQuestLimitKind_Stage,															// ÄùÀ »óÅÂ Á¦ÇÑ.
	eQuestLimitKind_Attr,															// Äù½ºÆ® ¼Ó¼º Á¦ÇÑ´Ù.
	// 071011 LYW --- QuestDefine : Add quest limit to check running quest.			// ÁøÇà ÁßÀÎ Äù½ºÆ®¸¦ Á¦ÇÑÇÑ´Ù.
	eQuestLimitKind_RunningQuest,
};

enum eQuestValue																	// Äù½ºÆ® °ª¿¡ µû¸¥ ÀÌ³Ñ ÄÚµå.
{
	eQuestValue_Add,																// Äù½ºÆ® Ãß°¡.
	eQuestValue_Minus,																// Äù½ºÆ® »èÁ¦.
	eQuestValue_Reset,
};

enum																				// Äù½ºÆ® Æ®¸®¿¡ µû¸¥ ÀÌ³Ñ ÄÚµå.
{
	eQTree_NotUse,																	// Æ®¸® »ç¿ë ¾ÈÇÏ±â, 
	eQTree_Close,																	// ´Ý±â.
	eQTree_Open,																	// ¿­±â.
};

enum																				// Äù½ºÆ® ¾ÆÀÌÅÛ Ä«¿îÆ® °ü·Ã ÀÌ³Ñ ÄÚµå.
{
	eQItem_AddCount,																// Äù½ºÆ® Ãß°¡ Ä«¿îÆ®.
	eQItem_SetCount,																// Äù½ºÆ® ¼¼ÆÃ Ä«¿îÆ®.
	eQItem_GetCount,																// Äù½ºÆ® ¹ÝÈ¯ Ä«¿îÆ®.
};

enum
{
	eQuest_NpcScript_Normal,														// ÀÏ¹Ý»óÅÂÀÇ Äù½ºÆ® NPC½ºÅ©¸³Æ® 
	eQuest_NpcScript_Lack,															// Á¶°Ç ºÒÃæÁ·½Ã »óÅÂÀÇ Äù½ºÆ® NPC½ºÅ©¸³Æ®
};

struct SUBQUEST																		// ¼­ºê Äù½ºÆ® ±¸Á¶Ã¼.
{
	DWORD	dwMaxCount;																// ÃÖ´ë Ä«¿îÆ®.
	DWORD	dwData;																	// µ¥ÀÌÅÍ °ª.
	DWORD	dwTime;																	// ½Ã°£ °ª.
	SUBQUEST() : dwMaxCount(0), dwData(0), dwTime(0)	{}							// ±âº» ÇÔ¼ö.
};

struct QUESTITEM																	// Äù½ºÆ® ¾ÆÀÌÅÛ ±¸Á¶Ã¼.
{
	DWORD	dwQuestIdx;																// Äù½ºÆ® ÀÎµ¦½º.
	DWORD	dwItemIdx;																// ¾ÆÀÌÅÛ ÀÎµ¦½º.
	DWORD	dwItemNum;																// ¾ÆÀÌÅÛ °³¼ö.
	QUESTITEM() : dwQuestIdx(0), dwItemIdx(0), dwItemNum(0)	{}						// ±âº» ÇÔ¼ö.
};

struct QUEST_ITEM_INFO																// Äù½ºÆ® ¾ÆÀÌÅÛ Á¤º¸ ±¸Á¶Ã¼.
{
	DWORD		ItemIdx;															// ¾ÆÀÌÅÛ ÀÎµ¦½º.
	DWORD		QuestKey;															// Äù½ºÆ® Å° °ª.
	char		ItemName[MAX_ITEMNAME_LENGTH+1];									// ¾ÆÀÌÅÛ ¸í.
	WORD		Image2DNum;															// 2d ÀÌ¹ÌÁö.
	WORD		SellPrice;															// ÆÇ¸Å °¡°Ý.
	char		ItemDesc[MAX_ITEMDESC_LENGTH+1];									// ¾ÆÀÌÅÛ ¼³¸í.
};

enum eQuestState
{
	eQuestState_ImPossible,		// ¼öÇàºÒ°¡
	eQuestState_Possible,		// ¼öÇà°¡´É
	eQuestState_Executed,		// ¼öÇàÁß
};

#pragma pack(pop)
#endif
