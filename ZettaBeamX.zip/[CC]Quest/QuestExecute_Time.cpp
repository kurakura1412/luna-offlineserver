// QuestExecute_Time.cpp: implementation of the QuestExecute_Time class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"																			// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "QuestExecute_Time.h"																// Äù½ºÆ® ½ÇÇà ½Ã°£ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"																// Äù½ºÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#ifdef _MAPSERVER_																			// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

#include "QuestGroup.h"																		// Äù½ºÆ® ±×·ì Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// »ý¼ºÀÚ.
CQuestExecute_Time::CQuestExecute_Time( DWORD dwExecuteKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
: CQuestExecute( dwExecuteKind, pTokens, dwQuestIdx, dwSubQuestIdx )
{
	GetScriptParam( m_bType, pTokens );														// Å¸ÀÔÀ» ¹Þ´Â´Ù.
	GetScriptParam( m_dwDay, pTokens );														// ³¯Â¥¸¦ ¹Þ´Â´Ù.
	GetScriptParam( m_dwHour, pTokens );													// ½Ã°£À» ¹Þ´Â´Ù.
	GetScriptParam( m_dwMin, pTokens );														// ºÐÀ» ¹Þ´Â´Ù.
}

CQuestExecute_Time::~CQuestExecute_Time()													// ¼Ò¸êÀÚ ÇÔ¼ö.
{
}

// ½ÇÇà ÇÔ¼ö.
BOOL CQuestExecute_Time::Execute( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )
{
#ifdef _MAPSERVER_																			// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch( m_dwExecuteKind )																// ½ÇÇà Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestExecute_RegistTime:															// ½Ã°£ µî·Ï ½ÇÇàÀÌ¶ó¸é,
		{
			// ½Ã°£ Ã¼Å©¸¦ µî·ÏÇÏ´Â ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
			pQuestGroup->RegistCheckTime( m_dwQuestIdx, m_dwSubQuestIdx, m_bType, m_dwDay, m_dwHour, m_dwMin );
		}
		break;
	}

#endif	

	return TRUE;																			// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
}

int CQuestExecute_Time::CheckCondition( PLAYERTYPE* pPlayer, 
							CQuestGroup* pQuestGroup, CQuest* pQuest )			// Äù½ºÆ® ÀÌº¥Æ®¸¦ ½ÇÇàÇÏ±â À§ÇÑ Á¶°ÇÀ» ¸¸Á·ÇÏ´ÂÁö Ã¼Å©ÇÏ´Â ÇÔ¼ö.
{
	int nErrorCode = e_EXC_ERROR_NO_ERROR ;												// ¿¡·¯ ÄÚµå¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í e_EXE_ERROR_NO_ERROR·Î ¼¼ÆÃÇÑ´Ù.

	if( !pPlayer )																		// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, 
	{
		nErrorCode = e_EXC_ERROR_NO_PLAYERINFO ;										// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;																// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuestGroup )																	// Äù½ºÆ® ±×·ì Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUESTGROUP ;										// Äù½ºÆ® ±×·ì Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;																// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuest )																		// Äù½ºÆ® Á¤º¸°¡ À¯È¿ÇÏÁö ¾Ê´Ù¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUEST ;												// Äù½ºÆ® Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;																// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

#ifdef _MAPSERVER_																// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

#endif //_MAPSERVER_

	return nErrorCode ;															// ±âº» °ªÀ» ¸®ÅÏÇÑ´Ù.
}
