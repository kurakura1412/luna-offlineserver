// QuestTrigger.cpp: implementation of the CQuestTrigger class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"														// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "QuestTrigger.h"												// Äù½ºÆ® Æ®¸®°Å Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"											// Äù½ºÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestCondition.h"												// Äù½ºÆ® »óÅÂ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestExecute.h"												// Äù½ºÆ® ½ÇÇà Çì´õ¸¦ ºÒ·¯¿Â´Ù.
#include "QuestEvent.h"													// Äù½ºÆ® ÀÌº¥Æ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#ifdef _MAPSERVER_														// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

#include "Player.h"														// ÇÃ·¹ÀÌ¾î Çì´õ¸¦ ¼±¾ðÇÑ´Ù.

#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// »ý¼ºÀÚ ÇÔ¼ö.
CQuestTrigger::CQuestTrigger( CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
	ReadTrigger( pTokens, dwQuestIdx, dwSubQuestIdx );					// Æ®¸®°Å¸¦ ÀÐ¾îµéÀÎ´Ù.
}

CQuestTrigger::~CQuestTrigger()											// ¼Ò¸êÀÚ ÇÔ¼ö.
{
	Release();															// ÇØÁ¦ ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
}

void CQuestTrigger::Release()											// ÇØÁ¦ ÇÔ¼ö.
{
	if( m_pQuestCondition )												// Äù½ºÆ® »óÅÂ Á¤º¸°¡ À¯È¿ÇÏ¸é,
	{
		delete m_pQuestCondition;										// Äù½ºÆ® »óÅÂ Á¤º¸¸¦ »èÁ¦ÇÑ´Ù.
		m_pQuestCondition = NULL;										// Äù½ºÆ® »óÅÂ Á¤º¸¸¦ ³ªÅ¸³»´Â Æ÷ÀÎÅÍ¸¦ null Ã³¸®¸¦ ÇÑ´Ù.
	}

	CQuestExecute* pQuestExecute = NULL;								// Äù½ºÆ® ½ÇÇà Æ÷ÀÎÅÍ¸¦ NULL Ã³¸®¸¦ ÇÑ´Ù.

	PTRLISTPOS pos = m_QuestExeList.GetHeadPosition();					// Äù½ºÆ® ½ÇÇà ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	while( pos )														// À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑµ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pQuestExecute = (CQuestExecute*)m_QuestExeList.GetNext( pos );	// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pQuestExecute )												// Á¤º¸°¡ À¯È¿ÇÏ´Ù¸é,
		{
			delete pQuestExecute;										// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ »èÁ¦ÇÑ´Ù.
		}
	}
	m_QuestExeList.RemoveAll();											// Äù½ºÆ® ½ÇÇà ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿î´Ù.
}

#include "QuestExecute_Quest.h"											// Äù½ºÆ® ½ÇÇà Äù½ºÆ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

// Æ®¸®°Å¸¦ ÀÐ¾îµéÀÌ´Â ÇÔ¼ö.
BOOL CQuestTrigger::ReadTrigger( CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
	char* OneToken;														// ÅäÅ« Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.

	m_dwEndParam = 0;													// Á¾·á ÆÄ¶ó¸ÞÅÍ¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	while( (OneToken = pTokens->GetNextTokenUpper()) != NULL )			// ÅäÅ« Á¤º¸°¡ À¯È¿ÇÑ µ¿¾È while¹®À» µ¹¸°´Ù.
	{
		if( OneToken[0] == '@' )										// ÅäÅ«ÀÌ @¿Í °°´Ù¸é,
		{
			m_pQuestCondition = CQuestScriptLoader::LoadQuestCondition(	// Äù½ºÆ® »óÅÂ Á¤º¸¸¦ ·ÎµùÇÏ¿©, 
				OneToken, pTokens, dwQuestIdx, dwSubQuestIdx );			// Æ÷ÀÎÅÍ º¯¼ö·Î ¹Þ´Â´Ù.
		}
		else if( OneToken[0] == '*' )									// ÅäÅ«ÀÌ *¿Í °°´Ù¸é,
		{
			// ¹Ýº¹Äù½ºÆ®ÀÇ È®ÀÎÀ» À§ÇØ¼­ Ãß°¡ RaMa - 04.10.26
			CQuestExecute* pQuestExecute = NULL ;						// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ º¯¼ö¸¦ ¼±¾ðÇÑ´Ù.

			pQuestExecute = CQuestScriptLoader::LoadQuestExecute(		// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ·ÎµùÇÏ¿©,
				OneToken, pTokens, dwQuestIdx, dwSubQuestIdx );			// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ º¯¼ö¿¡ ¹Þ´Â´Ù.

			// Äù½ºÆ® ½ÇÇàÀÌ Äù½ºÆ® Á¾·á¿Í °°À¸¸é,
			if(pQuestExecute && pQuestExecute->GetQuestExecuteKind() == eQuestExecute_EndQuest)
			{
				// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ¹Þ´Â´Ù.
				CQuestExecute_Quest* pQExe_Quest = (CQuestExecute_Quest*)pQuestExecute;

				if( pQExe_Quest )										// Äù½ºÆ® ½ÇÇà Á¤º¸°¡ À¯È¿ÇÏ¸é,
				{
					m_dwEndParam = pQExe_Quest->GetQuestExeIdx();		// Äù½ºÆ® ½ÇÇà ÀÎµ¦½º¸¦ ¹Þ´Â´Ù.
				}
			}
			m_QuestExeList.AddTail( pQuestExecute );					// Äù½ºÆ® ½ÇÇà ¸®½ºÆ®¿¡ Ãß°¡ÇÑ´Ù.
		}
	}
	return TRUE;														// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
}

//Äù½ºÆ® ÀÌº¥Æ®¸¦ Ã³¸®ÇÏ´Â ÇÔ¼ö.
BOOL CQuestTrigger::OnQuestEvent( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup,	// Äù½ºÆ® ÀÌº¥Æ®¸¦ Ã³¸®ÇÏ´Â ÇÔ¼ö.
								  CQuest* pQuest, CQuestEvent* pQuestEvent )
{	
	if( !m_pQuestCondition->CheckCondition( pQuestEvent ) )							// ÀÌº¥Æ® Á¤º¸¿¡ µû¸¥ Äù½ºÆ® »óÅÂ Á¤º¸¸¦ Ã¼Å©ÇÑ´Ù.
	{
		return FALSE;																// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
	}

	int nErrorCode = -1 ;															// ¿¡·¯ ÄÚµå¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í -1·Î ¼¼ÆÃÇÑ´Ù.

	CQuestExecute* pQuestExecute ;													// Äù½ºÆ® ½ÇÇà Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.

	PTRLISTPOS pos = m_QuestExeList.GetHeadPosition();								// Äù½ºÆ® ½ÇÇà ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í, À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	while( pos )																	// Äù½ºÆ® À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑ µ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pQuestExecute = NULL ;														// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ´ãÀ» Æ÷ÀÎÅÍ¸¦ null Ã³¸®¸¦ ÇÑ´Ù.
		pQuestExecute = (CQuestExecute*)m_QuestExeList.GetNext( pos );				// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( !pQuestExecute ) continue ;												// Äù½ºÆ® ½ÇÇà Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, continue Ã³¸®¸¦ ÇÑ´Ù.

		nErrorCode = pQuestExecute->CheckCondition( pPlayer, pQuestGroup, pQuest ) ;// Äù½ºÆ®¸¦ ½ÇÇà ÇÒ Á¶°ÇÀ» °®Ãß°í ÀÖ´ÂÁö Ã¼Å©ÇÏ¿© °á°ú¸¦ ¹Þ´Â´Ù.

		if( nErrorCode != -1 ) break ;												// ¿¡·¯ ÄÚµå°¡ -1ÀÌ ¾Æ´Ï¸é while¹®À» Å»ÃâÇÑ´Ù.
	}

#ifdef _MAPSERVER_																	// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	if( nErrorCode != -1 )															// ½ÇÇà °á°ú°¡ FALSE¿Í °°´Ù¸é,
	{
		MSG_INT Msg ;																// ¸Þ½ÃÁö ±¸Á¶Ã¼¸¦ ¼±¾ðÇÑ´Ù.
		Msg.Category = MP_QUEST;													// Ä«Å×°í¸®¸¦ Äù½ºÆ®·Î ¼¼ÆÃÇÑ´Ù.
		Msg.Protocol = MP_QUEST_EXECUTE_ERROR;										// ÇÁ·ÎÅäÄÝÀ» Äù½ºÆ® ½ÇÇà ¿¡·¯·Î ¼¼ÆÃÇÑ´Ù.
		Msg.dwObjectID = pPlayer->GetID();											// ÇÃ·¹ÀÌ¾î ¾ÆÀÌµð¸¦ ¼¼ÆÃÇÑ´Ù.

		Msg.nData = nErrorCode ;													// Äù½ºÆ® ÀÌº¥Æ® Ã³¸® ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.

		pPlayer->SendMsg( &Msg, sizeof(Msg) );										// ÇÃ·¹ÀÌ¾î¿¡°Ô ¿¡·¯ ¸Þ½ÃÁö¸¦ Àü¼ÛÇÑ´Ù.

		return FALSE ;																// false return Ã³¸®¸¦ ÇÑ´Ù.
	}

#endif

	pos = m_QuestExeList.GetHeadPosition();											// Äù½ºÆ® ½ÇÇà ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í, À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.

	while( pos )																	// Äù½ºÆ® À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑ µ¿¾È while¹®À» µ¹¸°´Ù.
	{
		pQuestExecute = NULL ;														// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ´ãÀ» Æ÷ÀÎÅÍ¸¦ null Ã³¸®¸¦ ÇÑ´Ù.
		pQuestExecute = (CQuestExecute*)m_QuestExeList.GetNext( pos );				// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( !pQuestExecute ) continue ;												// Äù½ºÆ® ½ÇÇà Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, continue Ã³¸®¸¦ ÇÑ´Ù.

		if( pQuestExecute->Execute( pPlayer, pQuestGroup, pQuest ) == FALSE )		// Äù½ºÆ® ÀÌº¥Æ®¸¦ ½ÇÇàÇÑ´Ù.
			return FALSE;
	}

	return TRUE;
}

//// Äù½ºÆ® ÀÌº¥Æ®¸¦ Ã³¸®ÇÏ´Â ÇÔ¼ö.
//BOOL CQuestTrigger::OnQuestEvent( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest, CQuestEvent* pQuestEvent )
//{
//	// condition
//	if( !m_pQuestCondition->CheckCondition( pQuestEvent ) )				// ÀÌº¥Æ® Á¤º¸¿¡ µû¸¥ Äù½ºÆ® »óÅÂ Á¤º¸¸¦ Ã¼Å©ÇÑ´Ù.
//	{
//		return FALSE;													// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
//	}
//
//	// execute
//	BOOL bError = TRUE;													// ¿¡·¯ ¿©ºÎ¸¦ ´ã´Â º¯¼ö¸¦ TRUE·Î ¼¼ÆÃÇÑ´Ù.
//
//	PTRLISTPOS pos = m_QuestExeList.GetHeadPosition();					// Äù½ºÆ® ½ÇÇà ¸®½ºÆ®¸¦ Çìµå·Î ¼¼ÆÃÇÏ°í, À§Ä¡ Á¤º¸¸¦ ¹Þ´Â´Ù.
//
//	CQuestExecute* pQuestExecute = NULL;								// Äù½ºÆ® ½ÇÇà Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í null Ã³¸®¸¦ ÇÑ´Ù.
//
//	while( pos )														// Äù½ºÆ® À§Ä¡ Á¤º¸°¡ À¯È¿ÇÑ µ¿¾È while¹®À» µ¹¸°´Ù.
//	{
//		pQuestExecute = (CQuestExecute*)m_QuestExeList.GetNext( pos );	// Äù½ºÆ® ½ÇÇà Á¤º¸¸¦ ¹Þ´Â´Ù.
//
//		if( pQuestExecute )												// Äù½ºÆ® ½ÇÇà Á¤º¸°¡ À¯È¿ÇÏ¸é,
//		{
//			bError = pQuestExecute->Execute( pPlayer, pQuestGroup, pQuest );	// Äù½ºÆ®¸¦ ½ÇÇàÇÏ¿© °á°ú¸¦ ¹Þ´Â´Ù.
//
//			if( bError == FALSE )	
//			{
//				break;								// °á°ú°¡ FALSE¿Í °°À¸¸é, while¹®À» Å»ÃâÇÑ´Ù.
//			}
//		}
//	}
//
//#ifdef _MAPSERVER_														// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,
//
//	if( bError == FALSE )												// ½ÇÇà °á°ú°¡ FALSE¿Í °°´Ù¸é,
//	{
//		// network send
//		MSGBASE Msg;													// ¸Þ½ÃÁö ±¸Á¶Ã¼¸¦ ¼±¾ðÇÑ´Ù.
//		Msg.Category = MP_QUEST;										// Ä«Å×°í¸®¸¦ Äù½ºÆ®·Î ¼¼ÆÃÇÑ´Ù.
//		Msg.Protocol = MP_QUEST_EXECUTE_ERROR;							// ÇÁ·ÎÅäÄÝÀ» Äù½ºÆ® ½ÇÇà ¿¡·¯·Î ¼¼ÆÃÇÑ´Ù.
//		Msg.dwObjectID = pPlayer->GetID();								// ÇÃ·¹ÀÌ¾î ¾ÆÀÌµð¸¦ ¼¼ÆÃÇÑ´Ù.
//		pPlayer->SendMsg( &Msg, sizeof(Msg) );							// ÇÃ·¹ÀÌ¾î¿¡°Ô ¿¡·¯ ¸Þ½ÃÁö¸¦ Àü¼ÛÇÑ´Ù.
//	}
//
//#endif
//
//	return TRUE;
//}
