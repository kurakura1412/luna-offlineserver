// QuestExecute_RandomItem.cpp: implementation of the CQuestExecute_RandomItem class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"																		// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "QuestExecute_RandomItem.h"													// Äù½ºÆ® ½ÇÇà ·£´ý ¾ÆÀÌÅÛ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"															// Äù½ºÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#ifdef _MAPSERVER_																		// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

#include "QuestGroup.h"																	// Äù½ºÆ® ±×·ì Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "ItemSlot.h"

#include "Player.h"

#include "ItemManager.h"

#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
// »ý¼ºÀÚ ÇÔ¼ö.
CQuestExecute_RandomItem::CQuestExecute_RandomItem( DWORD dwExecuteKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
: CQuestExecute( dwExecuteKind, pTokens, dwQuestIdx, dwSubQuestIdx )
{
	GetScriptParam( m_dwMaxItemCount, pTokens );										// ¾ÆÀÌÅÛ ÃÖ´ë ¼ö¸¦ ¹Þ´Â´Ù.
	GetScriptParam( m_dwRandomItemCount, pTokens );										// ·£´ý ¾ÆÀÌÅÛ Ä«¿îÆ®¸¦ ¹Þ´Â´Ù.
	
	m_pRandomItem = new RANDOMITEM[m_dwMaxItemCount];									// ÃÖ´ë ¼ö ¸¸Å­ ·£´ý ¾ÆÀÌÅÛ Á¤º¸¸¦ ´ãÀ» ¸Þ¸ð¸®¸¦ ÇÒ´çÇÏ¿© Æ÷ÀÎÅÍ·Î ¹Þ´Â´Ù.

	for( DWORD i = 0; i < m_dwMaxItemCount; ++i )										// ÃÖ´ë ¾ÆÀÌÅÛ ¼ö ¸¸Å­ for¹°À» µ¹¸°´Ù.
	{
		GetScriptParam( m_pRandomItem[i].wItemIdx, pTokens );							// ¾ÆÀÌÅÛ ÀÎµ¦½º¸¦ ¹Þ´Â´Ù.
		GetScriptParam( m_pRandomItem[i].wItemNum, pTokens );							// ¾ÆÀÌÅÛ °³¼ö¸¦ ¹Þ´Â´Ù.
		GetScriptParam( m_pRandomItem[i].wPercent, pTokens );							// ÆÛ¼¾Æ®¸¦ ¹Þ´Â´Ù.
	}

	m_dwQuestIdx = dwQuestIdx;
	m_dwSubQuestIdx = dwSubQuestIdx;
}

CQuestExecute_RandomItem::~CQuestExecute_RandomItem()									// ¼Ò¸êÀÚ ÇÔ¼ö.
{
	if( m_pRandomItem )																	// ·£´ý ¾ÆÀÌÅÛ Á¤º¸¸¦ ³ªÅ¸³»´Â Æ÷ÀÎÅÍ Á¤º¸°¡ À¯È¿ÇÏ¸é,
	{
		delete [] m_pRandomItem;														// ·£´ý ¾ÆÀÌÅÛ Á¤º¸¸¦ »èÁ¦ÇÑ´Ù.
		m_pRandomItem = NULL;															// Á¤º¸¸¦ ³ªÅ¸³»´Â Æ÷ÀÎÅÍ¸¦ NULL Ã³¸®¸¦ ÇÑ´Ù.
	}
}

// ½ÇÇà ÇÔ¼ö.
BOOL CQuestExecute_RandomItem::Execute( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )
{
#ifdef _MAPSERVER_																		// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch( m_dwExecuteKind )															// ½ÇÇà Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestExecute_RandomTakeItem:													// ·£´ý ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			cPtrList* pRandomItemList = NULL ;											// ·£´ý ¾ÆÀÌÅÛ ¸®½ºÆ® Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.
			pRandomItemList = pQuestGroup->GetRandomItemList() ;						// Äù½ºÆ® ±×·ìÀÇ ·£´ý ¾ÆÀÌÅÛ ¸®½ºÆ®¸¦ ¹Þ´Â´Ù.

			if( !pRandomItemList ) return FALSE ;

			RANDOMITEM* pItem ;

			PTRLISTPOS pos = NULL ;
			pos = pRandomItemList->GetHeadPosition() ;

			while(pos)
			{
				pItem = NULL ;
				pItem = (RANDOMITEM*)pRandomItemList->GetNext(pos) ;

				if( !pItem ) continue ;
		
				pQuestGroup->TakeItem( pPlayer, m_dwQuestIdx, m_dwSubQuestIdx, pItem->wItemIdx, pItem->wItemNum, MAX_QUEST_PROBABILITY );
			}

			pQuestGroup->ReleaseRandomItemList() ;										// ÇöÀç Äù½ºÆ® ±×·ìÀÇ ·£´ý ¾ÆÀÌÅÛ ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿î´Ù.
		}
		break;
	}

#endif	

	return TRUE;																		// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
}

int CQuestExecute_RandomItem::CheckCondition( PLAYERTYPE* pPlayer,				
							CQuestGroup* pQuestGroup, CQuest* pQuest )					
{
	int nErrorCode = e_EXC_ERROR_NO_ERROR ;												// ¿¡·¯ ÄÚµå¸¦ ´ãÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í e_EXE_ERROR_NO_ERROR·Î ¼¼ÆÃÇÑ´Ù.

	if( !pPlayer )																		// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é, 
	{
		nErrorCode = e_EXC_ERROR_NO_PLAYERINFO ;										// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;																// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuestGroup )																	// Äù½ºÆ® ±×·ì Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUESTGROUP ;										// Äù½ºÆ® ±×·ì Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;																// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

	if( !pQuest )																		// Äù½ºÆ® Á¤º¸°¡ À¯È¿ÇÏÁö ¾Ê´Ù¸é,
	{
		nErrorCode = e_EXC_ERROR_NO_QUEST ;												// Äù½ºÆ® Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
		return nErrorCode ;																// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
	}

#ifdef _MAPSERVER_																		// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch( m_dwExecuteKind )															// ½ÇÇà Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestExecute_RandomTakeItem:													// ·£´ý ¾ÆÀÌÅÛÀ» ¹Þ´Â ½ÇÇàÀÌ¸é,
		{
			RANDOMITEM* pItem = NULL;													// ·£´ý ¾ÆÀÌÅÛ Á¤º¸¸¦ ´ãÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í NULL Ã³¸®¸¦ ÇÑ´Ù.

			CItemSlot* pSlot ;															// ÀÎº¥Åä¸® ½½·Ô Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.

			cPtrList* pRandomItemList = NULL ;											// ·£´ý ¾ÆÀÌÅÛ ¸®½ºÆ® Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÑ´Ù.
			pRandomItemList = pQuestGroup->GetRandomItemList() ;						// Äù½ºÆ® ±×·ìÀÇ ·£´ý ¾ÆÀÌÅÛ ¸®½ºÆ®¸¦ ¹Þ´Â´Ù.

			if( !pRandomItemList )
			{
				nErrorCode = e_EXC_ERROR_NO_RANDOMITEMLIST ;							// Äù½ºÆ® ±×·ìÀÇ ·£´ý ¾ÆÀÌÅÛ ¸®½ºÆ®°¡ ¾ø´Ù´Â ¿¡·¯¸¦ ¼¼ÆÃÇÑ´Ù.
				return nErrorCode ;														// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.
			}

			pQuestGroup->ReleaseRandomItemList() ;										// ÇöÀç Äù½ºÆ® ±×·ìÀÇ ·£´ý ¾ÆÀÌÅÛ ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿î´Ù.

			for( DWORD i = 0; i < m_dwRandomItemCount; ++i )							// ÃÖ´ë ¾ÆÀÌÅÛ ¼ö ¸¸Å­ for¹®À» µ¹¸°´Ù.
			{
				pItem = NULL ;
				pItem = GetRandomItem();												// ·£´ý ¾ÆÀÌÅÛ Á¤º¸¸¦ ¹Þ´Â´Ù.

				if( ! pItem ) continue ;												// Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é continue Ã³¸®¸¦ ÇÑ´Ù.

				pSlot = NULL ;															// ¾ÆÀÌÅÛ ½½·Ô Á¤º¸¸¦ ¹ÞÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ðÇÏ°í null Ã³¸®¸¦ ÇÑ´Ù.
				pSlot = pPlayer->GetSlot(eItemTable_Inventory) ;						// ÇÃ·¹ÀÌ¾îÀÇ ÀÎº¥Åä¸® ½º·Ô Á¤º¸¸¦ ¹Þ´Â´Ù.

				if( !pSlot )															// ÀÎº¥Åä¸® Á¤º¸°¡ À¯È¿ÇÏÁö ¾ÊÀ¸¸é,
				{
					nErrorCode = e_EXC_ERROR_NO_INVENTORYINFO ;							// ÀÎº¥Åä¸® Á¤º¸°¡ ¾ø´Ù´Â ¿¡·¯ÄÚµå¸¦ ¼¼ÆÃÇÑ´Ù.
					return nErrorCode ;													// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.

					//pQuestGroup->ReleaseRandomItemList() ;								// ÇöÀç Äù½ºÆ® ±×·ìÀÇ ·£´ý ¾ÆÀÌÅÛ ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿î´Ù.
				}

				WORD EmptyCellPos[255];													// ºó ½½·Ô À§Ä¡¸¦ ¹ÞÀ» º¯¼ö¸¦ ¼±¾ðÇÑ´Ù.
				WORD EmptyCellNum;														// ºó ½½·Ô °³¼ö¸¦ ¹ÞÀ» º¯¼ö¸¦ ¼±¾ðÇÑ´Ù.

				WORD wResult = 0 ;														// ºó ½½·ÔÀÇ Ã¼Å© °á°ú °ªÀ» ¹ÞÀ» º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.

				wResult = ITEMMGR->CheckExtraSlot(pPlayer, pSlot, pItem->wItemIdx,		// ¾ÆÀÌÅÛÀ» ¹ÞÀ» °ø°£ÀÌ ÃæºÐÇÑÁö °á°ú °ªÀ» ¹Þ´Â´Ù.
								pItem->wItemNum, EmptyCellPos, EmptyCellNum) ;

				if( wResult == 0 )														// °á°ú °ªÀÌ 0°ú °°À¸¸é,
				{
					nErrorCode = e_EXC_ERROR_NO_INVENTORYINFO_RANDOMITEM ;				// ·»´ý ¾ÆÀÌÅÛÀ» À§ÇÑ ÀÎº¥Åä¸®°¡ ºÎÁ·ÇÏ´Ù´Â Ã³¸®¸¦ ÇÑ´Ù.
					return nErrorCode ;													// ¿¡·¯ ÄÚµå¸¦ return Ã³¸®¸¦ ÇÑ´Ù.

					//pQuestGroup->ReleaseRandomItemList() ;								// ÇöÀç Äù½ºÆ® ±×·ìÀÇ ·£´ý ¾ÆÀÌÅÛ ¸®½ºÆ®¸¦ ¸ðµÎ ºñ¿î´Ù.
				}

				RANDOMITEM* pRandomItem = new RANDOMITEM ;
				pRandomItem->wItemIdx = pItem->wItemIdx ;
				pRandomItem->wItemNum = pItem->wItemNum ;
				pRandomItemList->AddTail(pRandomItem) ;									// ·£´ýÀ¸·Î »ý¼ºµÈ ¾ÆÀÌÅÛ Á¤º¸¸¦ Ãß°¡ÇÑ´Ù.
			}
		}
		break;
	}

#endif //_MAPSERVER_

	return nErrorCode ;																	// ±âº» °ªÀ» ¸®ÅÏÇÑ´Ù.
}


RANDOMITEM* CQuestExecute_RandomItem::GetRandomItem()									// ·£´ý ¾ÆÀÌÅÛ Á¤º¸¸¦ ¹ÞÈ¯ÇÏ´Â ÇÔ¼ö.
{
	WORD RandRate = WORD( rand()%10001 );												// ·£´ý·üÀ» »Ì´Â´Ù.
	WORD FromPercent = 0;																// From ÆÛ¼¾Æ® º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.
	WORD ToPercent = 0;																	// To ÆÛ¼¾Æ® º¯¼ö¸¦ ¼±¾ðÇÏ°í 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	for( DWORD i = 0; i < m_dwMaxItemCount; ++i )										// ÃÖ´ë ¾ÆÀÌÅÛ ¼ö ¸¸Å­ for¹®À» µ¹¸°´Ù.
	{
		FromPercent = ToPercent;														// From ÆÛ¼¾Æ®¸¦ To ÆÛ¼¾Æ®·Î ¼¼ÆÃÇÑ´Ù.

		ToPercent = WORD( ToPercent + m_pRandomItem[i].wPercent );						// To ÆÛ¼¾Æ®¿¡ ·£´ý ÆÛ¼¾Æ®¸¦ ´õÇÑ´Ù.

		if( FromPercent <= RandRate && RandRate < ToPercent )							// From ÆÛ¼¾Æ®°¡ ·£´ý·ü ÀÌÇÏÀÌ°í, ·£´ý·üÀÌ ToÆÛ¼¾Æ® º¸´Ù ÀÛÀ¸¸é,
		{
			return &m_pRandomItem[i];													// ·£´ý ¾ÆÀÌÅÛ Á¤º¸¸¦ ¸®ÅÏÇÑ´Ù.
		}
	}

	return NULL;																		// NULLÀ» ¸®ÅÏÇÑ´Ù.
}
