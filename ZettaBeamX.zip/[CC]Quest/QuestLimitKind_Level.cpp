// QuestLimitKind_Level.cpp: implementation of the CQuestLimitKind_Level class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"														// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "QuestLimitKind_Level.h"										// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù ·¹º§ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"											// Äù½ºÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#ifdef _MAPSERVER_														// ¸Ê ¼­¹ö°¡ ¼±¾ð µÇ¾î ÀÖ´Ù¸é,

#include "Player.h"														// ÇÃ·¹ÀÌ¾î Çì´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#else																	// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇÁö ¾Ê¾Ò´Ù¸é,

#include "ObjectManager.h"												// ¿ÀºêÁ§Æ® ¸Å´ÏÁ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

// »ý¼ºÀÚ ÇÔ¼ö.
CQuestLimitKind_Level::CQuestLimitKind_Level( DWORD dwLimitKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx )
: CQuestLimitKind( dwLimitKind, pTokens, dwQuestIdx, dwSubQuestIdx )
{
	m_dwMin = m_dwMax = 0;												// ÃÖ¼Ò, ÃÖ´ë ·¹º§ °ªÀ» 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	if( m_dwLimitKind == eQuestLimitKind_Level )						// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù°¡ ·¹º§ Á¦ÇÑ°ú °°´Ù¸é,
	{
		GetScriptParam( m_dwMin, pTokens );								// ÃÖ¼Ò ·¹º§ °ªÀ» ¹Þ´Â´Ù.
		GetScriptParam( m_dwMax, pTokens );								// ÃÖ´ë ·¹º§ °ªÀ» ¹Þ´Â´Ù.
	}
	else if( m_dwLimitKind == eQuestLimitKind_Money )					// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù°¡ ¸Ó´Ï Á¦ÇÑ°ú °°´Ù¸é,
	{
		GetScriptParam( m_dwMax, pTokens );								// ÃÖ´ë ¸Ó´Ï °ªÀ» ¹Þ´Â´Ù.
	}
	else if( m_dwLimitKind == eQuestLimitKind_Stage )					// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù°¡ ½ºÅ×ÀÌÁö¿Í °°´Ù¸é,
	{
		GetScriptParam( m_dwMin, pTokens );								// ÃÖ¼Ò ·¹º§ °ªÀ» ¹Þ´Â´Ù.
		GetScriptParam( m_dwMax, pTokens );								// ÃÖ´ë ·¹º§ °ªÀ» ¹Þ´Â´Ù.
	}
	else if( m_dwLimitKind == eQuestLimitKind_Attr )					// Äù½ºÆ® ¸®¹ÌÆ® °ªÀÌ Attr°ú °°À¸¸é,
	{
		GetScriptParam( m_dwMin, pTokens );								// ÃÖ¼Ò °ªÀ» ¹Þ´Â´Ù.
	}
}

CQuestLimitKind_Level::~CQuestLimitKind_Level()							// ¼Ò¸êÀÚ ÇÔ¼ö.
{
}

// Äù½ºÆ® ¸®¹ÌÆ® Ã¼Å©ÇÔ¼ö.(¼­¹ö)
BOOL CQuestLimitKind_Level::CheckLimit( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )
{
#ifdef _MAPSERVER_														// ¸Ê¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch( m_dwLimitKind )												// ¸®¹ÌÆ® Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestLimitKind_Level:											// ¸®¹ÌÆ® Á¾·ù°¡ ·¹º§°ú °°´Ù¸é,
		{
			DWORD dwlevel = pPlayer->GetLevel();						// ÇÃ·¹ÀÌ¾îÀÇ ·¹º§À» ¹Þ´Â´Ù.

			if( dwlevel >= m_dwMin && dwlevel <= m_dwMax )				// ÃÖ¼Ò·¹º§ ÀÌ»ó, ÃÖ´ë ·¹º§ ÀÌÇÏ¸é,
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;

	case eQuestLimitKind_Money:											// ¸®¹ÌÆ® Á¾·ù°¡ ¸Ó´Ï¿Í °°´Ù¸é,
		{
			MONEYTYPE Money = pPlayer->GetMoney();						// ÇÃ·¹ÀÌ¾îÀÇ ¸Ó´Ï¸¦ ¹Þ´Â´Ù.

			if( Money >= m_dwMax )										// ÇÃ·¹ÀÌ¾îÀÇ ¸Ó´Ï°¡ ÃÖ´ë ¸Ó´Ïº¸´Ù Å©´Ù¸é,
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;

	case eQuestLimitKind_Stage:											// ¸®¹ÌÆ® Á¾·ù°¡ ½ºÅ×ÀÌÁö¿Í °°´Ù¸é,
		{
			BYTE bStage = pPlayer->GetStage();							// ÇÃ·¹ÀÌ¾îÀÇ ½ºÅ×ÀÌÁö¸¦ ¹Þ´Â´Ù. ( ¸î´Ü°è, ¹«½¼ Á÷¾÷ÀÎ°¡?)

			if( bStage == (BYTE)m_dwMin || bStage == (BYTE)m_dwMax )	// ÃÖ¼Ò ´Ü°è ÀÌ»ó, ÃÖ´ë ´Ü°è ÀÌÇÏ¸é,
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;
	}
#endif

	return FALSE;														// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
}

// Äù½ºÆ® ¸®¹ÌÆ® Ã¼Å©ÇÔ¼ö.(Å¬¶óÀÌ¾ðÆ®)
BOOL CQuestLimitKind_Level::CheckLimit( DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
#ifndef _MAPSERVER_														// ¸Ê¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖÁö ¾ÊÀ¸¸é,

	switch( m_dwLimitKind )												// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestLimitKind_Level:											// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù°¡ ·¹º§ Á¦ÇÑÀÌ¶ó¸é,
		{
			DWORD dwlevel = HERO->GetLevel();							// HEROÀÇ ·¹º§À» ¹Þ´Â´Ù.

			if( dwlevel >= m_dwMin && dwlevel <= m_dwMax )				// HEROÀÇ ·¹º§ÀÌ ÃÖ¼Ò ·¹º§ ÀÌ»ó, ÃÖ´ë ·¹º§ ÀÌÇÏ¸é,
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;

	case eQuestLimitKind_Money:											// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù°¡ ¸Ó´Ï¶ó¸é,
		{
			MONEYTYPE Money = HERO->GetMoney();							// HEROÀÇ ¸Ó´Ï¸¦ ¹Þ´Â´Ù.

			if( Money >= m_dwMax )										// HEROÀÇ ¸Ó´Ï°¡ ÃÖ´ë ¸Ó´Ï ÀÌ»óÀÌ¸é,
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;

	case eQuestLimitKind_Stage:											// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù°¡ ½ºÅ×ÀÌÁö¿Í °°´Ù¸é,
		{
			BYTE bStage = HERO->GetStage();								// HEROÀÇ ½ºÅ×ÀÌÁö¸¦ ¹Þ´Â´Ù.(¸î´Ü°è, ¾î¶²Á÷¾÷ÀÎ°¡?)

			if( bStage == (BYTE)m_dwMin || bStage == (BYTE)m_dwMax )	// ÃÖ¼Ò ´Ü°è ÀÌ»ó, ÃÖ´ë ´Ü°è ÀÌÇÏ¶ó¸é,
			{
				return TRUE;											// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
			}
		}
		break;
	}
#endif

	return FALSE;														// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
}