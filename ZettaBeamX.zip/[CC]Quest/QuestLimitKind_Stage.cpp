




#include "stdafx.h"															// Ç¥ÁØ ½Ã½ºÅÛ°ú, ÇÁ·ÎÁ§Æ®°¡ ÁöÁ¤ÇÑ, ÀÚÁÖ¾²´Â ÇØ´õµéÀ» ¸ðÀº ÇØ´õÆÄÀÏÀ» ºÒ·¯¿Â´Ù.

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "questlimitkind_stage.h"											// Äù½ºÆ® ¸®¹ÌÆ® Á¾·ù ½ºÅ×ÀÌÁö Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#include "QuestScriptLoader.h"												// Äù½ºÆ® ½ºÅ©¸³Æ® ·Î´õ Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#ifdef _MAPSERVER_															// ¸Ê¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖÀ¸¸é,

#include "Player.h"															// ÇÃ·¹ÀÌ¾î Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#else																		// ¸Ê¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖÁö ¾ÊÀ¸¸é,

#include "ObjectManager.h"													// ¿ÀºêÁ§Æ® ¸Å´ÏÁ® Çì´õ¸¦ ºÒ·¯¿Â´Ù.

#endif //_MAPSERVER_

// »ý¼ºÀÚ ÇÔ¼ö.
CQuestLimitKind_Stage::CQuestLimitKind_Stage(DWORD dwLimitKind, CStrTokenizer* pTokens, DWORD dwQuestIdx, DWORD dwSubQuestIdx)
: CQuestLimitKind( dwLimitKind, pTokens, dwQuestIdx, dwSubQuestIdx )
{
	byClass    = 0 ;												// Å¬·¡½º¸¦ ¹ÞÀ» º¯¼ö¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.
	byRacial   = 0 ;												// Á¾Á·À» ¹ÞÀ» º¯¼ö¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.
	byJobGrade = 0 ;												// Àâ ±×·¹ÀÌµå¸¦ ¹ÞÀ» º¯¼ö¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.
	byJobIndex = 0 ;												// Àâ ÀÎµ¦½º¸¦ ¹ÞÀ» º¯¼ö¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	dwClassIndex = 0 ;												// Å¬·¡½º ÀÎµ¦½º¸¦ ¹ÞÀ» º¯¼ö¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.

	m_pClassIndex = NULL ;											// Å¬·¡½º ÀÎµ¦½º Æ÷ÀÎÅÍ¸¦ null Ã³¸®¸¦ ÇÑ´Ù.

	m_byCount = 0 ;													// Ä«¿îÆ® º¯¼ö¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.
    
	if( m_dwLimitKind == eQuestLimitKind_Stage )					// ¸®¹ÌÆ® Á¾·ù°¡ ½ºÅ×ÀÌÁö¿Í °°À¸¸é,
	{
		GetScriptParam( m_byCount, pTokens ) ;						// Ä«¿îÆ®¸¦ ¹Þ´Â´Ù.
	}

	if( m_byCount > 0 )												// Ä«¿îÆ®°¡ 0º¸´Ù Å©¸é,
	{
		m_pClassIndex = new DWORD[m_byCount] ;						// Å¬·¡½º ÀÎµ¦½º¸¦ ´ãÀ» ¸Þ¸ð¸®¸¦ ÇÒ´çÇÑ´Ù.
	}
	else															// ±×·¸Áö ¾ÊÀ¸¸é,
	{
		return ;													// ¸®ÅÏ Ã³¸®¸¦ ÇÑ´Ù.
	}

	for( BYTE count = 0 ; count < m_byCount ; ++count )				// Ä«¿îÆ® ¼ö ¸¸Å­ for¹®À» µ¹¸°´Ù.
	{
		GetScriptParam( m_pClassIndex[count], pTokens ) ;			// Å¬·¡½º ÀÎµ¦½º¸¦ ¹Þ´Â´Ù.
	}
}

CQuestLimitKind_Stage::~CQuestLimitKind_Stage(void)					// ¼Ò¸êÀÚ ÇÔ¼ö.
{
	if( m_pClassIndex )												// Å¬·¡½º ÀÎµ¦½º Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
	{
		delete [] m_pClassIndex ;									// Å¬·¡½º ÀÎµ¦½º¸¦ »èÁ¦ÇÑ´Ù.
		m_pClassIndex = NULL ;										// Å¬·¡½º ÀÎµ¦½º Æ÷ÀÎÅÍ¸¦ NULL Ã³¸®¸¦ ÇÑ´Ù.
	}
}

// Äù½ºÆ® ¸®¹ÌÆ® Ã¼Å© ÇÔ¼ö.(¼­¹ö)
BOOL CQuestLimitKind_Stage::CheckLimit( PLAYERTYPE* pPlayer, CQuestGroup* pQuestGroup, CQuest* pQuest )
{
#ifdef _MAPSERVER_													// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖ´Ù¸é,

	switch(m_dwLimitKind)											// ¸®¹ÌÆ® Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestLimitKind_Stage :									// ¸®¹ÌÆ® Á¾·ù°¡ ½ºÅ×ÀÌÁö¿Í °°´Ù¸é,
		{
			CHARACTER_TOTALINFO totalInfo ;							// Äù½ºÆ® ÅäÅ» Á¤º¸¸¦ ¹ÞÀ» ±¸Á¶Ã¼¸¦ ¼±¾ðÇÑ´Ù.

			memset(&totalInfo, 0, sizeof(CHARACTER_TOTALINFO)) ;	// ±¸Á¶Ã¼ Á¤º¸¸¦ ¸Þ¸ð¸® ¼Â ÇÑ´Ù.

			pPlayer->GetCharacterTotalInfo(&totalInfo) ;			// ÇÃ·¹ÀÌ¾îÀÇ Ä³¸¯ÅÍ ÅäÅ» Á¤º¸¸¦ ¹Þ´Â´Ù.

			BYTE byClass    	 = totalInfo.Job[0] ;				// Å¬·¡½º °ªÀ» ¹Þ´Â´Ù.
			BYTE byRacial   	 = totalInfo.Race+1 ;				// Á¾Á· °ªÀ» ¹Þ´Â´Ù.
			BYTE byJobGrade 	 = totalInfo.JobGrade ;				// Àâ ±×·¹ÀÌµå °ªÀ» ¹Þ´Â´Ù.
			BYTE byJobIndex 	 = 0 ;								// Àâ ÀÎµ¦½º¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.
	
			if(byJobGrade == 1)										// Àâ ±×·¹ÀÌµå°¡ 1°ú °°´Ù¸é,
			{	
				byJobIndex = 1 ;									// Àâ ÀÎµ¦½º¸¦ 1·Î ¼¼ÆÃÇÑ´Ù.
			}
			else													// Àâ ±×·¹ÀÌµå°¡ 1ÀÌ ¾Æ´Ï¶ó¸é,
			{
				byJobIndex = totalInfo.Job[byJobGrade-1] ;			// Àâ ÀÎµ¦½º¸¦ ¹Þ´Â´Ù.
			}

			for( BYTE count = 0 ; count < m_byCount ; ++count )		// Ä«¿îÆ® ¼ö ¸¸Å­ for¹®À» µ¹¸°´Ù.
			{
				if( m_pClassIndex[count] <= 1000 ) continue ;		// Ä«¿îÆ®¿¡ ÇØ´çÇÏ´Â Å¬·¡½º ÀÎµ¦½º°¡ 1000º¸´Ù ÀÛÀ¸¸é, °è¼Ó~

				// Å¬·¡½º ÀÎµ¦½º¸¦ »ý¼ºÇÑ´Ù.
				DWORD dwLimitClass	  = m_pClassIndex[count] / 1000 ;
				DWORD dwLimitRacial	  = (m_pClassIndex[count] - (1000*dwLimitClass)) / 100 ;
				DWORD dwLimitGrade	  = (m_pClassIndex[count] - (1000*dwLimitClass) - (100*dwLimitRacial)) / 10 ;
				DWORD dwLimitJobIndex = (m_pClassIndex[count] - (1000*dwLimitClass) - (100*dwLimitRacial) - (10*dwLimitGrade)) ;

				// ½ºÅ×ÀÌÁö Á¦ÇÑÀ» ¸¸Á·ÇÏ¸é,
				if( (dwLimitClass == byClass) && (dwLimitRacial == byRacial) && (dwLimitGrade == byJobGrade) && (dwLimitJobIndex == byJobIndex) )
				{
					return TRUE ;									// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
				}
			}

			return FALSE ;											// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
		}
		break ;
	}
#endif // _MAPSERVER_

	return FALSE ;													// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
}

// Äù½ºÆ® ¸®¹ÌÆ® Ã¼Å© ÇÔ¼ö.( Å¬¶óÀÌ¾ðÆ® )
BOOL CQuestLimitKind_Stage::CheckLimit( DWORD dwQuestIdx, DWORD dwSubQuestIdx )
{
#ifndef _MAPSERVER_													// ¸Ê ¼­¹ö°¡ ¼±¾ðµÇ¾î ÀÖÁö ¾Ê´Ù¸é,

	switch(m_dwLimitKind)											// ¸®¹ÌÆ® Á¾·ù¸¦ È®ÀÎÇÑ´Ù.
	{
	case eQuestLimitKind_Stage :									// ¸®¹ÌÆ® Á¾·ù°¡ ½ºÅ×ÀÌÁö¿Í °°À¸¸é,
		{
			CHARACTER_TOTALINFO totalInfo ;							// Ä³¸¯ÅÍ ÅäÅ» Á¤º¸¸¦ ¹ÞÀ» ±¸Á¶Ã¼¸¦ ¼±¾ðÇÑ´Ù.

			memset(&totalInfo, 0, sizeof(CHARACTER_TOTALINFO)) ;	// Ä³¸¯ÅÍ ÅäÅ» Á¤º¸¸¦ ¹ÞÀ» ±¸Á¶Ã¼¸¦ ¸Þ¸ð¸® ¼ÂÇÑ´Ù.

			HERO->GetCharacterTotalInfo(&totalInfo) ;				// HEROÀÇ Ä³¸¯ÅÍ ÅäÅ» Á¤º¸¸¦ ¹Þ´Â´Ù.

			BYTE byClass    	 = totalInfo.Job[0] ;				// Å¬·¡½º °ªÀ» ¹Þ´Â´Ù.
			BYTE byRacial   	 = totalInfo.Race+1 ;				// Á¾Á· °ªÀ» ¹Þ´Â´Ù.
			BYTE byJobGrade 	 = totalInfo.JobGrade ;				// Àâ ±×·¹ÀÌµå °ªÀ» ¹Þ´Â´Ù.
			BYTE byJobIndex 	 = 0 ;								// Àâ ÀÎµ¦½º¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.

			if(byJobGrade == 1)										// Àâ ±×·¹ÀÌµå°¡ 1°ú °°À¸¸é,
			{
				byJobIndex = 1 ;									// Àâ ÀÎµ¦½º¸¦ 1·Î ¼¼ÆÃÇÑ´Ù.
			}
			else													// Àâ ±×·¹ÀÌµå°¡ 1°ú °°Áö ¾ÊÀ¸¸é,
			{
				byJobIndex = totalInfo.Job[byJobGrade-1] ;			// Àâ ÀÎµ¦½º¸¦ ¹Þ´Â´Ù.
			}

			for( BYTE count = 0 ; count < m_byCount ; ++count )		// Ä«¿îÆ® ¼ö ¸¸Å­ for¹®À» µ¹¸°´Ù.
			{
				if( m_pClassIndex[count] <= 1000 ) continue ;		// Å¬·¡½º ÀÎµ¦½º°¡ 1000 ÀÌÇÏ¶ó¸é,

				// Å¬·¡½º ÀÎµ¦½º¸¦ »ý¼ºÇÑ´Ù.
				DWORD dwLimitClass	  = m_pClassIndex[count] / 1000 ;
				DWORD dwLimitRacial	  = (m_pClassIndex[count] - (1000*dwLimitClass)) / 100 ;
				DWORD dwLimitGrade	  = (m_pClassIndex[count] - (1000*dwLimitClass) - (100*dwLimitRacial)) / 10 ;
				DWORD dwLimitJobIndex = (m_pClassIndex[count] - (1000*dwLimitClass) - (100*dwLimitRacial) - (10*dwLimitGrade)) ;

				// ½ºÅ×ÀÌÁö Á¦ÇÑÀ» ¸¸Á·ÇÏ¸é,
				if( (dwLimitClass == byClass) && (dwLimitRacial == byRacial) && (dwLimitGrade == byJobGrade) && (dwLimitJobIndex == byJobIndex) )
				{
					return TRUE ;									// TRUE¸¦ ¸®ÅÏÇÑ´Ù.
				}
			}

			return FALSE ;											// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
		}
		break ;
	}
#endif//_MAPSERVER_
	return FALSE ;													// FALSE¸¦ ¸®ÅÏÇÑ´Ù.
}
