/*********************************************************************

	 ÆÄÀÏ		: SHMonstermeterManager.cpp
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/07/08

	 ÆÄÀÏ¼³¸í	: ¸ó½ºÅÍ¹ÌÅÍ Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "SHMonstermeterManager.h"
#include "MHFile.h"
#include "ItemManager.h"
#include "Player.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// class CSHMonstermeterManager
//

CSHMonstermeterManager g_csMonstermeterManager;

// -------------------------------------------------------------------------------------------------------------------------------------
// CSHMonstermeterManager Method																								  »ý¼ºÀÚ
//
CSHMonstermeterManager::CSHMonstermeterManager()
{
	ZeroMemory(m_stReward, sizeof(m_stReward));
	LoadScriptFileData();
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHMonstermeterManager Method																								  ÆÄ±«ÀÚ
//
CSHMonstermeterManager::~CSHMonstermeterManager()
{
	for(int i=0; i<MAX_REWARD_BEHAVE_TYPE; i++)
	{
		SAFE_DELETE_ARRAY(m_stReward[i].stRewardBase);
	}
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  LoadScriptData Method																							  ½ºÅ©¸³Æ® ÆÄÀÏ ·Îµå
//
BOOL CSHMonstermeterManager::LoadScriptFileData()
{
 	char szFile[MAX_PATH];
	char szLine[MAX_PATH], szTxt[MAX_PATH];
	int	 nKind = 0;
	CMHFile fp;

	// ÃÖ´ë°³¼ö¸¦ ¾ò±â À§ÇØ Ã³À½ ÀÐ´Â ºÎºÐ
	sprintf(szFile, "./System/Resource/MonstermeterReward.bin");
	fp.Init(szFile, "rb");
	if(!fp.IsInited())
	{
		char szTmp[256];
		sprintf(szTmp, "%s ÆÄÀÏÀÌ Á¸ÀçÇÏÁö ¾Ê½À´Ï´Ù.", szFile);
		ASSERTMSG(0, szTmp);
		return FALSE;
	}

	while(TRUE)
	{
		if (fp.IsEOF()) break;
		fp.GetLine(szLine, sizeof(szLine));
		if (strstr(szLine, "//")) continue;			
		else if (strstr(szLine, "END_KIND")) 
		{
			nKind++;
			continue;
		}

		m_stReward[nKind].nNum++;
	}

	fp.Release();

	for(int i=0; i<MAX_REWARD_BEHAVE_TYPE; i++)
	{
		m_stReward[i].stRewardBase	= new stREWARD_BASE[m_stReward[i].nNum];
	}

	// µ¥ÀÌÅÍ¸¦ ÀÐ±â À§ÇØ µÎ ¹øÂ°..
	int nBehaveNum = 0, nValue[MAX_VALUE_NUM] = {0}, nRewardNum = 0;
	nKind = 0;
	fp.Init(szFile, "rb");
	if(!fp.IsInited())
	{
		return FALSE;
	}
	while(TRUE)
	{
		if (fp.IsEOF()) break;
		fp.GetLine(szLine, sizeof(szLine));
		if (strstr(szLine, "//")) continue;			
		else if (strstr(szLine, "END_KIND"))
		{
			nKind++;
			nRewardNum = 0;
			continue;
		}

		// µ¥ÀÌÅÍ ÀÐ±â
		sscanf(szLine, "%d %s %u %u", &nBehaveNum, szTxt, &nValue[0], &nValue[1]);
		if (strcmp(szTxt, "ITEM") == 0)	m_stReward[nKind].stRewardBase[nRewardNum].eRewardType = REWARD_TYPE_ITEM;
		else 
		{
			char szTmp[256];
			sprintf(szTmp, "Á¸ÀçÇÏÁö ¾Ê´Â Å°¿öµåÀÔ´Ï´Ù.(Å°¿öµå:%s, ÆÄÀÏ:%s)", szTxt, szFile);
			ASSERTMSG(0, szTmp);
		}

		m_stReward[nKind].stRewardBase[nRewardNum].nBehaveNum = nBehaveNum;
		m_stReward[nKind].stRewardBase[nRewardNum].nValue[0] = nValue[0];
		m_stReward[nKind].stRewardBase[nRewardNum].nValue[1] = nValue[1];
		nRewardNum++;
	}
	
	fp.Release();

	return TRUE;
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  ProcessReward Method																									   º¸»ó Ã³¸®
//
VOID CSHMonstermeterManager::ProcessReward(CPlayer* pPlayer, REWARD_BEHAVE_TYPE eType, int nBehaveNum)
{
	// stRewardBase[].nBehaveNum ¿¡ °ø¹è¼ö°¡ Á¸ÀçÇÒ °æ¿ì ¾ÆÀÌÅÛÀÌ Ã³À½ °Í¸¸ Áö±ÞµÇ°Å³ª, Áßº¹ Áö±ÞµÈ´Ù.(return ¿©ÇÏ¿¡ µû¶ó)
	// ±×·¡¼­ ³»¸²Â÷¼øÀ¸·Î Ã³¸®ÇÏ¿© ½ºÅ©¸³Æ®¿¡¼­ Á¦ÀÏ ¾Æ·¡ Ç×¸ñ 1°³¸¸ Áö±ÞµÇ°Ô ÇÑ´Ù.
	// µû¶ó¼­, ½ºÅ©¸³Æ®¿¡¼­ nBehaveNum À» ¼ø¼­(¿À¸§Â÷¼ø)´ë·Î ÀÛ¼ºÇØ¾ß ÇÑ´Ù.
	for(int i=m_stReward[eType].nNum-1; i>= 0; i--)
	{
		if ((nBehaveNum%m_stReward[eType].stRewardBase[i].nBehaveNum) == 0)
		{
			switch(m_stReward[eType].stRewardBase[i].eRewardType)
			{
				case REWARD_TYPE_ITEM:
					{
						CItemSlot* pSlot = pPlayer->GetSlot(eItemTable_Inventory);
						if(NULL == pSlot) ASSERTMSG(0,"¿Ã¹Ù¸¥ ¾ÆÀÌÅÛ ½½·ÔÀ» ¾òÀ» ¼ö ¾ø½À´Ï´Ù.");

						// 071211 KTH -- pPlayer Ãß°¡
						DWORD nNum = ITEMMGR->GetTotalEmptySlotNum(pSlot, pPlayer);
						if(nNum == 0)
						{
							return;
						}

						int nItemID = m_stReward[eType].stRewardBase[i].nValue[0];
						int nItemNum = m_stReward[eType].stRewardBase[i].nValue[1];

						// À¯È¿ ¾ÆÀÌÅÛÀÎ°¡?
						// ..½ºÅ©¸³Æ® µ¥ÀÌÅÍ ÆÄÀÏÀÌ³ª ±âÅ¸µîµîÀÇ ¿À·ù·Î À¯È¿ÇÏÁö ¾ÊÀº ¾ÆÀÌÅÛÀÌ¶ó¸é Ã³¸®ÇÏÁö ¾Ê´Â´Ù.
						ITEM_INFO* pstItem = ITEMMGR->GetItemInfo(nItemID);
						if (pstItem == NULL)
						{
							continue;
						}

						ITEMMGR->ObtainMonstermeterItem(pPlayer, nItemID, (WORD)nItemNum);
					}
					break;
			}
			return;
		}
	}
}

