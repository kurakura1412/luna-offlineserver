/*********************************************************************

	 ÆÄÀÏ		: SHGarden.cpp
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/04/10

	 ÆÄÀÏ¼³¸í	: ÅÔ¹ç Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#if defined( _AGENT00_ ) || defined(_MAP00_ )
//#include "math.inl"
#include "[lib]yhlibrary/HashTable.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "Common/SHMath.h"
#include "SHGarden.h"


// -------------------------------------------------------------------------------------------------------------------------------------
// CSHGarden Method																												  »ý¼ºÀÚ
//
CSHGarden::CSHGarden()
{
#ifndef _MYLUNA_
	m_pcsCrop.Initialize( 5 );
#else
	_dwcropid = 0;
#endif
	m_nEventKind = GARDEN_EVENT_CROP;
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHGarden Method																											  ÆÄ±«ÀÚ
//
CSHGarden::~CSHGarden()
{
#ifndef _MYLUNA_
	m_pcsCrop.SetPositionHead();
	for( CSHCrop* crop = 0;
		(crop = m_pcsCrop.GetData()) != NULL; )
	{
		SAFE_DELETE( crop );
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
// Create Method																										³óÀÛ¹° °ø°£ »ý¼º
//
VOID CSHGarden::Create(int nCropNum)
{
#ifdef _MYLUNA_
	_mmcrop.reserve(nCropNum);
#endif
	int i = 0;
	for( i = 0; i < nCropNum; ++i )
	{
	CSHCrop* crop = GetCrop( i );
	if( 0 == crop )
		{
#ifndef _MYLUNA_
			crop = new CSHCrop;
			m_pcsCrop.Add( crop, i );
#else
			crop = &(_mmcrop[i]);
			crop->InitME();
#endif
		}
		crop->SetID( (WORD)i );

		crop->SetParent( this );
		AddChild( crop, GARDEN_EVENT_CROP );
	}
#ifdef _MYLUNA_
	_dwcropid = i;
#endif
}
#ifdef _MYLUNA_
void CSHGarden::ReleaseME()
{
	CSHFarmObj::ReleaseME();
	for( std::unordered_map<int, CSHCrop>::iterator it = _mmcrop.begin(), itend = _mmcrop.end();
		it != itend;
		++it){
			CSHCrop& aa = it->second;
			aa.ReleaseME();
	}
	_mmcrop.clear();
	_dwcropid = 0;
}
void CSHGarden::InitME()
{
	CSHFarmObj::InitME();
	m_nEventKind = GARDEN_EVENT_CROP;
}
#endif


