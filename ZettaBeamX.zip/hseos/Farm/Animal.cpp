/*********************************************************************

	 ÆÄÀÏ		: Animal.cpp
	 ÀÛ¼ºÀÚ		: Shinobi
	 ÀÛ¼ºÀÏ		: 2008/03/08

	 ÆÄÀÏ¼³¸í	: °¡Ãà Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#ifdef _AGENT00_ 
#include "math.inl"
//#include "yhlibrary.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
//#include "protocol.h"
//#include "CommonDefine.h"
//#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
//#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif



#include "Common/SHMath.h"

#include "Animal.h"

#if defined(_AGENTSERVER)
#elif defined(_MAPSERVER_)

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif


	#include "Farm/SHFarmManager.h"
	#include "[CC]ServerModule/DataBase.h"
	#include "MapDBMsgParser.h"
#else
	#include "Farm/SHFarmManager.h"
	#include "ObjectManager.h"
	#include "GameIn.h"
	#include "MonsterGuageDlg.h"
	#include "ObjectBalloon.h"
	#include "OBalloonName.h"
	#include "ObjectGuagen.h"
#endif

DWORD CAnimal::ANIMAL_IN_STALL_TIME;															// °¡ÃàÀ» Ãà»ç¿¡ ³Ö´Â ½Ã°£(ºÐ)
DWORD CAnimal::ANIMAL_LIFE_DECREASE_TIME;														// °¡ÃàÀÇ »ý¸í·Â -1 ½Ã°£
DWORD CAnimal::ANIMAL_RETRY_TIME;																// °¡ÃàÀ» Ãà»ç¿¡ ´Ù½Ã ¼ÒÈ¯ÇÏ´Â µ¥ ÇÊ¿äÇÑ ½Ã°£ (ºÐ)
DWORD CAnimal::ANIMAL_FEED_TIME;																// °¡Ãà¿¡°Ô ¸ÔÀÌ¸¦ ÁÖ´Â ½Ã°£
DWORD CAnimal::ANIMAL_FEED_DELAY_TIME;															// °¡Ãà¿¡°Ô ´Ù½Ã ¸ÔÀÌ¸¦ ÁÖ´Âµ¥ ÇÊ¿äÇÑ ½Ã°£
DWORD CAnimal::ANIMAL_CLEANING_TIME;															// °¡ÃàÀ» ¾Ä±â´Â´ë ¼Ò¿äµÇ´Â ½Ã°£ (ºÐ)
DWORD CAnimal::ANIMAL_CLEANING_RETRY_TIME;														// °¡ÃàÀ» ´Ù½Ã ¾Ä±â´Â´ë °É¸®´Â ½Ã°£ (ºÐ)
DWORD CAnimal::ANIMAL_DIE_DELAY_TIME = 24*60;													// °¡ÃàÀÇ »ý¸í·ÂÀÌ 0ÀÌ µÈ ÈÄ Á×±â±îÁöÀÇ µô·¹ÀÌ ½Ã°£ (ºÐ)
DWORD CAnimal::ANIMAL_STALL_REWARD_TIME;														// °¡Ãà¿¡°Ô ¾ÆÀÌÅÛÀ» ¾ò´Â´ë °É¸®´Â ½Ã°£ (ºÐ)
DWORD CAnimal::ANIMAL_CONTENTMENT_DECREASE_TIME;												// °¡ÃàÀÇ ¸¸Á·µµ°¡ -1 µÇ´Â ½Ã°£
DWORD CAnimal::ANIMAL_INTEREST_DECREASE_TIME;													// °¡ÃàÀÇ °ü½Éµµ°¡ -1 µÇ´Â ½Ã°£

UINT CAnimal::ANIMAL_STEP_MIN_LIFE[8][2] = {0,};
UINT CAnimal::ANIMAL_STEP_MAX_LIFE = 4;
UINT CAnimal::ANIMAL_STEP_MAX_CONTENTMENT = 100;
UINT CAnimal::ANIMAL_STEP_MAX_INTEREST = 100;
//UINT CAnimal::ANIMAL_BREED_PROBA[5][ANIMAL_BREED_KIND_MAX+2] = {0,};
UINT		ANIMAL_REWARD_LIST[CAnimal::ANIMAL_KIND_MAX] = {0,};
UINT CAnimal::ANIMAL_STEP_FEED_LIFE[ANIMAL_FEED_KIND_MAX][2] = {0,};
UINT CAnimal::ANIMAL_STEP_CLEANING_LIFE[ANIMAL_CLEANER_KIND_MAX][2] = {0,};
char CAnimal::ANIMAL_NAME_TBL[ANIMAL_KIND_MAX][256];

//----------------------------------------------------------------------------------------------------------------------------------------
// CAnimal Method																													»ý¼ºÀÚ
//
CAnimal::CAnimal()
{
	SetAnimal(ANIMAL_RESULT_DIE);
}

//----------------------------------------------------------------------------------------------------------------------------------------
// ~CAnimal Method																													ÆÄ±«ÀÚ
//
CAnimal::~CAnimal()
{
}
//----------------------------------------------------------------------------------------------------------------------------------------
// MainLoop Method																										Ãà»ç ¸ÞÀÎ ·çÆ¾ Ã³¸®
//
VOID CAnimal::MainLoop()
{
	CSHFarmObj::MainLoop();
#if defined(_AGENTSERVER)
#elif defined(_MAPSERVER_)
	if(m_nContentment > 0)
	{
		// 091211 pdy ´ÙÀÚ¶õ °¡ÃàÀÌ »èÁ¦µÇÁö ¾Ê´Â ¹®Á¦ ¼öÁ¤
		if( m_eStep == ANIMAL_STEP_COMPLETE )
		{
			if (m_nDieDelayTimeTick)
			{
				if (gCurTime - m_nDieDelayTimeTick > SHMath_MINUTE(1))
				{
					m_nDieDelayTimeTick = gCurTime;
					m_nDieDelayTime++;

					if (m_nDieDelayTime >= ANIMAL_DIE_DELAY_TIME)	
					{
						CPen* pAnimalCage = (CPen*)GetParent();
						CSHFarm* pFarm = (CSHFarm*)(pAnimalCage ? pAnimalCage->GetParent() : 0 );

						if( pFarm )
						{
							InsertLogFarmAnimal(pFarm, this, eLog_FamilyFarmDieAnimal);
						}

						AddEvent(0, ANIMAL_RESULT_DIE);
						SetAnimal(ANIMAL_RESULT_DIE);
					}
				}
			}
			else
			{
				m_nDieDelayTimeTick = gCurTime ;
				m_nDieDelayTime = 0;
			}
		}
		else
		{
			// »ý¸í·Â(±âÁ¸¸¸Á·µµ) ½Ã°£ Ã¼Å©
			if( m_nContentment > 0 && gCurTime - m_nContentmentTimeTick > ANIMAL_CONTENTMENT_DECREASE_TIME )
			{
				m_nContentmentTimeTick = gCurTime;
				m_nBreedTimeTick = gCurTime;
				m_nContentment--;

				AddEvent(0, ANIMAL_RESULT_CONTENTMENT);

				if(m_nContentment <= 0)
				{
					CPen* pAnimalCage = (CPen*)GetParent();
					CSHFarm* pFarm = (CSHFarm*)(pAnimalCage ? pAnimalCage->GetParent() : 0 );

					if( pFarm )
					{
						InsertLogFarmAnimal(pFarm, this, eLog_FamilyFarmDieAnimal);
					}

					AddEvent(0, ANIMAL_RESULT_DIE);
					SetAnimal(ANIMAL_RESULT_DIE);
				}
			}
			// µî±Þµµ(±âÁ¸°ü½Éµµ) ½Ã°£ Ã¼Å©
			if( m_nInterest > 0 && gCurTime - m_nInterestTimeTick > ANIMAL_INTEREST_DECREASE_TIME )
			{
				m_nInterestTimeTick = gCurTime;
				m_nInterest--;

				if( m_nInterest < 0 )
					m_nInterest = 0;

				AddEvent(0, ANIMAL_RESULT_INTEREST);
			}
			// ¼öÈ®Ä«¿îÆ®(±âÁ¸»ý¸í·Â) °¨¼Ò ½Ã°£ Ã¼Å©
			if( m_nLife > 0 && (gCurTime - m_nHavestTimeTick > ANIMAL_LIFE_DECREASE_TIME) )
			{
				m_nHavestTimeTick = gCurTime;
				m_nLife--;

				// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â À§ÇÑ ¼³Á¤
				AddEvent(0, ANIMAL_RESULT_LIFE);

				if(m_nLife == 0)
				{
					SetAnimal(ANIMAL_RESULT_COMPLETE);
					AddEvent(0, ANIMAL_RESULT_COMPLETE);
				}
			}
		}
	}
	else
	{
		// µô·¹ÀÌ Å¸ÀÓ ¾øÀ½
/*		CPen*		pPen		= (CPen*)GetParent();
		CSHFarm*	pFarm		= (CSHFarm*)(pPen ? pPen->GetParent() : 0 );

		if( pFarm )
		{
			// ·Î±× Ãß°¡ ÇÏ¿©¾ßÇÔ.
			//InsertLogFarmAnimal(farm, this, eLog_FamolyFarmDieAnimal);
		}

		// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â À§ÇÑ ¼³Á¤
		AddEvent(NULL, ANIMAL_RESULT_DIE);
		SetAnimal(ANIMAL_RESULT_DIE);

		return;*/
	}
#else
	// Å¬¶óÀÌ¾ðÆ®¿¡¼­´Â °¡ÃàÀ» Ãà»ç ³Ö´Â ¿¬ÃâÀ» À§ÇØ Ã³À½ StepÀÌ ANIMAL_STEP_1ÀÌ ¾Æ´Ï±â ¶§¹®¿¡ µô·¹ÀÌ Å¸ÀÓ ÈÄ¿¡ Àû¿ë
if( m_nContentment > 0 )
	{
		if( m_eStep == ANIMAL_STEP_IN_STALL )
		{
			// °¡ÃàÀ» Ãà»ç¿¡ ³Ö´Â ÁßÀÏ ¶§ °ÔÀÌÁö Ç¥½Ã¸¦ À§ÇØ...
			CMonsterGuageDlg* pGuageDlg = GAMEIN->GetMonsterGuageDlg();
			if( pGuageDlg )
			{
				if( (CObject*)m_pcsParent->GetRenderObjEx(GetID()+5) == OBJECTMGR->GetSelectedObject())
				{
					pGuageDlg->SetMonsterLife(gCurTime-GetBreedTimeTick(), CAnimal::ANIMAL_IN_STALL_TIME);
				}
			}
			// ³Ö´Â ¸ð¼Ç ³¡
			if( gCurTime - m_nBreedTimeTick > ANIMAL_IN_STALL_TIME )
			{
				m_eStep = ANIMAL_STEP_1;
				AddEvent(NULL, ANIMAL_RESULT_IN_STALL);
			}
		}
		// ¼öÈ® ¸ð¼Ç ½Ã°£ << Á¶°ÇÀ» Ãß°¡ ÇØ¾ßÇÔ. ÇöÀç ¾ÆÀÌÅÛ ¼öÈ®ÀÌ °¡´ÉÇÑÁö Ã¼Å© ÇÏ´Â ºÎºÐÀÌ ÇÊ¿äÇÔ.
		else if(m_nLife==0 && m_eStep == ANIMAL_STEP_COMPLETE)
		{
			if( m_nBreedTimeTick )
			{
				if( gCurTime - m_nBreedTimeTick > ANIMAL_STALL_REWARD_TIME )
				{
					m_nBreedTimeTick = NULL;
					// ¼öÈ® ¸ð¼Ç ³¡
					AddEvent(NULL, ANIMAL_RESULT_REWARD);
				}
			}
		}
		else
		{
			// °¡Ãà¿¡ »ç·á¸¦ ÁÖ°í ÀÖ´Â ½Ã°£
			if( GetFeedTimeTick() )
			{
				CMonsterGuageDlg* pGuageDlg = GAMEIN->GetMonsterGuageDlg();

				if( gCurTime - GetFeedTimeTick() > CAnimal::ANIMAL_FEED_TIME )
				{
					if( pGuageDlg )
					{
						if( (CObject*)GetRenderObj() == OBJECTMGR->GetSelectedObject() )
						{
							pGuageDlg->SetMonsterLife(GetContentment(), 100);
						}
					}
					SetFeedTimeTick(NULL);
					AddEvent(NULL, ANIMAL_RESULT_FEEDING);
				}
				else
				{
					if( pGuageDlg )
					{
						if( (CObject*)GetRenderObj() == OBJECTMGR->GetSelectedObject() )
						{
							int nDelta = ((GetContentment()-m_nBeforeContentment)*(gCurTime-GetFeedTimeTick())<<8)/CAnimal::ANIMAL_FEED_TIME;
							pGuageDlg->SetMonsterLife((m_nBeforeContentment<<8)+nDelta, 100<<8);
						}
					}
				}
			}
			// Ãà»ç Ã»¼Ò¸¦ ÇÏ°í ÀÖ´Â ½Ã°£
		}
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
// Breed Method																													Ãà»ç ÇÏ±â
//
VOID CAnimal::Breed(int nPlayerID, int nAnimalCageGrade, int nKind)
{
	m_nOwnerID = nPlayerID;
	// Å¬¶óÀÌ¾ðÆ®¿¡¼­´Â Ãà»ç¿¡ ³Ö´Â ¿¬ÃâÀ» À§ÇØ StepÀ» ´Ù¸£°Ô ÇÑ´Ù. ´ÜÁö Å¬¶óÀÌ¾ðÆ®»óÀÇ ¿¬ÃâÀ» À§ÇÔÀÏ »ÓÀÓ
#if defined(_MAPSERVER_)
	m_eStep = ANIMAL_STEP_1;
#else
	m_eStep = ANIMAL_STEP_IN_STALL;
#endif
	//CPen*		pPen		= (CPen*)GetParent();
	m_nKind = nKind;
	m_nBreedTimeTick = 0;
	m_nContentmentTimeTick = gCurTime;
	m_nInterestTimeTick = gCurTime;
	m_nGrade = 0;
	m_nLife = (WORD)ANIMAL_STEP_MAX_LIFE;
	m_nHavestTimeTick = gCurTime;
	m_nContentment	= (WORD)ANIMAL_STEP_MIN_LIFE[nAnimalCageGrade-1][0];
	m_nInterest		= (WORD)ANIMAL_STEP_MIN_LIFE[nAnimalCageGrade-1][1];
	//m_nLife = GetLifeFromTbl( ((CPen*)GetParent())->GetGrade() );
}

// -------------------------------------------------------------------------------------------------------------------------------------
// Feed Method																													»ç·á ÁÖ±â
//
VOID CAnimal::Feed(int nGrade)
{
	int nPlusContentment = GetFeedContentmentFromTbl(nGrade);
	int nPlusInterest = GetFeedInterestFromTbl(nGrade);

	m_nBeforeContentment = m_nContentment;
	m_nBeforeInterest = m_nInterest;

	m_nContentment = (WORD)(m_nContentment + nPlusContentment);
	m_nInterest = (WORD)(m_nInterest + nPlusInterest);

	if( m_nContentment > 100 )
	{
		m_nContentment = 100;
	}

	if( m_nInterest > 100 )
	{
		m_nInterest = 100;
	}

	AddEvent(0, ANIMAL_RESULT_CONTENTMENT);
	AddEvent(0, ANIMAL_RESULT_INTEREST);

}

// ---------------------------------------------------------------------------------------------------------------------------------------
// GetItem Method																												¾ÆÀÌÅÛ ¾ò±â
//
//CAnimal::ANIMAL_BREED_KIND	CAnimal::Reward()
//{
	// °¡Ãà¿¡¼­ ¾ÆÀÌÅÛ ¾ò±â
	// °¡ÃàµéÀÇ »ý¸í·É¿¡ µû¸¥ ¾ÆÀÌÅÛ È®·ü
//	int nRandom = CSHMath::GetRandomNum(1, 100);
	//int nTbaItemIndex = ANIMAL_BREED_KIND_GREAT;
	//int nCheckNum = sizeof(ANIMAL_BREED_PROBA)/sizeof(ANIMAL_BREED_PROBA[0]);
	//for( int i = 0; i < nCheckNum; i++ )
	//{
	//	if( GetLife() >= ANIMAL_BREED_PROBA[i][0] && GetLife() <= ANIMAL_BREED_PROBA[i][1] )
	//	{
	//		nTbaItemIndex = i;
	//		break;
	//	}
	//}

	//// Ãà»çÀÇ µî±Þ¿¡ µû¸¥ Áõ°¨ È®·ü
	//int nProba = 0;
	//int nItemKind = ANIMAL_BREED_KIND_NORMAL;
	//for(int i=0; i < ANIMAL_BREED_KIND_MAX; i++)
	//{
	//	nProba += ANIMAL_BREED_PROBA[nTbaItemIndex][2+i]+ANIMAL_BREED_DELTA_PROBA[m_pcsParent->GetGrade()-1][i];
	//	if (nRandom < nProba)
	//	{
	//		nItemKind = i;
	//		break;
	//	}
	//}

	//// Àú±Þ »ç·á¸¦ »ç¿ëÇÑ ÀûÀÌ ÀÖÀ¸¸é
	//if( GetFeedFreq(ANIMAL_FEED_KIND_GRADE_1) )
	//{
	//	if( nItemKind == ANIMAL_BREED_KIND_GREAT ||
	//		nItemKind == ANIMAL_BREED_KIND_GOOD )
	//	{
	//		nItemKind = ANIMAL_BREED_KIND_NORMAL;
	//	}
	//}
	//// Áß±Þ »ç·á¸¦ »ç¿ëÇÑ ÀûÀÌ ÀÖÀ¸¸é
	//else if( GetFeedFreq(ANIMAL_FEED_KIND_GRADE_2) )
	//{
	//	if( nItemKind == ANIMAL_BREED_KIND_GREAT )
	//	{
	//		nItemKind = ANIMAL_BREED_KIND_GOOD;
	//	}
	//}

	//return (ANIMAL_BREED_KIND)nItemKind;
	//return (ANIMAL_BREED_KIND)1;
//}

// -------------------------------------------------------------------------------------------------------------------------------------
// Plant Method																													°¡Ãà ¼³Á¤
//
VOID CAnimal::SetAnimal(ANIMAL_RESULT eResult)
{
	switch(eResult)
	{
	case ANIMAL_RESULT_DIE:
		m_nOwnerID = 0;
		m_nKind = 0;
		m_nGrade = 0;
		m_eStep = ANIMAL_STEP_EMPTY;
		m_nLife = 0;
		m_nBreedTimeTick = 0;
		m_nFeedTimeTick = 0;
		m_nNextStepTime = 0;
		m_nBeforeLife = 0;
		m_nContentment = 0;
		m_nInterest = 0;
		m_nDieDelayTimeTick = 0;				
		m_nDieDelayTime = 0;	
		break;
	case ANIMAL_RESULT_COMPLETE:
		m_eStep = ANIMAL_STEP_COMPLETE;
		m_nBreedTimeTick = 0;
		m_nDieDelayTimeTick = 0;				
		m_nDieDelayTime = 0;	
		break;
	}
}

// -------------------------------------------------------------------------------------------------------------------------------------
// GetMaxLifeFromTbl Method																				°¡Ãà ÃÖ´ë »ý¸í·Â ¾ò±â (Å×ÀÌºí¿¡¼­)
//
WORD CAnimal::GetMaxLife()
{
	return (WORD)ANIMAL_STEP_MAX_LIFE;
}
// -------------------------------------------------------------------------------------------------------------------------------------
// GetMaxLifeFromTbl Method																			  »ç·á »ç¿ë »ý¸í·Â ¾ò±â (Å×ÀÌºí¿¡¼­)
//
WORD CAnimal::GetFeedLifeFromTbl(int nGrade)
{
	WORD nReturn = 0; //ANIMAL_STEP_FEED_LIFE[nGrade];

	return nReturn;
}

WORD CAnimal::GetFeedContentmentFromTbl(int nGrade)
{
	return (WORD)ANIMAL_STEP_FEED_LIFE[nGrade][0];;
}

WORD CAnimal::GetFeedInterestFromTbl(int nGrade)
{
	return (WORD)ANIMAL_STEP_FEED_LIFE[nGrade][1];
}

VOID CAnimal::Cleaning(int nGrade)
{
	//int nPlusContentment = GetFeedContentmentFromTbl(nGrade);
	//int nPlusInterest = GetFeedInterestFromTbl(nGrade);
	int nPlusContentment = ANIMAL_STEP_CLEANING_LIFE[nGrade-1][0];
	int nPlusInterest = ANIMAL_STEP_CLEANING_LIFE[nGrade-1][1];

	m_nBeforeContentment = m_nContentment;
	m_nBeforeInterest = m_nInterest;

	m_nContentment = (WORD)(m_nContentment + nPlusContentment);
	m_nInterest = (WORD)(m_nInterest + nPlusInterest);

	if( m_nContentment > 100 )
	{
		m_nContentment = 100;
	}

	if( m_nInterest > 100 )
	{
		m_nInterest = 100;
	}

	AddEvent(0, ANIMAL_RESULT_CONTENTMENT);
	AddEvent(0, ANIMAL_RESULT_INTEREST);

	if( m_nContentment == 100 && m_nInterest > 10 )
	{
		SetAnimal(ANIMAL_RESULT_COMPLETE);
		AddEvent(0, ANIMAL_RESULT_COMPLETE);
	}
}

WORD CAnimal::GetGrade()
{
	if( m_nInterest >= 10 && m_nInterest < 20 )
		return 0;
	else if( m_nInterest < 29 )
		return 1;
	else if( m_nInterest >= 29 )
		return 2;

	return 0;
}

void CAnimal::InitME()
{
	CSHFarmObj::InitME();
	SetAnimal(ANIMAL_RESULT_DIE);
}