/*********************************************************************

	 ÆÄÀÏ		: SHFarm.cpp
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/04/10

	 ÆÄÀÏ¼³¸í	: ³óÀå Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#if defined( _AGENT00_ ) || defined(_MAP00_ )
//#include "math.inl"
#include "[lib]yhlibrary/HashTable.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "Common/SHMath.h"
 
#include "SHFarm.h"
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// class CSHFarm
//

// -------------------------------------------------------------------------------------------------------------------------------------
// CSHFarm Method																												  »ý¼ºÀÚ
//
CSHFarm::CSHFarm()
{
#ifndef _MYLUNA_
	// 090629 LUJ, ÇØ½¬ Å×ÀÌºí·Î ±³Ã¼
	m_pcsGarden.Initialize( 1 );
	m_pcsFence.Initialize( 1 );
	m_pcsAnimalCage.Initialize( 1 );
	m_pcsHouse.Initialize( 1 );
	m_pcsWarehouse.Initialize( 1 );
#endif
	m_nEventKind = FARM_EVENT_GARDEN;
	m_bRendering = FALSE;
	SetTaxArrearageFreq(0);
	SetTaxPayPlayerName(0);
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHFarm Method																												  ÆÄ±«ÀÚ
//
CSHFarm::~CSHFarm()
{
#ifndef _MYLUNA_
	Release();
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
// Init Method																													  ÃÊ±âÈ­
//
VOID CSHFarm::Init()
{
	SetOwnState(CSHFarmObj::OWN_STATE_EMPTY);
	SetOwner(0);
	SetGrade(0);
	GetGarden(0)->SetGrade(0);
	GetHouse(0)->SetGrade(0);
	GetWarehouse(0)->SetGrade(0);
	GetAnimalCage(0)->SetGrade(0);
	GetFence(0)->SetGrade(0);
	SetTaxArrearageFreq(0);
	SetTaxPayPlayerName(0);
}

void CSHFarm::CreateGarden( int gardenSize, int cropSize )
{
#ifdef _MYLUNA_
	_mmGarden.reserve(gardenSize);
#endif
	int i = 0;
	for( i = 0; i < gardenSize; ++i )
	{
		CSHGarden* garden = GetGarden( i );

		if( 0 == garden )
		{
#ifdef _MYLUNA_
			garden = &(_mmGarden[i]);
			garden->InitME();
#else
			garden = new CSHGarden;
			m_pcsGarden.Add( garden, i );
#endif
		}

		garden->SetID((WORD)i);
		garden->SetParent(this);
		garden->Create( cropSize );
		AddChild(garden,FARM_EVENT_GARDEN );
	}
#ifdef _MYLUNA_
	_dwGarden = i;
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
// CreateFence Method																									ÇÏÀ§ ±¸¼º¹° »ý¼º
//
VOID CSHFarm::CreateFence(int nFenceNum)
{
#ifdef _MYLUNA_
	_mmFence.reserve(nFenceNum);
#endif
	int i = 0;
	for( i = 0; i < nFenceNum; ++i )
	{
		CSHFarmObj* farmObject = GetFence( i );

		if( 0 == farmObject )
		{
#ifdef _MYLUNA_
			farmObject = &(_mmFence[i]);
			farmObject->InitME();
#else
			farmObject = new CSHFarmObj;
			m_pcsFence.Add( farmObject, i );
#endif
		}
		farmObject->SetID((WORD)i);
		farmObject->SetParent(this);
		AddChild(
			farmObject,
			FARM_EVENT_FENCE );
	}
#ifdef _MYLUNA_
	_dwFence = i;
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
// CreateAnimalCage Method																								ÇÏÀ§ ±¸¼º¹° »ý¼º
//
VOID CSHFarm::CreateAnimalCage(int nAnimalCageNum, int animalSize )
{
#ifdef _MYLUNA_
	_mmAnimalCage.reserve(nAnimalCageNum);
#endif
	int i = 0;
	for( i = 0; i < nAnimalCageNum; ++i )
	{
		CPen* pen = GetAnimalCage( i );

		if( 0 == pen )
		{
#ifdef _MYLUNA_
			pen = &(_mmAnimalCage[i]);
			pen->InitME();
#else
			pen = new CPen;
			m_pcsAnimalCage.Add( pen, i );
#endif
		}

		pen->SetID((WORD)i);
		pen->SetParent(this);
		pen->Create( animalSize );
		AddChild(
			pen,
			FARM_EVENT_ANIMALCAGE );
	}
#ifdef _MYLUNA_
	_dwAnimalCage = i;
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
// CreateHouse Method																									ÇÏÀ§ ±¸¼º¹° »ý¼º
//
VOID CSHFarm::CreateHouse(int nHouseNum)
{
#ifdef _MYLUNA_
	_mmHouse.reserve(nHouseNum);
#endif
	int i = 0;
	for( i = 0; i < nHouseNum; ++i )
	{
		CSHFarmObj* farmObject = GetHouse( i );

		if( 0 == farmObject )
		{
#ifdef _MYLUNA_
			farmObject = &(_mmHouse[i]);
			farmObject->InitME();
#else
			farmObject = new CSHFarmObj;
			m_pcsHouse.Add( farmObject, i );
#endif
		}
		
		farmObject->SetID( (WORD)i );
		farmObject->SetParent( this );
		AddChild(
			farmObject,
			FARM_EVENT_HOUSE );
	}
#ifdef _MYLUNA_
	_dwHouse = i;
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
// CreateWarehouse Method																								ÇÏÀ§ ±¸¼º¹° »ý¼º
//
VOID CSHFarm::CreateWarehouse(int nWarehouseNum)
{
#ifdef _MYLUNA_
	_mmWarehouse.reserve(nWarehouseNum);
#endif
	int i = 0;
	for( i = 0; i < nWarehouseNum; ++i )
	{
		CSHFarmObj* farmObject = GetWarehouse( i );

		if( 0 == farmObject )
		{
#ifdef _MYLUNA_
			farmObject = &(_mmWarehouse[i]);
			farmObject->InitME();
#else
			farmObject = new CSHFarmObj;
			m_pcsWarehouse.Add( farmObject, i );
#endif
		}

		farmObject->SetID( (WORD)i );
		farmObject->SetParent( this );
		AddChild(farmObject,FARM_EVENT_WAREHOUSE );
	}
#ifdef _MYLUNA_
	_dwWarehouse = i;
#endif
}

void CSHFarm::Release()
{
	// 090629 LUJ, Á¤¿ø »èÁ¦
	m_pcsGarden.SetPositionHead();
	CSHGarden* garden = NULL;
	while( (garden = m_pcsGarden.GetData()) != NULL )
	{
		SAFE_DELETE( garden );
	}
	m_pcsGarden.RemoveAll();

	// 090629 LUJ, ¿ïÅ¸¸® »èÁ¦
	m_pcsFence.SetPositionHead();
	CSHFarmObj* farmObject = m_pcsFence.GetData();
	while( (farmObject = m_pcsFence.GetData()) != NULL )
	{
		SAFE_DELETE( farmObject );
	}
	m_pcsFence.RemoveAll();

	// 090629 LUJ, °¡Ãà ¿ì¸® »èÁ¦
	m_pcsAnimalCage.SetPositionHead();
	CPen* pen = NULL;
	while( (pen = m_pcsAnimalCage.GetData()) != NULL )
	{
		SAFE_DELETE( pen );
	}
	m_pcsAnimalCage.RemoveAll();

	// 090629 LUJ, Áý »èÁ¦
	m_pcsHouse.SetPositionHead();
	farmObject = NULL;
	while( (farmObject = m_pcsHouse.GetData()) != NULL )
	{
		SAFE_DELETE( farmObject );
	}
	m_pcsHouse.RemoveAll();

	// 090629 LUJ, Ã¢°í »èÁ¦
	m_pcsWarehouse.SetPositionHead();
	farmObject = NULL;
	while( (farmObject = m_pcsWarehouse.GetData()) != NULL )
	{
		SAFE_DELETE( farmObject );
	}
	m_pcsWarehouse.RemoveAll();
}

VOID CSHFarm::SetTaxPayPlayerName(char* pszName)
{
	if( pszName == nullptr){
		ZeroMemory(m_szTaxPayPlayerName, sizeof(m_szTaxPayPlayerName));
	} else {
		SafeStrCpy(m_szTaxPayPlayerName, pszName, MAX_NAME_LENGTH+1);
	}
	//pszName == NULL ? ZeroMemory(m_szTaxPayPlayerName, sizeof(m_szTaxPayPlayerName)) : SafeStrCpy(m_szTaxPayPlayerName, pszName, MAX_NAME_LENGTH+1);
}
#ifdef _MYLUNA_
CSHGarden* CSHFarm::GetGarden(int nGardenID)
{
	if( _mmGarden.find(nGardenID) != _mmGarden.end()) return &(_mmGarden.at(nGardenID));
	else return NULL;
}
int CSHFarm::GetGardenNum()
{
	return _mmGarden.size();
}
CSHFarmObj* CSHFarm::GetFence(int nFenceID)
{
	if( _mmFence.find(nFenceID) != _mmFence.end()) return &(_mmFence.at(nFenceID));
	else return NULL;
}
int CSHFarm::GetFenceNum()
{
	return _mmFence.size();
}
CPen* CSHFarm::GetAnimalCage(int nAnimalCageID)
{
	if( _mmAnimalCage.find(nAnimalCageID) != _mmAnimalCage.end()) return &(_mmAnimalCage.at(nAnimalCageID));
	else return NULL;
}
int CSHFarm::GetAnimalCageNum()
{
	return _mmAnimalCage.size();
}
CSHFarmObj* CSHFarm::GetHouse(int nHouseID)
{
	if( _mmHouse.find(nHouseID) != _mmHouse.end()) return &(_mmHouse.at(nHouseID));
	else return NULL;
}
int CSHFarm::GetHouseNum()
{
	return _mmHouse.size();
}
CSHFarmObj* CSHFarm::GetWarehouse(int nWarehouseID)
{
	if( _mmWarehouse.find(nWarehouseID) != _mmWarehouse.end()) return &(_mmWarehouse.at(nWarehouseID));
	else return NULL;
}
int CSHFarm::GetWarehouseNum()
{
	return _mmWarehouse.size();
}
void CSHFarm::ReleaseME()
{
	CSHFarmObj::ReleaseME();
	for( std::unordered_map<int, CSHGarden >::iterator it=_mmGarden.begin(), 
	itend=_mmGarden.end();
	it != itend;
	++it){
		CSHGarden& aa = it->second;
		aa.ReleaseME();
	}
	_mmGarden.clear();
	_dwGarden=0;
	for( std::unordered_map<int, CSHFarmObj >::iterator it=_mmFence.begin(), 
	itend=_mmFence.end();
	it != itend;
	++it){
		CSHFarmObj& aa = it->second;
		aa.ReleaseME();	}
	_mmFence.clear();
	_dwFence=0;
	for( std::unordered_map<int, CPen >::iterator it=_mmAnimalCage.begin(), 
	itend=_mmAnimalCage.end();
	it != itend;
	++it){
		CPen& aa = it->second;
		aa.ReleaseME();	}
	_mmAnimalCage.clear();
	_dwAnimalCage=0;
	for( std::unordered_map<int, CSHFarmObj >::iterator it=_mmHouse.begin(), 
	itend=_mmHouse.end();
	it != itend;
	++it){
		CSHFarmObj& aa = it->second;
		aa.ReleaseME();	}
	_mmHouse.clear();
	_dwHouse=0;
	for( std::unordered_map<int, CSHFarmObj >::iterator it=_mmWarehouse.begin(), 
	itend=_mmWarehouse.end();
	it != itend;
	++it){
		CSHFarmObj& aa = it->second;
		aa.ReleaseME();	}
	_mmWarehouse.clear();
	_dwWarehouse=0;
}
void CSHFarm::InitME()
{
	CSHFarmObj::InitME();
	_dwGarden=0;
	_dwFence=0;
	_dwAnimalCage=0;
	_dwHouse=0;
	_dwWarehouse=0;
	m_nEventKind = FARM_EVENT_GARDEN;
	m_bRendering = FALSE;
	SetTaxArrearageFreq(0);
	SetTaxPayPlayerName(0);
	Init();
}


#endif


