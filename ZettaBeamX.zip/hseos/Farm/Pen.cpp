/*********************************************************************

	 ÆÄÀÏ		: Pen.cpp
	 ÀÛ¼ºÀÚ		: Shinobi
	 ÀÛ¼ºÀÏ		: 2008/03/11

	 ÆÄÀÏ¼³¸í	: Ãà»ç Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#if defined( _AGENT00_ ) || defined( _MAP00_)
#include <unordered_map>
#include "math.inl"
#include "[lib]yhlibrary/HashTable.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
//#include "protocol.h"
//#include "CommonDefine.h"
//#include "CommonGameDefine.h"
//#include "ServerGameDefine.h"
//#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "Common/SHMath.h"
#include "Pen.h"


// -------------------------------------------------------------------------------------------------------------------------------------
// CPen Method																												  »ý¼ºÀÚ
//
CPen::CPen()
{
#ifndef _MYLUNA_
	m_pcsAnimal.Initialize( 5 );
#endif
	m_nEventKind = GARDEN_EVENT_ANIMAL;
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CPen Method																											  ÆÄ±«ÀÚ
//
CPen::~CPen()
{
#ifndef _MYLUNA_
	m_pcsAnimal.SetPositionHead();
	CAnimal* animal = NULL;
	while( (animal = m_pcsAnimal.GetData()) != NULL )
	{
		SAFE_DELETE( animal );
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
// Create Method																										³óÀÛ¹° °ø°£ »ý¼º
//
VOID CPen::Create(int nAnimalNum)
{
#ifdef _MYLUNA_
	_mmAnimal.reserve(nAnimalNum);
#endif
	for(int i=0; i<nAnimalNum; i++)
	{
		CAnimal* animal = GetAnimal( i );

		if( 0 == animal )
		{
#ifdef _MYLUNA_
			animal = &(_mmAnimal[i]);
			animal->InitME();
#else
			animal = new CAnimal;
			m_pcsAnimal.Add( animal, i );
#endif
		}

		animal->SetID((WORD)i);
		animal->SetParent(this);
		AddChild( animal, GARDEN_EVENT_ANIMAL );
	}
}

#ifdef _MYLUNA_
void CPen::ReleaseME()
{
	CSHFarmObj::ReleaseME();
	for(std::unordered_map<int, CAnimal>::iterator it=_mmAnimal.begin(),
	itend = _mmAnimal.end();
	it != itend;
	++it){
		CAnimal& aa = it->second;
	 aa.ReleaseME();}
	_mmAnimal.clear();
}
void CPen::InitME()
{
	CSHFarmObj::InitME();
	m_nEventKind = GARDEN_EVENT_ANIMAL;
}
#endif