/*********************************************************************

	 ÆÄÀÏ		: SHCrop.cpp
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/04/10

	 ÆÄÀÏ¼³¸í	: ³óÀÛ¹° Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#ifdef _AGENT00_ 
#include "math.inl"
#include "yhlibrary.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#ifdef _MAP00_

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#endif

#include "Common/SHMath.h"

#include "SHCrop.h"

#if defined(_AGENTSERVER)
#elif defined(_MAPSERVER_)
	#include "Farm/SHFarmManager.h"
	#include "[CC]ServerModule/DataBase.h"
	// 071220 LUJ
	#include "MapDBMsgParser.h"
#else
	#include "Farm/SHFarmManager.h"
	#include "ObjectManager.h"
	#include "GameIn.h"
	#include "MonsterGuageDlg.h"
	#include "ObjectBalloon.h"
	#include "OBalloonName.h"
	#include "ObjectGuagen.h"
#endif

DWORD	CSHCrop::CROP_LIFE_DECREASE_TIME;														// ³óÀÛ¹° »ý¸í·Â -1 ½Ã°£
DWORD	CSHCrop::CROP_PLANT_SEEDING_TIME;														// ³óÀÛ¹°À» ½É°í ½ÏÀÌ ³ª¿À´Âµ¥ °É¸®´Â ½Ã°£
DWORD	CSHCrop::CROP_PLANT_RETRY_TIME;															// ³óÀÛ¹°À» ´Ù½Ã ½É´Â µ¥ ÇÊ¿äÇÑ ½Ã°£ (ºÐ)
DWORD	CSHCrop::CROP_MANURE_TIME;																// ³óÀÛ¹°¿¡ ºñ·á¸¦ ÁÖ´Â ½Ã°£
DWORD	CSHCrop::CROP_MANURE_RETRY_TIME;														// ³óÀÛ¹°¿¡ ´Ù½Ã ºñ·á¸¦ ÁÖ´Â µ¥ ÇÊ¿äÇÑ ½Ã°£ (ÃÊ)
DWORD	CSHCrop::CROP_HARVEST_TIME;																// ³óÀÛ¹°ÀÇ ¼öÈ® ¿äÃ» ÈÄ ¼öÈ®ÇÏ´Âµ¥ °É¸®´Â ½Ã°£
DWORD	CSHCrop::CROP_DIE_DELAY_TIME = 24*60;													// »ý¸í·ÂÀÌ 1ÀÌ µÈ ÈÄ Á×±â±îÁöÀÇ µô·¹ÀÌ ½Ã°£ (ºÐ)

UINT	CSHCrop::CROP_NEXT_STEP_TIME[CROP_SEED_GRADE_MAX][CROP_STEP_MAX-1] = {0,};				// ´ÙÀ½ ´Ü°è°¡ µÇ±â À§ÇØ ÇÊ¿äÇÑ ½Ã°£ (ºÐ)
UINT	CSHCrop::CROP_STEP_MIN_LIFE[CROP_SEED_GRADE_MAX][CROP_STEP_MAX-1] = {0,};				// ´Ü°è¿¡ µû¸¥ ÃÖ¼Ò/ÃÖ´ë »ý¸í·Â
UINT	CSHCrop::CROP_STEP_MAX_LIFE[CROP_SEED_GRADE_MAX][CROP_STEP_MAX-1] = {0,};				// ´Ü°è¿¡ µû¸¥ ÃÖ¼Ò/ÃÖ´ë »ý¸í·Â
UINT	CSHCrop::CROP_STEP_MANURE_MIN_LIFE[CROP_SEED_GRADE_MAX][CROP_MANURE_KIND_MAX] = {0,};	// ºñ·á¿¡ µû¸¥ Áõ°¡ »ý¸í·Â
UINT	CSHCrop::CROP_STEP_MANURE_MAX_LIFE[CROP_SEED_GRADE_MAX][CROP_MANURE_KIND_MAX] = {0,};	// ºñ·á¿¡ µû¸¥ Áõ°¡ »ý¸í·Â

UINT	CSHCrop::CROP_HARVEST_PROBA[5][CROP_HARVEST_KIND_MAX+2] = {0,};							// ³óÀÛ¹° »ý¸í·Â¿¡ µû¸¥ ¼öÈ® È®·ü
UINT	CSHCrop::CROP_HARVEST_DELTA_PROBA[CROP_SEED_GRADE_MAX][CROP_HARVEST_KIND_MAX] = {0,};	// ÅÔ¹ç µî±Þ¿¡ µû¸¥ ¼öÈ® Áõ°¨ È®·ü

// -------------------------------------------------------------------------------------------------------------------------------------
// CSHCrop Method																												  »ý¼ºÀÚ
//
CSHCrop::CSHCrop()
{
	SetCrop(CROP_RESULT_DIE);
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHCrop Method																												 ÆÄ±«ÀÚ
//
CSHCrop::~CSHCrop()
{
}

// -------------------------------------------------------------------------------------------------------------------------------------
// MainLoop Method																									 ÅÔ¹ç ¸ÞÀÎ ·çÆ¾ Ã³¸®
//
VOID CSHCrop::MainLoop()
{
  	CSHFarmObj::MainLoop();
#if defined(_AGENTSERVER)
#elif defined(_MAPSERVER_)
//	if (g_csFarmManager.GetFarmZone(0) == NULL) return;

 	if (m_nLife > 0)
	{
		// 091211 pdy ´ÙÀÚ¶õ ³óÀÛ¹°ÀÌ »èÁ¦°¡ ¾ÈµÇ´Â ¹®Á¦ ¼öÁ¤ 
		if (m_eStep == CROP_STEP_COMPLETE)
		{
			if (m_nDieDelayTimeTick)
			{
				if (gCurTime - m_nDieDelayTimeTick > SHMath_MINUTE(1))
				{
					m_nDieDelayTimeTick = gCurTime;
					m_nDieDelayTime++;

					if (m_nDieDelayTime >= CROP_DIE_DELAY_TIME)
					{
						// 071218 LUJ,	·Î±×. ³óÀÛ¹°Àº Á¤¿ø(SHGarden)¿¡ ¼ÓÇØÀÖ°í, Á¤¿øÀº ³óÀå(CSHFarm)¿¡ ¼ÓÇØÀÖ´Ù
						{
							CSHGarden*	garden	= ( CSHGarden* )GetParent();
							CSHFarm*	farm	= ( CSHFarm* )( garden ? garden->GetParent() : 0 );

							if( farm )
							{
								InsertLogFarmCrop( farm, this, eLog_FamilyFarmDieCrop );
							}
						}
						
						m_nLife = 0;
						// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â À§ÇÑ ¼³Á¤
 						AddEvent(0, CROP_RESULT_DIE);
						SetCrop(CROP_RESULT_DIE);
					}
				}
			}
			else
			{
				m_nDieDelayTimeTick = gCurTime ;
				m_nDieDelayTime = 0;
			}
		}
		else
		{
			// »ý¸í·ÂÀÌ 1 ÀÌ¸é Á×±â±îÁöÀÇ µô·¹ÀÌ ½Ã°£À» Ã¼Å©ÇØ¼­ Á×À½ Ã³¸®¸¦ ÇÑ´Ù.
			if (m_nLife == 1)
			{
				if (m_nDieDelayTimeTick)
				{
					if (gCurTime - m_nDieDelayTimeTick > SHMath_MINUTE(1))
					{
						m_nDieDelayTimeTick = gCurTime;
						m_nDieDelayTime++;

						// 091211 pdy º¸Åë´Ü°èÀÇ ÀÛ¹° »èÁ¦½Ã°£ÀÌ 24½Ã°£À¸·Î ¼³Á¤µÇ¾îÀÖ´ø ¹ö±× ¼öÁ¤ 
						if (m_nDieDelayTime >= (CROP_LIFE_DECREASE_TIME/60000))	
						{
							// 071218 LUJ,	·Î±×. ³óÀÛ¹°Àº Á¤¿ø(SHGarden)¿¡ ¼ÓÇØÀÖ°í, Á¤¿øÀº ³óÀå(CSHFarm)¿¡ ¼ÓÇØÀÖ´Ù
							{
								CSHGarden*	garden	= ( CSHGarden* )GetParent();
								CSHFarm*	farm	= ( CSHFarm* )( garden ? garden->GetParent() : 0 );

								if( farm )
								{
									InsertLogFarmCrop( farm, this, eLog_FamilyFarmDieCrop );
								}
							}
							
							m_nLife = 0;
							// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â À§ÇÑ ¼³Á¤
 							AddEvent(0, CROP_RESULT_DIE);
							SetCrop(CROP_RESULT_DIE);
						}
					}
					return;
				}
			}

			// »ý¸í·Â °¨¼Ò ½Ã°£ Ã¼Å©
			if (gCurTime - m_nPlantTimeTick > CROP_LIFE_DECREASE_TIME)
			{
				m_nPlantTimeTick = gCurTime;
				m_nLife--;
				// »ý¸í·ÂÀÌ ´ÙÇÔ
				if (m_nLife == 0)
				{
					m_nLife = 1;
					// Á×±â ±îÁöÀÇ µô·¹ÀÌ½Ã°£ ¼³Á¤
					m_nDieDelayTimeTick = gCurTime;
					m_nDieDelayTime = 0;
					// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â À§ÇÑ ¼³Á¤
 					AddEvent(0, CROP_RESULT_LIFE);
					return;
				}
				else
				{
					// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â À§ÇÑ ¼³Á¤
 					AddEvent(0, CROP_RESULT_LIFE);
				}
			}

			//  ´Ü°è »ó½Â Ã³¸®
			if (gCurTime - m_nNextStepTimeTick > SHMath_MINUTE(1))
			{
				m_nNextStepTimeTick = gCurTime;
				m_nNextStepTime++;
				if (m_nNextStepTime >= GetNextStepTimeTickFromTbl(m_nSeedGrade, m_eStep))
				{
					int nTmpStep = m_eStep + 1;

					// ¼ºÀå ¿Ï·á
					if (nTmpStep >= CROP_STEP_COMPLETE)
					{
						// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â À§ÇÑ ¼³Á¤
						AddEvent(0, CROP_RESULT_STEP_UP_COMPLETE);
						SetCrop(CROP_RESULT_STEP_UP_COMPLETE);
					}
					else
					{
						// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â À§ÇÑ ¼³Á¤
						AddEvent(0, CROP_RESULT_STEP_UP);
						SetCrop(CROP_RESULT_STEP_UP);
					}
				}
				else
				{
					AddEvent(0, CROP_RESULT_NEXT_STEP_TIME);
				}
			}
		}
	}
#else
	// Å¬¶óÀÌ¾ðÆ®¿¡¼­´Â ½É´Â ¿¬ÃâÀ» À§ÇØ Ã³À½ StepÀÌ CROP_STEP_1ÀÌ ¾Æ´Ï±â ¶§¹®¿¡ µô·¹ÀÌ Å¸ÀÓ ÈÄ¿¡ Àû¿ë
   	if (m_nLife > 0)
	{
 		if (m_eStep == CROP_STEP_SEEDING)
		{
			// ³óÀÛ¹°À» ½É´Â ÁßÀÏ ¶§ °ÔÀÌÁö Ç¥½Ã¸¦ À§ÇØ..
			CMonsterGuageDlg* pGuageDlg = GAMEIN->GetMonsterGuageDlg() ;
			if (pGuageDlg)
			{
				if ((CObject*)m_pcsParent->GetRenderObjEx(GetID()+15) == OBJECTMGR->GetSelectedObject())
				{
					pGuageDlg->SetMonsterLife(gCurTime-GetPlantTimeTick(), CSHCrop::CROP_PLANT_SEEDING_TIME);
				}
			}
			// ½É´Â ¸ð¼Ç ³¡
			if (gCurTime - m_nPlantTimeTick > CROP_PLANT_SEEDING_TIME)
			{
				m_eStep = CROP_STEP_1;
				AddEvent(NULL, CROP_RESULT_PLANT);
			}
		}
		// ¼öÈ® ¸ð¼Ç ½Ã°£
		else if (m_eStep == CROP_STEP_COMPLETE)
		{
			if (m_nPlantTimeTick)
			{
				if (gCurTime - m_nPlantTimeTick > CROP_HARVEST_TIME)
				{
					m_nPlantTimeTick = NULL;
					// ¼öÈ® ¸ð¼Ç ³¡
					AddEvent(NULL, CROP_RESULT_HARVEST);
				}
			}
		}
		else
		{
 			// ³óÀÛ¹°¿¡ ºñ·á¸¦ ÁÖ°í ÀÖ´Â ½Ã°£
   			if (GetManureTimeTick())
			{
				CMonsterGuageDlg* pGuageDlg = GAMEIN->GetMonsterGuageDlg() ;

				if (gCurTime - GetManureTimeTick() > CSHCrop::CROP_MANURE_TIME)
				{
					if (pGuageDlg)
					{
						if ((CObject*)GetRenderObj() == OBJECTMGR->GetSelectedObject())
						{
							pGuageDlg->SetMonsterLife(GetLife(), GetMaxLife());
						}
					}
					SetManureTimeTick(NULL);
					AddEvent(NULL, CROP_RESULT_MANURE);
				}
				else
				{
					if (pGuageDlg)
					{
						if ((CObject*)GetRenderObj() == OBJECTMGR->GetSelectedObject())
						{
							int nDelta = ((GetLife()-GetBeforeLife())*(gCurTime - GetManureTimeTick())<<8)/CSHCrop::CROP_MANURE_TIME;
							pGuageDlg->SetMonsterLife((GetBeforeLife()<<8)+nDelta, GetMaxLife()<<8);
						}
					}
				}
			}
		}
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
// Plant Method																												 ³óÀÛ¹° ½É±â
//
VOID CSHCrop::Plant(int nPlayerID, int nSeedGrade, int nKind)
{
	m_nOwnerID = nPlayerID;
	// Å¬¶óÀÌ¾ðÆ®¿¡¼­´Â ½É´Â ¿¬ÃâÀ» À§ÇØ Step ¸¦ ´Ù¸£°Ô ÇÑ´Ù. ´ÜÁö Å¬¶óÀÌ¾ðÆ®»óÀÇ ¿¬ÃâÀ» À§ÇÔÀÏ »Ó
#if defined(_MAPSERVER_)
	m_eStep = CROP_STEP_1;
#else
	m_eStep = CROP_STEP_SEEDING;
#endif
	m_nKind = nKind;
	m_nPlantTimeTick = gCurTime;
	m_nSeedGrade = nSeedGrade;
	m_nNextStepTimeTick = gCurTime;
	m_nLife = GetLifeFromTbl(m_nSeedGrade, m_eStep);
}

// -------------------------------------------------------------------------------------------------------------------------------------
// Manure Method																											   ºñ·á ÁÖ±â
//
VOID CSHCrop::Manure(int nManureGrade, int nManureKind)
{
	int nPlusLife = GetManureLifeFromTbl(nManureGrade, nManureKind);

	m_nBeforeLife = m_nLife;
	m_nLife = m_nLife + (WORD)nPlusLife;

	int nMaxLife = GetMaxLifeFromTbl(m_nSeedGrade, m_eStep);
	if (m_nLife > nMaxLife)
	{
		m_nLife = (WORD)nMaxLife;
	}

	m_nManureFreq[nManureKind-1]++;

	m_nDieDelayTimeTick = 0;
	m_nDieDelayTime = 0;
}

// -------------------------------------------------------------------------------------------------------------------------------------
// Harvest Method																												¼öÈ®ÇÏ±â
//
CSHCrop::CROP_HARVEST_KIND CSHCrop::Harvest()
{
	// ³óÀÛ¹° ¼öÈ®ÇÏ±â
	// ..³óÀÛ¹°ÀÇ »ý¸í·Â¿¡ µû¸¥ ¼öÈ® È®·ü
	int nRandom = CSHMath::GetRandomNum(1, 100);
	int nTbaHarvestIndex = CROP_HARVEST_KIND_GREAT;
	int nCheckNum = sizeof(CROP_HARVEST_PROBA)/sizeof(CROP_HARVEST_PROBA[0]);
	for(int i=0; i<nCheckNum; i++)
	{
		if ( GetLife() >= CROP_HARVEST_PROBA[i][0] && GetLife() <= CROP_HARVEST_PROBA[i][1])
		{
			nTbaHarvestIndex = i;
			break;
		}
	}

	// ..ÅÔ¹çÀÇ µî±Þ¿¡ µû¸¥ Áõ°¨ È®·ü
	int nProba = 0;
	int nHarvestKind = CROP_HARVEST_KIND_NORMAL;
	for(int i=0; i<CROP_HARVEST_KIND_MAX; i++)
	{
		nProba += CROP_HARVEST_PROBA[nTbaHarvestIndex][2+i]+CROP_HARVEST_DELTA_PROBA[m_pcsParent->GetGrade()-1][i];
		if (nRandom < nProba)
		{
			nHarvestKind = i;
			break;
		}
	}

	// Àú±Þ ºñ·á¸¦ »ç¿ëÇÑ ÀûÀÌ ÀÖÀ¸¸é ´ëÇ³,Ç³ÀÛ -> ÆòÀÛ
	if (GetManureFreq(CROP_MANURE_KIND_GRADE1))
	{
		if (nHarvestKind == CROP_HARVEST_KIND_GREAT || 
			nHarvestKind == CROP_HARVEST_KIND_GOOD)
		{
			nHarvestKind = CROP_HARVEST_KIND_NORMAL;
		}
	}
	// Áß±Þ ºñ·á¸¦ »ç¿ëÇÑ ÀûÀÌ ÀÖÀ¸¸é ´ëÇ³ -> Ç³ÀÛ
	else if (GetManureFreq(CROP_MANURE_KIND_GRADE2))
	{
		if (nHarvestKind == CROP_HARVEST_KIND_GREAT)
		{
			nHarvestKind = CROP_HARVEST_KIND_GOOD;
		}
	}

	return (CROP_HARVEST_KIND)nHarvestKind;
}

// -------------------------------------------------------------------------------------------------------------------------------------
// Plant Method																												 ³óÀÛ¹° ¼³Á¤
//
VOID CSHCrop::SetCrop(CROP_RESULT eResult)
{
	switch(eResult)
	{
	case CROP_RESULT_DIE:
		m_nOwnerID = 0;
		m_nKind = 0;			
		m_nSeedGrade = 0;			
		m_eStep = CROP_STEP_EMPTY;				
		m_nLife = 0;				
		m_nPlantTimeTick = 0;		
		m_nManureTimeTick = 0;
		m_nNextStepTimeTick = gCurTime;	
		m_nNextStepTime = 0;
		m_nBeforeLife = 0;
		m_nDieDelayTimeTick = 0;
		m_nDieDelayTime = 0;
		ZeroMemory(m_nManureFreq, sizeof(m_nManureFreq));
		break;
	case CROP_RESULT_STEP_UP:
		m_nPlantTimeTick = 0;		
		m_nManureTimeTick = 0;
		m_nNextStepTimeTick = gCurTime;	
		m_nNextStepTime = 0;
		m_nDieDelayTimeTick = 0;
		m_nDieDelayTime = 0;
		m_eStep = (CROP_STEP)((int)m_eStep + 1);
		m_nLife = GetLife();						// 100623 ONS ÀÛ¹°ÁøÈ­½Ã ÇöÀç»ý¸íÄ¡¸¦ À¯ÁöÇÑ´Ù.
		break;
	case CROP_RESULT_STEP_UP_COMPLETE:
		m_nPlantTimeTick = 0;		
		m_nManureTimeTick = 0;
		m_nDieDelayTimeTick = 0;
		m_nDieDelayTime = 0;
		m_nNextStepTimeTick = gCurTime;	
		m_eStep = (CROP_STEP)((int)m_eStep + 1);
		break;
	}
}

// -------------------------------------------------------------------------------------------------------------------------------------
// GetNextStepTimeTick Method																³óÀÛ¹° ´ÙÀ½ ´Ü°è ÇÊ¿ä ½Ã°£ ¾ò±â (Å×ÀÌºí¿¡¼­)
//
WORD CSHCrop::GetNextStepTimeTickFromTbl(int nSeedGrade, CROP_STEP eCurStep)
{
	if (eCurStep < CROP_STEP_1) eCurStep = CROP_STEP_1;
	else if (eCurStep == CROP_STEP_COMPLETE) eCurStep = (CROP_STEP)(CROP_STEP_COMPLETE-1);

	return (WORD)CROP_NEXT_STEP_TIME[nSeedGrade-1][eCurStep-CROP_STEP_1];
}

// -------------------------------------------------------------------------------------------------------------------------------------
// GetLifeFromTbl Method																				 ³óÀÛ¹° »ý¸í·Â ¾ò±â (Å×ÀÌºí¿¡¼­)
//
WORD CSHCrop::GetLifeFromTbl(int nSeedGrade, CROP_STEP eCurStep)
{
	if (eCurStep < CROP_STEP_1) eCurStep = CROP_STEP_1;
	else if (eCurStep == CROP_STEP_COMPLETE) eCurStep = (CROP_STEP)(CROP_STEP_COMPLETE-1);

	return (WORD)CROP_STEP_MIN_LIFE[nSeedGrade-1][eCurStep-CROP_STEP_1];
}

// -------------------------------------------------------------------------------------------------------------------------------------
// GetMaxLifeFromTbl Method																			³óÀÛ¹° ÃÖ´ë »ý¸í·Â ¾ò±â (Å×ÀÌºí¿¡¼­)
//
WORD CSHCrop::GetMaxLifeFromTbl(int nSeedGrade, CROP_STEP eCurStep)
{
	if (eCurStep < CROP_STEP_1) eCurStep = CROP_STEP_1;
	else if (eCurStep == CROP_STEP_COMPLETE) eCurStep = (CROP_STEP)(CROP_STEP_COMPLETE-1);

	return (WORD)CROP_STEP_MAX_LIFE[nSeedGrade-1][eCurStep-CROP_STEP_1];
}

// -------------------------------------------------------------------------------------------------------------------------------------
// GetMaxLifeFromTbl Method																			  ºñ·á »ç¿ë »ý¸í·Â ¾ò±â (Å×ÀÌºí¿¡¼­)
//
WORD CSHCrop::GetManureLifeFromTbl(int nGrade, int nKind)
{
	int nReturn = CSHMath::GetRandomNum(CROP_STEP_MANURE_MIN_LIFE[nGrade-1][nKind-1], CROP_STEP_MANURE_MAX_LIFE[nGrade-1][nKind-1]);

	return (WORD)nReturn;
}

void	CSHCrop::InitME()
{
	CSHFarmObj::InitME();
	SetCrop(CROP_RESULT_DIE);
}