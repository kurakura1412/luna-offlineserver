/*********************************************************************

	 ÆÄÀÏ		: SHFarmZone.cpp
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/04/10

	 ÆÄÀÏ¼³¸í	: ³óÀå Áö¿ª Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#if defined( _AGENT00_ ) || defined(_MAP00_ )
//#include "math.inl"
#include "[lib]yhlibrary/HashTable.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "Common/SHMath.h"
#include "SHFarmZone.h"


// -------------------------------------------------------------------------------------------------------------------------------------
// CSHFarmZone Method																											  »ý¼ºÀÚ
//
CSHFarmZone::CSHFarmZone(FARM_ZONE eBelongZone, int nMapID, int nFarmNum)
{
	m_csFarm.Initialize( 10 );

	for( int i = 0; i < nFarmNum; ++i )
	{
		CSHFarm* farm = new CSHFarm;
		farm->SetID( (WORD)i );
		farm->SetParent( this );
		AddChild(
			farm,
			FARM_ZONE_EVENT_FARM );
		m_csFarm.Add( farm, i );
	}
	m_eBelongZone = eBelongZone;
	m_nMapID = nMapID;
	m_nEventKind = FARM_ZONE_EVENT_FARM;
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHFarmZone Method																											  ÆÄ±«ÀÚ
//
CSHFarmZone::~CSHFarmZone()
{
#ifndef _MYLUNA_
	m_csFarm.SetPositionHead();
	CSHFarm* farm = NULL;
	while( (farm = m_csFarm.GetData()) != NULL )
	{
		SAFE_DELETE( farm );
	}
#endif
}

int CSHFarmZone::GetFarmNum( DWORD objectIndex )
{
	DWORD ownedFarmCount = 0;

	m_csFarm.SetPositionHead();
	CSHFarm* farm = NULL;
	while( (farm = m_csFarm.GetData()) != NULL )
	{
		if( farm->GetOwner() == objectIndex )
		{
			++ownedFarmCount;
		}
	}

	return ownedFarmCount;
}

#ifdef _MYLUNA_
CSHFarmZone::CSHFarmZone()
{
	m_eBelongZone = FARM_ZONE::FARM_ZONE_ALKER;
	m_nMapID = 0;
}

void CSHFarmZone::ReleaseME()
{
	CSHFarmObj::ReleaseME();
	std::unordered_map<int, CSHFarm>::iterator it, itend;
	for(it = _mmFarm.begin(), itend = _mmFarm.end();
		it != itend;
		++it){ 
			CSHFarm& aa = it->second;
			aa.ReleaseME();
	}
	_mmFarm.clear();
}
void CSHFarmZone::InitME(FARM_ZONE eBelongZone, int nMapID, int nFarmNum)
{
	CSHFarmObj::InitME();
	m_eBelongZone = eBelongZone;
	m_nMapID = nMapID;
	_mmFarm.reserve(nFarmNum);
	for( int i = 0; i < nFarmNum; ++i )
	{
		//CSHFarm* farm = new CSHFarm;
		CSHFarm* farm = &(_mmFarm[i]);
		
		farm->SetID( (WORD)i );
		farm->SetParent( this );
		AddChild(
			farm,
			FARM_ZONE_EVENT_FARM );
		m_csFarm.Add( farm, i );
	}
	m_eBelongZone = eBelongZone;
	m_nMapID = nMapID;
	m_nEventKind = FARM_ZONE_EVENT_FARM;
}
#endif

