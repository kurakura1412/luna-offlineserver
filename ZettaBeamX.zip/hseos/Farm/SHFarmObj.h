#ifndef __SHFARMOBJ_H__INCLUDED
#define __SHFARMOBJ_H__INCLUDED
/*********************************************************************

	 ÆÄÀÏ		: SHFarmObj.h
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/04/18

	 ÆÄÀÏ¼³¸í	: ³óÀå ±âº» ¹°Ã¼ Å¬·¡½ºÀÇ Çì´õ

 *********************************************************************/

#pragma once

#ifdef _MYLUNA_
#include "math.inl"
#endif

#ifdef _CLIENT_
#include "SHFarmRenderObj.h"
#endif
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
//
class CSHFarmObj
{
public:
	//----------------------------------------------------------------------------------------------------------------
	static const int	MAX_CHILD_NUM					= 256;		// ÃÖ´ë ÀÚ½Ä °³¼ö

	//----------------------------------------------------------------------------------------------------------------
	enum OWN_STATE													// ¼ÒÀ¯ »óÅÂ						
	{
		OWN_STATE_EMPTY = 0,										// ..ºñ¾î ÀÖ´Â »óÅÂ										
		OWN_STATE_OWNED,											// ..´©±º°¡°¡ ¼ÒÀ¯ÇÏ°í ÀÖ´Â »óÅÂ
		OWN_STATE_MAX = 100000,										// ..³¡
	};

	//----------------------------------------------------------------------------------------------------------------
	enum GRADE														// µî±Þ
	{
		GRADE_1 = 1,												 
		GRADE_2,
		GRADE_3,
		GRADE_4,
		GRADE_5,
		GRADE_6,
		GRADE_7,
		GRADE_8,
		MAX_GRADE = GRADE_8,
	};

	//----------------------------------------------------------------------------------------------------------------
	struct stEVENT													// ¹ß»ýÇÑ ÀÌº¥Æ®
	{
		DWORD nOwnerID;												// ..¼ÒÀ¯ÀÚ
		WORD nEvent[256];											// ..ÀÌº¥Æ®
		WORD nEventNum;												// ..ÀÌº¥Æ® °³¼ö
	};

protected:
	//----------------------------------------------------------------------------------------------------------------
	CSHFarmObj*						m_pcsParent;					// ºÎ¸ð
	CSHFarmObj*						m_pcsChild[MAX_CHILD_NUM];		// ÀÚ½Ä
	WORD							m_nChildNum;					// ÀÚ½Ä °³¼ö

	//----------------------------------------------------------------------------------------------------------------
	WORD							m_nID;							// ID

	DWORD							m_nOwnerID;						// ¼ÒÀ¯ÀÚ
	OWN_STATE						m_eOwnState;					// ¼ÒÀ¯»óÅÂ
	WORD							m_nLife;						// ¼ö¸í
	WORD							m_nGrade;						// µî±Þ

	VECTOR3							m_stPos;						// ÁÂÇ¥
	float							m_nDir;							// ¹æÇâ

	//----------------------------------------------------------------------------------------------------------------
	stEVENT							m_stEvent;						// ÀÌº¥Æ®
	WORD							m_nEventKind;					// ÀÌº¥Æ® Á¾·ù

	//----------------------------------------------------------------------------------------------------------------
#ifdef _CLIENT_
	CSHFarmRenderObj*				m_pcsRenderObj;					// È­¸éÃâ·Â ¿ÀºêÁ§Æ®.
	CSHFarmRenderObj*				m_ppcsRenderObjEx[30];			// È­¸éÃâ·Â È®Àå ¿ÀºêÁ§Æ®.
#endif
public:
	//----------------------------------------------------------------------------------------------------------------
	CSHFarmObj();
	// 090629 LUJ, ÆÄ»ý Å¬·¡½ºÀÇ ¼Ò¸êÀÚ°¡ È£ÃâµÇµµ·Ï ¼öÁ¤
	virtual ~CSHFarmObj();
	//								ºÎ¸ð ¼³Á¤
	VOID							SetParent(CSHFarmObj* pcsParent)	{ m_pcsParent = pcsParent; }
	//								ºÎ¸ð ¾ò±â
	CSHFarmObj*						GetParent()							{ return m_pcsParent; }

	//----------------------------------------------------------------------------------------------------------------
	//								ÀÚ½Ä ¼³Á¤
	VOID							AddChild(CSHFarmObj* pcsChild, int nParentEvent = 0)	
									{ 
										m_pcsChild[m_nChildNum] = pcsChild;
										m_pcsChild[m_nChildNum]->SetEventKind((WORD)nParentEvent);
										m_nChildNum++;
										if (m_nChildNum >= MAX_CHILD_NUM)
										{
											m_nChildNum = MAX_CHILD_NUM-1;
											#if defined(_DEBUG)
												MessageBox(NULL, "Overflow : CSHFarmObj::MAX_CHILD_NUM", NULL, NULL);
											#endif
										}
									}

	//----------------------------------------------------------------------------------------------------------------
	//								ID ¼³Á¤
	VOID							SetID(WORD nID)						{ m_nID = nID; }
	//								ID ¾ò±â
	WORD							GetID()								{ return m_nID; }

	//----------------------------------------------------------------------------------------------------------------
	//								¼ÒÀ¯ÀÚ ¼³Á¤
	VOID							SetOwner(DWORD nOwnerID)			{ m_nOwnerID = nOwnerID; }
	//								¼ÒÀ¯ÀÚ ¾ò±â
	DWORD							GetOwner()							{ return m_nOwnerID; }

	//----------------------------------------------------------------------------------------------------------------
	//								¼ÒÀ¯ »óÅÂ ¼³Á¤
	VOID							SetOwnState(OWN_STATE eOwnState)	{ m_eOwnState = eOwnState; }
	//								¼ÒÀ¯ »óÅÂ ¾ò±â
	OWN_STATE						GetOwnState()						{ return m_eOwnState; }

	//----------------------------------------------------------------------------------------------------------------
	//								¼ö¸í ¼³Á¤
	VOID							SetLife(WORD nLife)					{ m_nLife = nLife; }
	//								¼ö¸í ¾ò±â
	WORD							GetLife()							{ return m_nLife; }

	//----------------------------------------------------------------------------------------------------------------
	//								µî±Þ ¼³Á¤
	VOID							SetGrade(WORD nGrade)				{ m_nGrade = nGrade; }
	//								µî±Þ ¾ò±â
	WORD							GetGrade()							{ return m_nGrade; }

	//----------------------------------------------------------------------------------------------------------------
	//								ÁÂÇ¥ ¼³Á¤
	VOID							SetPos(VECTOR3* pPos)				{ m_stPos = *pPos; }
	//								ÁÂÇ¥ ¾ò±â
	VECTOR3*						GetPos()							{ return &m_stPos; }

	//----------------------------------------------------------------------------------------------------------------
	//								¹æÇâ ¼³Á¤
	VOID							SetDir(float nDir)					{ m_nDir = nDir; }
	//								¹æÇâ ¾ò±â
	float							GetDir()							{ return m_nDir; }

	//----------------------------------------------------------------------------------------------------------------
	//								ÀÌº¥Æ® ÃÊ±âÈ­
	VOID							InitEvent()
									{
										ZeroMemory(&m_stEvent, sizeof(m_stEvent));
									}
	//								ÀÌº¥Æ® Ãß°¡
	VOID							AddEvent(DWORD nOwnerID, WORD nEvent)
									{
										m_stEvent.nOwnerID = m_nOwnerID;
										m_stEvent.nEvent[m_stEvent.nEventNum] = nEvent;
										m_stEvent.nEventNum++;
									}
	//								ÀÌº¥Æ® ¾ò±â
	stEVENT*						GetEvent()							{ return &m_stEvent; }
	//								ÀÌº¥Æ® Á¾·ù ¼³Á¤
	VOID							SetEventKind(WORD nEventKind)		{ m_nEventKind = nEventKind; }
	//								ÀÌº¥Æ® Á¾·ù ¾ò±â
	WORD							GetEventKind()						{ return m_nEventKind; }
#ifdef _CLIENT_
	//----------------------------------------------------------------------------------------------------------------
	//								È­¸é Ãâ·Â ¿ÀºêÁ§Æ® ¼³Á¤
	VOID							SetRenderObj(CSHFarmRenderObj* pObj)				{ m_pcsRenderObj = pObj; }
	VOID							SetRenderObjEx(CSHFarmRenderObj* pObj, int nID)		{ m_ppcsRenderObjEx[nID] = pObj; }
	//								È­¸é Ãâ·Â ¿ÀºêÁ§Æ® ¾ò±â
	CSHFarmRenderObj*				GetRenderObj()										{ return m_pcsRenderObj; }
	CSHFarmRenderObj*				GetRenderObjEx(int nID)								{ return m_ppcsRenderObjEx[nID]; }
#endif
	//----------------------------------------------------------------------------------------------------------------
	//								¸ÞÀÎ ·çÇÁ
	virtual VOID					MainLoop();

public:
	virtual void ReleaseME();
	virtual void InitME();

};
#endif // __SHFARMOBJ_H__INCLUDED
