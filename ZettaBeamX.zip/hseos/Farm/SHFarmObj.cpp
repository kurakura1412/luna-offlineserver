/*********************************************************************

	 ÆÄÀÏ		: SHFarmObj.cpp
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/04/18

	 ÆÄÀÏ¼³¸í	: ³óÀå ±âº» ¹°Ã¼ Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#ifdef _AGENT00_ 
#include "math.inl"
//#include "yhlibrary.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
//#include "protocol.h"
//#include "CommonDefine.h"
//#include "CommonGameDefine.h"
//#include "ServerGameDefine.h"
//#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "SHMain.h"
#include "SHFarmObj.h"

// -------------------------------------------------------------------------------------------------------------------------------------
// CSHFarmObj Method																											  »ý¼ºÀÚ
//
CSHFarmObj::CSHFarmObj()
{
	m_pcsParent = NULL;
	ZeroMemory(m_pcsChild, sizeof(m_pcsChild));
	m_nChildNum = 0;
	m_nID = 0;
	m_nOwnerID = 0;
	m_eOwnState = OWN_STATE_EMPTY;
	m_nLife = 0;
	m_nGrade = 0;
	ZeroMemory(&m_stEvent, sizeof(m_stEvent));
	m_nEventKind = 0;
#ifdef _CLIENT_
	m_pcsRenderObj = NULL;
	ZeroMemory(m_ppcsRenderObjEx,	sizeof(m_ppcsRenderObjEx));
#endif
	m_nDir = 0.0f;
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHFarmObj Method																											  ÆÄ±«ÀÚ
//
CSHFarmObj::~CSHFarmObj()
{
#ifdef _CLIENT_
	if (m_pcsRenderObj)
	{
		m_pcsRenderObj->Release();
	} 

	int nCnt = sizeof(m_ppcsRenderObjEx)/sizeof(m_ppcsRenderObjEx[0]);
	for(int i=0; i<nCnt; i++)
	{
		if (m_ppcsRenderObjEx[i])
		{
			m_ppcsRenderObjEx[i]->Release();
		}
	}
#endif
}

VOID CSHFarmObj::MainLoop()
{
	if (m_pcsChild)
	{
		for(int i=0; i<m_nChildNum; i++)
		{
			m_pcsChild[i]->MainLoop();
		}
	}
}

void CSHFarmObj::ReleaseME()
{
#ifdef _CLIENT_
	if (m_pcsRenderObj)
	{
		m_pcsRenderObj->Release();
	} 

	int nCnt = sizeof(m_ppcsRenderObjEx)/sizeof(m_ppcsRenderObjEx[0]);
	for(int i=0; i<nCnt; i++)
	{
		if (m_ppcsRenderObjEx[i])
		{
			m_ppcsRenderObjEx[i]->Release();
		}
	}
#endif
}
void CSHFarmObj::InitME()
{
	m_pcsParent = NULL;
	ZeroMemory(m_pcsChild, sizeof(m_pcsChild));
	m_nChildNum = 0;
	m_nID = 0;
	m_nOwnerID = 0;
	m_eOwnState = OWN_STATE_EMPTY;
	m_nLife = 0;
	m_nGrade = 0;
	ZeroMemory(&m_stEvent, sizeof(m_stEvent));
	m_nEventKind = 0;
#ifdef _CLIENT_
	m_pcsRenderObj = NULL;
	ZeroMemory(m_ppcsRenderObjEx,	sizeof(m_ppcsRenderObjEx));
#endif
	m_nDir = 0.0f;
}