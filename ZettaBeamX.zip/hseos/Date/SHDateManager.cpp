#include "stdafx.h"

#ifdef _AGENT00_ 
//#include "math.inl"
#include "yhlibrary.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
#include "ServerGameStruct.h"
#include "CommonGameFunc.h"
#include "ServerSystem.h"
#endif

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
#include "ServerSystem.h"
#endif

#include "MHFile.h"
#include "SHDateManager.h"

#if defined(_AGENTSERVER)
	#include "Network.h"
	#include "[CC]ServerModule/DataBase.h"
	#include "[CC]ServerModule/Console.h"
	#include "AgentDBMsgParser.h"
	#include "AgentNetworkMsgParser.h"
#elif defined(_MAPSERVER_)
	#include "UserTable.h"
	#include "Player.h"
	#include "PackedData.h"
	#include "Network.h"
	#include "[CC]Header/GameResourceManager.h"
	#include "[CC]ServerModule/DataBase.h"
	#include "MapDBMsgParser.h"
	#include "Party.h"
	#include "PartyManager.h"
	#include "MHTimeManager.h"
	#include "RecallManager.h"
#else
	#include "Player.h"
	#include "ChatManager.h"
	#include "GameIn.h"
	#include "ObjectManager.h"
	#include "WindowIDEnum.h"
	#include "cMsgBox.h"
	#include "interface/cWindowManager.h"
	#include "ResidentRegist/SHResidentRegistManager.h"
	#include "PartyManager.h"
	#include "DateMatchingDlg.h"
	#include "mhMap.h"
	#include "cStatic.h"
	#include "SHChallengeZoneClearNo1Dlg.h"
	#include "SHChallengeZoneListDlg.h"
#endif
#include "..\[CC]ServerModule\Console.h"

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// class CSHDateManager
//
CSHDateManager g_csDateManager;


UINT	CSHDateManager::NOTICE_HEART_MATCHING_POING = 0;						// ÇÏÆ® ¾Ë¸®¹Ì ¸ÅÄª Æ÷ÀÎÆ®
UINT	CSHDateManager::ENTER_CHALLENGE_ZONE_MATCHING_POINT = 0;				// Ã§¸°Áö Á¸ ÀÔÀå °¡´É ¸ÅÄª Æ÷ÀÎÆ®
UINT	CSHDateManager::ENTER_CHALLENGE_ZONE_FREQ_PER_DAY = 0;					// Ã§¸°Áö Á¸ ÀÔÀå °¡´É È¸¼ö(ÇÏ·ç)
UINT	CSHDateManager::ENTER_CHALLENGE_ZONE_SECTION_NUM = 0;					// Ã§¸°Áö Á¸ ±¸°£ °³¼ö
DWORD	CSHDateManager::CHALLENGE_ZONE_START_DELAY_TIME = 0;					// Ã§¸°Áö Á¸ ½ÃÀÛ ´ë±â ½Ã°£
DWORD	CSHDateManager::CHALLENGE_ZONE_END_DELAY_TIME = 0;						// Ã§¸°Áö Á¸ Á¾·á ´ë±â ½Ã°£

UINT	CSHDateManager::CHALLENGE_ZONE_MOTION_NUM_START = 0;					// Ã§¸°Áö Á¸ ½ÃÀÛ ¸ð¼Ç ¹øÈ£
UINT	CSHDateManager::CHALLENGE_ZONE_MOTION_NUM_SUCCESS = 0;					// Ã§¸°Áö Á¸ ¼º°ø ¸ð¼Ç ¹øÈ£
UINT	CSHDateManager::CHALLENGE_ZONE_MOTION_NUM_SUCCESS_LEAST_CLEAR_TIME = 0;	// Ã§¸°Áö Á¸ ÃÖ´Ü ½Ã°£ Å¬¸®¾î ¼º°ø ¸ð¼Ç ¹øÈ£
UINT	CSHDateManager::CHALLENGE_ZONE_MOTION_NUM_FAIL = 0;						// Ã§¸°Áö Á¸ ½ÇÆÐ ¸ð¼Ç ¹øÈ£
// -------------------------------------------------------------------------------------------------------------------------------------
// CSHFamilyManager Method																										  »ý¼ºÀÚ
//
CSHDateManager::CSHDateManager()
{
	m_bIsChallengeZone = FALSE;

	m_pnDateZoneMoveIndexList = NULL;
	m_nDateZoneMoveIndexNum = 0;

	m_pstChallengeZoneMoveIndexList = NULL;
	m_nChallengeZoneMoveIndexNum = 0;

	// ÀÏ¹Ý ±âº» Ã¤³Î°úÀÇ ½Äº°À» À§ÇØ ±âº»°ªÀ¸·Î 1000 À» ¼³Á¤
	m_nChallengeZoneEnterNum = 1000;

	m_pstChallengeZoneMonsterGroupSection = NULL;

	m_pstChallengeZoneSectionMonLevel = NULL;
	m_nChallengeZoneSectionNum = 0;

	m_nChallengeZoneState = 0;
	m_nChallengeZoneTime = 0;
	m_nChallengeZoneTimeTick = 0;

	m_bChallengeZoneStart = FALSE;
	m_nChallengeZoneFirstEnterPlayerID = 0;

	m_nChallengeZoneLeastClearTime = 0;
	LoadDateInfo();
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHFamilyManager Method																										  ÆÄ±«ÀÚ
//
CSHDateManager::~CSHDateManager()
{
	SAFE_DELETE_ARRAY(m_pnDateZoneMoveIndexList);
	SAFE_DELETE_ARRAY(m_pstChallengeZoneMoveIndexList);
	SAFE_DELETE_ARRAY(m_pstChallengeZoneSectionMonLevel);

	if (m_pstChallengeZoneMonsterGroupSection)
	{
		for(UINT i=0; i<ENTER_CHALLENGE_ZONE_SECTION_NUM; i++)
		{
			for(UINT j=0; j<m_pstChallengeZoneMonsterGroupSection[i].nGroupNum; j++)
			{
				SAFE_DELETE_ARRAY(m_pstChallengeZoneMonsterGroupSection[i].pstGroup[j].pstMonster);
			}
			SAFE_DELETE_ARRAY(m_pstChallengeZoneMonsterGroupSection[i].pstGroup);
		}
		SAFE_DELETE_ARRAY(m_pstChallengeZoneMonsterGroupSection);
	}
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  Init Method																													  ÃÊ±âÈ­
//
VOID CSHDateManager::Init()
{
#if !defined(_MAPSERVER_) && !defined(_AGENTSERVER)
	if (IsChallengeZone(MAP->GetMapNum()))
	{
		m_bIsChallengeZone = TRUE;
		return;
	}

	m_bIsChallengeZone = FALSE;
	m_nChallengeZoneState = 0;
	m_nChallengeZoneTime = 0;
	m_nChallengeZoneTimeTick = 0;
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  LoadDateInfo Method																										 µ¥ÀÌÅÍ ÀÐ±â
//
BOOL CSHDateManager::LoadDateInfo()
{
	char szLine[MAX_PATH], szFile[MAX_PATH];
	int	 nKind = 0, nCnt = 0;
	CMHFile fp;

	sprintf(szFile, "./System/Resource/DateMatching.bin");
	fp.Init(szFile, "rb");
	if(!fp.IsInited()) return FALSE;

	while(FALSE == fp.IsEOF())
	{
		fp.GetLine(szLine, sizeof(szLine));
		if (strstr(szLine, "//") ||
			IsEmptyLine(szLine))
		{
			continue;			
		}
		else if (strstr(szLine, "END_KIND")) 
		{
			nCnt = 0;
			nKind++;
			continue;
		}

		switch(nKind)
		{
		case 1: m_nDateZoneMoveIndexNum++;			break;
		case 2: m_nChallengeZoneMoveIndexNum++;		break;
		case 4: ENTER_CHALLENGE_ZONE_SECTION_NUM++;	break;
		}
		
		nCnt++;
	}
	fp.Release();

	// µ¥ÀÌÆ® Á¸
	SAFE_DELETE_ARRAY(m_pnDateZoneMoveIndexList);
	m_pnDateZoneMoveIndexList = new UINT[m_nDateZoneMoveIndexNum];
	ZeroMemory(m_pnDateZoneMoveIndexList, sizeof(*m_pnDateZoneMoveIndexList)*m_nDateZoneMoveIndexNum);
	// Ã§¸°Áö Á¸
	SAFE_DELETE_ARRAY(m_pstChallengeZoneMoveIndexList);
	m_pstChallengeZoneMoveIndexList = new stCHALLENGEZONE_MAPINFO[m_nChallengeZoneMoveIndexNum];
	ZeroMemory(m_pstChallengeZoneMoveIndexList, sizeof(*m_pstChallengeZoneMoveIndexList)*m_nChallengeZoneMoveIndexNum);
	// Ã§¸°Áö Á¸ ±¸°£
	SAFE_DELETE_ARRAY(m_pstChallengeZoneSectionMonLevel);
	m_pstChallengeZoneSectionMonLevel = new stCHALLENGEZONE_SECTION_MONLEVEL[ENTER_CHALLENGE_ZONE_SECTION_NUM];
	ZeroMemory(m_pstChallengeZoneSectionMonLevel, sizeof(*m_pstChallengeZoneSectionMonLevel)*ENTER_CHALLENGE_ZONE_SECTION_NUM);
	
	// µ¥ÀÌÅÍ ÀÐ±â
	nKind = 0;
	nCnt = 0;
	fp.Init(szFile, "rb");
	if(!fp.IsInited()) return FALSE;

	while(FALSE == fp.IsEOF())
	{
		fp.GetLine(szLine, sizeof(szLine));
		if (strstr(szLine, "//") ||
			IsEmptyLine(szLine))
		{
			continue;			
		}
		else if (strstr(szLine, "END_KIND")) 
		{
			nCnt = 0;
			nKind++;
			continue;
		}

		switch(nKind)
		{
		case 0:		sscanf(szLine, "%d %d",			&NOTICE_HEART_MATCHING_POING,
													&ENTER_CHALLENGE_ZONE_MATCHING_POINT);				break;

		case 1:		sscanf(szLine, "%d",			&m_pnDateZoneMoveIndexList[nCnt]);					break;
		case 2:		sscanf(szLine, "%d %d",			&m_pstChallengeZoneMoveIndexList[nCnt].nMapNum,
													&m_pstChallengeZoneMoveIndexList[nCnt].nMoveIndex);	break;

		case 3:		sscanf(szLine, "%d %d %d",		&ENTER_CHALLENGE_ZONE_FREQ_PER_DAY,
													&CHALLENGE_ZONE_START_DELAY_TIME,
													&CHALLENGE_ZONE_END_DELAY_TIME);					break;

		case 4:		sscanf(szLine, "%d %d %d",		&m_pstChallengeZoneSectionMonLevel[nCnt].nStart,
													&m_pstChallengeZoneSectionMonLevel[nCnt].nEnd,
													&m_pstChallengeZoneSectionMonLevel[nCnt].nLimitTime);	
			
					m_pstChallengeZoneSectionMonLevel[nCnt].nLimitTime += CHALLENGE_ZONE_START_DELAY_TIME;
																										break;
		case 5:		sscanf(szLine, "%d %d %d %d",	&CHALLENGE_ZONE_MOTION_NUM_START,
													&CHALLENGE_ZONE_MOTION_NUM_SUCCESS,
													&CHALLENGE_ZONE_MOTION_NUM_SUCCESS_LEAST_CLEAR_TIME,
													&CHALLENGE_ZONE_MOTION_NUM_FAIL);					break;
		}
		
		nCnt++;
	}
	fp.Release();

	return TRUE;
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  LoadChallengeMonsterInfo Method																			Ã§¸°Áö Á¸ ¸ó½ºÅÍ µ¥ÀÌÅÍ ÀÐ±â
//
BOOL CSHDateManager::LoadChallengeMonsterInfo(int nMapNum)
{
#if defined(_MAPSERVER_)
	if (IsChallengeZone(nMapNum) == FALSE) return TRUE;
	m_bIsChallengeZone = TRUE;

	if (m_pstChallengeZoneMonsterGroupSection)
	{
		for(UINT i=0; i<ENTER_CHALLENGE_ZONE_SECTION_NUM; i++)
		{
			for(UINT j=0; j<m_pstChallengeZoneMonsterGroupSection[i].nGroupNum; j++)
			{
				SAFE_DELETE_ARRAY(m_pstChallengeZoneMonsterGroupSection[i].pstGroup[j].pstMonster);
			}
			SAFE_DELETE_ARRAY(m_pstChallengeZoneMonsterGroupSection[i].pstGroup);
		}
		SAFE_DELETE_ARRAY(m_pstChallengeZoneMonsterGroupSection);
	}

	// ¼½¼Ç °³¼ö¸¸Å­ »ý¼º
	m_pstChallengeZoneMonsterGroupSection = new stCHALLENGEZONE_MONSTER_GROUP_SECTION[ENTER_CHALLENGE_ZONE_SECTION_NUM];
	ZeroMemory(m_pstChallengeZoneMonsterGroupSection, sizeof(*m_pstChallengeZoneMonsterGroupSection)*ENTER_CHALLENGE_ZONE_SECTION_NUM);
	for(UINT nSection=0; nSection<ENTER_CHALLENGE_ZONE_SECTION_NUM; nSection++)
	{
		char szLine[MAX_PATH], szFile[MAX_PATH];
		int	 nKind = 0, nCnt = 0;
		CMHFile fp;

		sprintf(szFile, "./System/Resource/ChallengeZoneMonster%d%02d.bin", nMapNum, nSection+1);
		fp.Init(szFile, "rb");
		if(!fp.IsInited())
		{
			char szTmp[256];
			sprintf(szTmp, "%s ÆÄÀÏÀÌ Á¸ÀçÇÏÁö ¾Ê½À´Ï´Ù.", szFile);
			ASSERTMSG(0, szTmp);
			return FALSE;
		}

		// ±×·ì °³¼ö ÀÐ±â
		while(1)
		{
			if(fp.IsEOF()) break;
			fp.GetLine(szLine, sizeof(szLine));
			if (strstr(szLine, "//") ||
				IsEmptyLine(szLine))
			{
				continue;			
			}
			else if (strstr(szLine, "END_KIND")) 
			{
				nCnt = 0;
				nKind++;
				m_pstChallengeZoneMonsterGroupSection[nSection].nGroupNum++;
				continue;
			}

			nCnt++;
		}
		fp.Release();

		m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup = new stCHALLENGEZONE_MONSTER_GROUP[m_pstChallengeZoneMonsterGroupSection[nSection].nGroupNum];
		ZeroMemory(m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup, sizeof(*m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup)*m_pstChallengeZoneMonsterGroupSection[nSection].nGroupNum);

		// ¸ó½ºÅÍ °³¼ö ÀÐ±â
		nKind = 0;
		nCnt = 0;
		fp.Init(szFile, "rb");
		if(!fp.IsInited()) return FALSE;

		while(1)
		{
			if(fp.IsEOF()) break;
			fp.GetLine(szLine, sizeof(szLine));
			if (strstr(szLine, "//") ||
				IsEmptyLine(szLine))
			{
				continue;			
			}
			else if (strstr(szLine, "END_KIND")) 
			{
				m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind].nMonsterNum = nCnt;
				nCnt = 0;
				nKind++;
				continue;
			}

			nCnt++;
		}
		fp.Release();

		for(UINT i=0; i<m_pstChallengeZoneMonsterGroupSection[nSection].nGroupNum; i++)
		{
			m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[i].pstMonster = new stCHALLENGEZONE_MONSTER[m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[i].nMonsterNum];
			ZeroMemory(m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[i].pstMonster, sizeof(*m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[i].pstMonster)*m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[i].nMonsterNum);
		}

		//  ÃÖÁ¾ µ¥ÀÌÅÍ ¼³Á¤
		nKind = 0;
		nCnt = 0;
		fp.Init(szFile, "rb");
		if(!fp.IsInited()) return FALSE;

		while(1)
		{
			if(fp.IsEOF()) break;
			fp.GetLine(szLine, sizeof(szLine));
			if (strstr(szLine, "//") ||
				IsEmptyLine(szLine))
			{
				continue;			
			}
			else if (strstr(szLine, "END_KIND")) 
			{
				nCnt = 0;
				nKind++;
				continue;
			}

			sscanf(szLine, "%d %d %f %f %d",	&m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind].pstMonster[nCnt].nMonsterKind,
												&m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind].pstMonster[nCnt].nMonsterNum,
												&m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind].pstMonster[nCnt].nPosX,
												&m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind].pstMonster[nCnt].nPosZ,
												&m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind].pstMonster[nCnt].nDelayTime
												);
			// ÃÑ ¸ó½ºÅÍ ¼ö ¼³Á¤
			m_pstChallengeZoneMonsterGroupSection[nSection].nTotalMonsterNum += m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind].pstMonster[nCnt].nMonsterNum;
			// Ã³À½ µîÀåÇÏ´Â ¸ó½ºÅÍÀÇ µô·¹ÀÌ Å¸ÀÓÀ» Ã§¸°Áö ½ÃÀÛ µô·¹ÀÌ Å¸ÀÓÀ¸·Î ¼³Á¤
			if (nKind == 0)
			{
				m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind].pstMonster[nCnt].nDelayTime += CHALLENGE_ZONE_START_DELAY_TIME;
			}
			// µô·¹ÀÌ Å¸ÀÓÀº ´©ÀûÇØ¼­ °è»êÇÑ´Ù.
			if (nKind > 0)
			{
				m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind].pstMonster[nCnt].nDelayTime += 
				m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[nKind-1].pstMonster[0].nDelayTime;
			}
			nCnt++;
		}
		fp.Release();
	}
#endif

	return TRUE;
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  GetDateZoneMoveIndex Method																				  µ¥ÀÌÆ® Á¸ ÀÌµ¿ ÀÎµ¦½º ¾ò±â
//
BOOL CSHDateManager::GetDateZoneMoveIndex(UINT nSelIndex, int* pnIndex)
{
	if (nSelIndex >= m_nDateZoneMoveIndexNum)
	{
		return FALSE;
	}

	*pnIndex = m_pnDateZoneMoveIndexList[nSelIndex];

	return TRUE;
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  GetChallengeZoneMoveIndex Method																		  Ã§¸°Áö Á¸ ÀÌµ¿ ÀÎµ¦½º ¾ò±â
//
BOOL CSHDateManager::GetChallengeZoneMoveIndex(UINT nSelIndex, int* pnIndex)
{
	if (nSelIndex >= m_nChallengeZoneMoveIndexNum)
	{
		return FALSE;
	}

	*pnIndex = m_pstChallengeZoneMoveIndexList[nSelIndex].nMoveIndex;

	return TRUE;
}

MAPTYPE CSHDateManager::GetMapType(UINT index)
{
	if(index >= GetChallengeZoneMoveIndexNum())
	{
		return MAX_MAP_NUM;
	}

	return MAPTYPE(m_pstChallengeZoneMoveIndexList[index].nMapNum);
}

BOOL CSHDateManager::IsChallengeZone(int nMapNum)
{
	for(UINT i=0; i<m_nChallengeZoneMoveIndexNum; i++)
	{
		if (m_pstChallengeZoneMoveIndexList[i].nMapNum == (UINT)nMapNum)
		{
			return TRUE;
		}
	}

	return FALSE;
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  Process Method																									 
//
VOID CSHDateManager::MainLoop()
{
#if !defined(_MAPSERVER_) && !defined(_AGENTSERVER)
  	switch(m_nChallengeZoneState)
	{
	case CHALLENGEZONE_START:
		if (gCurTime - m_nChallengeZoneTimeTick > 1000)
		{
			// Ã³À½ ÇÑ ¹ø
			if (m_nChallengeZoneTime == 0)
			{
				// ÀÌÆåÆ® ¿¬Ãâ
				if (CHALLENGE_ZONE_MOTION_NUM_START)
					EFFECTMGR->StartEffectProcess(CHALLENGE_ZONE_MOTION_NUM_START, HERO, NULL, 0, 0);
			}

			m_nChallengeZoneTime += (gCurTime - m_nChallengeZoneTimeTick)/1000;
			if (m_nChallengeZoneTime >= CHALLENGE_ZONE_START_DELAY_TIME/1000)
			{
				m_nChallengeZoneState = NULL;
				m_nChallengeZoneTime = 0;
				CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1218));
				GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTimeTick(gCurTime);
			}
			else
			{
				m_nChallengeZoneTimeTick = gCurTime;
				CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1219), CHALLENGE_ZONE_START_DELAY_TIME/1000 - m_nChallengeZoneTime);
			}
		}
		break;
	case CHALLENGEZONE_END:
		if (gCurTime - m_nChallengeZoneTimeTick > 1000)
		{
			m_nChallengeZoneTime += (gCurTime - m_nChallengeZoneTimeTick)/1000;
			if (m_nChallengeZoneTime >= CHALLENGE_ZONE_END_DELAY_TIME/1000)
			{
				m_nChallengeZoneState = NULL;
				m_nChallengeZoneTime = 0;
			}
			else
			{
				m_nChallengeZoneTimeTick = gCurTime;
				CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1220), CHALLENGE_ZONE_END_DELAY_TIME/1000 - m_nChallengeZoneTime);
			}
		}
		break;
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_Process Method																							 Ã§¸°Áö Á¸ ¸ÞÀÎ ÇÁ·Î¼¼½º					 
//
VOID CSHDateManager::SRV_Process(CPlayer* pPlayer)
{
#if defined(_MAPSERVER_)
	SRV_ProcChallengeZoneEnterFreq(pPlayer);
	SRV_ProcRegenMonster(pPlayer);
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_StartChallengeZone Method																						  Ã§¸°Áö Á¸ ½ÃÀÛ					 
//
VOID CSHDateManager::SRV_StartChallengeZone(CPlayer* pPlayer, UINT nChannelNumFromAgent, UINT nSection)
{
#if defined(_MAPSERVER_)
	// Ã§¸°Áö Á¸¿¡ ÀÔÀåÀÌ¶ó¸é È¸¼ö Áõ°¡
	// ..Á¤»óÀûÀÎ Ã§¸°Áö Á¸À¸·ÎÀÇ ÀÌµ¿ÀÎ °æ¿ì ½Äº°À» À§ÇØ ¿¡ÀÌÀüÆ®¿¡¼­ 1000 ÀÌ»óÀ¸·Î º¸³¿
	if (nChannelNumFromAgent >= 1000)
	{
		pPlayer->IncreaseChallengeZoneEnterFreq();
		g_csDateManager.SRV_SendChallengeZoneEnterFreq(pPlayer);
		// ¿ø·¡ ¿©±â¼­ DB¿¡ ÀúÀåÇØ¾ß ÇÏÁö¸¸ ÀÌ ·çÆ¾ ½ÇÇà ÈÄ¿¡ DB Load ·çÆ¾ÀÌ ½ÇÇàµÈ´Ù.
		// ±×·¡¼­ Load ºÎºÐ¿¡¼­ ÀÔÀå È¸¼ö°¡ Áõ°¡µÆ´ÂÁö¸¦ Ã¼Å©ÇØ¼­ Áõ°¡µÇ¾ú´Ù¸é ±× °ªÀ» DB¿¡ ÀúÀåÇÑ´Ù.
	}

	if (m_bChallengeZoneStart == FALSE) return;

	// ¸ÕÀú µé¾î¿Í ÀÖ´Â ÆÄÆ®³Ê Ã¼Å©
	// ..ÆÄÆ®³Ê°¡ ¾ø°Å³ª Ã¤³ÎÀÌ ´Ù¸£´Ù¸é ¹º°¡ ÀÌ»ó..
	CPlayer* pFirstEnterPlayer = (CPlayer*)g_pUserTable->FindUser(m_nChallengeZoneFirstEnterPlayerID);
	if(pFirstEnterPlayer && pPlayer->GetChannelID() == pFirstEnterPlayer->GetChannelID())
	{
		// ÆÄÆ®³Ê ID ¼³Á¤
		pPlayer->SetChallengeZonePartnerID(pFirstEnterPlayer->GetID());
		pFirstEnterPlayer->SetChallengeZonePartnerID(pPlayer->GetID());
		// ¸ó½ºÅÍ ¼ö ¼³Á¤
		pPlayer->SetChallengeZoneMonsterNum(m_pstChallengeZoneMonsterGroupSection[nSection].nTotalMonsterNum);
		pPlayer->SetChallengeZoneMonsterNumTillNow(0);
		pPlayer->SetChallengeZoneKillMonsterNum(0);
		pPlayer->SetChallengeZoneCreateMonRightNow(FALSE);
		pFirstEnterPlayer->SetChallengeZoneMonsterNum(m_pstChallengeZoneMonsterGroupSection[nSection].nTotalMonsterNum);
		pFirstEnterPlayer->SetChallengeZoneMonsterNumTillNow(0);
		pFirstEnterPlayer->SetChallengeZoneKillMonsterNum(0);
		pFirstEnterPlayer->SetChallengeZoneCreateMonRightNow(FALSE);
		// ..±¸°£ ¹üÀ§ Ã¼Å©. ¸¸¾à ±¸°£ÀÌ ¹üÀ§¸¦ ¹þ¾î³­´Ù¸é ±×³É ¸Ê ±¸°æ..¤»
		if (nSection < ENTER_CHALLENGE_ZONE_SECTION_NUM)
		{
			// Ã§¸°Áö ½ÃÀÛ »óÅÂ ¼³Á¤
			// ½ÃÀÛ ¹× ¸ó½ºÅÍ ¼³Á¤Àº 1¸íÀÌ ´ã´çÇÑ´Ù.
			pPlayer->SetChallengeZoneStartState(1);
			// ±¸°£ ¼³Á¤
			pPlayer->SetChallengeZoneSection(nSection);
			pFirstEnterPlayer->SetChallengeZoneSection(nSection);
			// Æ½ Ä«¿îÆ® ¼³Á¤
			pPlayer->SetChallengeZoneStartTimeTick(gCurTime);
			pFirstEnterPlayer->SetChallengeZoneStartTimeTick(gCurTime);

			// 091124 ONS °æÇèÄ¡ ºñÀ²À» ·ÎµåÇÑ´Ù.
			ChallengeZone_ExpRate_Load(pFirstEnterPlayer->GetID(), pPlayer->GetID(), nSection);
			ChallengeZone_ExpRate_Load(pPlayer->GetID(), pFirstEnterPlayer->GetID(), nSection);
		}
	}
	else
	{
		if (g_pServerSystem->IsTestServer())
		{
			g_Console.LOG(4, "CHALLENGEZONE_ENTER_ERROR:%d", pPlayer->GetID());
		}
	}

	m_bChallengeZoneStart = FALSE;
	m_nChallengeZoneFirstEnterPlayerID = 0;
#endif
}
// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_NotifyStartChallengeZone Method																				 Ã§¸°Áö Á¸ ½ÃÀÛ ¾Ë¸²					 
//
// 091124 ONS Ã§¸°Áö Á¸ ½ÃÀÛ ¾Ë¸² - ÀÌ¸§, °æÇèÄ¡ºñÀ² Á¤º¸¸¦ °¢ Å¬¶óÀÌ¾ðÆ®·Î Àü¼ÛÇÑ´Ù.
VOID CSHDateManager::SRV_NotifyStartChallengeZone(CPlayer* pPlayer, char* pszName1, char* pszName2, DWORD dwExpRate1, DWORD dwExpRate2, UINT nSection)
{
#if defined(_MAPSERVER_)
	MSG_NAME2_DWORD3 stPacket;

	stPacket.Category	= MP_DATE;
	stPacket.Protocol	= MP_DATE_CHALLENGEZONE_START;	
	
	SafeStrCpy(stPacket.Name1, pszName1, MAX_NAME_LENGTH+1);
	SafeStrCpy(stPacket.Name2, pszName2, MAX_NAME_LENGTH+1);
	stPacket.dwData1 = dwExpRate1;
	stPacket.dwData2 = dwExpRate2;
	stPacket.dwData3 = nSection;

	pPlayer->SendMsg(&stPacket, sizeof(stPacket));

#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_ProcChallengeEnterFreq Method																			Ã§¸°Áö Á¸ ÀÔÀå È¸¼ö Ã³¸®					 
//
VOID CSHDateManager::SRV_ProcChallengeZoneEnterFreq(CPlayer* pPlayer)
{
#if defined(_MAPSERVER_)
	// ³¯(day)ÀÌ º¯°æµÇ¾úÀ¸¸é(ÀÚÁ¤ÀÌ Áö³ª¸é ÀÔÀå È¸¼ö ÃÊ±âÈ­)
	if (MHTIMEMGR_OBJ->GetOldLocalTime()->wDay != MHTIMEMGR_OBJ->GetCurLocalTime()->wDay)
	{
		if (pPlayer->GetChallengeZoneEnterFreq())
		{
			pPlayer->SetChallengeZoneEnterFreq(0);
			SRV_SendChallengeZoneEnterFreq(pPlayer);
			// ¿©±â¼­ DBÀúÀåÀÌ ÇÊ¿äÇÏÁö¸¸, ÀúÀåÇÏ¸é ÇÑ ¼ø°£¿¡ Á¢¼ÓÀÚ ¼ö ¸¸Å­ÀÇ DBÄõ¸®°¡ ¹ß»ýÇÑ´Ù. ¹«½¼ ÀÏÀÌ ¹ß»ýÇÒÁö´Â....
			// ÀúÀåÇÏ´Â °Ô È®½ÇÇÏ±ä ÇÏÁö¸¸ ÀúÀåÀº ¾È ÇØµµ µÈ´Ù. ¼­¹ö»ó¿¡¼­ÀÇ °ª¸¸ 0 À¸·Î ÇØ ÁÖ¸é µÈ´Ù.
			// Ã§¸°Áö Á¸À¸·Î ÀÌµ¿ÇÏ°Å³ª, ·Î±×¾Æ¿ô, ¸Ê ÀÌµ¿À» ÇÒ ¶§ DB Load ¸¦ ÇÏ¸é¼­ ³¯Â¥ Ã¼Å©¸¦ ÇØ¼­ 
			// ³¯Â¥°¡ Áö³µ´Ù¸é DB¿¡ ÀúÀåµÇ¾î ÀÖ´Â °ª¿¡ »ó°ü¾øÀÌ 0 À¸·Î ¸®ÅÏÇÏ±â ¶§¹®.
			// ±×¸®°í, Ã§¸°Áö Á¸À¸·Î ÀÌµ¿ÇÒ ¶§ 0 À¸·Î ¸®ÅÏµÈ °ª¿¡ Ã§¸°Áö Á¸À¸·Î µé¾î°¡¸é¼­ +1 µÇ¾î
			// DB¿¡ ÀúÀåÀ» ÇÏ¹Ç·Î DB ÀúÀåÀº ¿©±â¼­ ½Å°æ ¾È ½áµµ µÊ. (Áï, Ã§¸°Áö Á¸À¸·Î ÀÌµ¿ÇÏ´Â ¼ø°£¿¡¸¸ DB ÀúÀåÀ» ÇÔ)
			// ..³¯Â¥ Ã¼Å©¸¦ ÀÌ·¸°Ô ÇÏÁö ¾Ê°í, ÆÐ¹Ð¸® Å»ÅðÃ³·³ Ã§·£Áö Á¸ ÀÌµ¿À» ½ÃµµÇÒ ¶§, ±× ¶§ ³¯Â¥¸¦
			// ..Ã¼Å©ÇØ¼­ Ã³¸®ÇØµµ µÇ´Âµ¥, ±×·² °æ¿ì Å¬¶óÀÌ¾ðÆ®¿¡ °»½ÅµÈ Á¤º¸¸¦ º¸³»ÁÖ´Â °Ô ºÒ°¡´ÉÇØÁö°í, ¶ÇÇÑ
			// ..¼­¹ö¿¡¼­ Ã§¸°Áö Á¸¿¡ µé¾î°£ ¸¶Áö¸· ³¯Â¥¸¦ °®°í ÀÖ¾î¾ß ÇÏ´Âµ¥, ¼­¹ö¿¡¼­ °®°í ÀÖÁö ¾Ê°í Ã³¸®ÇÒ ¼ö ÀÖ´Â
			// ..¹æ¹ý(DB ÇÁ·Î½ÃÀú¿¡¼­ Ã³¸®ÇÒ ¼ö ÀÖ´Â ¹æ¹ý)À» ¿ì¼±½ÃÇØ¼­ ÀÌ·¸°Ô Ã³¸®ÇßÀ½.
			//
			// ±×·±µ¥ ¹®Á¦°¡ ÀÖÀ» ¼ö ÀÖ´Ù. °ÔÀÓ¼­¹öÀÇ ½Ã½ºÅÛÅ¸ÀÓÀÌ DB¼­¹öÀÇ ½Ã½ºÅÛÅ¸ÀÓº¸´Ù ºü¸¦ °æ¿ì, °ÔÀÓ¼­¹ö¿¡¼­´Â
			// È¸¼ö°¡ 0À¸·Î ÃÊ±âÈ­ µÈ ÈÄ, ¸Ê ÀÌµ¿À» ÇÏ°Ô µÇ¾ú´Â µ¥, ±× ¶§ DB¼­¹öÀÇ ½Ã½ºÅÛÅ¸ÀÓÀÌ ÀÚÁ¤ÀÌ Áö³ªÁö ¾Ê¾Ò´Ù¸é,
			// DB¿¡ ÀúÀåµÇ¾î ÀÖ´Â °ªÀ» ÀÐ¾î¹ö·Á, DB¼­¹öÀÇ ½Ã½ºÅÛÅ¸ÀÓÀÌ ÀÚÁ¤ÀÌ ³ÑÀº ÈÄ ¸ÊÀÌµ¿À» ÇÏ±â Àü±îÁö´Â 
			// Ã§¸°Áö Á¸¿¡ ÀÔÀåÇÒ ¼ö ¾ø°Ô µÈ´Ù. °ÔÀÓ¼­¹öÀÇ ½Ã½ºÅÛÅ¸ÀÓ°ú DB¼­¹öÀÇ ½Ã½ºÅÛÅ¸ÀÓÀÇ ¿ÀÂ÷°¡ °ü°Ç~
			// ÀÌ ¹®Á¦¸¦ ¹æÁöÇÏ±â À§ÇØ ¼¼ÀÌºê ÇÃ·¡±×¸¦ ÇÏ³ª µÖ¼­ ÇÃ·¡±×°¡ ¼¼ÆÃµÇ¾î ÀÖÀ¸¸é ¸Ê ÀÌÅ»½Ã¿¡ DBÀúÀåÀ» ÇÏµµ·Ï ÇÑ´Ù.
			pPlayer->SetChallengeZoneNeedSaveEnterFreq(TRUE);
			// ±×·±µ¥ ¸¸¾à ¸Ê ÀÌÅ»ÇÒ ¶§ÀÇ ÀúÀå DBÄõ¸®º¸´Ù Á¢¼Ó ¸ÊÀÇ ·Îµå DBÄõ¸®°¡ ¸ÕÀú ¼öÇàµÈ´Ù¸é..???  ¹æ¹ý ¾øÀ½..
			// DB¼­¹öÀÇ ½Ã½ºÅÛÅ¸ÀÓÀ» »ç¿ëÇÏÁö ¾Ê°í °ÔÀÓ¼­¹öÀÇ ½Ã½ºÅÛÅ¸ÀÓÀ» »ç¿ëÇÑ´Ù°í ÇØµµ, ¸ðµç ¸Ê¼­¹ö°¡ ÇÑ ÇÏµå¿þ¾î¿¡
			// Å¾ÀçµÇ¾î ÀÖÁö ¾ÊÀº ÀÌ»ó ½Ã°£¿ÀÂ÷¸¦ ÇÇÇÒ ¼ö´Â ¾ø´Ù. ¹®Á¦ È®·üÀº Á» ÁÙ¾îµé°ÚÁö¸¸..
		}
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_SendChallengeZoneEnterFreq Method																		Ã§¸°Áö Á¸ ÀÔÀå È¸¼ö Àü¼Û					 
//
VOID CSHDateManager::SRV_SendChallengeZoneEnterFreq(CPlayer* pPlayer)
{
#if defined(_MAPSERVER_)
	MSG_DWORD2 msg;

	msg.Category	= MP_DATE;
	msg.Protocol	= MP_DATE_CHALLENGEZONE_ENTER_FREQ;
	msg.dwData1		= pPlayer->GetChallengeZoneEnterFreq();
	msg.dwData2		= pPlayer->GetChallengeZoneEnterBonusFreq();
	pPlayer->SendMsg(&msg, sizeof(msg));
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_ProcRegenMonster Method																				  Ã§¸°Áö Á¸ ¸ó½ºÅÍ µîÀå Ã³¸®					 
//
VOID CSHDateManager::SRV_ProcRegenMonster(CPlayer* pPlayer)
{
#if defined(_MAPSERVER_)
	// Ã§¸°Áö »óÅÂ°¡ ¾Æ´Ï¸é..
	if (pPlayer->GetChallengeZoneStartState() == 0)
	{
		return;
	}

	// Ã§¸°Áö°¡ ³¡³µÀ¸¸é ´ë±â ½Ã°£ ÈÄ ±ÍÈ¯ÇÏ±â Àü¿¡ Àá±ñ µô·¹ÀÌ.. Å¬¶óÀÌ¾ðÆ®¿¡¼­ ¸¶Áö¸· ¸ó½ºÅÍ¸¦ Àâ´Â ¿¬ÃâÀÌ ³¡³ª´Â ½Ã°£À» À§ÇØ..
	// ¿©±â¿¡¼­ÀÇ µô·¹ÀÌ°¡ ³¡³ª¸é Á¾·á Ä«¿îÆ® ´Ù¿î µé¾î°¨.
	if (pPlayer->GetChallengeZoneStartState() == CHALLENGEZONE_END_SUCCESS)
	{
		if (pPlayer->GetChallengeZoneStartTimeTick())
		{
			const DWORD END_DELAY = 5000;
			if (gCurTime - pPlayer->GetChallengeZoneStartTimeTick() > END_DELAY)
			{
				pPlayer->SetChallengeZoneStartState(CHALLENGEZONE_END_START_COUNTDOWN);
				pPlayer->SetChallengeZoneStartTimeTick(gCurTime);

				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= MP_DATE_CHALLENGEZONE_END_SUCCESS;
				stPacket.dwObjectID			= pPlayer->GetID();
				stPacket.dwData				= 0;
				// ÃÖ´Ü ½Ã°£ Å¬¸®¾î Å¸ÀÓÀ» °»½ÅÇß´Ù¸é Å¬¶óÀÌ¾ðÆ® ¿¬ÃâÀ» À§ÇØ °ª ¼³Á¤
				if (pPlayer->GetChallengeZoneClearTime() &&
					pPlayer->GetChallengeZoneClearTime() < m_pstChallengeZoneSectionMonLevel[pPlayer->GetChallengeZoneSection()].nLeastClearTime)
				{
					stPacket.dwData			= 1;
				}

				pPlayer->SendMsg(&stPacket, sizeof(stPacket));	
			}
		}
		return;
	}

	// Ã§¸°Áö°¡ ³¡³µÀ¸¸é ´ë±â ½Ã°£ ÈÄ ±ÍÈ¯
	if (pPlayer->GetChallengeZoneStartState() > CHALLENGEZONE_END)
	{
		if (pPlayer->GetChallengeZoneStartTimeTick())
		{
			if (gCurTime - pPlayer->GetChallengeZoneStartTimeTick() > CHALLENGE_ZONE_END_DELAY_TIME)
			{
				pPlayer->SetChallengeZoneStartTimeTick(0);

				MSG_DWORD stPacket;

				stPacket.Category 		= MP_DATE;
				stPacket.Protocol 		= MP_DATE_CHALLENGEZONE_RETURN;
				stPacket.dwObjectID		= pPlayer->GetID();;
				pPlayer->SendMsg(&stPacket, sizeof(stPacket) );
			}
		}
		return;
	}

	UINT nSection	= pPlayer->GetChallengeZoneSection();
	UINT i			= pPlayer->GetChallengeZoneStartState()-1;
	for(; i<m_pstChallengeZoneMonsterGroupSection[nSection].nGroupNum; i++)
	{
		// µîÀå ½Ã°£ÀÌ µÆ³ª? ¶Ç´Â Áö±Ý±îÁö ³ª¿Â ¸ó½ºÅÍ¸¦ ¸ðµÎ ÇØÄ¡¿üÀ¸¸é ¹Ù·Î ´ÙÀ½ ¸ó½ºÅÍ µîÀå
		if (gCurTime - pPlayer->GetChallengeZoneStartTimeTick() > m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[i].pstMonster[0].nDelayTime ||
			pPlayer->IsChallengeZoneCreateMonRightNow())
		{
			// ¸ó½ºÅÍ ¼ÒÈ¯
			for(UINT j=0; j<m_pstChallengeZoneMonsterGroupSection[nSection].pstGroup[i].nMonsterNum; j++)
			{
				VECTOR3 stPos;
				stPos.x = GetChallengeZoneMonsterGroup(nSection, i)->pstMonster[j].nPosX;
				stPos.z = GetChallengeZoneMonsterGroup(nSection, i)->pstMonster[j].nPosZ;
				RECALLMGR->ChallengeZoneRecall(g_csDateManager.GetChallengeZoneMonsterGroup(nSection, i)->pstMonster[j].nMonsterKind, 
											   (BYTE)g_csDateManager.GetChallengeZoneMonsterGroup(nSection, i)->pstMonster[j].nMonsterNum, 
											   pPlayer->GetChannelID(), 
											   &stPos,
											   0);
				/*
				if (g_pServerSystem->IsTestServer())
				{
					g_Console.LOG(4, "CHALLENGEZONE Monster: Channel:%d Group:%d Mon:%d,%d)", 
								  pPlayer->GetChannelID(),
								  i, 
								  g_csDateManager.GetChallengeZoneMonsterGroup(nSection, i)->pstMonster[j].nMonsterKind, 
								  g_csDateManager.GetChallengeZoneMonsterGroup(nSection, i)->pstMonster[j].nMonsterNum);
				}
				*/

				// Áö±Ý±îÁö ³ª¿Â ¸ó½ºÅÍ ¼ö ¼³Á¤
				UINT nNum = pPlayer->GetChallengeZoneMonsterNumTillNow() + g_csDateManager.GetChallengeZoneMonsterGroup(nSection, i)->pstMonster[j].nMonsterNum;
				pPlayer->SetChallengeZoneMonsterNumTillNow(nNum);
			}
			pPlayer->SetChallengeZoneStartState(pPlayer->GetChallengeZoneStartState()+1);
			pPlayer->SetChallengeZoneCreateMonRightNow(FALSE);
			break;
		}
	}

	// Å¸ÀÓ¾Æ¿ô
	if (gCurTime - pPlayer->GetChallengeZoneStartTimeTick() > m_pstChallengeZoneSectionMonLevel[pPlayer->GetChallengeZoneSection()].nLimitTime)
	{
		SRV_EndChallengeZone(pPlayer, CHALLENGEZONE_END_TIMEOUT);
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_ProcMonsterDie Method																				  Ã§¸°Áö Á¸ ¸ó½ºÅÍ Á×À½ Ã³¸®					 
//
VOID CSHDateManager::SRV_ProcMonsterDie(CPlayer* pPlayer)
{
#if defined(_MAPSERVER_)
	pPlayer->IncreaseChallengeZoneKillMonsterNum();
	CPlayer* pPartner = (CPlayer*)g_pUserTable->FindUser(pPlayer->GetChallengeZonePartnerID());
	if (pPartner)
	{
		UINT nKillMonNum = pPlayer->GetChallengeZoneKillMonsterNum() + pPartner->GetChallengeZoneKillMonsterNum();
		// ¸ó½ºÅÍ¸¦ ¸ðµÎ ÇØÄ¡¿üÀ¸¸é ¼º°ø!!
		if (nKillMonNum >= pPlayer->GetChallengeZoneMonsterNum())
		{
			SRV_EndChallengeZone(pPlayer,  CHALLENGEZONE_END_SUCCESS);
		}
		else
		{
			// Áö±Ý±îÁö ³ª¿Â ¸ó½ºÅÍ¸¦ ¸ðµÎ ÇØÄ¡¿üÀ¸¸é ¹Ù·Î ´ÙÀ½ ¸ó½ºÅÍ µîÀå ¼³Á¤
			// ..¸ó½ºÅÍ µîÀåÀ» ´ã´çÇÏ´Â ÇÃ·¹ÀÌ¾î¸¦ Ã¼Å©ÇØ¼­ Ã³¸®
			if (pPlayer->GetChallengeZoneStartState())
			{
				if (nKillMonNum  >= pPlayer->GetChallengeZoneMonsterNumTillNow())
				{
					pPlayer->SetChallengeZoneCreateMonRightNow(TRUE);
				}
			}
			else
			{
				if (nKillMonNum  >= pPartner->GetChallengeZoneMonsterNumTillNow())
				{
					pPartner->SetChallengeZoneCreateMonRightNow(TRUE);
				}
			}
		}
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_SetChallengeZoneEnterBonusFreq Method															 Ã§¸°Áö Á¸ ÀÔÀå º¸³Ê½º È¸¼ö Áõ°¡				 
//
VOID CSHDateManager::SRV_SetChallengeZoneEnterBonusFreq(CPlayer* pPlayer, UINT nFreq)
{
#if defined(_MAPSERVER_)
	pPlayer->SetChallengeZoneEnterBonusFreq(pPlayer->GetChallengeZoneEnterBonusFreq()+nFreq);
	// DB¿¡ ÀúÀå
	ChallengeZone_EnterFreq_Save(pPlayer->GetID(), pPlayer->GetChallengeZoneEnterFreq(), pPlayer->GetChallengeZoneEnterBonusFreq());

	SRV_SendChallengeZoneEnterFreq(pPlayer);
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_EndChallengeZone Method																						    Ã§¸°Áö Á¸À» ³¡³¿					 
//
VOID CSHDateManager::SRV_EndChallengeZone(CPlayer* pPlayer, CHALLENGEZONE_STATE eEndState)
{
#if defined(_MAPSERVER_)
	if (IsChallengeZoneHere() == FALSE) return;
	
	switch(eEndState)
	{
	// Å¸ÀÓ¾Æ¿ô
	case CHALLENGEZONE_END_TIMEOUT:
		if (pPlayer->GetChallengeZoneStartState() < CHALLENGEZONE_END &&
			pPlayer->GetChallengeZonePartnerID())
		{
			CPlayer* pPartner = (CPlayer*)g_pUserTable->FindUser(pPlayer->GetChallengeZonePartnerID());
			if (pPartner)
			{
				// Å¸ÀÓ¾Æ¿ôÀÌ¸é Ã§¸°Áö Á¸ ³¡.
				pPlayer->SetChallengeZoneStartState(eEndState);
				pPlayer->SetChallengeZoneStartTimeTick(gCurTime);

				pPartner->SetChallengeZoneStartState(eEndState);
				pPartner->SetChallengeZoneStartTimeTick(gCurTime);

				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= MP_DATE_CHALLENGEZONE_END_TIMEOUT;
				stPacket.dwObjectID			= pPlayer->GetID();
				stPacket.dwData				= CHALLENGE_ZONE_END_DELAY_TIME;
				pPlayer->SendMsg(&stPacket, sizeof(stPacket));	

				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= MP_DATE_CHALLENGEZONE_END_TIMEOUT;
				stPacket.dwObjectID			= pPartner->GetID();
				stPacket.dwData				= CHALLENGE_ZONE_END_DELAY_TIME;
				pPartner->SendMsg(&stPacket, sizeof(stPacket));	
			}
			else
			{
				// Å¸ÀÓ¾Æ¿ôÀÎµ¥, ÆÄÆ®³Ê°¡ ¾ø´Ù? 
				// ÆÄÆ®³Ê°¡ ³ª°¡¸é¼­ µ¿½Ã¿¡ Å¸ÀÓ¾Æ¿ôÀÏ °æ¿ì ÆÄÆ®³Ê°¡ ³ª°¡¸é¼­ ³¡À» ³½´Ù.
				// È¥ÀÚ µé¾î¿ÍÀÖ´Â µ¥ Å¸ÀÓ¾Æ¿ô? ºñÁ¤»óÀÎÀûÀÎ »óÈ². ¾îÂ·°Å³ª ÂÑ¾Æ³»ÀÚ
				pPlayer->SetChallengeZoneStartState(eEndState);
				pPlayer->SetChallengeZoneStartTimeTick(gCurTime);

				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= MP_DATE_CHALLENGEZONE_END_TIMEOUT;
				stPacket.dwObjectID			= pPlayer->GetID();
				stPacket.dwData				= CHALLENGE_ZONE_END_DELAY_TIME;
				pPlayer->SendMsg(&stPacket, sizeof(stPacket));	
			}
		}
		break;
	// pPlayer °¡ Ã§¸°Áö Á¸À» ÀÌÅ»ÇÏ¸é pPartner ¿¡°Ô ½ÇÆÐ¸¦ ¾Ë¸°´Ù.
	case CHALLENGEZONE_END_PARTNER_OUT:
		if (pPlayer->GetChallengeZoneStartState() < CHALLENGEZONE_END &&
			pPlayer->GetChallengeZonePartnerID())
		{
			CPlayer* pPartner = (CPlayer*)g_pUserTable->FindUser(pPlayer->GetChallengeZonePartnerID());
			if (pPartner)
			{
				pPartner->SetChallengeZoneStartState(eEndState);
				pPartner->SetChallengeZoneStartTimeTick(gCurTime);

				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= MP_DATE_CHALLENGEZONE_END_PARTNER_OUT;
				stPacket.dwObjectID			= pPlayer->GetID();
				stPacket.dwData				= CHALLENGE_ZONE_END_DELAY_TIME;
				pPartner->SendMsg(&stPacket, sizeof(stPacket));	
			}
		}
		break;
	// pPlayer °¡ Á×¾ú´Â µ¥, pPartner µµ Á×¾îÀÖ´Ù¸é ¸ðµÎ¿¡°Ô ½ÇÆÐ¸¦¾Ë¸°´Ù.
	case CHALLENGEZONE_END_ALL_DIE:
		if (pPlayer->GetChallengeZoneStartState() < CHALLENGEZONE_END &&
			pPlayer->GetChallengeZonePartnerID())
		{
			CPlayer* pPartner = (CPlayer*)g_pUserTable->FindUser(pPlayer->GetChallengeZonePartnerID());
			if (pPartner)
			{
				// µÑ ´Ù Á×¾úÀ¸¸é Ã§¸°Áö Á¸ ³¡.
				if (pPartner->GetState() == eObjectState_Die)
				{
					pPlayer->SetChallengeZoneStartState(eEndState);
					pPlayer->SetChallengeZoneStartTimeTick(gCurTime);

					pPartner->SetChallengeZoneStartState(eEndState);
					pPartner->SetChallengeZoneStartTimeTick(gCurTime);

					MSG_DWORD stPacket;
					stPacket.Category			= MP_DATE;
					stPacket.Protocol			= MP_DATE_CHALLENGEZONE_END_ALL_DIE;
					stPacket.dwObjectID			= pPlayer->GetID();
					stPacket.dwData				= CHALLENGE_ZONE_END_DELAY_TIME;
					pPlayer->SendMsg(&stPacket, sizeof(stPacket));	

					stPacket.Category			= MP_DATE;
					stPacket.Protocol			= MP_DATE_CHALLENGEZONE_END_ALL_DIE;
					stPacket.dwObjectID			= pPartner->GetID();
					stPacket.dwData				= CHALLENGE_ZONE_END_DELAY_TIME;
					pPartner->SendMsg(&stPacket, sizeof(stPacket));	
				}
			}
			else
			{
				// Á×¾ú´Â µ¥, ÆÄÆ®³Ê°¡ ¾ø´Ù? 
				// ÆÄÆ®³Ê°¡ ³ª°¡¸é¼­ µ¿½Ã¿¡ Á×¾úÀ» °æ¿ì ÆÄÆ®³Ê°¡ ³ª°¡¸é¼­ ³¡À» ³½´Ù.
				// È¥ÀÚ µé¾î¿ÍÀÖ´Â µ¥ Á×¾ú´Ù? ºñÁ¤»óÀÎÀûÀÎ »óÈ². ¾îÂ·°Å³ª ÂÑ¾Æ³»ÀÚ
				pPlayer->SetChallengeZoneStartState(eEndState);
				pPlayer->SetChallengeZoneStartTimeTick(gCurTime);

				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= MP_DATE_CHALLENGEZONE_END_ALL_DIE;
				stPacket.dwObjectID			= pPlayer->GetID();
				stPacket.dwData				= CHALLENGE_ZONE_END_DELAY_TIME;
				pPlayer->SendMsg(&stPacket, sizeof(stPacket));	
			}
		}
		break;
	// ¸ó½ºÅÍ¸¦ ¸ðµÎ Àâ¾Æ¼­ ¼º°ø!
	case CHALLENGEZONE_END_SUCCESS:
		{
			if (pPlayer->GetChallengeZoneStartState() < CHALLENGEZONE_END)
			{
				CPlayer* pPartner = (CPlayer*)g_pUserTable->FindUser(pPlayer->GetChallengeZonePartnerID());
				if (pPartner)
				{
					UINT nClearTime = gCurTime - pPlayer->GetChallengeZoneStartTimeTick() - CHALLENGE_ZONE_START_DELAY_TIME;

					pPlayer->SetChallengeZoneStartState(eEndState);
					pPlayer->SetChallengeZoneStartTimeTick(gCurTime);

					pPartner->SetChallengeZoneStartState(eEndState);
					pPartner->SetChallengeZoneStartTimeTick(gCurTime);

					// Å¬¸®¾î Å¸ÀÓ ¼³Á¤
					pPlayer->SetChallengeZoneClearTime(nClearTime);
					pPartner->SetChallengeZoneClearTime(nClearTime);
					// DB ÀúÀå
					ChallengeZone_Success_Save(pPlayer->GetID(), pPartner->GetID(), pPlayer->GetChallengeZoneSection(), nClearTime);
					ChallengeZone_Success_Save(pPartner->GetID(), pPlayer->GetID(), pPartner->GetChallengeZoneSection(), nClearTime);
				}
			}
		}
		break;
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_EnterDateZone Method																							  µ¥ÀÌÆ® Á¸ ÀÔÀå
//
VOID CSHDateManager::SRV_EnterDateZone(CPlayer* pPlayer, DWORD nTargetPlayerID, int nZoneIndex)
{
#if defined(_MAPSERVER_)
	MSG_DWORD stPacket;
	stPacket.Category			= MP_DATE;
	stPacket.Protocol			= MP_DATE_ENTER_DATEZONE_2;
	stPacket.dwObjectID			= pPlayer->GetID();
	stPacket.dwData				= nZoneIndex;

	pPlayer->SendMsg(&stPacket, sizeof(stPacket));

	TCHAR text[MAX_PATH] = {0};
	_sntprintf(
		text,
		_countof(text),
		"map:%d(%d)",
		g_pServerSystem->GetMapNum(),
		pPlayer->GetChannelID());
	LogItemMoney(
		pPlayer->GetID(),
		pPlayer->GetObjectName(),
		0,
		text,
		eLog_DateMatchBegin,
		pPlayer->GetMoney(),
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0);
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_EnterDateZone2 Method																							  µ¥ÀÌÆ® Á¸ ÀÔÀå
//
VOID CSHDateManager::SRV_EnterDateZone2(CPlayer* pPlayer, MSG_DWORD4* pPacket)
{
#if defined(_MAPSERVER_)
	MSG_DWORD4 stPacket;
	stPacket.Category			= MP_DATE;
	stPacket.Protocol			= MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_2;
	stPacket.dwObjectID			= pPlayer->GetID();
	stPacket.dwData1			= pPacket->dwData1;
	stPacket.dwData2			= pPacket->dwData2;
	stPacket.dwData3			= pPacket->dwData3;
	stPacket.dwData4			= pPacket->dwData4;

	pPlayer->SendMsg(&stPacket, sizeof(stPacket));	
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_EnterChallengeZone Method																						  Ã§¸°Áö Á¸ ÀÔÀå
//
VOID CSHDateManager::SRV_EnterChallengeZone(CPlayer* pPlayer, DWORD nTargetPlayerID, int nZoneIndex, DWORD dwExpRate, int nKind)
{
#if defined(_MAPSERVER_)
	RESULT eResult = RESULT_OK;
	MSG_DWORD2 stPacket;

	// ÇÏ·ç ÀÔÀå °¡´É È¸¼ö¸¦ ³ÑÁö ¾Ê¾Ò³ª?
	if (pPlayer->GetChallengeZoneEnterFreq() >= ENTER_CHALLENGE_ZONE_FREQ_PER_DAY+pPlayer->GetChallengeZoneEnterBonusFreq())
	{
		eResult = RESULT_FAIL_02;
	}

	// Ã§¸°Áö Á¸¿¡¼­´Â ºÒ°¡´É
	if (IsChallengeZoneHere())
	{
		eResult = RESULT_FAIL_03;
	}

	// PK ¸ðµå ÁßÀº ºÒ°¡´É
	if (pPlayer->IsPKMode())
	{
		eResult = RESULT_FAIL_05;
	}

//---KES AUTONOTE
	if( pPlayer->GetAutoNoteIdx() )
	{
		eResult = RESULT_FAIL_06;
	}
//--------------

	// 090821 ONS ±æµåÅä³Ê¸ÕÆ®¸Ê ³»¿¡¼­´Â µ¥ÀÌÆ®¸ÞÄª ºÒ°¡´É.
	if(g_pServerSystem->GetMapNum() == 94)
	{
		eResult = RESULT_FAIL_13;
	}

	DWORD playerExperienceRate = 0;

	// 091124 ONS Ã§¸°ÁöÁ¸ °æÇèÄ¡ ºñÀ² ÀúÀå.
	if (nKind == 0)
	{
		DWORD dwPlayerExpRate = 0;
		DWORD dwTargetExpRate = 0;
		if( GENDER_MALE == pPlayer->GetGender() )
		{	
			dwPlayerExpRate = 100 - dwExpRate;
			dwTargetExpRate = dwExpRate;
		}	
		else
		{
			dwTargetExpRate = 100 - dwExpRate;
			dwPlayerExpRate = dwExpRate;
		}

		playerExperienceRate = dwPlayerExpRate;

		ChallengeZone_ExpRate_Save(pPlayer->GetID(), dwPlayerExpRate);
		ChallengeZone_ExpRate_Save(nTargetPlayerID,	dwTargetExpRate);
	}
	stPacket.Category			= MP_DATE;
	stPacket.Protocol			= MP_DATE_ENTER_CHALLENGEZONE_2;
	if (nKind != 0)
	{
		stPacket.Protocol		= MP_DATE_ENTER_CHALLENGEZONE_3;
	}
	stPacket.dwObjectID			= pPlayer->GetID();
	stPacket.dwData1			= nZoneIndex;
	stPacket.dwData2			= eResult;

	pPlayer->SendMsg(&stPacket, sizeof(stPacket));

	TCHAR text[MAX_PATH] = {0};
	_sntprintf(
		text,
		_countof(text),
		"map:%d, %d%%",
		GetMapType(nZoneIndex),
		playerExperienceRate);
	LogItemMoney(
		pPlayer->GetID(),
		pPlayer->GetObjectName(),
		nTargetPlayerID,
		text,
		eLog_DateMatchBegin,
		pPlayer->GetMoney(),
		0,
		0,
		0,
		0,
		0,
		0,
		0,
		0);
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_EnterChallengeZone Method																						  Ã§¸°Áö Á¸ ÀÔÀå
//
VOID CSHDateManager::SRV_EnterChallengeZone2(CPlayer* pPlayer, MSG_DWORD5* pPacket, int nKind)
{
#if defined(_MAPSERVER_)
	RESULT eResult = RESULT_OK;
	MSG_DWORD5 stPacket;

	// ÇÏ·ç ÀÔÀå °¡´É È¸¼ö¸¦ ³ÑÁö ¾Ê¾Ò³ª?
	if (pPlayer->GetChallengeZoneEnterFreq() >= ENTER_CHALLENGE_ZONE_FREQ_PER_DAY+pPlayer->GetChallengeZoneEnterBonusFreq())
	{
		eResult = RESULT_FAIL_02;
	}

	// Ã§¸°Áö Á¸¿¡¼­´Â ºÒ°¡´É
	if (IsChallengeZoneHere())
	{
		eResult = RESULT_FAIL_03;
	}

	// PK ¸ðµå ÁßÀº ºÒ°¡´É
	if (pPlayer->IsPKMode())
	{
		eResult = RESULT_FAIL_05;
	}

//---KES AUTONOTE
	if( pPlayer->GetAutoNoteIdx() )
	{
		eResult = RESULT_FAIL_06;	//=_=6¹øÀÌ ¸Ö±î.. ÀÏ´Ü »ç¿ëÇÏÀÚ
	}
//--------------

	// 090821 ONS ±æµåÅä³Ê¸ÕÆ®¸Ê ³»¿¡¼­´Â µ¥ÀÌÆ®¸ÞÄª ºÒ°¡´É.
	if(g_pServerSystem->GetMapNum() == 94)
	{
		eResult = RESULT_FAIL_13;
	}

	// 091124 ONS Ã§¸°ÁöÁ¸ °æÇèÄ¡ ºñÀ² ÀúÀå.
	if (nKind == 0)
	{
		DWORD dwExpRate = pPacket->dwData5;
		DWORD dwPlayerExpRate = 0;
		DWORD dwTargetExpRate = 0;
		if( GENDER_MALE == pPlayer->GetGender() )
		{	
			dwPlayerExpRate = 100 - dwExpRate;
			dwTargetExpRate = dwExpRate;
		}	
		else
		{
			dwTargetExpRate = 100 - dwExpRate;
			dwPlayerExpRate = dwExpRate;
		}

		ChallengeZone_ExpRate_Save(pPlayer->GetID(), dwPlayerExpRate);
		ChallengeZone_ExpRate_Save(pPacket->dwData2, dwTargetExpRate);
	}

	stPacket.Category			= MP_DATE;
	stPacket.Protocol			= MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_2;
	if (nKind != 0)
	{
		stPacket.Protocol		= MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_4;
	}
	stPacket.dwObjectID			= pPlayer->GetID();
	stPacket.dwData1			= pPacket->dwData1;
	stPacket.dwData2			= pPacket->dwData2;
	stPacket.dwData3			= pPacket->dwData3;
	stPacket.dwData4			= pPacket->dwData4;
	stPacket.dwData5			= eResult;

	pPlayer->SendMsg(&stPacket, sizeof(stPacket));	
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  ASRV_ParseRequestFromClient Method																 Å¬¶óÀÌ¾ðÆ® ¿äÃ» ºÐ¼®/Ã³¸®(¿¡ÀÌÀüÆ®)
//
VOID CSHDateManager::ASRV_ParseRequestFromClient(DWORD dwConnectionID, char* pMsg, DWORD dwLength)
{
#if defined(_AGENTSERVER)
	MSGBASE* pTempMsg = (MSGBASE*)pMsg;

	// Å¬¶óÀÌ¾ðÆ®¿¡¼­ ÆÐÅ¶ Á¶ÀÛÀ¸·Î ³²ÀÇ Ä³¸¯ÅÍ ID ¸¦ º¸³¾ ¼ö ÀÖ±â ¶§¹®¿¡
	// g_pUserTableForObjectID->FindUser ·Î UserInfo ¸¦ ±¸ÇÏ¸é ¾È µÊ!!
	USERINFO* pUserInfo = g_pUserTable->FindUser( dwConnectionID );
	if( pUserInfo == NULL ) return;
	pTempMsg->dwObjectID = pUserInfo->dwCharacterID;

	switch( pTempMsg->Protocol )
	{
	// µ¥ÀÌÆ® Á¸ ÀÔÀå
	// Ã§¸°Áö Á¸ ÀÔÀå
	case MP_DATE_ENTER_DATEZONE:
	case MP_DATE_ENTER_CHALLENGEZONE:
		{
			// 091124 ONS °æÇèÄ¡ºñÀ²À» Àü´ÞÇÏ±â À§ÇØ ¸Þ¼¼Áö ¼öÁ¤
			MSG_DWORD3* pPacket = (MSG_DWORD3*)pMsg;
			// ¿äÃ»ÀÚ°¡ Ã¤ÆÃÁßÀÎ ÇÃ·¹ÀÌ¾îÀÎ°¡?
			if (pUserInfo->DateMatchingInfo.nRequestChatState != DATE_MATCHING_CHAT_REQUEST_STATE_CHATTING)
			{
				return;
			}

			// ´ë»ó ÇÃ·¹ÀÌ¾î Ã£±â
			USERINFO* pTargetUserInfo = g_pUserTableForObjectID->FindUser(pUserInfo->DateMatchingInfo.nChatPlayerID);
			if (pTargetUserInfo == NULL)
			{
				// Ã¤ÆÃÀ» °­Á¦·Î ³¡³½´Ù.
				// ..¸ÊÀÌµ¿, ·Î±×¾Æ¿ô µîµîÀÇ °æ¿ì..
				pUserInfo->DateMatchingInfo.nRequestChatState			= DATE_MATCHING_CHAT_REQUEST_STATE_NONE;
				pUserInfo->DateMatchingInfo.nChatPlayerID				= 0;//NULL;
				// ..Ã¤ÆÃÀÌ Á¾·áµÇ¾úÀ½À» ¾Ë¸°´Ù.
				MSG_DWORD2 stPacket;
				stPacket.Category			= MP_RESIDENTREGIST;
				stPacket.Protocol			= MP_RESIDENTREGIST_DATEMATCHING_RESULT_REQUEST_CHAT;
				stPacket.dwObjectID			= pUserInfo->dwCharacterID;
				stPacket.dwData1			= DATE_MATCHING_CHAT_RESULT_END_CHAT;
				stPacket.dwData2			= 0;//NULL;										// »ó´ëID
				g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket) );
				return;
			}

			// ´ë»ó ÇÃ·¹ÀÌ¾îÀÇ ´ëÈ­ »ó´ë°¡ ¿äÃ»ÀÚÀÎ°¡?
			if (pTargetUserInfo->DateMatchingInfo.nChatPlayerID != pUserInfo->dwCharacterID)
			{
				// Ã¤ÆÃÀ» °­Á¦·Î ³¡³½´Ù.
				// ..¸ÊÀÌµ¿, ·Î±×¾Æ¿ô µîµîÀÇ °æ¿ì..
				pUserInfo->DateMatchingInfo.nRequestChatState			= DATE_MATCHING_CHAT_REQUEST_STATE_NONE;
				pUserInfo->DateMatchingInfo.nChatPlayerID				= 0;//NULL;
				// ..Ã¤ÆÃÀÌ Á¾·áµÇ¾úÀ½À» ¾Ë¸°´Ù.
				MSG_DWORD2 stPacket;
				stPacket.Category			= MP_RESIDENTREGIST;
				stPacket.Protocol			= MP_RESIDENTREGIST_DATEMATCHING_RESULT_REQUEST_CHAT;
				stPacket.dwObjectID			= pUserInfo->dwCharacterID;
				stPacket.dwData1			= DATE_MATCHING_CHAT_RESULT_END_CHAT;
				stPacket.dwData2			= 0;//NULL;										// »ó´ëID
				g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket) );
				return;
			}

			// Ã¤ÆÃ »ó´ë ID ÀÔ·Â
			pPacket->dwData2 = pUserInfo->DateMatchingInfo.nChatPlayerID;

			// »ó´ë¹æÀÇ ÀüÅõ»óÅÂ Ã¼Å©¸¦ À§ÇØ »ó´ë¹æ Å¬¶óÀÌ¾ðÆ®¿¡ Àü¼Û - ÀüÅõ»óÅÂ Ã¼Å©¸¦ Å¬¶óÀÌ¾ðÆ®¿¡¼­¸¸ ÇÔ
			g_Network.Send2User( pTargetUserInfo->dwConnectionIndex, pMsg, dwLength );
		}
		break;
	case MP_DATE_ENTER_DATEZONE_DIFF_AGENT:
	case MP_DATE_ENTER_CHALLENGEZONE_DIFF_AGENT:
		{
			MSG_DWORD3* pPacket = (MSG_DWORD3*)pMsg;
			// ¿äÃ»ÀÚ°¡ Ã¤ÆÃÁßÀÎ ÇÃ·¹ÀÌ¾îÀÎ°¡?
			if (pUserInfo->DateMatchingInfo.nRequestChatState != DATE_MATCHING_CHAT_REQUEST_STATE_CHATTING)
			{
				return;
			}

			// ´ë»ó ÇÃ·¹ÀÌ¾î Ã£±â
			// ..´ë»ó ÇÃ·¹ÀÌ¾î ¿¡ÀÌÀüÆ®¿¡ ¾Ë¸®±â
			MSG_DWORD5 stPacket;
			ZeroMemory(&stPacket, sizeof(stPacket));
			stPacket.Category			= MP_DATE;
			stPacket.Protocol			= pPacket->Protocol;;
			stPacket.dwObjectID			= pPacket->dwData2;
			stPacket.dwData1			= pUserInfo->DateMatchingInfo.nChatPlayerID;
			stPacket.dwData2			= pUserInfo->dwCharacterID;
			stPacket.dwData3			= g_pServerSystem->GetServerNum();
			stPacket.dwData4			= pPacket->dwData1;
			// 091223 ONS °æÇèÄ¡À² Àü´Þ Ã³¸® Ãß°¡
			stPacket.dwData5			= pPacket->dwData3;
			g_Network.Send2SpecificAgentServer((char*)&stPacket, sizeof(stPacket) );
		}
		break;
	// µ¥ÀÌÆ® Á¸ ÀÔÀå - »ó´ë¹æ ÀüÅõ »óÅÂ Ã¼Å© ÈÄ
	// Ã§¸°Áö Á¸ ÀÔÀå - »ó´ë¹æ ÀüÅõ »óÅÂ Ã¼Å© ÈÄ
	case MP_DATE_ENTER_DATEZONE_2:
	case MP_DATE_ENTER_CHALLENGEZONE_2:
		{
			MSG_DWORD2* pPacket = (MSG_DWORD2*)pMsg;

			// ´ë»ó ÇÃ·¹ÀÌ¾î Ã£±â. ´ë»ó ÇÃ·¹ÀÌ¾î°¡ ÆÄÆ¼ÀåÀÓ. Çò°¥¸®¸é ¾È µÇ¿ë~
			USERINFO* pTargetUserInfo = g_pUserTableForObjectID->FindUser(pUserInfo->DateMatchingInfo.nChatPlayerID);
			if (pTargetUserInfo == NULL)
			{
				return;
			}

			// ¿äÃ»ÀÚ°¡ Ã¤ÆÃÁßÀÎ ÇÃ·¹ÀÌ¾îÀÎ°¡?
			if (pTargetUserInfo->DateMatchingInfo.nRequestChatState != DATE_MATCHING_CHAT_REQUEST_STATE_CHATTING)
			{
				return;
			}

			// ÀüÅõ »óÅÂÀÎ°¡?
			if (pPacket->dwData2 != RESULT_OK)
			{
				goto FAILED;
			}

			// Ã¤ÆÃ »ó´ë ID ÀÔ·Â
			pPacket->dwObjectID = pTargetUserInfo->dwCharacterID;
			pPacket->dwData2 = pTargetUserInfo->DateMatchingInfo.nChatPlayerID;


			// ¸Ê¼­¹ö¿¡ Àü¼Û
			g_Network.Send2Server( pTargetUserInfo->dwMapServerConnectionIndex, pMsg, dwLength );
			return;

FAILED:
			MSG_DWORD stPacket;
			stPacket.Category			= MP_DATE;
			stPacket.Protocol			= pTempMsg->Protocol;
			stPacket.dwObjectID			= pUserInfo->dwCharacterID;
			stPacket.dwData				= pPacket->dwData2;
			g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));

			stPacket.Category			= MP_DATE;
			stPacket.Protocol			= pTempMsg->Protocol;
			stPacket.dwObjectID			= pTargetUserInfo->dwCharacterID;
			stPacket.dwData				= pPacket->dwData2;
			g_Network.Send2User( pTargetUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));
		}
		break;
	case MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT:
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT:
		{
			MSG_DWORD6* pPacket = (MSG_DWORD6*)pMsg;

			// ÀüÅõ »óÅÂÀÎ°¡?
			if (pPacket->dwData5 != RESULT_OK)
			{
				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= pTempMsg->Protocol;
				stPacket.dwObjectID			= pUserInfo->dwCharacterID;
				stPacket.dwData				= pPacket->dwData5;
				g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));

				// ´ë»ó ÇÃ·¹ÀÌ¾î ¿¡ÀÌÀüÆ®¿¡ ¾Ë¸®±â
				{
					MSG_DWORD2 stPacket;
					stPacket.Category			= MP_DATE;
					stPacket.Protocol			= MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_BATTLE_FOR_OTHER_AGENT;
					if (pPacket->Protocol == MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT)
					{
						stPacket.Protocol = MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_BATTLE_FOR_OTHER_AGENT;
					}
					stPacket.dwObjectID			= pPacket->dwData3;
					stPacket.dwData1			= pPacket->dwData2;
					stPacket.dwData2			= pPacket->dwData5;
					g_Network.Send2SpecificAgentServer((char*)&stPacket, sizeof(stPacket) );
				}
			}
			else
			{
				// ´ë»ó ÇÃ·¹ÀÌ¾î°¡ ÆÄÆ¼ÀåÀÌ±â¿¡ ÆÄÆ¼ »óÅÂ¸¦ Ã¼Å©ÇÏ±â À§ÇØ ´ë»ó ÇÃ·¹ÀÌ¾î ¿¡ÀÌÀüÆ®¿¡ ¾Ë¸®±â
				{
					MSG_DWORD5 stPacket;
					ZeroMemory(&stPacket, sizeof(stPacket));
					stPacket.Category			= MP_DATE;
					stPacket.Protocol			= MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT;
					if (pPacket->Protocol == MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT)
					{
						stPacket.Protocol = MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT;
					}
					stPacket.dwObjectID			= pPacket->dwData3;
					stPacket.dwData1			= pPacket->dwData2;
					stPacket.dwData2			= pUserInfo->dwCharacterID;
					stPacket.dwData3			= g_pServerSystem->GetServerNum();
					stPacket.dwData4			= pPacket->dwData4;
					// 091223 ONS °æÇèÄ¡À² Àü´Þ Ã³¸® Ãß°¡
					stPacket.dwData5			= pPacket->dwData6;
					g_Network.Send2SpecificAgentServer((char*)&stPacket, sizeof(stPacket) );
				}
			}
		}
		break;
	default:
		g_Network.Send2Server( pUserInfo->dwMapServerConnectionIndex, pMsg, dwLength );
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  ASRV_ParseRequestFromServer Method																	   ¼­¹ö ¿äÃ» ºÐ¼®/Ã³¸®(¿¡ÀÌÀüÆ®)
//
VOID CSHDateManager::ASRV_ParseRequestFromServer(DWORD dwConnectionID, char* pMsg, DWORD dwLength)
{
#if defined(_AGENTSERVER)
	MSGBASE* pTempMsg = (MSGBASE*)pMsg;
	
	// USERINFO ¸¦ ÂüÁ¶ÇÏÁö ¾Ê´Â °æ¿ì
	//
	switch( pTempMsg->Protocol )
	{
	case MP_DATE_ENTER_DATEZONE_DIFF_AGENT:
	case MP_DATE_ENTER_CHALLENGEZONE_DIFF_AGENT:
		{
			MSG_DWORD5* pPacket = (MSG_DWORD5*)pMsg;

			// ´ë»óÀÚ°¡ ÀÖ³ª?
			USERINFO* pTargetUserInfo = g_pUserTableForObjectID->FindUser(pPacket->dwData1);
			if (pTargetUserInfo == NULL)
			{
				return;
			}

			// ´ë»ó ÇÃ·¹ÀÌ¾îÀÇ ´ëÈ­ »ó´ë°¡ ¿äÃ»ÀÚÀÎ°¡?
			if (pTargetUserInfo->DateMatchingInfo.nChatPlayerID != pPacket->dwData2)
			{
				return;
			}

			// »ó´ë¹æÀÇ ÀüÅõ»óÅÂ Ã¼Å©¸¦ À§ÇØ »ó´ë¹æ Å¬¶óÀÌ¾ðÆ®¿¡ Àü¼Û - ÀüÅõ»óÅÂ Ã¼Å©¸¦ Å¬¶óÀÌ¾ðÆ®¿¡¼­¸¸ ÇÔ
			g_Network.Send2User( pTargetUserInfo->dwConnectionIndex, pMsg, dwLength );
		}
		return;
	case MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_BATTLE_FOR_OTHER_AGENT:
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_BATTLE_FOR_OTHER_AGENT:
		{
			MSG_DWORD2* pPacket = (MSG_DWORD2*)pMsg;

			// ¿äÃ»ÀÚ°¡ ÀÖ³ª?
			USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser(pPacket->dwData1);
			if (pUserInfo == NULL)
			{
				return;
			}

			// ´ë»óÀÚ°¡ ÀüÅõ»óÅÂÀÌ´Ù.
			MSG_DWORD stPacket;
			stPacket.Category			= MP_DATE;
			stPacket.Protocol			= pTempMsg->Protocol;
			stPacket.dwObjectID			= pUserInfo->dwCharacterID;
			stPacket.dwData				= pPacket->dwData2;
			g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));
		}
		return;
	case MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT:
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT:
		{
			MSG_DWORD5* pPacket = (MSG_DWORD5*)pMsg;

			// ¿äÃ»ÀÚ°¡ ÀÖ³ª?
			USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser(pPacket->dwData1);
			if (pUserInfo == NULL)
			{
				return;
			}

			// ÆÄÆ¼ »óÅÂ¸¦ Ã¼Å©ÇÑ´Ù.
			// ..¸Ê¼­¹ö¿¡ ¾Ë¸®±â
			MSG_DWORD5 stPacket;
			ZeroMemory(&stPacket, sizeof(stPacket));
			stPacket.Category			= MP_DATE;
			stPacket.Protocol			= pTempMsg->Protocol;
			stPacket.dwObjectID			= pUserInfo->dwCharacterID;
			stPacket.dwData1			= pPacket->dwData1;
			stPacket.dwData2			= pPacket->dwData2;
			stPacket.dwData3			= pPacket->dwData3;
			stPacket.dwData4			= pPacket->dwData4;
			// 091223 ONS °æÇèÄ¡À² Àü´Þ Ã³¸® Ãß°¡
			stPacket.dwData5			= pPacket->dwData5;
			g_Network.Send2Server( pUserInfo->dwMapServerConnectionIndex, (char*)&stPacket, sizeof(stPacket));
		}
		return;
	case MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_3:
		{
			MSG_DWORD4* pPacket = (MSG_DWORD4*)pMsg;

			// ¿äÃ»ÀÚ°¡ ÀÖ³ª?
			USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser(pPacket->dwData1);
			if (pUserInfo == NULL)
			{
				return;
			}

			// µ¥ÀÌÆ® Á¸À¸·Î ÀÌµ¿
			// ..ÀÌµ¿ ÀÎµ¦½º ¾ò±â
			int nZone = 0;
			if (GetDateZoneMoveIndex(pPacket->dwData4, &nZone) == FALSE)
			{
				return;
			}

			MSG_DWORD3 stPacket;
			stPacket.Category	= MP_USERCONN;
			stPacket.Protocol	= MP_USERCONN_CHANGEMAP_SYN;
			stPacket.dwObjectID	= pUserInfo->dwCharacterID;
			stPacket.dwData1	= nZone ;
			UserConn_ChangeMap_Syn(pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket) );
		}
		return;
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_3:
		{
			MSG_DWORD5* pPacket = (MSG_DWORD5*)pMsg;

			// ¿äÃ»ÀÚ°¡ ÀÖ³ª?
			USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser(pPacket->dwData1);
			if (pUserInfo == NULL)
			{
				return;
			}

			// ´ë»óÀÚÀÇ ÆÄÆ¼ »óÅÂ¸¦ Ã¼Å©ÇÑ´Ù.
			// ..¸Ê¼­¹ö¿¡ ¾Ë¸®±â
			MSG_DWORD5 stPacket;
			ZeroMemory(&stPacket, sizeof(stPacket));
			stPacket.Category			= MP_DATE;
			stPacket.Protocol			= MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_3;
			stPacket.dwObjectID			= pUserInfo->dwCharacterID;
			stPacket.dwData1			= pPacket->dwData1;
			stPacket.dwData2			= pPacket->dwData2;
			stPacket.dwData3			= pPacket->dwData3;
			stPacket.dwData4			= pPacket->dwData4;
			// 091223 ONS °æÇèÄ¡À² Àü´Þ Ã³¸® Ãß°¡
			stPacket.dwData5			= pPacket->dwData5;
			g_Network.Send2Server( pUserInfo->dwMapServerConnectionIndex, (char*)&stPacket, sizeof(stPacket));
		}
		return;
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_5:
		{
			MSG_DWORD5* pPacket = (MSG_DWORD5*)pMsg;

			USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser(pPacket->dwData1);
			if (pUserInfo == NULL)
			{
				return;
			}

			// ÆÄÆ®³Ê°¡ ÀÌ¹Ì Ã§¸°Áö Á¸À¸·Î ÀÔÀåÇÑ ÈÄ ÀÌ°÷ÀÌ ¼öÇàµÇ±â ¶§¹®¿¡ ÀÔÀå Á¶°ÇÀ» Ã¼Å©ÇÏ´Â °Ô º°·Î ÀÇ¹Ì°¡ ¾ø´Ù. ±×³É ÀÔÀå ½ÃÅ´.
			// Ã§¸°Áö Á¸À¸·Î ÀÌµ¿
			// ..¸ÊÀº ·£´ýÀ¸·Î..
			if (m_nChallengeZoneMoveIndexNum == 0) return;
			int nZone = pPacket->dwData5;

			// ..ÀÔÀå ±¸°£ ¼³Á¤
			if (ENTER_CHALLENGE_ZONE_SECTION_NUM == 0 || 
				pPacket->dwData4 >= ENTER_CHALLENGE_ZONE_SECTION_NUM) return;

			pUserInfo->nChallengeZoneEnterSection		= pPacket->dwData4;
			pUserInfo->nChallengeZoneEnterID			= pPacket->dwData3;

			// ..±ÍÈ¯ ¸Ê ¼³Á¤
			// ....Ã§¸°Áö Á¸¿¡¼­ Ã§¸°Áö Á¸À¸·Î ÀÌµ¿ÇÏ´Â °æ¿ì°¡ ¾Æ´Ò °æ¿ì¿¡¸¸.
			if (IsChallengeZone(pUserInfo->wUserMapNum) == FALSE)
			{
				pUserInfo->nChallengeZoneReturnMapNum		= pUserInfo->wUserMapNum;
			}

			// ..ÀÌµ¿
			MSG_DWORD3 stPacket;

			stPacket.Category	= MP_USERCONN;
			stPacket.Protocol	= MP_USERCONN_CHANGEMAP_SYN;
			stPacket.dwObjectID	= pUserInfo->dwCharacterID;
			stPacket.dwData1	= nZone ;
			UserConn_ChangeMap_Syn(pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket) );
		}
		return;
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_6:
		{
			MSG_DWORD2* pPacket = (MSG_DWORD2*)pMsg;

			// ¿äÃ»ÀÚ°¡ ÀÖ³ª?
			USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser(pPacket->dwData1);
			if (pUserInfo == NULL)
			{
				return;
			}

			// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â
			MSG_DWORD stPacket;
			stPacket.Category			= MP_DATE;
			stPacket.Protocol			= pTempMsg->Protocol;
			stPacket.dwObjectID			= pUserInfo->dwCharacterID;
			stPacket.dwData				= pPacket->dwData2;
			g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));
		}
		return;
	}

	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser(pTempMsg->dwObjectID);
	if (pUserInfo == NULL) return;


	switch( pTempMsg->Protocol )
	{
	// µ¥ÀÌÆ® Á¸ ÀÔÀå - ¸Ê¼­¹ö¿¡¼­ ÆÄÆ¼ È®ÀÎ ÈÄ
	case MP_DATE_ENTER_DATEZONE_2:
		{
			MSG_DWORD* pPacket = (MSG_DWORD*)pMsg;
			// ¿äÃ»ÀÚ°¡ Ã¤ÆÃÁßÀÎ ÇÃ·¹ÀÌ¾îÀÎ°¡?
			if (pUserInfo->DateMatchingInfo.nRequestChatState != DATE_MATCHING_CHAT_REQUEST_STATE_CHATTING)
			{
				return;
			}

			// ´ë»ó ÇÃ·¹ÀÌ¾î Ã£±â
			USERINFO* pTargetUserInfo = g_pUserTableForObjectID->FindUser(pUserInfo->DateMatchingInfo.nChatPlayerID);
			if (pTargetUserInfo == NULL)
			{
				return;
			}

			// µ¥ÀÌÆ® Á¸À¸·Î ÀÌµ¿
			// ..ÀÌµ¿ ÀÎµ¦½º ¾ò±â
			int nZone = 0;
			if (GetDateZoneMoveIndex(pPacket->dwData, &nZone) == FALSE)
			{
				return;
			}

			MSG_DWORD3 stPacket;

			stPacket.Category	= MP_USERCONN;
			stPacket.Protocol	= MP_USERCONN_CHANGEMAP_SYN;
			stPacket.dwObjectID	= pUserInfo->dwCharacterID;
			stPacket.dwData1	= nZone ;
			UserConn_ChangeMap_Syn(pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket) );

			stPacket.Category	= MP_USERCONN;
			stPacket.Protocol	= MP_USERCONN_CHANGEMAP_SYN;
			stPacket.dwObjectID	= pTargetUserInfo->dwCharacterID;
			stPacket.dwData1	= nZone ;
			UserConn_ChangeMap_Syn( pTargetUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));
		}
		break;
	case MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_2:
		{
			MSG_DWORD4* pPacket = (MSG_DWORD4*)pMsg;
			// ¿äÃ»ÀÚ°¡ Ã¤ÆÃÁßÀÎ ÇÃ·¹ÀÌ¾îÀÎ°¡?
			if (pUserInfo->DateMatchingInfo.nRequestChatState != DATE_MATCHING_CHAT_REQUEST_STATE_CHATTING)
			{
				return;
			}

			// µ¥ÀÌÆ® Á¸À¸·Î ÀÌµ¿
			// ..ÀÌµ¿ ÀÎµ¦½º ¾ò±â
			int nZone = 0;
			if (GetDateZoneMoveIndex(pPacket->dwData4, &nZone) == FALSE)
			{
				return;
			}

			MSG_DWORD3 stPacket;

			stPacket.Category	= MP_USERCONN;
			stPacket.Protocol	= MP_USERCONN_CHANGEMAP_SYN;
			stPacket.dwObjectID	= pUserInfo->dwCharacterID;
			stPacket.dwData1	= nZone ;
			UserConn_ChangeMap_Syn(pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket) );

			// ´ë»óÀÚ ¿¡ÀÌÀüÆ®¿¡ ¾Ë¸®±â
			{
				MSG_DWORD4 stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_3;
				stPacket.dwObjectID			= pPacket->dwData3;
				stPacket.dwData1			= pPacket->dwData2;
				stPacket.dwData2			= pUserInfo->dwCharacterID;
				stPacket.dwData3			= g_pServerSystem->GetServerNum();
				stPacket.dwData4			= pPacket->dwData4;
				g_Network.Send2SpecificAgentServer((char*)&stPacket, sizeof(stPacket) );
			}
		}
		break;
	// Ã§¸°Áö Á¸ ÀÔÀå - ¸Ê¼­¹ö¿¡¼­ ÆÄÆ¼ È®ÀÎ ÈÄ, ÆÄÆ®³ÊÀÇ ÀÔÀå °¡´É È¸¼ö¸¦ Ã¼Å©..
	case MP_DATE_ENTER_CHALLENGEZONE_2:
		{
			MSG_DWORD2* pPacket = (MSG_DWORD2*)pMsg;
			// ¿äÃ»ÀÚ°¡ Ã¤ÆÃÁßÀÎ ÇÃ·¹ÀÌ¾îÀÎ°¡?
			if (pUserInfo->DateMatchingInfo.nRequestChatState != DATE_MATCHING_CHAT_REQUEST_STATE_CHATTING)
			{
				return;
			}

			// ´ë»ó ÇÃ·¹ÀÌ¾î Ã£±â
			USERINFO* pTargetUserInfo = g_pUserTableForObjectID->FindUser(pUserInfo->DateMatchingInfo.nChatPlayerID);
			if (pTargetUserInfo == NULL)
			{
				return;
			}

			if (pPacket->dwData2 == RESULT_OK)
			{
				// ÆÄÆ¼ÀåÀÌ ÆÄÆ¼ »óÅÂ¿Í ÀÚ½ÅÀÇ ÀÔÀå È¸¼ö¸¦ Ã¼Å©ÇÏ°í ¿ÔÀ¸´Ï
				// ÀÌ¹ø¿£ ÆÄÆ®³ÊÀÇ ÀÔÀå È¸¼ö¸¦ Ã¼Å©ÇÏ±â À§ÇØ ¶Ç ¸Ê¼­¹ö·Î.. ÇíÇí..
				MSG_DWORD2 stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= MP_DATE_ENTER_CHALLENGEZONE_3;
				stPacket.dwObjectID			= pTargetUserInfo->dwCharacterID;
				stPacket.dwData1			= pPacket->dwData1;
				g_Network.Send2Server( pTargetUserInfo->dwMapServerConnectionIndex, (char*)&stPacket, sizeof(stPacket) );
			}
			else
			{
				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= pTempMsg->Protocol;
				stPacket.dwObjectID			= pUserInfo->dwCharacterID;
				stPacket.dwData				= pPacket->dwData2;
				g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));
			}
		}
		break;
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_2:
		{
			MSG_DWORD5* pPacket = (MSG_DWORD5*)pMsg;
			// ¿äÃ»ÀÚ°¡ Ã¤ÆÃÁßÀÎ ÇÃ·¹ÀÌ¾îÀÎ°¡?
			if (pUserInfo->DateMatchingInfo.nRequestChatState != DATE_MATCHING_CHAT_REQUEST_STATE_CHATTING)
			{
				return;
			}

			if (pPacket->dwData5 == RESULT_OK)
			{
				// ÆÄÆ¼ÀåÀÌ ÆÄÆ¼ »óÅÂ¿Í ÀÚ½ÅÀÇ ÀÔÀå È¸¼ö¸¦ Ã¼Å©ÇÏ°í ¿ÔÀ¸´Ï
				// ÀÌ¹ø¿£ ÆÄÆ®³ÊÀÇ ÀÔÀå È¸¼ö¸¦ Ã¼Å©ÇÏ±â À§ÇØ ¶Ç ¸Ê¼­¹ö·Î.. ÇíÇí..
				// ¿¡ÀÌÀüÆ®°¡ ´Ù¸£¹Ç·Î ´ë»óÀÚ ¿¡ÀÌÀüÆ®·Î..
				MSG_DWORD5 stPacket;
				ZeroMemory(&stPacket, sizeof(stPacket));
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_3;
				stPacket.dwObjectID			= pPacket->dwData3;
				stPacket.dwData1			= pPacket->dwData2;
				stPacket.dwData2			= pUserInfo->dwCharacterID;
				stPacket.dwData3			= g_pServerSystem->GetServerNum();
				stPacket.dwData4			= pPacket->dwData4;
				g_Network.Send2SpecificAgentServer((char*)&stPacket, sizeof(stPacket) );
			}
			else
			{
				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= pTempMsg->Protocol;
				stPacket.dwObjectID			= pUserInfo->dwCharacterID;
				stPacket.dwData				= pPacket->dwData5;
				g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));
			}
		}
		break;
	// Ã§¸°Áö Á¸ ÀÔÀå - ÆÄÆ®³ÊÀÇ ÀÔÀå °¡´É È¸¼ö È®ÀÎ ÈÄ
	case MP_DATE_ENTER_CHALLENGEZONE_3:
		{
			MSG_DWORD2* pPacket = (MSG_DWORD2*)pMsg;
			// ¿äÃ»ÀÚ°¡ Ã¤ÆÃÁßÀÎ ÇÃ·¹ÀÌ¾îÀÎ°¡?
			if (pUserInfo->DateMatchingInfo.nRequestChatState != DATE_MATCHING_CHAT_REQUEST_STATE_CHATTING)
			{
				return;
			}

			// ´ë»ó ÇÃ·¹ÀÌ¾î Ã£±â
			USERINFO* pTargetUserInfo = g_pUserTableForObjectID->FindUser(pUserInfo->DateMatchingInfo.nChatPlayerID);
			if (pTargetUserInfo == NULL)
			{
				return;
			}

			if (pPacket->dwData2 == RESULT_OK)
			{
				// Ã§¸°Áö Á¸À¸·Î ÀÌµ¿
				// ..¸ÊÀº ·£´ýÀ¸·Î..
				if (m_nChallengeZoneMoveIndexNum == 0) return;
				
				const int nRand = rand()%m_nChallengeZoneMoveIndexNum;
				const int nZone = m_pstChallengeZoneMoveIndexList[nRand].nMoveIndex;
				const MAPTYPE mapNum = MAPTYPE(m_pstChallengeZoneMoveIndexList[nRand].nMapNum);

				if (ENTER_CHALLENGE_ZONE_SECTION_NUM == 0 || 
					pPacket->dwData1 >= ENTER_CHALLENGE_ZONE_SECTION_NUM) return;
				pUserInfo->nChallengeZoneEnterSection		= pPacket->dwData1;
				pTargetUserInfo->nChallengeZoneEnterSection = pPacket->dwData1;

				// ..ÀÔÀå ¼ø¼­ ¼³Á¤
				// ....¿¡ÀÌÀüÆ®°¡ ¿©·¯°³ÀÏ ¶§´Â ¿¡ÀÌÀüÆ® º°·Î ±¸ºÐÀ» Áö¾î¾ß ÇÏ¹Ç·Î ¿¡ÀÌÀüÆ®³¢¸® 100000000 ÀÇ °£°Ý ¼³Á¤
				// ....0 ¹ø ¿¡ÀÌÀüÆ® 0 ~ 100000000, 1 ¹ø ¿¡ÀÌÀüÆ® 100000000 ~ 200000000, 2 ¹ø ¿¡ÀÌÀüÆ® 200000000 ~ 300000000 ....
				// ....±×·¸±â¿¡ ¿¡ÀÌÀüÆ® ¹øÈ£´Â ÀûÀº ¼öºÎÅÍ 1¾¿ Áõ°¡ÇØ¾ßÇÏ¸ç 42°³(¿¡ÀÌÀüÆ® ÇÏ³ª´ç 1¾ïÀ» ÇÒ´çÇÒ ¶§)¸¦ ³ÑÁö ¾Ê´Â °ÍÀÌ ¹®Á¦°¡
				// ....¹ß»ýÇÒ È®·üÀÌ Àû´Ù.
				pUserInfo->nChallengeZoneEnterID			= m_nChallengeZoneEnterNum + g_pServerSystem->GetServerNum()*100000000;
				pTargetUserInfo->nChallengeZoneEnterID		= m_nChallengeZoneEnterNum + g_pServerSystem->GetServerNum()*100000000;
				m_nChallengeZoneEnterNum++;
				// ..È¤½Ã ÃÖ´ë¹üÀ§¸¦ ³ÑÀ» °æ¿ì ±âº»°ªÀ¸·Î ¼³Á¤. ¼­¹ö°¡ ÄÑÁø ÀÌÈÄ·Î 42xxxxxxxx ¹øÀÇ ¸ÅÄª Ã§¸°Áö ½ÇÇà...°ú¿¬ ÀÌ·±ÀÏÀÌ..?
				if (m_nChallengeZoneEnterNum < 1000) m_nChallengeZoneEnterNum = 1000;

				// ..±ÍÈ¯ ¸Ê ¼³Á¤
				// ....Ã§¸°Áö Á¸¿¡¼­ Ã§¸°Áö Á¸À¸·Î ÀÌµ¿ÇÏ´Â °æ¿ì°¡ ¾Æ´Ò °æ¿ì¿¡¸¸.
				if (IsChallengeZone(pUserInfo->wUserMapNum) == FALSE)
				{
					pUserInfo->nChallengeZoneReturnMapNum		= pUserInfo->wUserMapNum;
					pTargetUserInfo->nChallengeZoneReturnMapNum	= pTargetUserInfo->wUserMapNum;
				}

				WORD wServerPort = g_pServerTable->GetServerPort( eSK_MAP, (WORD)mapNum );
				SERVERINFO* pInfo = g_pServerTable->FindServer( wServerPort );				
				if( pInfo )
				{
					MSG_DWORD2 msg;
					msg.Category = MP_PARTY;
					msg.Protocol = MP_PARTY_INSTANTPARTY_REGIST_SYN;
					msg.dwObjectID = pUserInfo->dwCharacterID;
					msg.dwData1 = pUserInfo->dwCharacterID;
					msg.dwData2 = pUserInfo->dwCharacterID;
					g_Network.Send2Server( pInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );

					msg.Category = MP_PARTY;
					msg.Protocol = MP_PARTY_INSTANTPARTY_REGIST_SYN;
					msg.dwObjectID = pTargetUserInfo->dwCharacterID;
					msg.dwData1 = pTargetUserInfo->dwCharacterID;
					msg.dwData2 = pUserInfo->dwCharacterID;
					g_Network.Send2Server( pInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
				}

				// ..ÀÌµ¿
				MSG_DWORD3 stPacket;

				stPacket.Category	= MP_USERCONN;
				stPacket.Protocol	= MP_USERCONN_CHANGEMAP_SYN;
				stPacket.dwObjectID	= pUserInfo->dwCharacterID;
				stPacket.dwData1	= nZone ;
				UserConn_ChangeMap_Syn(pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket) );

				stPacket.Category	= MP_USERCONN;
				stPacket.Protocol	= MP_USERCONN_CHANGEMAP_SYN;
				stPacket.dwObjectID	= pTargetUserInfo->dwCharacterID;
				stPacket.dwData1	= nZone ;
				UserConn_ChangeMap_Syn( pTargetUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));
			}
			else
			{
				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= pTempMsg->Protocol;
				stPacket.dwObjectID			= pTargetUserInfo->dwCharacterID;
				stPacket.dwData				= pPacket->dwData2;
				g_Network.Send2User( pTargetUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));
			}
		}
		break;
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_4:
		{
			MSG_DWORD5* pPacket = (MSG_DWORD5*)pMsg;
			// ¿äÃ»ÀÚ°¡ Ã¤ÆÃÁßÀÎ ÇÃ·¹ÀÌ¾îÀÎ°¡?
			if (pUserInfo->DateMatchingInfo.nRequestChatState != DATE_MATCHING_CHAT_REQUEST_STATE_CHATTING)
			{
				return;
			}

			if (pPacket->dwData5 == RESULT_OK)
			{
				// Ã§¸°Áö Á¸À¸·Î ÀÌµ¿
				// ..¸ÊÀº ·£´ýÀ¸·Î..
				if (m_nChallengeZoneMoveIndexNum == 0) return;
				
				const int nRand = rand()%m_nChallengeZoneMoveIndexNum;
				const int nZone = m_pstChallengeZoneMoveIndexList[nRand].nMoveIndex;
				const MAPTYPE mapNum = MAPTYPE(m_pstChallengeZoneMoveIndexList[nRand].nMapNum);

				if (ENTER_CHALLENGE_ZONE_SECTION_NUM == 0 || 
					pPacket->dwData4 >= ENTER_CHALLENGE_ZONE_SECTION_NUM) return;
				pUserInfo->nChallengeZoneEnterSection		= pPacket->dwData4;

				// ..ÀÔÀå ¼ø¼­ ¼³Á¤
				// ....¿¡ÀÌÀüÆ®°¡ ¿©·¯°³ÀÏ ¶§´Â ¿¡ÀÌÀüÆ® º°·Î ±¸ºÐÀ» Áö¾î¾ß ÇÏ¹Ç·Î ¿¡ÀÌÀüÆ®³¢¸® 100000000 ÀÇ °£°Ý ¼³Á¤
				// ....0 ¹ø ¿¡ÀÌÀüÆ® 0 ~ 100000000, 1 ¹ø ¿¡ÀÌÀüÆ® 100000000 ~ 200000000, 2 ¹ø ¿¡ÀÌÀüÆ® 200000000 ~ 300000000 ....
				// ....±×·¸±â¿¡ ¿¡ÀÌÀüÆ® ¹øÈ£´Â ÀûÀº ¼öºÎÅÍ 1¾¿ Áõ°¡ÇØ¾ßÇÏ¸ç 42°³(¿¡ÀÌÀüÆ® ÇÏ³ª´ç 1¾ïÀ» ÇÒ´çÇÒ ¶§)¸¦ ³ÑÁö ¾Ê´Â °ÍÀÌ ¹®Á¦°¡
				// ....¹ß»ýÇÒ È®·üÀÌ Àû´Ù.
				pUserInfo->nChallengeZoneEnterID			= m_nChallengeZoneEnterNum + g_pServerSystem->GetServerNum()*100000000;
				m_nChallengeZoneEnterNum++;
				// ..È¤½Ã ÃÖ´ë¹üÀ§¸¦ ³ÑÀ» °æ¿ì ±âº»°ªÀ¸·Î ¼³Á¤. ¼­¹ö°¡ ÄÑÁø ÀÌÈÄ·Î 42xxxxxxxx ¹øÀÇ ¸ÅÄª Ã§¸°Áö ½ÇÇà...°ú¿¬ ÀÌ·±ÀÏÀÌ..?
				if (m_nChallengeZoneEnterNum < 1000) m_nChallengeZoneEnterNum = 1000;

				// ..±ÍÈ¯ ¸Ê ¼³Á¤
				// ....Ã§¸°Áö Á¸¿¡¼­ Ã§¸°Áö Á¸À¸·Î ÀÌµ¿ÇÏ´Â °æ¿ì°¡ ¾Æ´Ò °æ¿ì¿¡¸¸.
				if (IsChallengeZone(pUserInfo->wUserMapNum) == FALSE)
				{
					pUserInfo->nChallengeZoneReturnMapNum		= pUserInfo->wUserMapNum;
				}

				WORD wServerPort = g_pServerTable->GetServerPort( eSK_MAP, (WORD)mapNum );
				SERVERINFO* pInfo = g_pServerTable->FindServer( wServerPort );				
				if( pInfo )
				{
					MSG_DWORD2 msg;
					msg.Category = MP_PARTY;
					msg.Protocol = MP_PARTY_INSTANTPARTY_REGIST_SYN;
					msg.dwObjectID = pUserInfo->dwCharacterID;
					msg.dwData1 = pUserInfo->dwCharacterID;
					msg.dwData2 = pUserInfo->dwCharacterID;
					g_Network.Send2Server( pInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );

					msg.Category = MP_PARTY;
					msg.Protocol = MP_PARTY_INSTANTPARTY_REGIST_SYN;
					msg.dwObjectID = pUserInfo->DateMatchingInfo.nChatPlayerID;
					msg.dwData1 = pUserInfo->DateMatchingInfo.nChatPlayerID;
					msg.dwData2 = pUserInfo->dwCharacterID;
					g_Network.Send2Server( pInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
				}

				// ..ÀÌµ¿
				MSG_DWORD3 stPacket;

				stPacket.Category	= MP_USERCONN;
				stPacket.Protocol	= MP_USERCONN_CHANGEMAP_SYN;
				stPacket.dwObjectID	= pUserInfo->dwCharacterID;
				stPacket.dwData1	= nZone ;
				UserConn_ChangeMap_Syn(pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket) );

				// ..´ë»óÀÚ ¿¡ÀÌÀüÆ®¿¡ ¾Ë¸®±â
				{
					MSG_DWORD5 stPacket;
					stPacket.Category			= MP_DATE;
					stPacket.Protocol			= MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_5;
					stPacket.dwObjectID			= pPacket->dwData3;
					stPacket.dwData1			= pPacket->dwData2;
					stPacket.dwData2			= pPacket->dwData1;
					stPacket.dwData3			= pUserInfo->nChallengeZoneEnterID;
					stPacket.dwData4			= pPacket->dwData4;
					stPacket.dwData5			= nZone;
					g_Network.Send2SpecificAgentServer((char*)&stPacket, sizeof(stPacket) );
				}
			}
			else
			{
				// Å¬¶óÀÌ¾ðÆ®¿¡ ¾Ë¸®±â
				MSG_DWORD stPacket;
				stPacket.Category			= MP_DATE;
				stPacket.Protocol			= pTempMsg->Protocol;
				stPacket.dwObjectID			= pUserInfo->dwCharacterID;
				stPacket.dwData				= pPacket->dwData5;
				g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket));

				// ´ë»óÀÚ ¿¡ÀÌÀüÆ®¿¡ ¾Ë¸®±â
				{
					MSG_DWORD2 stPacket;
					stPacket.Category			= MP_DATE;
					stPacket.Protocol			= MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_6;
					stPacket.dwObjectID			= pPacket->dwData3;
					stPacket.dwData1			= pPacket->dwData2;
					stPacket.dwData2			= pPacket->dwData5;
					g_Network.Send2SpecificAgentServer((char*)&stPacket, sizeof(stPacket) );
				}
			}
		}
		break;
	// Ã§¸°Áö Á¸¿¡¼­ ÀÌÀü ¸ÊÀ¸·Î ±ÍÈ¯
	case MP_DATE_CHALLENGEZONE_RETURN:
		{
			LoadCharacterMap(pUserInfo->dwCharacterID);
		}
		break;
	default:
		g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)pMsg, dwLength );
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  SRV_ParseRequestFromClient Method																		   Å¬¶óÀÌ¾ðÆ® ¿äÃ» ºÐ¼®/Ã³¸®
//
VOID CSHDateManager::SRV_ParseRequestFromClient(DWORD dwConnectionID, char* pMsg, DWORD dwLength)
{
#if defined(_MAPSERVER_)
	MSGBASE* pPacket = (MSGBASE*)pMsg;

	// Àß¸øµÈ ÇÃ·¹ÀÌ¾î Ã³¸®
	CPlayer* pPlayer = (CPlayer*)g_pUserTable->FindUser( pPacket->dwObjectID );
	if( !pPlayer )	
	{
		return;
	}

	switch(pPacket->Protocol)
	{
	// µ¥ÀÌÆ® Á¸ ÀÔÀå 
	case MP_DATE_ENTER_DATEZONE_2:
		{
			MSG_DWORD2* pPacket = (MSG_DWORD2*)pMsg;
			SRV_EnterDateZone(pPlayer, pPacket->dwData2, pPacket->dwData1);
		}
		break;
	case MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT:
		{
			MSG_DWORD4* pPacket = (MSG_DWORD4*)pMsg;
			SRV_EnterDateZone2(pPlayer, pPacket);
		}
		break;
	// Ã§¸°Áö Á¸ ÀÔÀå 
	case MP_DATE_ENTER_CHALLENGEZONE_2:
		{
			// 091124 ONS °æÇèÄ¡ºñÀ²À» Àü´ÞÇÑ´Ù.
			MSG_DWORD3* pPacket = (MSG_DWORD3*)pMsg;
			SRV_EnterChallengeZone(pPlayer, pPacket->dwData2, pPacket->dwData1, pPacket->dwData3);
		}
		break;
	case MP_DATE_ENTER_CHALLENGEZONE_3:
		{
			MSG_DWORD2* pPacket = (MSG_DWORD2*)pMsg;
			// 091124 ONS °æÇèÄ¡ºñÀ²À» Àü´ÞÇÑ´Ù.
			SRV_EnterChallengeZone(pPlayer, pPacket->dwData2, pPacket->dwData1, 0, 1);
		}
		break;
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT:
		{
			MSG_DWORD5* pPacket = (MSG_DWORD5*)pMsg;
			SRV_EnterChallengeZone2(pPlayer, pPacket);
		}
		break;
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_3:
		{
			MSG_DWORD5* pPacket = (MSG_DWORD5*)pMsg;
			SRV_EnterChallengeZone2(pPlayer, pPacket, 1);
		}
		break;
	}
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  CLI_IsPossibleEnterDateZone Method																		  µ¥ÀÌÆ® Á¸ ÀÔÀåÀÌ °¡´ÉÇÑ°¡?
//
BOOL CSHDateManager::CLI_IsPossibleEnterDateZone()
{
#if !defined(_MAPSERVER_) && !defined(_AGENTSERVER)
	CDateMatchingDlg* pDlg = GAMEIN->GetDateMatchingDlg() ;

	if( pDlg &&
		pDlg->GetChatingDlg()->IsOnChatMode() &&
		HERO->GetGender() != g_csResidentRegistManager.CLI_GetChatPartner().stRegistInfo.nSex)
	{
		return TRUE;
	}

#endif
	return FALSE;
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  CLI_IsPossibleEnterChallengeZone Method																	  Ã§¸°Áö Á¸ ÀÔÀåÀÌ °¡´ÉÇÑ°¡?
//
BOOL CSHDateManager::CLI_IsPossibleEnterChallengeZone()
{
#if !defined(_MAPSERVER_) && !defined(_AGENTSERVER)
	CDateMatchingDlg* pDlg = GAMEIN->GetDateMatchingDlg() ;

	if( pDlg &&
		pDlg->GetChatingDlg()->IsOnChatMode() &&
		HERO->GetGender() != g_csResidentRegistManager.CLI_GetChatPartner().stRegistInfo.nSex &&
		g_csResidentRegistManager.CLI_GetChatPartner().nMatchingPoint >= ENTER_CHALLENGE_ZONE_MATCHING_POINT &&
		IsChallengeZoneHere() == FALSE)
	{
		return TRUE;
	}

#endif
	return FALSE;
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  CLI_RequestDateMatchingEnterDateZone Method															  µ¥ÀÌÆ® ¸ÅÄª µ¥ÀÌÆ® Á¸ ÀÔÀå ¿äÃ»
//
VOID CSHDateManager::CLI_RequestDateMatchingEnterDateZone(int nZoneIndex)
{
#if !defined(_MAPSERVER_) && !defined(_AGENTSERVER)
	if (HERO->GetObjectBattleState() == eObjectBattleState_Battle)
	{
		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1209) );
		return;
	}

	MSG_DWORD2 stPacket;
	stPacket.Category 		= MP_DATE;
	stPacket.Protocol 		= MP_DATE_ENTER_DATEZONE;
	stPacket.dwObjectID		= HEROID;
	stPacket.dwData1		= nZoneIndex;

	if (g_csResidentRegistManager.CLI_GetChatPartner().nAgentID >= 1000)
	{
		stPacket.Protocol 		= MP_DATE_ENTER_DATEZONE_DIFF_AGENT;
		stPacket.dwData2		= g_csResidentRegistManager.CLI_GetChatPartner().nAgentID - 1000;
	}

	NETWORK->Send( (MSGROOT*)&stPacket, sizeof(stPacket) );
#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  CLI_RequestDateMatchingEnterChallengeZone Method													  µ¥ÀÌÆ® ¸ÅÄª Ã§¸°Áö Á¸ ÀÔÀå ¿äÃ»
//
VOID CSHDateManager::CLI_RequestDateMatchingEnterChallengeZone(int nZoneIndex, DWORD dwExpRate)
{
#if !defined(_MAPSERVER_) && !defined(_AGENTSERVER)
	if (HERO->GetObjectBattleState() == eObjectBattleState_Battle)
	{
		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1209) );
		return;
	}

	// 091124 ONS °æÇèÄ¡ºñÀ²À» Àü´ÞÇÏµµ·Ï ÆÐÅ¶ ¼öÁ¤
	MSG_DWORD3 stPacket;
	stPacket.Category 		= MP_DATE;
	stPacket.Protocol 		= MP_DATE_ENTER_CHALLENGEZONE;
	stPacket.dwObjectID		= HEROID;
	stPacket.dwData1		= nZoneIndex;

	if (g_csResidentRegistManager.CLI_GetChatPartner().nAgentID >= 1000)
	{
		stPacket.Protocol 		= MP_DATE_ENTER_CHALLENGEZONE_DIFF_AGENT;
		stPacket.dwData2		= g_csResidentRegistManager.CLI_GetChatPartner().nAgentID - 1000;
	}

	stPacket.dwData3			= dwExpRate;

	NETWORK->Send( (MSGROOT*)&stPacket, sizeof(stPacket) );
	WINDOWMGR->MsgBox( MBI_MATCHAT_CONFIRM, MBT_OK, CHATMGR->GetChatMsg( 2219 ) );

#endif
}

// -------------------------------------------------------------------------------------------------------------------------------------
//  CLI_ParseAnswerFromSrv Method																			  ¼­¹ö·ÎºÎÅÍÀÇ ÀÀ´ä ºÐ¼®/Ã³¸®
//
VOID CSHDateManager::CLI_ParseAnswerFromSrv(void* pMsg)
{
#if !defined(_MAPSERVER_) && !defined(_AGENTSERVER)
	MSGBASE* pTmp = (MSGBASE*)pMsg;

	switch(pTmp->Protocol)
	{
	// µ¥ÀÌÆ® Á¸ ÀÔÀåÀ» À§ÇÑ ÀüÅõ »óÅÂ Ã¼Å©
	case MP_DATE_ENTER_DATEZONE:
		{
			MSG_DWORD2* pPacket = (MSG_DWORD2*)pMsg;
			MSG_DWORD2 stPacket;

			stPacket.Category 		= MP_DATE;
			stPacket.Protocol 		= MP_DATE_ENTER_DATEZONE_2;
			stPacket.dwObjectID		= HEROID;
			stPacket.dwData1		= pPacket->dwData1;
			stPacket.dwData2		= RESULT_OK;
			if (HERO->GetObjectBattleState() == eObjectBattleState_Battle)
			{
				stPacket.dwData2 = RESULT_FAIL_01;
			}

			NETWORK->Send( (MSGROOT*)&stPacket, sizeof(stPacket) );
		}
		break;
	// µ¥ÀÌÆ® Á¸ ÀÔÀåÀ» À§ÇÑ ÀüÅõ »óÅÂ Ã¼Å©
	case MP_DATE_ENTER_DATEZONE_DIFF_AGENT:
		{
			MSG_DWORD4* pPacket = (MSG_DWORD4*)pMsg;
			MSG_DWORD5 stPacket;

			stPacket.Category 		= MP_DATE;
			stPacket.Protocol 		= MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT;
			stPacket.dwObjectID		= HEROID;
			stPacket.dwData1		= pPacket->dwData1;
			stPacket.dwData2		= pPacket->dwData2;
			stPacket.dwData3		= pPacket->dwData3;
			stPacket.dwData4		= pPacket->dwData4;
			stPacket.dwData5		= RESULT_OK;
			if (HERO->GetObjectBattleState() == eObjectBattleState_Battle)
			{
				stPacket.dwData5 = RESULT_FAIL_01;
			}

			NETWORK->Send( (MSGROOT*)&stPacket, sizeof(stPacket) );
		}
		break;
	// Ã§¸°Áö Á¸ ÀÔÀåÀ» À§ÇÑ ÀüÅõ »óÅÂ Ã¼Å©
	case MP_DATE_ENTER_CHALLENGEZONE:
		{
			// 091124 ONS °æÇèÄ¡ºñÀ²À» Àü´ÞÇÏµµ·Ï ÆÐÅ¶ ¼öÁ¤
			MSG_DWORD3* pPacket = (MSG_DWORD3*)pMsg;

			DWORD dwZoneIndex = pPacket->dwData1;
			DWORD dwExpRate = pPacket->dwData3;

			GAMEIN->GetChallengeZoneListDlg()->SetActive(TRUE);
			GAMEIN->GetChallengeZoneListDlg()->SetGuestMode(dwZoneIndex, dwExpRate);
		}
		break;
	// Ã§¸°Áö Á¸ ÀÔÀåÀ» À§ÇÑ ÀüÅõ »óÅÂ Ã¼Å©
	case MP_DATE_ENTER_CHALLENGEZONE_DIFF_AGENT:
		{
			MSG_DWORD5* pPacket = (MSG_DWORD5*)pMsg;

			DWORD dwPartnerIndex = pPacket->dwData2;
			DWORD dwDiffAgentID = pPacket->dwData3;
			DWORD dwZoneIndex = pPacket->dwData4;
			DWORD dwExpRate = pPacket->dwData5;

			GAMEIN->GetChallengeZoneListDlg()->SetActive(TRUE);
			GAMEIN->GetChallengeZoneListDlg()->SetGuestMode(dwZoneIndex, dwExpRate, TRUE, dwDiffAgentID, dwPartnerIndex);
		}
		break;
	// µ¥ÀÌÆ® Á¸ ÀÔÀå ºÒ°¡
	// Ã§¸°Áö Á¸ ÀÔÀå ºÒ°¡
	case MP_DATE_ENTER_DATEZONE_2:
	case MP_DATE_ENTER_CHALLENGEZONE_2:
	case MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT:
	case MP_DATE_ENTER_DATEZONE_2_DIFF_AGENT_CHECK_BATTLE_FOR_OTHER_AGENT:
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT:
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_BATTLE_FOR_OTHER_AGENT:
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_2:
		{
			MSG_DWORD* pPacket = (MSG_DWORD*)pMsg;
			switch(pPacket->dwData)
			{
			case RESULT_FAIL_01:		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1209) );	break;
			case RESULT_FAIL_02:		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1210) );	break;
//			case RESULT_FAIL_03:		CHATMGR->AddMsg( CTC_SYSMSG, "ÀÌ¹Ì Ã§¸°Áö ÁßÀÔ´Ï´Ù." );		break;
			case RESULT_FAIL_04:		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1211) );	break;
			case RESULT_FAIL_05:		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1263) );	break;
			// 090821 ONS ±æµå Åä³Ê¸ÕÆ® ¸Ê¿¡¼­ µ¥ÀÌÆ®¸ÅÄª ÀÌµ¿ ±ÝÁö.
			case RESULT_FAIL_13:		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1656) );	break;
			}
		}
		break;
	case MP_DATE_ENTER_CHALLENGEZONE_3:
	case MP_DATE_ENTER_CHALLENGEZONE_2_DIFF_AGENT_CHECK_PARTY_FOR_OTHER_AGENT_6:
		{
			MSG_DWORD* pPacket = (MSG_DWORD*)pMsg;
			switch(pPacket->dwData)
			{
			case RESULT_FAIL_02:		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1212) );			break;
//			case RESULT_FAIL_03:		CHATMGR->AddMsg( CTC_SYSMSG, "ÆÄÆ®³Ê°¡ ÀÌ¹Ì Ã§¸°Áö ÁßÀÔ´Ï´Ù." );	break;
			case RESULT_FAIL_04:		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1213) );			break;
			case RESULT_FAIL_05:		CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1264) );	break;
			}
		}
		break;
	// Ã§¸°Áö Á¸ ½ÃÀÛ
	case MP_DATE_CHALLENGEZONE_START:
		{
 			char szTxt[256] = "";
			MSG_NAME2_DWORD3* pPacket = (MSG_NAME2_DWORD3*)pMsg;

			m_nChallengeZoneState = CHALLENGEZONE_START;
			m_nChallengeZoneTimeTick = gCurTime;
			m_nChallengeZoneTime = 0;

			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetActive(TRUE);
			// ±¸°£
			sprintf(szTxt, "LV. %d~%d", m_pstChallengeZoneSectionMonLevel[pPacket->dwData3].nStart, m_pstChallengeZoneSectionMonLevel[pPacket->dwData3].nEnd);
			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneLeastClearSection(szTxt);
			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTime(m_pstChallengeZoneSectionMonLevel[pPacket->dwData3].nLimitTime - CHALLENGE_ZONE_START_DELAY_TIME);
		
			// 091124 ONS ÆÄÆ¼¿ø Á¤º¸ : ÀÌ¸§(°æÇèÄ¡ºñÀ²)¸¦ Ç¥½Ã
			sprintf(szTxt, "%s ( %u%c )", pPacket->Name1, pPacket->dwData1, '%');
			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneExpRatePlayer1(szTxt);
			ZeroMemory(szTxt, sizeof(szTxt));
			sprintf(szTxt, "%s ( %u%c )", pPacket->Name2, pPacket->dwData2, '%');
			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneExpRatePlayer2(szTxt);
		}
		break;
	// Ã§¸°Áö Á¸ ÀÔÀå È¸¼ö ¼³Á¤
	case MP_DATE_CHALLENGEZONE_ENTER_FREQ:
		{
			MSG_DWORD2* pPacket = (MSG_DWORD2*)pMsg;

 			if (HERO == NULL) return;

			int nPossibleFreq = ENTER_CHALLENGE_ZONE_FREQ_PER_DAY - pPacket->dwData1;
			if (nPossibleFreq < 0) nPossibleFreq = 0;
			nPossibleFreq += pPacket->dwData2;
			GAMEIN->GetDateMatchingDlg()->SetEnterChallengeZoneFreq(nPossibleFreq);
		}
		break;
	// Ã§¸°Áö Á¸ ½ÇÆÐ - Å¸ÀÓ¾Æ¿ô
	case MP_DATE_CHALLENGEZONE_END_TIMEOUT:
		{
			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1214));
			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1220), CHALLENGE_ZONE_END_DELAY_TIME/1000);
			m_nChallengeZoneState = CHALLENGEZONE_END;
			m_nChallengeZoneTimeTick = gCurTime;
			m_nChallengeZoneTime = 0;

			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTime(0);
			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTimeTick(0);
			// ÀÌÆåÆ® ¿¬Ãâ
			if (CHALLENGE_ZONE_MOTION_NUM_FAIL)
				EFFECTMGR->StartEffectProcess(CHALLENGE_ZONE_MOTION_NUM_FAIL, HERO, NULL, 0, 0);
		}
		break;
	// Ã§¸°Áö Á¸ ½ÇÆÐ - ÆÄÆ®³ÊÀÇ ÀÌÅ»
	case MP_DATE_CHALLENGEZONE_END_PARTNER_OUT:
		{
			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1215));
			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1220), CHALLENGE_ZONE_END_DELAY_TIME/1000);
			m_nChallengeZoneState = CHALLENGEZONE_END;
			m_nChallengeZoneTimeTick = gCurTime;
			m_nChallengeZoneTime = 0;

			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTime(0);
			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTimeTick(0);
			// ÀÌÆåÆ® ¿¬Ãâ
			if (CHALLENGE_ZONE_MOTION_NUM_FAIL)
				EFFECTMGR->StartEffectProcess(CHALLENGE_ZONE_MOTION_NUM_FAIL, HERO, NULL, 0, 0);
		}
		break;
	// Ã§¸°Áö Á¸ ½ÇÆÐ - ¸ðµÎ »ç¸Á
	case MP_DATE_CHALLENGEZONE_END_ALL_DIE:
		{
			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1216));
			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1220), CHALLENGE_ZONE_END_DELAY_TIME/1000);
			m_nChallengeZoneState = CHALLENGEZONE_END;
			m_nChallengeZoneTimeTick = gCurTime;
			m_nChallengeZoneTime = 0;

			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTime(0);
			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTimeTick(0);
			// ÀÌÆåÆ® ¿¬Ãâ
			if (CHALLENGE_ZONE_MOTION_NUM_FAIL)
				EFFECTMGR->StartEffectProcess(CHALLENGE_ZONE_MOTION_NUM_FAIL, HERO, NULL, 0, 0);
		}
		break;
	// Ã§¸°Áö Á¸ ¼º°ø 
	case MP_DATE_CHALLENGEZONE_END_SUCCESS:
		{
			MSG_DWORD* pPacket = (MSG_DWORD*)pMsg;

			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1217));
			CHATMGR->AddMsg( CTC_SYSMSG, CHATMGR->GetChatMsg(1220), CHALLENGE_ZONE_END_DELAY_TIME/1000);
			m_nChallengeZoneState = CHALLENGEZONE_END;
			m_nChallengeZoneTimeTick = gCurTime;
			m_nChallengeZoneTime = 0;

			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTime(0);
			GAMEIN->GetChallengeZoneClearNo1Dlg()->SetChallengeZoneStartTimeTick(0);
			// ÃÖ´Ü ½Ã°£ Å¬¸®¾î Å¸ÀÓÀ» °»½ÅÇß³ª?
			// ..ÀÌÆåÆ® ¿¬Ãâ
			if (pPacket->dwData)
			{
				if (CHALLENGE_ZONE_MOTION_NUM_SUCCESS)
					EFFECTMGR->StartEffectProcess(CHALLENGE_ZONE_MOTION_NUM_SUCCESS, HERO, NULL, 0, 0);
			}
			else
			{
				if (CHALLENGE_ZONE_MOTION_NUM_SUCCESS_LEAST_CLEAR_TIME)
					EFFECTMGR->StartEffectProcess(CHALLENGE_ZONE_MOTION_NUM_SUCCESS_LEAST_CLEAR_TIME, HERO, NULL, 0, 0);
			}
		}
		break;
	}
#endif
}

void CSHDateManager::ReleaseME()
{
#ifdef _MAPSERVER_
	//SAFE_DELETE_ARRAY(m_pnDateZoneMoveIndexList);
	//SAFE_DELETE_ARRAY(m_pstChallengeZoneMoveIndexList);
	//SAFE_DELETE_ARRAY(m_pstChallengeZoneSectionMonLevel);

	if (m_pstChallengeZoneMonsterGroupSection)
	{
		for(UINT i=0; i<ENTER_CHALLENGE_ZONE_SECTION_NUM; i++)
		{
			for(UINT j=0; j<m_pstChallengeZoneMonsterGroupSection[i].nGroupNum; j++)
			{
				SAFE_DELETE_ARRAY(m_pstChallengeZoneMonsterGroupSection[i].pstGroup[j].pstMonster);
			}
			SAFE_DELETE_ARRAY(m_pstChallengeZoneMonsterGroupSection[i].pstGroup);
		}
		SAFE_DELETE_ARRAY(m_pstChallengeZoneMonsterGroupSection);
	}
#endif
}
void CSHDateManager::InitME(int wmapnum)
{
#ifdef _MAPSERVER_
	/////////////////
	LoadChallengeMonsterInfo(wmapnum);
	//////////////
	if (IsChallengeZone(wmapnum))
	{
		m_bIsChallengeZone = TRUE;
		return;
	}
	m_bIsChallengeZone = FALSE;
	m_nChallengeZoneState = 0;
	m_nChallengeZoneTime = 0;
	m_nChallengeZoneTimeTick = 0;
#endif
}
