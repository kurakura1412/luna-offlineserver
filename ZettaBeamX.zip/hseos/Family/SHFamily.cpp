/*********************************************************************

	 ÆÄÀÏ		: SHFamilyManager.cpp
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/07/03

	 ÆÄÀÏ¼³¸í	: CSHFamilyManager Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#if defined( _AGENT00_ ) || defined(_MAP00_ )
//#include "math.inl"
#include "[lib]yhlibrary/HashTable.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "SHFamily.h"

#if defined(_AGENTSERVER)
	#include "Network.h"
#elif defined(_MAPSERVER_)
#else
	#include "Player.h"
	#include "ChatManager.h"
	#include "GameIn.h"
#endif


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// class CSHFamilyMember
//

// -------------------------------------------------------------------------------------------------------------------------------------
// CSHFamilyMember Method																										  »ý¼ºÀÚ
//
CSHFamilyMember::CSHFamilyMember() : CSHGroupMember()
{
	ZeroMemory(&m_stInfoEx, sizeof(m_stInfoEx));
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHFamilyMember Method																										  ÆÄ±«ÀÚ
//
CSHFamilyMember::~CSHFamilyMember()
{
}


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// class CSHFamily
//

// -------------------------------------------------------------------------------------------------------------------------------------
// CSHFamily Method																												  »ý¼ºÀÚ
//
CSHFamily::CSHFamily() : CSHGroup()
{
	ZeroMemory(&m_stInfoEx, sizeof(m_stInfoEx));
	ZeroMemory(&m_pcsMember, sizeof(m_pcsMember));
	m_nEmblemChangedNum = 0;
	m_nMemberNumMax = MAX_MEMBER_NUM;
}

CSHFamily::CSHFamily(DWORD nMasterID, char* pszName) : CSHGroup(nMasterID, pszName)
{
	ZeroMemory(&m_stInfoEx, sizeof(m_stInfoEx));
	ZeroMemory(&m_pcsMember, sizeof(m_pcsMember));
	m_nMemberNumMax = MAX_MEMBER_NUM;
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHFamily Method																											  ÆÄ±«ÀÚ
//
CSHFamily::~CSHFamily()
{}


// -------------------------------------------------------------------------------------------------------------------------------------
// DelMember Method																											   ¸â¹ö »èÁ¦
//
VOID CSHFamily::DelMember(DWORD nMemberID)
{
	BOOL bSort = FALSE;
	for(UINT i=0; i<m_stInfo.nMemberNum; i++)
	{
		if (nMemberID == m_pcsMember[i].Get()->nID)
		{
			// ¸â¹ö ¼ö °¨¼Ò
			m_stInfo.nMemberNum--;
			bSort = TRUE;
		}

		// Á¤·Ä
		if (i<m_stInfo.nMemberNum && bSort)
		{
			SetMember(GetMember(i+1), i);
		}
	}

	if (bSort)
	{
		// »èÁ¦
		CSHFamilyMember csMember;
		SetMember(&csMember, m_stInfo.nMemberNum);
	}
}

