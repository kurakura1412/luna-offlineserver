/*********************************************************************

	 ÆÄÀÏ		: SHFamilyManager.cpp
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/07/03

	 ÆÄÀÏ¼³¸í	: CSHFamilyManager Å¬·¡½ºÀÇ ¼Ò½º

 *********************************************************************/

#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
//#include "ServerSystem.h"
#endif


#ifdef _AGENT00_ 
#include "math.inl"
#include "yhlibrary.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "SHGroup.h"

#if defined(_AGENTSERVER)
	#include "Network.h"
#elif defined(_MAPSERVER_)
#else
	#include "Player.h"
	#include "ChatManager.h"
	#include "GameIn.h"
#endif


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// class CSHGroupMember
//

// -------------------------------------------------------------------------------------------------------------------------------------
// CSHGroupMember Method																										  »ý¼ºÀÚ
//
CSHGroupMember::CSHGroupMember()
{
	ZeroMemory(&m_stInfo, sizeof(m_stInfo));
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHGroupMember Method																										  ÆÄ±«ÀÚ
//
CSHGroupMember::~CSHGroupMember()
{
}



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// class CSHGroup
//

// -------------------------------------------------------------------------------------------------------------------------------------
// CSHGroup Method																												  »ý¼ºÀÚ
//
CSHGroup::CSHGroup()
{
	ZeroMemory(&m_stInfo, sizeof(m_stInfo));

	m_pcsMember = NULL;
	m_nIndexAtTbl = 0;
}

CSHGroup::CSHGroup(DWORD nMasterID, char* pszName)
{
	ZeroMemory(&m_stInfo, sizeof(m_stInfo));

	m_pcsMember = NULL;
	m_nIndexAtTbl = 0;

	m_stInfo.nMasterID = nMasterID;
	SafeStrCpy(m_stInfo.szName, pszName, MAX_NAME_LENGTH+1);
}

// -------------------------------------------------------------------------------------------------------------------------------------
// ~CSHGroup Method																												  ÆÄ±«ÀÚ
//
CSHGroup::~CSHGroup()
{
}

