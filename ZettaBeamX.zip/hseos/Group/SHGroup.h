#ifndef __SHGROUP_H__INCLUDED
#define __SHGROUP_H__INCLUDED
/*********************************************************************

	 ÆÄÀÏ		: SHGroup.h
	 ÀÛ¼ºÀÚ		: hseos
	 ÀÛ¼ºÀÏ		: 2007/07/10

	 ÆÄÀÏ¼³¸í	: CSHGroup Å¬·¡½ºÀÇ Çì´õ

 *********************************************************************/

#include "[CC]Header/CommonGameDefine.h"

#pragma once

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// class CSHGroupMember
//
class CSHGroupMember
{
public:
	//----------------------------------------------------------------------------------------------------------------
	enum MEMBER_CONSTATE																		// ¸â¹ö Á¢¼Ó »óÅÂ
	{
		MEMBER_CONSTATE_LOGOFF = 0,																// ..Á¢¼Ó ¾È ÇÔ
		MEMBER_CONSTATE_LOGIN,																	// ..Á¢¼Ó Áß
	};

	struct stINFO																				// ¸â¹ö ±¸Á¶
	{
		DWORD			nID;																	// ..ID
		int				nRace;																	// ..Á¾Á·
		int				nSex;																	// ..¼ºº°
		int				nJobFirst;																// ..Á÷¾÷(Ã³À½)
		int				nJobCur;																// ..Á÷¾÷(ÇöÀç)
		int				nJobGrade;																// ..Á÷¾÷µî±Þ
		int				nLV;																	// ..·¹º§
		MEMBER_CONSTATE	eConState;																// ..Á¢¼Ó »óÅÂ
		char			szNickname[MAX_NAME_LENGTH+1];											// ..È£Äª
		char			szName[MAX_NAME_LENGTH+1];												// ..ÀÌ¸§
	};

protected:
	//----------------------------------------------------------------------------------------------------------------
	stINFO				m_stInfo;																// Á¤º¸

public:
	//----------------------------------------------------------------------------------------------------------------
	CSHGroupMember();
	virtual ~CSHGroupMember();
	void			Set(stINFO* pstInfo)							{ m_stInfo = *pstInfo; }
	//				Á¤º¸ ¾ò±â
	stINFO*			Get()											{ return &m_stInfo; }
};



//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// class CSHGroup
//
class CSHGroup
{
public:
	//----------------------------------------------------------------------------------------------------------------
	struct stINFO																				// ±×·ì ±¸Á¶
	{
		DWORD					nID;															// ..ID
		char					szName[MAX_NAME_LENGTH+1];										// ..ÀÌ¸§
		DWORD					nMasterID;														// ..¸¶½ºÅÍID
		char					szMasterName[MAX_NAME_LENGTH+1];								// ..¸¶½ºÅÍ ÀÌ¸§
		UINT					nMemberNum;														// ..¸â¹ö ¼ö
	};

protected:
	//----------------------------------------------------------------------------------------------------------------
	stINFO						m_stInfo;														// Á¤º¸
	CSHGroupMember*				m_pcsMember;													// ¸â¹ö
	UINT						m_nMemberNumMax;												// ÃÖ´ë ¸â¹ö ¼ö

	//----------------------------------------------------------------------------------------------------------------
	UINT						m_nIndexAtTbl;													// Å×ÀÌºí¿¡¼­ÀÇ ÀÎµ¦½º

public:
	//----------------------------------------------------------------------------------------------------------------
	CSHGroup();
	CSHGroup(DWORD nMasterID, char* pszName);
	// 090915 LUJ, ÆÄ»ý Å¬·¡½ºÀÇ ¼Ò¸êÀÚ°¡ È£ÃâµÇµµ·Ï ¼öÁ¤
	virtual ~CSHGroup();
	VOID				Set(stINFO* pstInfo)	{ m_stInfo = *pstInfo; }
	//					Á¤º¸ ¾ò±â
	stINFO*				Get()					{ return &m_stInfo; }

	//					¸â¹ö Ãß°¡
	VOID				AddMember(CSHGroupMember* pcsMember)		
						{
							m_pcsMember[m_stInfo.nMemberNum].Set(pcsMember->Get()); 
							m_stInfo.nMemberNum++; 
						}
	//					¸â¹ö ¼³Á¤
	VOID				SetMember(CSHGroupMember* pcsMember, int nIndex)	{ m_pcsMember[nIndex].Set(pcsMember->Get()); }
	//					¸â¹ö ¾ò±â
	CSHGroupMember*		GetMember(int nIndex)								{ return &m_pcsMember[nIndex]; }
	UINT				GetMemberNumMax()									{ return m_nMemberNumMax; }

	//----------------------------------------------------------------------------------------------------------------
	//					Å×ÀÌºí¿¡¼­ÀÇ ÀÎµ¦½º ¼³Á¤
	VOID				SetIndexAtTbl(int nIndex)							{ m_nIndexAtTbl = nIndex; }
	//					Å×ÀÌºí¿¡¼­ÀÇ ÀÎµ¦½º ¾ò±â
	UINT				GetIndexAtTbl()										{ return m_nIndexAtTbl; }
};
#endif // __SHGROUP_H__INCLUDED
