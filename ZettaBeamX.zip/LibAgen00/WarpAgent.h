#ifndef WARPAGENT_H
#define WARPAGENT_H

class MoonBase;
class CServerSystem;

class WarpAgent
{
public:
	WarpAgent();
	~WarpAgent();
	bool init();
	void Update();
	void start(int mapnum);
	void setNetData( MoonBase* zz);
	void parseIN(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength);
	void parseINSVR(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength);
	void acceptplayer(int connidx);
	void end();
private:
	CServerSystem * svragen;
	bool _alive;
};

#endif // WARPAGENT_H
