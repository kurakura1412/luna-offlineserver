#include "stdafx.h"

#include "yhlibrary.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
#include "ServerGameStruct.h"
#include "ServerSystem.h"

#include "WarpAgent.h"
#include "Network.h"
#include "DataBase.h"

char g_szMapName[64];
char g_szHeroIDName[17] = { 0, };

WarpAgent::WarpAgent()
{
	svragen = nullptr;
	_alive = true;
} 

WarpAgent::~WarpAgent()
{
	if( svragen){
		//svragen->End();
		_alive = false;
		delete svragen;
		svragen = nullptr;
		g_pServerSystem = nullptr;
	}
}

bool WarpAgent::init()
{
	if( g_pServerSystem ) return false;
	svragen = new (std::nothrow) CServerSystem;
	g_pServerSystem = svragen;
	start(0);
	return true;
}

void WarpAgent::start(int mapnum)
{
	if( svragen ) svragen->Start(mapnum);
}

void WarpAgent::setNetData(MoonBase* zz)
{
	g_Network.setLuna( zz);
	g_DB.setLuna( zz );
}

void WarpAgent::parseIN(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength)
{
	//if( !_alive ) return;
	ReceivedMsgFromUser(dwConnectionIndex,pMsg,dwLength  );
}
void WarpAgent::Update()
{
	//if( !_alive ) return;
	if( svragen ) svragen->Process();
}
void WarpAgent::acceptplayer(int connidx)
{
	//if( !_alive ) return;
	OnAcceptUser(connidx);
}
void WarpAgent::parseINSVR(unsigned int dwConnectionIndex, char* pMsg, unsigned int dwLength)
{
	//if( !_alive ) return;
	ReceivedMsgFromServer(dwConnectionIndex,pMsg,dwLength  );
}
void WarpAgent::end()
{
	_alive = false;
	if( svragen ) svragen->End();
}
