#include "giftevent.h"
#ifdef _AGENT00_ 
#include "..\[lib]yhlibrary\IndexGenerator.h"
#include "yhlibrary.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
//#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif
#include "giftmanager.h"

#include "UserTable.h"
#include "Network.h"

cGiftEvent::cGiftEvent(void)
{
	Release();
}

cGiftEvent::~cGiftEvent(void)
{
	Release();
}

BOOL cGiftEvent::Init( DWORD CharacterIdx, DWORD ID, EVENTINFO* pInfo )
{
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( CharacterIdx );
	if( !pUserInfo )
	{
		FILE* pFile = fopen( "./log/GiftEventLog.txt", "a+" );
		fprintf( pFile, "%u\tInvalid User(cGiftEvent::Init) - character_idx : %u\n", gCurTime, CharacterIdx );
		fclose( pFile );
		return FALSE;
	}

	mCharacterIdx = CharacterIdx;
	mID = ID;
	mpInfo = pInfo;
	mDelay = pInfo->Delay * 1000;
	mCheckTime = gCurTime;

	MSG_DWORD2 msg;
	msg.Category = MP_ITEM;
	msg.Protocol = MP_ITEM_GIFT_EVENT_NOTIFY;
	msg.dwData1 = mpInfo->Index;
	msg.dwData2 = 1;

	g_Network.Send2User( pUserInfo->dwConnectionIndex, ( char* )&msg, sizeof( msg ) );

	return TRUE;
}

BOOL cGiftEvent::Excute()
{
	// ¾ÆÀÌÅÛ Áö±Þ
	USERINFO* pInfo = g_pUserTableForObjectID->FindUser( mCharacterIdx );
	if( !pInfo )
	{
		return TRUE;
	}

	// ½Ã°£ È®ÀÎ
	if( gCurTime - mCheckTime < mDelay )
	{
		mDelay -= gCurTime - mCheckTime;
		mCheckTime = gCurTime;
		return FALSE;
	}

	MSG_DWORD4 msg;
	msg.Category = MP_ITEM;
	msg.Protocol = MP_ITEM_GIFT_EVENT_NOTIFY;
	msg.dwData1 = mCharacterIdx;
	msg.dwData2 = mpInfo->Index;
	msg.dwData3 = mpInfo->Item;
	msg.dwData4 = mpInfo->Count;
#ifdef _MYLUNA_
	g_Network.Send2Server( 3, ( char* )&msg, sizeof( msg ) );
#else
	g_Network.Send2Server( pInfo->dwMapServerConnectionIndex, ( char* )&msg, sizeof( msg ) );
#endif
	// ´ÙÀ½ ÀÌº¥Æ®
	GIFTMGR->AddEvent( mCharacterIdx, mpInfo->Next );

	return TRUE;
}

void cGiftEvent::Release()
{
	mID = 0;			
	mCharacterIdx = 0;	

	mpInfo = NULL;			

	mDelay = 0;			
	mCheckTime = 0;		
}
