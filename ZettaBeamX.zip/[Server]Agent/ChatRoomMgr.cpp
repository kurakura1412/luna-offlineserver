//=================================================================================================
//	FILE		: CChatRoomMgr.cpp
//	DESC		: Implementation part of chatroom manager class.
//	DATE		: MARCH 31, 2008 LYW
//=================================================================================================





//-------------------------------------------------------------------------------------------------
//		Include part.
//-------------------------------------------------------------------------------------------------
#include <list>
#include "StdAfx.h"																						// An include file for standard system include files
#ifdef _AGENT00_ 
//#include "Wnano.h"
#include "yhlibrary.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "[CC]ServerModule/DataBase.h"
#include "[CC]ServerModule/Network.h"																// An include file for network.

#include "ChatRoomMgr.h"																				// An include file for chatroom manager.

#include "AgentDBMsgParser.h"
#include "FilteringTable.h"





//-------------------------------------------------------------------------------------------------
//	NAME : CChatRoomMgr
//	DESC : The function constructor.
//  DATE : MARCH 31, 2008 LYW
//-------------------------------------------------------------------------------------------------
CChatRoomMgr::CChatRoomMgr(void)
{
}





//-------------------------------------------------------------------------------------------------
//	NAME : ~CChatRoomMgr
//	DESC : The function destructor.
//  DATE : MARCH 31, 2008 LYW
//-------------------------------------------------------------------------------------------------
CChatRoomMgr::~CChatRoomMgr(void)
{
}





//-------------------------------------------------------------------------------------------------
//	NAME : RegistPlayer_To_Lobby
//	DESC : À¯Àú Á¤º¸¸¦ ´ã¾Æ Dist ¼­¹ö·Î º¸³»´Â ÇÔ¼ö.
//  DATE : MARCH 31, 2008 LYW
//-------------------------------------------------------------------------------------------------
BYTE CChatRoomMgr::IsAddedUser(DWORD dwCharacterID)
{
	// À¯Àú Á¤º¸ ¹Þ±â.
	USERINFO* pInfo = NULL ;
	pInfo = g_pUserTableForObjectID->FindUser(dwCharacterID) ;

	ASSERT(pInfo) ;

	if(!pInfo)
	{
		// 080704 LYW --- ChatRoomMgr : ÀÓ½Ã ¹öÆÛ »çÀÌÁî È®Àå.
		//char tempMsg[128] = {0, } ;

		char tempMsg[257] = {0, } ;
		sprintf(tempMsg, "%d : Failed to find user to user id", dwCharacterID) ;

		Throw_Error(tempMsg, __FUNCTION__) ;

		return FALSE ;
	}

	if(pInfo->byAddedChatSystem) return TRUE ;
	else return FALSE ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : RegistPlayer_To_Lobby
//	DESC : À¯Àú Á¤º¸¸¦ ´ã¾Æ Dist ¼­¹ö·Î º¸³»´Â ÇÔ¼ö.
//  DATE : MARCH 31, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::RegistPlayer_To_Lobby(USERINFO* pUserInfo, BYTE byProtocol) 
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pUserInfo) ;

	if(!pUserInfo)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ÀÓ½Ã À¯Àú µ¥ÀÌÅÍ.
	int nNameLength ;

	ST_CR_USER guest ;
	memset(&guest, 0, sizeof(ST_CR_USER)) ;

	for(BYTE count = 0 ; count < MAX_CHARACTER_NUM ; ++count)
	{
		if(pUserInfo->SelectInfoArray[count].dwCharacterID != pUserInfo->dwCharacterID) continue ;

		// Ä³¸¯ÅÍ Á¤º¸¸¦ ¹Þ´Â´Ù.
		guest.dwUserID			= pUserInfo->dwUserID ;

		guest.dwPlayerID	= pUserInfo->SelectInfoArray[count].dwCharacterID ; 
		//guest.wClassIdx		= pUserInfo->SelectInfoArray[count].wClassIndex ;
		guest.byLevel		= (BYTE)pUserInfo->SelectInfoArray[count].Level ;
		guest.byMapNum		= (BYTE)pUserInfo->SelectInfoArray[count].MapNum ;

		// Ä³¸¯ÅÍÀÇ ÀÌ¸§À» Ã¼Å©ÇÑ´Ù.
		nNameLength = 0 ;
		nNameLength = strlen(pUserInfo->SelectInfoArray[count].name) ;
		ASSERT(nNameLength > 0) ;
		if(nNameLength <= 0)
		{
			Throw_Error("Failed to receive user name!!", __FUNCTION__) ;
		}

		strcpy(guest.name, pUserInfo->SelectInfoArray[count].name) ;

		// Ä³¸¯ÅÍ Á¤º¸¸¦ ´ã´Â´Ù.
		MSG_CR_USER msg ;
		memset(&msg, 0, sizeof(MSG_CR_USER)) ;

		msg.Category	= MP_CHATROOM ;
		msg.Protocol	= byProtocol ;
		msg.dwObjectID	= guest.dwPlayerID ;

		memcpy(&msg.user, &guest, sizeof(ST_CR_USER)) ;

		// Dist·Î µî·Ï ¸Þ½ÃÁö Àü¼Û.
		g_Network.Send2DistributeServer((char*)&msg, sizeof(MSG_CR_USER)) ;

		// Ä³¸¯ÅÍÀÇ »óÅÂ¸¦ Lobby¿¡ ÀÖ´Â »óÅÂ·Î ¼¼ÆÃ.
		pUserInfo->byAddedChatSystem = TRUE ;

		break ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : RegistPlayer_To_Lobby
//	DESC : À¯Àú Á¤º¸¸¦ ´ã¾Æ Dist ¼­¹ö·Î º¸³»´Â ÇÔ¼ö.
//  DATE : MAY 7, 2008 LYW
//-------------------------------------------------------------------------------------------------
BYTE CChatRoomMgr::RegistPlayer_To_Lobby(ST_CR_USER* pUserInfo)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pUserInfo) ;

	if(!pUserInfo)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return FALSE ;
	}



	// ÀÌ¸§ Ã¼Å©.
	int nNameLength = 0 ;
	nNameLength = strlen(pUserInfo->name) ;

	ASSERT(nNameLength > 0) ;
	if(nNameLength <= 0 || !pUserInfo->name)
	{
		Throw_Error("Failed to receive name!!", __FUNCTION__) ;
		return FALSE ;
	}



	// Ä³¸¯ÅÍ Á¤º¸¸¦ ´ã´Â´Ù.
	MSG_CR_USER msg ;
	memset(&msg, 0, sizeof(MSG_CR_USER)) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_ADD_USER_SYN ;
	msg.dwObjectID	= pUserInfo->dwPlayerID ;

	memcpy(&msg.user, pUserInfo, sizeof(ST_CR_USER)) ;

	// Dist·Î µî·Ï ¸Þ½ÃÁö Àü¼Û.
	g_Network.Send2DistributeServer((char*)&msg, sizeof(MSG_CR_USER)) ;

	return TRUE ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : ForceRegistPlayer_To_Lobby
//	DESC : °­Á¦·Î Ä³¸¯ÅÍ Á¤º¸¸¦ Dist¿¡ µî·Ï ½ÃÅ°´Â ÇÔ¼ö.
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::ForceRegistPlayer_To_Lobby(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ±âº» ¸Þ½ÃÁö º¯È¯.
	MSGBASE* pmsg = NULL ;
	pmsg = (MSGBASE*)pMsg ;

	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// À¯Àú Á¤º¸ ¹Þ±â.
	USERINFO* pInfo = NULL ;
	pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwObjectID) ;

	if(!pInfo)
	{
		Throw_Error(err_FRUI, __FUNCTION__) ;

		MSGBASE msg ;
		memset(&msg, 0, sizeof(MSGBASE)) ;

		msg.Category	= MP_CHATROOM ;
		msg.Protocol	= MP_CHATROOM_FORCE_ADD_USER_NACK ;
		msg.dwObjectID	= pmsg->dwObjectID ;

		g_Network.Send2User(dwIndex, (char*)&msg, sizeof(MSGBASE)) ;

		return ;
	}

	// À¯Àú Á¤º¸ µî·Ï.
	RegistPlayer_To_Lobby(pInfo, MP_CHATROOM_FORCE_ADD_USER_SYN) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : ChatMsg_Normal_Syn
//	DESC : Ã¤ÆÃ¹æ ³»¿¡¼­ ¸Þ½ÃÁö Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 24, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::ChatMsg_Normal_Syn(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_MSG_BROADCAST* pmsg = NULL ;
	pmsg = (MSG_CR_MSG_BROADCAST*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// ¸Þ½ÃÁö Àü¼Û Ã³¸®.
	USERINFO* pInfo ;
	for(BYTE count = 0 ; count < pmsg->byCount ; ++count)
	{
		// À¯Àú¸¦ °Ë»ö.
		pInfo = NULL ;
		pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwUser[count]) ;

		if(!pInfo) continue ;

		MSG_CR_MSG msg ;
		memset(&msg, 0, sizeof(MSG_CR_MSG)) ;

		msg.Category	= MP_CHATROOM ;
		msg.Protocol	= MP_CHATROOM_CHATMSG_NORMAL_NOTICE ;
		msg.dwObjectID	= pmsg->dwObjectID ;

		SafeStrCpy(msg.name, pmsg->name, MAX_NAME_LENGTH + 1) ;
		SafeStrCpy(msg.Msg, pmsg->Msg, MAX_CHAT_LENGTH + 1) ;

		// ¸Þ½ÃÁö¸¦ À¯Àú¿¡°Ô Àü¼Û.
		g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&msg, sizeof(MSG_CR_MSG)) ;
	}

	// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ Àü¼Û.
	if(pmsg->Protocol == MP_CHATROOM_CHATMSG_NORMAL_SYN)
	{
		MSG_CR_MSG_BROADCAST msg ;
		memset(&msg, 0, sizeof(MSG_CR_MSG_BROADCAST)) ;

		msg.Category	= MP_CHATROOM ;
		msg.Protocol	= MP_CHATROOM_CHATMSG_NORMAL_NOTICE_OTHER_AGENT ;
		msg.dwObjectID	= pmsg->dwObjectID ;

		SafeStrCpy(msg.name, pmsg->name, MAX_NAME_LENGTH + 1) ;
		SafeStrCpy(msg.Msg, pmsg->Msg, MAX_CHAT_LENGTH+1) ;

		for(BYTE count = 0 ; count < pmsg->byCount ; ++count)
		{
			msg.dwUser[count] = pmsg->dwUser[count] ;

			++msg.byCount ;
		}

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡ ¸Þ½ÃÁö¸¦ Àü¼Û.
		g_Network.Send2AgentExceptThis((char*)&msg, sizeof(MSG_CR_MSG_BROADCAST)) ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : DestroyPlayer_From_Lobby
//	DESC : À¯Àú Á¤º¸¸¦ »èÁ¦ÇÏ´Â ÇÔ¼ö.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::DestroyPlayer_From_Lobby(USERINFO* pUserInfo) 
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pUserInfo) ;

	if(!pUserInfo)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	if(pUserInfo->dwCharacterID == 0 || pUserInfo->dwUserID == 0) return ;

	pUserInfo->byAddedChatSystem = FALSE ;
	
	// À¯Àú »èÁ¦ ¿äÃ»À» º¸³½´Ù.
	MSGBASE msg ;
	memset(&msg, 0, sizeof(MSGBASE)) ;

	msg.Category	= MP_CHATROOM ;
	msg.Protocol	= MP_CHATROOM_DEL_USER_SYN ;
	msg.dwObjectID	= pUserInfo->dwCharacterID ;

	g_Network.Send2DistributeServer((char*)&msg, sizeof(MSGBASE)) ;
}






//-------------------------------------------------------------------------------------------------
//	NAME : UpdatePlayerInfo
//	DESC : À¯ÀúÀÇ Á¤º¸¸¦ ¾÷µ¥ÀÌÆ® ½ÃÅ°´Â ÇÔ¼ö.
//  DATE : MARCH 31, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UpdatePlayerInfo(USERINFO* pUserInfo)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pUserInfo) ;

	if(!pUserInfo)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ÀÓ½Ã À¯Àú µ¥ÀÌÅÍ.
	ST_CR_USER guest ;
	memset(&guest, 0, sizeof(ST_CR_USER)) ;

	for(BYTE count = 0 ; count < MAX_CHARACTER_NUM ; ++count)
	{
		if(pUserInfo->SelectInfoArray[count].dwCharacterID != pUserInfo->dwCharacterID) continue ;

		// Ä³¸¯ÅÍ Á¤º¸¸¦ ¹Þ´Â´Ù.
		//guest.wClassIdx		= pUserInfo->SelectInfoArray[count].wClassIndex ;
		guest.byLevel		= (BYTE)pUserInfo->SelectInfoArray[count].Level ;
		guest.byMapNum		= (BYTE)pUserInfo->SelectInfoArray[count].MapNum ;

		strcpy(guest.name, pUserInfo->SelectInfoArray[count].name) ;

		MSG_CR_USER msg ;
		memset(&msg, 0, sizeof(MSG_CR_USER)) ;

		msg.Category	= MP_CHATROOM ;
		msg.Protocol	= MP_CHATROOM_UPDATE_USERINFO_SYN ;
		msg.dwObjectID	= pUserInfo->dwCharacterID ;

		msg.user.byLevel		= guest.byLevel ;
		msg.user.byMapNum	= guest.byMapNum ;
		//msg.user.wClassIdx	= guest.wClassIdx ;

		SafeStrCpy(msg.user.name, guest.name, MAX_NAME_LENGTH + 1) ;

		g_Network.Send2DistributeServer((char*)&msg, sizeof(MSG_CR_USER)) ;

		break ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : UserMsgParser
//	DESC : À¯Àú·Î ºÎÅÍ ¿À´Â ³×Æ®¿öÅ© ¸Þ½ÃÁö Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
//  DATE : MARCH 31, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::UserMsgParser(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ±âº» ¸Þ½ÃÁö º¯È¯.
	MSGBASE* pmsg = NULL ;
	pmsg = (MSGBASE*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTB, __FUNCTION__) ;
		return ;
	}

	// ÇÁ·ÎÅäÄÝ Ã¼Å©.
	switch(pmsg->Protocol)
	{
	case MP_CHATROOM_FORCE_ADD_USER_SYN :	ForceRegistPlayer_To_Lobby(dwIndex, pMsg, dwLength) ;	break ;
	case MP_CHATROOM_CHATMSG_NORMAL_SYN :	ChatMsg_Normal_Syn(dwIndex, pMsg, dwLength) ;			break ;
	default : g_Network.Send2DistributeServer(pMsg, dwLength) ;										break ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : ServerMsgParser
//	DESC : ¼­¹ö·Î ºÎÅÍ ¿À´Â ³×Æ®¿öÅ© ¸Þ½ÃÁö Ã³¸®¸¦ ÇÏ´Â ÇÕ¼ö.
//  DATE : MARCH 31, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::ServerMsgParser(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ±âº» ¸Þ½ÃÁö º¯È¯.
	MSGBASE* pmsg = NULL ;
	pmsg = (MSGBASE*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTB, __FUNCTION__) ;
		return ;
	}
	
	// ÇÁ·ÎÅäÄÝ È®ÀÎ.
	switch(pmsg->Protocol)
	{
	case MP_CHATROOM_ADD_USER_ACK :

	case MP_CHATROOM_ROOMLIST_ACK :
	case MP_CHATROOM_ROOMLIST_NACK :

	case MP_CHATROOM_CREATE_ROOM_ACK :	
	case MP_CHATROOM_CREATE_ROOM_NACK :

	case MP_CHATROOM_JOIN_ROOM_ACK :
	case MP_CHATROOM_JOIN_ROOM_NACK :

	case MP_CHATROOM_OUT_ROOM_ACK :
	case MP_CHATROOM_OUT_ROOM_NACK :
	case MP_CHATROOM_OUT_ROOM_EMPTYROOM :
	case MP_CHATROOM_OUT_ROOM_LAST_MAN :

	case MP_CHATROOM_CHANGE_OPTION_NACK :

	case MP_CHATROOM_CHANGE_OWNER_NACK :

	case MP_CHATROOM_KICK_GUEST_NACK :

	case MP_CHATROOM_REQUEST_FRIEND_NACK :

	case MP_CHATROOM_CHATMSG_NORMAL_NACK :	

	case MP_CHATROOM_SEARCH_FOR_NAME_ACK :
	case MP_CHATROOM_SEARCH_FOR_NAME_NACK :

	case MP_CHATROOM_SEARCH_FOR_TITLE_ACK :
	case MP_CHATROOM_SEARCH_FOR_TITLE_NACK :

	case MP_CHATROOM_UPDATEINFO_CREATED_ROOM :
	case MP_CHATROOM_UPDATEINFO_DELETED_ROOM :
	case MP_CHATROOM_UPDATEINFO_SECRETMODE :
	case MP_CHATROOM_UPDATEINFO_ROOMTYPE :
	case MP_CHATROOM_UPDATEINFO_TITLE :
	case MP_CHATROOM_UPDATEINFO_CUR_GUESTCOUNT :
	case MP_CHATROOM_UPDATEINFO_TOTAL_GUESTCOUNT :				SendMsg2User(dwIndex, pMsg, dwLength) ; break ;

	case MP_CHATROOM_JOIN_ROOM_NOTICE :					
	case MP_CHATROOM_JOIN_ROOM_OTHER_AGENT :					Join_Room_Notice(dwIndex, pMsg, dwLength) ; break ;

	case MP_CHATROOM_OUT_ROOM_NOTICE :
	case MP_CHATROOM_OUT_ROOM_NOTICE_OTHER_AGENT :				Out_Room_Notice(dwIndex, pMsg, dwLength) ; break ;

	case MP_CHATROOM_OUT_ROOM_CHANGE_OWNER_NOTICE :
	case MP_CHATROOM_OUT_ROOM_CHANGE_OWNER_NOTICE_OTHER_AGENT : Out_Room_Change_Owner_Notcie(dwIndex, pMsg, dwLength) ; break ;		

	case MP_CHATROOM_CHANGE_OPTION_NOTICE :
	case MP_CHATROOM_CHANGE_OPTION_NOTICE_OTHER_AGENT :			Change_Option_Notice(dwIndex, pMsg, dwLength) ; break ;

	case MP_CHATROOM_CHANGE_OWNER_NOTICE :
	case MP_CHATROOM_CHANGE_OWNER_NOTICE_OTHER_AGENT :			Change_Owner_Notice(dwIndex, pMsg, dwLength) ; break ;

	case MP_CHATROOM_KICK_GUEST_ACK :
	case MP_CHATROOM_KICK_GUEST_ACK_OTHER_AGENT :				Kick_Guest_Ack(dwIndex, pMsg, dwLength) ; break ;

	case MP_CHATROOM_KICK_GUEST_NOTICE :
	case MP_CHATROOM_KICK_GUEST_NOTICE_OTHER_AGENT :			Kick_Guest_Notice(dwIndex, pMsg, dwLength) ; break ;

	case MP_CHATROOM_REQUEST_FRIEND_ACK :						Request_Friend_Ack(dwIndex, pMsg, dwLength) ; break ;

	case MP_CHATROOM_CHATMSG_NORMAL_NOTICE_OTHER_AGENT :		ChatMsg_Normal_Syn(dwIndex, pMsg, dwLength) ; break ;

	default : break ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : SendMsg2User
//	DESC : ¼­¹ö(Dist)·Î ºÎÅÍ Àü´Þ µÈ ¸Þ½ÃÁö¸¦ Å¬¶óÀÌ¾ðÆ®·Î Àü¼Û.
//  DATE : APRIL 2, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::SendMsg2User(DWORD dwIndex, char* pMsg, DWORD dwLength) 
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSGBASE* pmsg = NULL ;
	pmsg = (MSGBASE*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}


	// À¯Àú Ã£±â.
	USERINFO* pInfo = NULL ;
	pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwObjectID) ;

	if(!pInfo) return ;

	// ¸Þ½ÃÁö Àü´Þ.
	g_Network.Send2User(pInfo->dwConnectionIndex, pMsg, dwLength) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : Join_Room_Ack
//		 : 
//	DESC : Ã¤ÆÃ¹æ Âü¿© ¼º°ø Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. Àü¼Û¿ë ¸Þ½ÃÁö ¼±¾ð.
//		 : 2. À¯Àú °Ë»ö.
//		 : 3. Âü°¡ÇÑ À¯ÀúÀÏ°æ¿ì´Â ¼º°ø ¸Þ½ÃÁö Àü¼Û.
//		 : 4. Âü°¡ÇÑ À¯Àú°¡ ¾Æ´Ò°æ¿ì¿¡´Â Âü¿© °øÁö Àü¼Û.
//		 : 5. ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ °°Àº ¹æ½ÄÀ¸·Î Àü¼Û.
//		 : 
//  DATE : APRIL 7, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Join_Room_Notice(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_JOIN_NOTICE* pmsg = NULL ;
	pmsg = (MSG_CR_JOIN_NOTICE*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// ¸¹ÀÌ »ç¿ëµÇ´Â ¿¬»ê - »çÀÌÁî ¹Þ±â.
	int nSize = 0 ;
	nSize = sizeof(MSG_CR_JOIN_NOTICE) ;

	USERINFO* pInfo ;
	for(BYTE count = 0 ; count < pmsg->byCount ; ++count)
	{
		// À¯Àú¸¦ °Ë»ö.
		pInfo = NULL ;
		pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwUser[count]) ;

		if(!pInfo) continue ;

		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_JOIN_NOTICE sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		sendMsg.Protocol = MP_CHATROOM_JOIN_ROOM_NOTICE ;

		// ¸Þ½ÃÁö¸¦ À¯Àú¿¡°Ô Àü¼Û.
		g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&sendMsg, nSize) ;
	}

	// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ Àü¼Û.
	if(pmsg->Protocol == MP_CHATROOM_JOIN_ROOM_NOTICE)
	{
		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_JOIN_NOTICE sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡°Ô Àü¼Û ÇÒ ÇÁ·ÎÅäÄÝ ¼¼ÆÃ.
		sendMsg.Protocol = MP_CHATROOM_JOIN_ROOM_OTHER_AGENT ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡ ¸Þ½ÃÁö¸¦ Àü¼Û.
		g_Network.Send2AgentExceptThis((char*)&sendMsg, nSize) ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : Out_Room_Notice
//		 : 
//	DESC : Ã¤ÆÃ¹æ ³ª°¡±â ¼º°ø Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. À¯Àú °Ë»ö.
//		 : 2. ³ª°¡´Â À¯ÀúÀÏ°æ¿ì´Â ¼º°ø ¸Þ½ÃÁö Àü¼Û.
//		 : 3. ³ª°¡´Â À¯Àú°¡ ¾Æ´Ò°æ¿ì¿¡´Â Âü¿© °øÁö Àü¼Û.
//		 : 4. ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ °°Àº ¹æ½ÄÀ¸·Î Àü¼Û.
//		 : 
//  DATE : APRIL 7, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Out_Room_Notice(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_IDNAME* pmsg = NULL ;
	pmsg = (MSG_CR_IDNAME*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// ¸¹ÀÌ »ç¿ëµÇ´Â ¿¬»ê - »çÀÌÁî ¹Þ±â.
	int nSize = 0 ;
	nSize = sizeof(MSG_CR_IDNAME) ;

	USERINFO* pInfo ;
	for(BYTE count = 0 ; count < pmsg->byCount ; ++count)
	{
		// À¯Àú¸¦ °Ë»ö.
		pInfo = NULL ;
		pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwUser[count]) ;

		if(!pInfo) continue ;

		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_IDNAME sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		sendMsg.Protocol = MP_CHATROOM_OUT_ROOM_NOTICE ;

		// ¸Þ½ÃÁö¸¦ À¯Àú¿¡°Ô Àü¼Û.
		g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&sendMsg, nSize) ;
	}

	// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ Àü¼Û.
	if(pmsg->Protocol == MP_CHATROOM_OUT_ROOM_NOTICE)
	{
		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_IDNAME sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡°Ô Àü¼Û ÇÒ ÇÁ·ÎÅäÄÝ ¼¼ÆÃ.
		sendMsg.Protocol = MP_CHATROOM_OUT_ROOM_NOTICE_OTHER_AGENT ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡ ¸Þ½ÃÁö¸¦ Àü¼Û.
		g_Network.Send2AgentExceptThis((char*)&sendMsg, nSize) ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : Out_Room_Change_Owner_Notcie
//		 : 
//	DESC : Ã¤ÆÃ¹æÀ» ³ª°£ »ç¶÷ Ã³¸®¸¦ ÇÏ´Âµ¥, ¹æÀåÀÌ Á¤»óÀûÀÌÁö ¾ÊÀº °æ·Î·Î ³ª°¬À» ¶§ Ã³¸®ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. À¯Àú °Ë»ö.
//		 : 2. ¸Þ½ÃÁö Àü¼Û.
//		 : 3. ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ °°Àº ¹æ½ÄÀ¸·Î Àü¼Û.
//		 : 
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Out_Room_Change_Owner_Notcie(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_IDNAME* pmsg = NULL ;
	pmsg = (MSG_CR_IDNAME*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// ¸¹ÀÌ »ç¿ëµÇ´Â ¿¬»ê - »çÀÌÁî ¹Þ±â.
	int nSize = 0 ;
	nSize = sizeof(MSG_CR_IDNAME) ;

	USERINFO* pInfo ;
	for(BYTE count = 0 ; count < pmsg->byCount ; ++count)
	{
		// À¯Àú¸¦ °Ë»ö.
		pInfo = NULL ;
		pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwUser[count]) ;

		if(!pInfo) continue ;

		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_IDNAME sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		sendMsg.Protocol = MP_CHATROOM_OUT_ROOM_CHANGE_OWNER_NOTICE ;

		// ¸Þ½ÃÁö¸¦ À¯Àú¿¡°Ô Àü¼Û.
		g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&sendMsg, nSize) ;
	}

	// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ Àü¼Û.
	if(pmsg->Protocol == MP_CHATROOM_OUT_ROOM_CHANGE_OWNER_NOTICE)
	{
		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_IDNAME sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡°Ô Àü¼Û ÇÒ ÇÁ·ÎÅäÄÝ ¼¼ÆÃ.
		sendMsg.Protocol = MP_CHATROOM_OUT_ROOM_CHANGE_OWNER_NOTICE_OTHER_AGENT ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡ ¸Þ½ÃÁö¸¦ Àü¼Û.
		g_Network.Send2AgentExceptThis((char*)&sendMsg, nSize) ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : Change_Option_Notice
//		 : 
//	DESC : Ã¤ÆÃ¹æ ¿É¼ÇÀÌ º¯°æµÇ¾ú´Ù´Â Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. À¯Àú °Ë»ö.
//		 : 2. ¸Þ½ÃÁö Àü¼Û.
//		 : 3. ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ °°Àº ¹æ½ÄÀ¸·Î Àü¼Û.
//		 : 
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Change_Option_Notice(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_ROOM_NOTICE* pmsg = NULL ;
	pmsg = (MSG_CR_ROOM_NOTICE*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// ¸¹ÀÌ »ç¿ëµÇ´Â ¿¬»ê - »çÀÌÁî ¹Þ±â.
	int nSize = 0 ;
	nSize = sizeof(MSG_CR_ROOM_NOTICE) ;

	USERINFO* pInfo ;
	for(BYTE count = 0 ; count < pmsg->byCount ; ++count)
	{
		// À¯Àú¸¦ °Ë»ö.
		pInfo = NULL ;
		pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwUser[count]) ;

		if(!pInfo) continue ;

		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_ROOM_NOTICE sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		sendMsg.Protocol = MP_CHATROOM_CHANGE_OPTION_NOTICE ;

		// ¸Þ½ÃÁö¸¦ À¯Àú¿¡°Ô Àü¼Û.
		g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&sendMsg, nSize) ;
	}

	// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ Àü¼Û.
	if(pmsg->Protocol == MP_CHATROOM_CHANGE_OPTION_NOTICE)
	{
		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_ROOM_NOTICE sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡°Ô Àü¼Û ÇÒ ÇÁ·ÎÅäÄÝ ¼¼ÆÃ.
		sendMsg.Protocol = MP_CHATROOM_CHANGE_OPTION_NOTICE_OTHER_AGENT ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡ ¸Þ½ÃÁö¸¦ Àü¼Û.
		g_Network.Send2AgentExceptThis((char*)&sendMsg, nSize) ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : Change_Owner_Notice
//		 :
//	DESC : ¹æÀå º¯°æ ¼º°ø Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. À¯Àú °Ë»ö.
//		 : 2. ¸Þ½ÃÁö Àü¼Û.
//		 : 3. ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ °°Àº ¹æ½ÄÀ¸·Î Àü¼Û.
//		 : 
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Change_Owner_Notice(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_IDNAME* pmsg = NULL ;
	pmsg = (MSG_CR_IDNAME*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// ¸¹ÀÌ »ç¿ëµÇ´Â ¿¬»ê - »çÀÌÁî ¹Þ±â.
	int nSize = 0 ;
	nSize = sizeof(MSG_CR_IDNAME) ;

	// À¯Àú ¼ö ¸¸Å­ ·çÇÁ.
	USERINFO* pInfo ;
	for(BYTE count = 0 ; count < pmsg->byCount ; ++count)
	{
		// À¯Àú¸¦ °Ë»ö.
		pInfo = NULL ;
		pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwUser[count]) ;

		if(!pInfo) continue ;

		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_IDNAME sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		sendMsg.Protocol = MP_CHATROOM_CHANGE_OWNER_NOTICE ;

		// ¸Þ½ÃÁö¸¦ À¯Àú¿¡°Ô Àü¼Û.
		g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&sendMsg, nSize) ;
	}

	// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ Àü¼Û.
	if(pmsg->Protocol == MP_CHATROOM_CHANGE_OWNER_NOTICE)
	{
		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_IDNAME sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡°Ô Àü¼Û ÇÒ ÇÁ·ÎÅäÄÝ ¼¼ÆÃ.
		sendMsg.Protocol = MP_CHATROOM_CHANGE_OWNER_NOTICE_OTHER_AGENT ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡ ¸Þ½ÃÁö¸¦ Àü¼Û.
		g_Network.Send2AgentExceptThis((char*)&sendMsg, nSize) ;
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : Kick_Guest_Ack
//		 : 
//	DESC : °­Á¦ ÅðÀå ´çÇÑ »ç¶÷¿¡°Ô ÀüÇÏ´Â Ã³¸®.
//		 : 
//		 : 1. À¯Àú °Ë»ö.
//		 : 2. ¸Þ½ÃÁö Àü¼Û.
//		 : 3. ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ °°Àº ¹æ½ÄÀ¸·Î Àü¼Û.
//		 : 
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Kick_Guest_Ack(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_KICK_ACK* pmsg = NULL ;
	pmsg = (MSG_CR_KICK_ACK*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// ¸¹ÀÌ »ç¿ëµÇ´Â ¿¬»ê - »çÀÌÁî ¹Þ±â.
	int nSize = 0 ;
	nSize = sizeof(MSG_CR_KICK_ACK) ;

	// À¯Àú¸¦ °Ë»ö.
	USERINFO* pInfo = NULL ;
	pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwKickPlayer) ;

	if(pInfo)
	{
		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_KICK_ACK sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		sendMsg.Protocol = MP_CHATROOM_KICK_GUEST_ACK ;

		// ¸Þ½ÃÁö¸¦ À¯Àú¿¡°Ô Àü¼Û.
		g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&sendMsg, nSize) ;
	}
	else
	{
		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ Àü¼Û.
		if(pmsg->Protocol == MP_CHATROOM_KICK_GUEST_ACK)
		{
			// ¸Þ½ÃÁö¸¦ º¹»ç.
			MSG_CR_KICK_ACK sendMsg ;
			memset(&sendMsg, 0, nSize) ;
			memcpy(&sendMsg, pmsg, nSize) ;

			// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡°Ô Àü¼Û ÇÒ ÇÁ·ÎÅäÄÝ ¼¼ÆÃ.
			sendMsg.Protocol = MP_CHATROOM_KICK_GUEST_ACK_OTHER_AGENT ;

			// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡ ¸Þ½ÃÁö¸¦ Àü¼Û.
			g_Network.Send2AgentExceptThis((char*)&sendMsg, nSize) ;
		}
	}
}





//-------------------------------------------------------------------------------------------------
//	NAME : Kick_Guest_Notice
//		 : 
//	DESC : °­Á¦ ÅðÀå ¼º°ø Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. À¯Àú °Ë»ö.
//		 : 2. ¸Þ½ÃÁö Àü¼Û.
//		 : 3. ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ °°Àº ¹æ½ÄÀ¸·Î Àü¼Û.
//		 : 
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Kick_Guest_Notice(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_CR_IDNAME* pmsg = NULL ;
	pmsg = (MSG_CR_IDNAME*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// ¸¹ÀÌ »ç¿ëµÇ´Â ¿¬»ê - »çÀÌÁî ¹Þ±â.
	int nSize = 0 ;
	nSize = sizeof(MSG_CR_IDNAME) ;

	// À¯Àú ¼ö ¸¸Å­ ·çÇÁ.
	USERINFO* pInfo ;
	for(BYTE count = 0 ; count < pmsg->byCount ; ++count)
	{
		// À¯Àú¸¦ °Ë»ö.
		pInfo = NULL ;
		pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwUser[count]) ;

		if(!pInfo) continue ;

		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_IDNAME sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		sendMsg.Protocol = MP_CHATROOM_KICK_GUEST_NOTICE ;

		// ¸Þ½ÃÁö¸¦ À¯Àú¿¡°Ô Àü¼Û.
		g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&sendMsg, nSize) ;
	}

	// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ Àü¼Û.
	if(pmsg->Protocol == MP_CHATROOM_KICK_GUEST_NOTICE)
	{
		// ¸Þ½ÃÁö¸¦ º¹»ç.
		MSG_CR_IDNAME sendMsg ;
		memset(&sendMsg, 0, nSize) ;
		memcpy(&sendMsg, pmsg, nSize) ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡°Ô Àü¼Û ÇÒ ÇÁ·ÎÅäÄÝ ¼¼ÆÃ.
		sendMsg.Protocol = MP_CHATROOM_KICK_GUEST_NOTICE_OTHER_AGENT ;

		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡ ¸Þ½ÃÁö¸¦ Àü¼Û.
		g_Network.Send2AgentExceptThis((char*)&sendMsg, nSize) ;
	}
}





////-------------------------------------------------------------------------------------------------
////	NAME : ChatMsg_Normal_Notice
////		 : 
////	DESC : Ã¤ÆÃ¹æ ³» ¸Þ½ÃÁö Àü¼Û Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
////		 : 
////	DESC : °­Á¦ ÅðÀå ¼º°ø Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
////		 : 
////		 : 1. À¯Àú °Ë»ö.
////		 : 2. ¸Þ½ÃÁö Àü¼Û.
////		 : 3. ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ °°Àº ¹æ½ÄÀ¸·Î Àü¼Û.
////		 : 
////  DATE : APRIL 14, 2008 LYW
////-------------------------------------------------------------------------------------------------
//void CChatRoomMgr::ChatMsg_Normal_Notice(DWORD dwIndex, char* pMsg, DWORD dwLength)
//{
//	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
//	ASSERT(pMsg) ;
//
//	if(!pMsg)
//	{
//		Throw_Error(err_IMP, __FUNCTION__) ;
//		return ;
//	}
//
//	// ¿øº» ¸Þ½ÃÁö º¯È¯.
//	MSG_CR_MSG_RESULT* pmsg = NULL ;
//	pmsg = (MSG_CR_MSG_RESULT*)pMsg ;
//
//	ASSERT(pmsg) ;
//
//	if(!pmsg)
//	{
//		Throw_Error(err_FCMTO, __FUNCTION__) ;
//		return ;
//	}
//
//	// ¸¹ÀÌ »ç¿ëµÇ´Â ¿¬»ê - »çÀÌÁî ¹Þ±â.
//	int nSize = 0 ;
//	nSize = sizeof(MSG_CR_MSG_RESULT) ;
//
//	// À¯Àú ¼ö ¸¸Å­ ·çÇÁ.
//	USERINFO* pInfo ;
//	for(BYTE count = 0 ; count < pmsg->byCount ; ++count)
//	{
//		// À¯Àú¸¦ °Ë»ö.
//		pInfo = NULL ;
//		pInfo = g_pUserTableForObjectID->FindUser(pmsg->dwUser[count]) ;
//
//		if(!pInfo) continue ;
//
//		// ¸Þ½ÃÁö¸¦ º¹»ç.
//		MSG_CR_MSG_RESULT sendMsg ;
//		memset(&sendMsg, 0, nSize) ;
//		memcpy(&sendMsg, pmsg, nSize) ;
//
//		// ¸Þ½ÃÁö¸¦ À¯Àú¿¡°Ô Àü¼Û.
//		g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&sendMsg, nSize) ;
//	}
//
//	// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡µµ Àü¼Û.
//	if(pmsg->Protocol == MP_CHATROOM_CHATMSG_NORMAL_NOTICE)
//	{
//		// ¸Þ½ÃÁö¸¦ º¹»ç.
//		MSG_CR_MSG_RESULT sendMsg ;
//		memset(&sendMsg, 0, nSize) ;
//		memcpy(&sendMsg, pmsg, nSize) ;
//
//		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡°Ô Àü¼Û ÇÒ ÇÁ·ÎÅäÄÝ ¼¼ÆÃ.
//		sendMsg.Protocol = MP_CHATROOM_CHATMSG_NORMAL_NOTICE_OTHER_AGENT ;
//
//		// ´Ù¸¥ ¿¡ÀÌÀüÆ®¿¡ ¸Þ½ÃÁö¸¦ Àü¼Û.
//		g_Network.Send2AgentExceptThis((char*)&sendMsg, nSize) ;
//	}
//}





//-------------------------------------------------------------------------------------------------
//	NAME : Request_Friend_Ack
//		 : 
//	DESC : Ä£±¸ ¿äÃ» Ã¼Å© ¼º°ø Ã³¸®¸¦ ÇÏ´Â ÇÔ¼ö.
//		 : 
//		 : 1. À¯Àú Ã£±â.
//		 : 2. Ä£±¸ Ãß°¡ Ã³¸®.
//		 : 
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Request_Friend_Ack(DWORD dwIndex, char* pMsg, DWORD dwLength)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(pMsg) ;

	if(!pMsg)
	{
		Throw_Error(err_IMP, __FUNCTION__) ;
		return ;
	}

	// ¿øº» ¸Þ½ÃÁö º¯È¯.
	MSG_NAME* pmsg = NULL ;
	pmsg = (MSG_NAME*)pMsg ;

	ASSERT(pmsg) ;

	if(!pmsg)
	{
		Throw_Error(err_FCMTO, __FUNCTION__) ;
		return ;
	}

	// À¯Àú Ã£±â.
	USERINFO * userinfo = NULL ;
	userinfo = (USERINFO *)g_pUserTableForObjectID->FindUser(pmsg->dwObjectID) ;

	if(!userinfo) return ;
	
	// Ä£±¸ Ãß°¡ Ã³¸®.
	// 080704 LYW --- ChatRoomMgr : ÀÓ½Ã ¹öÆÛ »çÀÌÁî È®Àå.
	//char buf[MAX_NAME_LENGTH+1] = {0, } ;
	//SafeStrCpy( buf, pmsg->Name, MAX_NAME_LENGTH+1 ) ;

	char buf[257] = {0, } ;

	SafeStrCpy( buf, pmsg->Name, 256 ) ;

	//±ÝÁö¹®ÀÚ Ã¼Å© "'"µî...
	if( FILTERTABLE->IsInvalidCharInclude( (unsigned char*) buf ) ) return ;
	
	// 100305 ONS Çã¶ô¿©ºÎ¸¦ ¹¯Áö¾Ê°í Ä£±¸¸¦ Ãß°¡ÇÏµµ·Ï ¼öÁ¤.
	FriendAddFriendByName(pmsg->dwObjectID, buf) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME : Error
//	DESC : Ã¤ÆÃ¹æ ³», ¿¡·¯ ¸Þ½ÃÁö °ü·Ã ·Î±×¸¦ ³²±â´Â ÇÔ¼ö.
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Throw_Error(BYTE errType, const char* szCaption)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(szCaption) ;

	if(!szCaption || strlen(szCaption) <= 1)
	{
#ifdef _USE_ERR_MSGBOX_
		MessageBox( NULL, "Invalid Caption!!", "Throw_Error", MB_OK) ;
#else
		// 080704 LYW --- ChatRoomMgr : ÀÓ½Ã ¹öÆÛ »çÀÌÁî È®Àå.
		//char tempStr[128] = {0, } ;
		//SafeStrCpy(tempStr, __FUNCTION__, 128) ;

		char tempStr[257] = {0, } ;

		SafeStrCpy(tempStr, __FUNCTION__, 256) ;
		strcat(tempStr, " - ") ;
		strcat(tempStr, "Invalid Caption!!") ;
		WriteLog(tempStr) ;
#endif //_USE_ERR_MSGBOX_
		return ;
	}

	// 080704 LYW --- ChatRoomMgr : ÀÓ½Ã ¹öÆÛ »çÀÌÁî È®Àå.
	// ¿¡·¯ Å¸ÀÔ È®ÀÎ.
	//char tempErr[128] = {0, } ;
	//switch(errType)
	//{
	//case err_IMP :		SafeStrCpy(tempErr, "Invalid a message parameter!!", 128) ;					break ;
	//case err_FCMTB :	SafeStrCpy(tempErr, "Failed to convert a message to base!!", 128) ;			break ;
	//case err_FCMTO :	SafeStrCpy(tempErr, "Failed to convert a message to original!!", 128) ;		break ;
	//case err_FRUI : 	SafeStrCpy(tempErr, "Failed to receive a user info!!", 128) ;				break ;
	//default : break ;
	//}

	char tempErr[257] = {0, } ;

	switch(errType)
	{
	case err_IMP :		SafeStrCpy(tempErr, "Invalid a message parameter!!", 256) ;					break ;
	case err_FCMTB :	SafeStrCpy(tempErr, "Failed to convert a message to base!!", 256) ;			break ;
	case err_FCMTO :	SafeStrCpy(tempErr, "Failed to convert a message to original!!", 256) ;		break ;
	case err_FRUI : 	SafeStrCpy(tempErr, "Failed to receive a user info!!", 256) ;				break ;
	default : break ;
	}

	// ¿¡·¯ Ãâ·Â/·Î±×.
#ifdef _USE_ERR_MSGBOX_
	MessageBox( NULL, tempErr, szCaption, MB_OK) ;
#else
	// 080704 LYW --- ChatRoomMgr : ÀÓ½Ã ¹öÆÛ »çÀÌÁî È®Àå.
	//char tempStr[128] = {0, } ;
	//SafeStrCpy(tempStr, szCaption, 128) ;

	char tempStr[257] = {0, } ;

	SafeStrCpy(tempStr, szCaption, 256) ;
	strcat(tempStr, " - ") ;
	strcat(tempStr, tempErr) ;
	WriteLog(tempStr) ;
#endif //_USE_ERR_MSGBOX_
}





//-------------------------------------------------------------------------------------------------
//	NAME : Throw_Error
//	DESC : Ã¤ÆÃ¹æ ³», ¿¡·¯ ¸Þ½ÃÁö °ü·Ã ·Î±×¸¦ ³²±â´Â ÇÔ¼ö.
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::Throw_Error(const char* szErr, const char* szCaption)
{
	// ÇÔ¼ö ÆÄ¶ó¸ÞÅÍ Ã¼Å©.
	ASSERT(szCaption) ;

	if(!szErr || strlen(szErr) <= 1)
	{
#ifdef _USE_ERR_MSGBOX_
		MessageBox( NULL, "Invalid err message!!", "Throw_Error", MB_OK) ;
#else
		// 080704 LYW --- ChatRoomMgr : ÀÓ½Ã ¹öÆÛ »çÀÌÁî È®Àå.
		//char tempStr[128] = {0, } ;
		//SafeStrCpy(tempStr, __FUNCTION__, 128) ;

		char tempStr[257] = {0, } ;

		SafeStrCpy(tempStr, __FUNCTION__, 256) ;
		strcat(tempStr, " - ") ;
		strcat(tempStr, "Invalid err message!!") ;
		WriteLog(tempStr) ;
#endif //_USE_ERR_MSGBOX_
		return ;
	}

	if(!szCaption || strlen(szCaption) <= 1)
	{
#ifdef _USE_ERR_MSGBOX_
		MessageBox( NULL, "Invalid Caption!!", "Throw_Error", MB_OK) ;
#else
		// 080704 LYW --- ChatRoomMgr : ÀÓ½Ã ¹öÆÛ »çÀÌÁî È®Àå.
		//char tempStr[128] = {0, } ;
		//SafeStrCpy(tempStr, __FUNCTION__, 128) ;

		char tempStr[257] = {0, } ;

		SafeStrCpy(tempStr, __FUNCTION__, 256) ;
		strcat(tempStr, " - ") ;
		strcat(tempStr, "Invalid Caption!!") ;
		WriteLog(tempStr) ;
#endif //_USE_ERR_MSGBOX_
		return ;
	}

	// ¿¡·¯ Ãâ·Â/·Î±×.
#ifdef _USE_ERR_MSGBOX_
	MessageBox( NULL, szErr, szCaption, MB_OK) ;
#else
	// 080704 LYW --- ChatRoomMgr : ÀÓ½Ã ¹öÆÛ »çÀÌÁî È®Àå.
	//char tempStr[128] = {0, } ;
	//SafeStrCpy(tempStr, szCaption, 128) ;

	char tempStr[257] = {0, } ;

	SafeStrCpy(tempStr, szCaption, 256) ;
	strcat(tempStr, " - ") ;
	strcat(tempStr, szErr) ;
	WriteLog(tempStr) ;
#endif //_USE_ERR_MSGBOX_
}





//-------------------------------------------------------------------------------------------------
//	NAME : WriteLog
//	DESC : Ã¤ÆÃ¹æ ³», ¿¡·¯ ¸Þ½ÃÁö °ü·Ã ·Î±×¸¦ ³²±â´Â ÇÔ¼ö.
//  DATE : APRIL 14, 2008 LYW
//-------------------------------------------------------------------------------------------------
void CChatRoomMgr::WriteLog(char* pMsg)
{
	SYSTEMTIME time ;
	GetLocalTime(&time) ;

	TCHAR szTime[_MAX_PATH] = {0, } ;
	sprintf(szTime, "%04d-%02d-%02d %02d:%02d:%02d", time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute, time.wSecond) ;

	FILE *fp = fopen("Log/Agent-ChatRoomErr.log", "a+");
	if (fp)
	{
		fprintf(fp, "%s [%s]\n", pMsg,  szTime);
		fclose(fp);
	}
}




