// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
#define AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#define _WIN32_WINNT	0x0500 
//#define _CRYPTCHECK_ 

#pragma warning(disable:4786)
#pragma warning(disable:4100) // ÂüÁ¶ÇÏÁö ¾Ê´Â ¸Å°³º¯¼ö
#pragma warning(disable:4127) // Á¶°Ç½ÄÀÌ »ó¼öÀÎ °æ¿ì
#pragma warning(disable:4201) // ºñÇ¥ÁØ È®ÀåÀ» »ç¿ëÇÑ°æ¿ì ³»ºÎ¿¡ Struct ¸¸µé¶§ ÀÌ¸§À» ÀûÁö ¾Ê¾ÒÀ½.

#include <windows.h>
#include <winsock2.h>
#include <ole2.h>
#include <initguid.h>
#include <stdio.h>
#include <assert.h>
#include <tchar.h>
// TODO: reference additional headers your program requires here


#ifdef _AGENT00_ 

#endif

#ifdef _AGENT00_ 

#else
#include "DataBase.h"
#include "Console.h"
#include "yhlibrary.h"
//#include "CommonHeader.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
#include "ServerGameStruct.h"
#include "CommonGameFunc.h"


#include "ServerSystem.h"

#endif

template< typename T > class CPool;

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
