#include "stdafx.h"
#ifdef _AGENT00_ 
#include "Wnano.h"
#include "yhlibrary.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
#include "ServerGameStruct.h"

#include "CommonGameFunc.h"
#include "ServerSystem.h"
#else
#include "CommonDBMsgParser.h"

#endif
#include "AgentDBMsgParser.h"
#include "DataBase.h"
#include "UserTable.h"
#include "ServerTable.h"
#include "Console.h"
#include "Network.h"
#include "MsgTable.h"
#include "ServerSystem.h"
#include "GMPowerList.h"
// S ??夷?夷띿㎞ ??吏몄쭠 added by hseos 2007.07.09 
#include "hseos/Family/SHFamilyManager.h"
#include "hseos/Farm/SHFarmManager.h"
// E ??夷?夷띿㎞ ??吏몄쭠 added by hseos 2007.07.09
#include "AgentNetworkMsgParser.h"


//---KES PUNISH
#include "PunishManager.h"
//-------------

// 080507 LYW --- AgentDBMsgParser : ?吏??夷붿콌 夷?夷??吏??梨숈쮫泥??泥??.
#include "ChatRoomMgr.h"

// 080813 LYW --- AgentDBMsgParser : 吏몄꺽姨뚯쮼 姨??吏깆쮷吏?夷?夷??吏??梨숈쮫泥??泥??.
#include "SiegeRecallMgr.h"

// 080822 LYW --- AgentDBMsgParser : Npc 姨??吏?夷?夷??吏??梨숈쮫泥??泥??.
#include "NpcRecallMgr.h"

#ifdef _HACK_SHIELD_
#include "HackShieldManager.h"
#endif
#ifdef _NPROTECT_
#include "NProtectManager.h"
#endif
#include "giftmanager.h"

//MSG_CHAT g_WisperTemp;
//MSG_CHAT g_MunpaTemp;
//MSG_CHAT g_PartyTemp;

extern int g_nServerSetNum;

//-----------------------------------------------------------------------
// DB???夷?夷?吏??夷?吏???? ?????姨?夷?吏?吏??夷???姨?吏?夷?吏?夷?吏?夷?夷?夷?? ?????吏?吏?
// enum Query ??? ?姨?夷?姨?吏?吏?吏??夷???夷?吏?姨??!!!! ??????吏?????姨?? ?????夷??.
DBMsgFunc g_DBMsgFunc[MaxQuery] =
{
	NULL,
	RUserIDXSendAndCharacterBaseInfo,	// ???夷?夷?吏???? ?夷?吏?姨?夷???吏?Query
	RCreateCharacter,
	NULL,
	RDeleteCharacter,
	RCharacterNameCheck,
	NULL,
	NULL,
	RSearchWhisperUserAndSend, /// ???夷?夷?吏?夷?吏??夷?夷?? ???吏?姨???姨?吏?夷???夷?? ?夷???夷?夷???吏??姨?吏?姨?吏?姨??吏?吏?
	NULL,							//SavePoint 
	NULL,							/// ?夷???姨?吏?姨?吏??夷?吏?吏?吏?夷?吏??姨???????????夷??
	NULL,							/// ?夷???姨?吏?夷?夷????姨?夷?吏?姨?? ?姨??????
	RFriendIsValidTarget,		//FriendGetUserIDXbyName
	RFriendAddFriend,
	RFriendIsValidTarget,
	RFriendDelFriend,
	RFriendDelFriendID,
	NULL, //???吏?吏?夷?夷?吏?姨?夷???吏??夷?吏???吏????夷?夷?吏???? ?夷?吏???吏?姨??)
	RFriendNotifyLogintoClient,
	RFriendGetFriendList,
	RFriendGetLoginFriends,
	RNoteIsNewNote,
	NULL,
	RNoteDelete,
	RNoteSave,
//For GM-Tool	
	RGM_BanCharacter,
	RGM_UpdateUserLevel,			/// eGM_UpdateUserLevel,
	RGM_WhereIsCharacter,
	RGM_Login,
	RGM_GetGMPowerList,
//	
	NULL,
	RCheckGuildMasterLogin,			// checkguildmasterlogin
	RCheckGuildFieldWarMoney,		// check guildfieldwarmoney
	RAddGuildFieldWarMoney,			// addd guildfieldwarmoney
	NULL,							// 051108 event
	NULL,							// eEventItemUse2

	RGM_UpdateUserState,

	NULL,							// eLogGMToolUse

	NULL,

	NULL,
	NULL,
	// desc_hseos_姨뚯쮼夷섏㎏姨뚯㏏??01
	// S 姨뚯쮼夷섏㎏姨뚯㏏?? ??吏몄쭠 added by hseos 2007.06.15
	NULL,							// eInitMonstermeterInfoOfDB
	RGetUserSexKind,				// eGetUserSexKind
	// E 姨뚯쮼夷섏㎏姨뚯㏏?? ??吏몄쭠 added by hseos 2007.06.15

	// desc_hseos_??夷?夷띿㎞01
	// S ??夷?夷띿㎞ ??吏몄쭠 added by hseos 2007.07.09	2007.07.10	2007.07.14	2007.10.11
	RFamily_LoadInfo,					// eFamily_LoadInfo
	RFamily_SaveInfo,					// eFamily_SaveInfo
	RFamily_Member_LoadInfo,			// eFamily_Member_LoadInfo
	RFamily_Member_LoadExInfo01,		// eFamily_Member_LoadExInfo01,
	NULL,								// eFamily_Member_SaveInfo
	RFamily_CheckName,					// eFamily_CheckName
	RFamily_Leave_LoadInfo,				// eFamily_Leave_LoadInfo
	NULL,								// eFamily_Leave_SaveInfo
	NULL,								// 091111 ONS ??夷?夷띿㎞ 夷붿㎞?梨낆Ł梨?吏???吏몄쭠
	RFarm_SendNote_DelFarm,
	NULL,								//ePunishList_Add,	//---?吏?梨뚯쮰梨곗쮯?
	RPunishListLoad,					//ePunishList_Load,	//---?吏?梨뚯쮰梨곗쮯?
	RPunishCountAdd,					//ePunishCount_Add, //---吏?夷띿㎏ ?夷띿찈泥???吏몄쭠

	RGiftEvent,							//eGiftEvent,
//-------------

  	// 080812 LYW --- AgentDBMsgParser : 姨??吏깆쮷吏?db 姨먯꺼夷됱쭨???吏??夷夷띿㎞ ??吏몄쭠.
  	RSiegeRecallUpdate,	// eSiegeRecallUpdate,
  
  	// 080813 LYW --- AgentDBMsgParser : 姨??吏깆쮷吏?db ?吏싳쮼夷?夷?夷됱콉 ?夷夷띿㎞ ??吏몄쭠.
  	RSiegeRecallLoad,	//eSiegeRecallLoad,
  
  	// 080831 LYW --- AgentDBMsgParser : 姨??吏깆쮷吏?db ?吏싳쮼夷???吏몄쭠 ?夷夷띿㎞ ??吏몄쭠.
  	RSiegeRecallInsert,
  
  	// 080831 LYW --- AgentDBMsgParser : 姨??吏깆쮷吏?db ?吏싳쮼夷?夷⑹콛?吏??夷夷띿㎞ ??吏몄쭠.
  	NULL,	// eSiegeRecallRemove,
  
	// 090525 ShinJS --- ??夷띿쭬?夷띿쮯? ???姨??夷덉콠姨? DB 吏?夷⑹쿋 ?夷夷띿㎞ ??吏몄쭠
	RSearchCharacterForInvitePartyMember,
};	

// ???夷?夷?吏???? ?夷?吏?姨?夷???吏??吏?吏???吏?姨??夷?? DB???夷?夷?吏?
void UserIDXSendAndCharacterBaseInfo(DWORD UserIDX, DWORD AuthKey, DWORD dwConnectionIndex)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eCharacterBaseQuery, dwConnectionIndex, "EXEC MP_CHARACTER_SELECTBYUSERIDX %d, %d", UserIDX, AuthKey);
}

void CheatLog(DWORD CharacterIDX,DWORD CheatKind)
{
	char txt[256];
	sprintf(txt,"INSERT TB_LogHacking (Character_idx,CheatKind,LogDate) values(%d,%d,getdate())",
				CharacterIDX,CheatKind);
	g_DB.LogQuery(eQueryType_FreeQuery,0,0,txt);
}

void CreateCharacter(CHARACTERMAKEINFO* pMChar, WORD ServerNo, DWORD dwConnectionIndex)
{
	CHARACTERMAKEINFO* pMsg = pMChar;
	char txt[512];

	// 100301 ShinJS --- 吏뱀갹夷섏Ł 姨띿쮼???夷?夷띿㎞姨?姨띿쮼姨붿쭠姨뚯㎝ ??夷됱쮬夷? 姨뚯쿋?吏?
	BYTE byRace				= pMsg->RaceType;
	BYTE byClass			= pMsg->JobType - 1;
	const PlayerStat stat	= g_pServerSystem->GetBaseStatus( (RaceType)byRace, byClass + 1 );

	BYTE Str = (BYTE)stat.mStrength.mPlus;
	BYTE Dex = (BYTE)stat.mDexterity.mPlus;
	BYTE Vit = (BYTE)stat.mVitality.mPlus;
	BYTE Int = (BYTE)stat.mIntelligence.mPlus;
	BYTE Wis = (BYTE)stat.mWisdom.mPlus;

	DWORD item[3][2];

	item[0][0] = 11000001;
	item[0][1] = 12000063;

	item[1][0] = 11000187;
	item[1][1] = 12000032;

	item[2][0] = 11000249;
	item[2][1] = 12000001;

	char ip[16];
	WORD port;
	g_Network.GetUserAddress( dwConnectionIndex, ip, &port );

	int LoginPoint = 2019;
	BYTE bStartMap = 20;
	
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	char szBufName[MAX_NAME_LENGTH+1];
	char szBufIp[MAX_IPADDRESS_SIZE];

	SafeStrCpy(szBufName, pMsg->Name, MAX_NAME_LENGTH+1);
	SafeStrCpy(szBufIp, ip, MAX_IPADDRESS_SIZE);

	if(IsCharInString(szBufName, "'") || IsCharInString(szBufIp, "'"))	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC %s %d, %d, %d, %d, %d, %d, \'%s\', %d, %d, %d, %d, %d, %d, %d, %d, \'%s\', %u, %u", 
		"MP_CHARACTER_CREATECHARACTER", pMsg->UserID, Str, Dex, Vit, Int, Wis, 
		szBufName, pMsg->FaceType, pMsg->HairType, bStartMap, pMsg->SexType,
		pMsg->RaceType, pMsg->JobType, LoginPoint, ServerNo, szBufIp, item[byClass%3][0], item[byClass%3][1]);
		
	if(g_DB.Query(eQueryType_FreeQuery, eCreateCharacter, dwConnectionIndex, txt) == FALSE)
	{
	}

}

void CharacterNameCheck(char* pName, DWORD dwConnectionIndex)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(IsCharInString(pName, "'"))	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eNewCharacterCheckName, dwConnectionIndex, "EXEC %s \'%s\'", "MP_CHARACTER_NAMECHECK", pName);
}

void LoginCheckDelete(DWORD UserID)//, DWORD dwConnectionIndex)
{
	// 090710 LUJ, 夷?吏?姨?姨붿쿃 ?夷夷띿㎞ 夷뗭쭬 姨뚯㎝夷붿쿋姨? 夷붿꺽?吏숈쮰吏??泥댁쮫???
	char txt[ MAX_PATH ] = { 0 };
	sprintf( txt, "EXEC DBO.UP_GAMELOGOUT %d, %d", UserID, g_nServerSetNum );
	g_DB.LoginQuery( eQueryType_FreeQuery, eLoginCheckDelete, 0, txt );
}

void DeleteCharacter(DWORD dwPlayerID, WORD ServerNo, DWORD dwConnectionIndex)
{
	USERINFO* pinfo = g_pUserTable->FindUser(dwConnectionIndex);
	if(!pinfo)
		return;
	CHARSELECTINFO * SelectInfoArray = (CHARSELECTINFO*)pinfo->SelectInfoArray;
	
	for(int i = 0; i < MAX_CHARACTER_NUM; i++)
	{
		if(SelectInfoArray[i].dwCharacterID == dwPlayerID)
			break;
		if(i == MAX_CHARACTER_NUM - 1)	// ??吏??夷?吏?吏??吏?吏???夷?吏?吏?????夷?? ???夷?夷?吏?吏?夷??夷???夷?吏????夷?夷?吏??? ?姨?吏?????夷??
		{
			// ?姨?吏?吏?吏?夷?? ???夷?夷?吏?吏?夷????夷?姨?吏???夷?夷?吏??? ??????吏???????夷??姨???姨??夷???夷??
			return;
		}
	}

	char ip[16];
	WORD port;
	g_Network.GetUserAddress( dwConnectionIndex, ip, &port );

	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	char szBufIp[MAX_IPADDRESS_SIZE];
	SafeStrCpy(szBufIp, ip, MAX_IPADDRESS_SIZE);
	if(IsCharInString(szBufIp, "'"))	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eDeleteCharacter, dwConnectionIndex, "EXEC %s %d, %d, \'%s\'", "MP_CHARACTER_DELETECHARACTER", dwPlayerID, ServerNo, szBufIp );
}

void SearchWhisperUserAndSend( DWORD dwPlayerID, char* CharacterName, DWORD dwKey )
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(IsCharInString(CharacterName, "'"))	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eLoginMapInfoSearchForName, dwKey, "EXEC %s \'%s\', %d", "MP_LOGINCHARACTERSEARCHFORNAME", CharacterName, dwPlayerID );
}

void SaveMapChangePointUpdate(DWORD CharacterIDX, WORD MapChangePoint_Idx)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eSavePoint, CharacterIDX, "EXEC  %s %d, %d", "MP_CHARACTER_MAPCHANGEPOINTUPDATE", CharacterIDX, MapChangePoint_Idx);
	
}

void LoadCharacterMap(DWORD CharacterIDX)
{
	g_DB.FreeMiddleQuery(RLoadCharacterMap, CharacterIDX, "EXEC %s %d", "MP_CHARACTER_CharacterMapLoad", CharacterIDX);
}

void RLoadCharacterMap(LPMIDDLEQUERY pData, LPDBMESSAGE pMessage )
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(!pRecverInfo)
		return;
#ifdef _AGENT00_ 
  DWORD dwMapNum = (DWORD)pData->getDataINT( 1);
#else
	DWORD dwMapNum = (DWORD)atoi((char*)pData[0].Data[1]);
#endif
	MSG_DWORD3 stPacket;

	stPacket.Category	= MP_USERCONN;
	stPacket.Protocol	= MP_USERCONN_CHANGEMAP_SYN;
	stPacket.dwObjectID	= pRecverInfo->dwCharacterID;
	stPacket.dwData1	= g_pServerSystem->GetMapChangeIndex(dwMapNum);
	UserConn_ChangeMap_Syn(pRecverInfo->dwConnectionIndex, (char*)&stPacket, sizeof(stPacket) );
}

void UnRegistLoginMapInfo(DWORD CharacterIDX)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eUnRegistLoginMapInfo, CharacterIDX, "EXEC %s %d", "MP_LOGINMAPINFO_UNREGIST", CharacterIDX);
}

void FriendGetUserIDXbyName(DWORD CharacterIDX, char* TargetName)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(IsCharInString(TargetName, "'"))	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eFriendGetTargetMemeberIDX, CharacterIDX, "EXEC %s \'%s\', %u", "MP_FRIEND_GETTARGETIDX", TargetName, CharacterIDX);
}

void FriendAddFriend(DWORD CharacterIDX, DWORD TargetID) //CharacterIDX : ?姨?????夷???, TargetID : ?姨???夷?吏???
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eFriendAdd, CharacterIDX, "EXEC %s %u, %u", "MP_FRIEND_ADDFRIEND", CharacterIDX, TargetID);
}

// 100305 ONS ?李얠쮮泥숈찓吏ㅼ쮼?夷띿쭩 夷붿㎟?泥좎찎?吏몄콬 ?吏숈㏏夷띿쮰吏???吏몄쭠??夷됱쮬夷? 姨뚯쿋?吏?
void FriendAddFriendByName(DWORD CharacterIDX, char* TargetName) //CharacterIDX : ?姨?????夷???, TargetID : ?姨???夷?吏???
{
	if(IsCharInString(TargetName, "'"))	return;

	g_DB.FreeQuery(eFriendAdd, CharacterIDX, "EXEC %s %u, \'%s\'", "MP_FRIEND_ADDFRIEND", CharacterIDX, TargetName);
}

void FriendIsValidTarget(DWORD CharacterIDX, DWORD TargetID, char* FromName)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(IsCharInString(FromName, "'"))	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eFriendIsValidTarget, CharacterIDX, "EXEC %s %d, %d, \'%s\'", "MP_FRIEND_ISVALIDTARGET", CharacterIDX, TargetID, FromName);
}

void FriendDelFriend(DWORD CharacterIDX, char* TargetName)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(IsCharInString(TargetName, "'"))	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eFriendDel, CharacterIDX, "EXEC %s %u, \'%s\'", "MP_FRIEND_DELFRIEND", CharacterIDX, TargetName);
}

void FriendDelFriendID(DWORD CharacterIDX, DWORD TargetID, DWORD bLast)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eFriendDelID, CharacterIDX, "EXEC %s %u, %u, %d", "MP_FRIEND_DELFRIENDID", CharacterIDX, TargetID, bLast);
}

void FriendNotifyLogintoClient(DWORD CharacterIDX)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eFriendNotifyLogin, CharacterIDX, "EXEC %s %u", "MP_FRIEND_NOTIFYLOGIN", CharacterIDX); //?夷?吏?夷?吏??夷?吏?夷?????? ?夷?吏?夷?夷?夷?吏?
}

void FriendGetLoginFriends(DWORD CharacterIDX)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eFriendGetLoginFriends, CharacterIDX, "EXEC %s %u", "MP_FRIEND_LOGINFRIEND", CharacterIDX);//?夷?夷?吏?吏??夷?吏?夷?????? ?夷?吏?夷?夷?夷?吏?
}

void FriendGetFriendList(DWORD CharacterIDX)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eFriendGetFriendList, CharacterIDX, "EXEC %s %u", "MP_FRIEND_GETFRIENDLIST", CharacterIDX);
}

void NoteIsNewNote(DWORD PlayerID)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eNoteIsNewNote, PlayerID, "EXEC %s %u", "MP_NOTE_ISNEWNOTE", PlayerID);
}

void NoteSendtoPlayer(DWORD FromIDX, char* FromName, char* ToName, char* Title, char* Note)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if( IsCharInString(ToName, "'") || IsCharInString(FromName, "'") || IsCharInString(Title, "'") || IsCharInString(Note, "'") )	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeLargeQuery(RNoteSendtoPlayer, FromIDX, "EXEC %s \'%s\', \'%s\', \'%s\', \'%s\', %d, %d", "MP_NOTE_SENDNOTE", ToName, FromName, Title, Note, 0, 0);	
}

void NoteServerSendtoPlayer(DWORD FromIDX, char* FromName, char* ToName, char* Title, char* Note)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if( IsCharInString(ToName, "'") || IsCharInString(FromName, "'") || IsCharInString(Title, "'") || IsCharInString(Note, "'") )	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeLargeQuery(RNoteServerSendtoPlayer, FromIDX, "EXEC %s \'%s\', \'%s\', \'%s\', \'%s\', %d, %d", "MP_NOTE_SENDNOTE", ToName, FromName, Title, Note, 0, 0);	
}

void NoteSendtoPlayerID(DWORD FromIDX, char* FromName, DWORD ToIDX, char* Note)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if( IsCharInString(FromName, "'") || IsCharInString(Note, "'") )	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeLargeQuery(RNoteSendtoPlayer, FromIDX, "EXEC %s %u, \'%s\', %u, \'%s\'", "MP_NOTE_SENDNOTEID", FromIDX, FromName, ToIDX, Note);
}

void NoteDelAll(DWORD CharacterIDX)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eNoteDelAll, 0, "EXEC %s %u", "MP_NOTE_DELALLNOTE", CharacterIDX);
}

void NoteList(DWORD CharacterIDX, WORD Page, WORD Mode)
{	
	USERINFO * userinfo = (USERINFO *)g_pUserTableForObjectID->FindUser(CharacterIDX);
	if(!userinfo)
		return;
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeMiddleQuery(RNoteList, CharacterIDX, "EXEC %s %u, %d, %u, %d", "MP_NOTE_GETNOTELIST", CharacterIDX, 11, Page, Mode);
}

void NoteRead(DWORD CharacterIDX, DWORD NoteIDX, DWORD IsFront)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeLargeQuery(RNoteRead, CharacterIDX, "EXEC %s %u, %u, %u", "MP_NOTE_READNOTE", CharacterIDX, NoteIDX, IsFront);
}

void NoteDelete(DWORD PlayerID, DWORD NoteID, BOOL bLast)
{	
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eNoteDelete, PlayerID, "EXEC %s %d, %d, %d, %d", "MP_NOTE_DELNOTE", PlayerID, FALSE/*@bUserDelete*/, NoteID, bLast);
}

void NoteSave(DWORD PlayerID, DWORD NoteID, BOOL bLast)
{
	g_DB.FreeQuery(eNoteSave, PlayerID, "EXEC %s %u, %u, %d", "MP_NOTE_SAVENOTE", PlayerID, NoteID, bLast);
}

//---for GM_Tool
void GM_WhereIsCharacter(DWORD dwID, char* CharacterName, DWORD dwSeacherID )
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if( IsCharInString(CharacterName, "'") )	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eGM_WhereIsCharacter, dwID, "EXEC %s \'%s\', %d", "MP_LOGINCHARACTERSEARCHFORNAME", CharacterName, dwSeacherID );
}

void GM_BanCharacter(DWORD dwID, char* CharacterName, DWORD dwSeacherID )
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if( IsCharInString(CharacterName, "'") )	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery(eGM_BanCharacter, dwID, "EXEC %s \'%s\', %d", "MP_LOGINCHARACTERSEARCHFORNAME", CharacterName, dwSeacherID );
}

void GM_UpdateUserLevel(DWORD dwID, DWORD dwServerGroup, char* Charactername, BYTE UserLevel)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if( IsCharInString(Charactername, "'") )	return;

    char txt[128];
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC %s %d, \'%s\', %d", "MP_GMTOOL_UPDATEUSERLEVEL", dwServerGroup, Charactername, UserLevel);
	g_DB.LoginQuery(eQueryType_FreeQuery, eGM_UpdateUserLevel, dwID, txt);
}

void GM_Login( DWORD dwConnectionIdx, char* strID, char* strPW, char* strIP )
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if( IsCharInString(strID, "'") || IsCharInString(strPW, "'") || IsCharInString(strIP, "'"))	return;

	char txt[128];
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC RP_OPERATORLOGINCHECK \'%s\', \'%s\', \'%s\'", strID, strPW, strIP);	
	g_DB.LoginQuery(eQueryType_FreeQuery, eGM_Login, dwConnectionIdx, txt);
}

void GM_GetGMPowerList( DWORD dwStartIdx, DWORD dwFlag )
{
	char txt[128];
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC %s %d, %d", "RP_OPERATORINFO", dwStartIdx, dwFlag );
	g_DB.LoginQuery(eQueryType_FreeQuery, eGM_GetGMPowerList, 0, txt);
}

void	RUserIDXSendAndCharacterBaseInfo(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  DWORD count = 0;
  DWORD AgentAuthKey = 0;
  if( pData->isnextOK() ){ count = pData->getDataINT( 0 );
    AgentAuthKey = pData->getDataINT( eCL_AuthKey );
  }
#else
	DWORD count = pMessage->dwResult;
	if(atoi((char*)pData[0].Data[0]) == 0)
		count = 0;
	DWORD AgentAuthKey = atoi((char*)pData[0].Data[eCL_AuthKey]);
#endif
	USERINFO* pInfo = g_pUserTable->FindUser(pMessage->dwID);
	if(pInfo == NULL)		// ????夷?? ?夷?吏?吏?吏??姨?
		return;
	if(pInfo->dwUniqueConnectIdx != AgentAuthKey)	// ?夷?吏?吏?吏?吏?吏??夷???夷?吏?夷????? ?夷?吏?姨?吏?姨??
		return;

	//count = min(		MAX_CHARACTER_NUM,		count); // where is min?
  if( count > MAX_CHARACTER_NUM ){ count = MAX_CHARACTER_NUM;}

	SEND_CHARSELECT_INFO msg;
	ZeroMemory(		&msg,		sizeof(msg));

	msg.Category = MP_USERCONN;
	msg.Protocol = MP_USERCONN_CHARACTERLIST_ACK;

//---KES Crypt
#ifdef _CRYPTCHECK_ 
	msg.eninit = *pInfo->crypto.GetEnKey();
	msg.deinit = *pInfo->crypto.GetDeKey();
#endif
//--------
	if( !count ) /// ?姨?????夷??夷?夷?夷?吏????夷?夷?吏?????吏?吏??姨?夷?夷??.
	{
		msg.CharNum = 0;			// ??? ???吏?姨?吏???吏?吏?吏?0????夷?吏????夷?夷?吏??? ?????夷?吏?夷?? ?姨?夷?夷???吏??????夷??
		g_Network.Send2User(pMessage->dwID, (char*)&msg, sizeof(SEND_CHARSELECT_INFO));
#ifdef _CRYPTCHECK_
		pInfo->crypto.SetInit( TRUE );		// init on	
#endif
#ifdef _NPROTECT_
		//??吏몄꺼?夷?姨붿ℓ夷뚯㎟吏뱀쮼夷됱쭨姨뚯㎝ 夷됱콝姨먯광姨?姨뚯쿋夷됱쮬 ??夷?.(?夷붿쮯?吏???姨?, ?夷夷띿㎟??夷⑹껨姨뚯쮼?吏뽰찓吏뺤찈吏? 吏???姨붿쭠姨뚯㎝)
		if( pInfo->m_nCSAInit == 0 )	//?夷????泥?? 姨?夷?姨먯광 ??夷?夷띿콝
		{
			pInfo->m_nCSAInit = 1;		//?夷????泥?姨???
			NPROTECTMGR->SendAuthQuery(pInfo);

		}
#endif
		return;
	}

#ifdef _AGENT00_ 
  DWORD ii = 0;
  for( DWORD i=0; i < MAX_CHARACTER_NUM ; i++)
#else
  msg.CharNum = (BYTE)(count);
	for( DWORD i=0; i<count; i++)
#endif
	{
#ifdef _AGENT00_ 
		msg.BaseObjectInfo[i].dwObjectID = pData->getDataINT( eCL_ObjectID);
		msg.StandingArrayNum[i] = (WORD)pData->getDataINT( eCL_StandIndex);
    std::string d0 = pData->getSTR( eCL_ObjectName );
		SafeStrCpy( msg.BaseObjectInfo[i].ObjectName,		&d0[0],	_countof(msg.BaseObjectInfo[i].ObjectName));
		msg.ChrTotalInfo[i].FaceType = (BYTE)pData->getDataINT( eCL_BodyType);
		msg.ChrTotalInfo[i].HairType = (BYTE)pData->getDataINT( eCL_HeadType);
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Weapon] = pData->getDataINT( eCL_Weapon);
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Dress] = pData->getDataINT( eCL_Dress);
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Shoes] = pData->getDataINT( eCL_shoes);
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Glove] = pData->getDataINT( eCL_Glove);
		msg.ChrTotalInfo[i].Level = (LEVELTYPE)pData->getDataINT( eCL_Grade );
		msg.ChrTotalInfo[i].LoginMapNum = (MAPTYPE)pData->getDataINT( eCL_Map );
		msg.ChrTotalInfo[i].Gender = (BYTE)pData->getDataINT( eCL_Gender );
		msg.ChrTotalInfo[i].Race = (BYTE)pData->getDataINT( eCL_Race );
		msg.ChrTotalInfo[i].JobGrade = (BYTE)pData->getDataINT( eCL_JobGrade );
		msg.ChrTotalInfo[i].Job[0] = (BYTE)pData->getDataINT( eCL_Job1 );
		msg.ChrTotalInfo[i].Job[1] = (BYTE)pData->getDataINT( eCL_Job2 );
		msg.ChrTotalInfo[i].Job[2] = (BYTE)pData->getDataINT( eCL_Job3 );
		msg.ChrTotalInfo[i].Job[3] = (BYTE)pData->getDataINT( eCL_Job4 );
		msg.ChrTotalInfo[i].Job[4] = (BYTE)pData->getDataINT( eCL_Job5 );
		msg.ChrTotalInfo[i].Job[5] = (BYTE)pData->getDataINT( eCL_Job6 );
    std::string d1 = pData->getSTR( eCL_GuildName);
		SafeStrCpy( msg.ChrTotalInfo[i].GuildName, &d1[0], MAX_GUILD_NAME+1 );
#else
		// ???夷?夷?吏???? ?吏?吏?夷?夷???吏?夷?夷??姨???????????夷???吏?夷?
		msg.BaseObjectInfo[i].dwObjectID = atoi((char*)pData[i].Data[eCL_ObjectID]);
		msg.StandingArrayNum[i] = (WORD)atoi((char*)pData[i].Data[eCL_StandIndex]);
		SafeStrCpy(
			msg.BaseObjectInfo[i].ObjectName,
			(char*)pData[i].Data[eCL_ObjectName],
			_countof(msg.BaseObjectInfo[i].ObjectName));
		msg.ChrTotalInfo[i].FaceType = (BYTE)atoi((char*)pData[i].Data[eCL_BodyType]);
		msg.ChrTotalInfo[i].HairType = (BYTE)atoi((char*)pData[i].Data[eCL_HeadType]);
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Weapon] = atoi((char*)pData[i].Data[eCL_Weapon]);
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Dress] = atoi((char*)pData[i].Data[eCL_Dress]);
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Shoes] = atoi((char*)pData[i].Data[eCL_shoes]);
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Glove] = atoi((char*)pData[i].Data[eCL_Glove]);
		msg.ChrTotalInfo[i].Level = (LEVELTYPE)atoi((char*)pData[i].Data[eCL_Grade]);
		msg.ChrTotalInfo[i].LoginMapNum = (MAPTYPE)atoi((char*)pData[i].Data[eCL_Map]);
		msg.ChrTotalInfo[i].Gender = (BYTE)atoi((char*)pData[i].Data[eCL_Gender]);
		msg.ChrTotalInfo[i].Race = (BYTE)atoi((char*)pData[i].Data[eCL_Race]);
		msg.ChrTotalInfo[i].JobGrade = (BYTE)atoi((char*)pData[i].Data[eCL_JobGrade]);
		msg.ChrTotalInfo[i].Job[0] = (BYTE)atoi((char*)pData[i].Data[eCL_Job1]);
		msg.ChrTotalInfo[i].Job[1] = (BYTE)atoi((char*)pData[i].Data[eCL_Job2]);
		msg.ChrTotalInfo[i].Job[2] = (BYTE)atoi((char*)pData[i].Data[eCL_Job3]);
		msg.ChrTotalInfo[i].Job[3] = (BYTE)atoi((char*)pData[i].Data[eCL_Job4]);
		msg.ChrTotalInfo[i].Job[4] = (BYTE)atoi((char*)pData[i].Data[eCL_Job5]);
		msg.ChrTotalInfo[i].Job[5] = (BYTE)atoi((char*)pData[i].Data[eCL_Job6]);
		SafeStrCpy( msg.ChrTotalInfo[i].GuildName, (char*)pData[i].Data[eCL_GuildName], MAX_GUILD_NAME+1 );
#endif
		msg.BaseObjectInfo[i].ObjectState = eObjectState_None;
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Hat] = 0;
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Earring1] = 0;
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Earring2] = 0;
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Necklace] = 0;
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Ring1] = 0;
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Ring2] = 0;
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Belt] = 0;	
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Shield] = 0;
		msg.ChrTotalInfo[i].WearedItemIdx[eWearedItem_Band] = 0;
		msg.ChrTotalInfo[i].bVisible = TRUE;
		msg.ChrTotalInfo[i].Height = 1;
		msg.ChrTotalInfo[i].Width = 1;
		pInfo->SelectInfoArray[i].dwCharacterID = msg.BaseObjectInfo[i].dwObjectID;
		pInfo->SelectInfoArray[i].Level = msg.ChrTotalInfo[i].Level;
		pInfo->SelectInfoArray[i].MapNum = msg.ChrTotalInfo[i].LoginMapNum;
		pInfo->SelectInfoArray[i].Gender = msg.ChrTotalInfo[i].Gender;
		SafeStrCpy(pInfo->SelectInfoArray[i].name, msg.BaseObjectInfo[i].ObjectName, 32) ;
    
#ifdef _AGENT00_ 
    ii++;
    if( !pData->isnextOK() ) break;
#endif
	}
#ifdef _AGENT00_ 
  count = ii;
  msg.CharNum = (BYTE)(count);
#endif
	
	g_Network.Send2User(pMessage->dwID, (char*)&msg, sizeof(SEND_CHARSELECT_INFO));

#ifdef _CRYPTCHECK_
	pInfo->crypto.SetInit( TRUE );		// init on	
#endif

#ifdef _HACK_SHIELD_
		HACKSHIELDMGR->SendGUIDReq(pInfo);
#endif

#ifdef _NPROTECT_
		//??吏몄꺼?夷?姨붿ℓ夷뚯㎟吏뱀쮼夷됱쭨姨뚯㎝ 夷됱콝姨먯광姨?姨뚯쿋夷됱쮬 ??夷?.(?夷붿쮯?吏???姨?, ?夷夷띿㎟??夷⑹껨姨뚯쮼?吏뽰찓吏뺤찈吏? 吏???姨붿쭠姨뚯㎝)
		if( pInfo->m_nCSAInit == 0 )	//?夷????泥?? 姨?夷?姨먯광 ??夷?夷띿콝
		{
			pInfo->m_nCSAInit = 1;		//?夷????泥?姨???
			NPROTECTMGR->SendAuthQuery(pInfo);
		}
#endif
}

void SkillInsertToDB(DWORD CharacterIDX, DWORD SkillIDX, BYTE level/*, POSTYPE SkillPos, BYTE bWeared, BYTE bLevel, WORD Option*/)
{
	char txt[128];
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC %s %u, %d, %d", "MP_SKILLTREE_INSERT", CharacterIDX, SkillIDX, level);
	g_DB.Query(eQueryType_FreeQuery, eSkillInsert, CharacterIDX, txt);
}

// desc_hseos_夷띿쿂姨띿쮼??夷???01
// S 夷띿쿂姨띿쮼??夷??? ??吏몄쭠 added by hseos 2007.05.29
// ..??夷뚯쮷??姨?吏몄쭥, 夷띿쿂姨띿쮼???夷 姨뚯쿋 ??吏뱀갹?吏?
void InitMonstermeterInfoOfDB(DWORD nPlayerID)
{
	char txt[128];
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC  dbo.MP_MONSTERMETER_INITINFO %d", nPlayerID);
	g_DB.Query(eQueryType_FreeQuery, eInitMonstermeterInfoOfDB, 0, txt);
}
// E 夷띿쿂姨띿쮼??夷??? ??吏몄쭠 added by hseos 2007.05.29

// desc_hseos_姨뚯쮼夷섏㎏姨뚯㏏??01
// S 姨뚯쮼夷섏㎏姨뚯㏏?? ??吏몄쭠 added by hseos 2007.06.15
void GetUserSexKind(DWORD nUserID)
{
	char txt[128];
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC  MP_USER_SEXKIND %d", nUserID);
	g_DB.LoginQuery(eQueryType_FreeQuery, eGetUserSexKind, nUserID, txt);
}

void RGetUserSexKind(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
	if( !pData->isnextOK() ) return;
  int result = pData->getDataINT( 0);
#else
	int result = atoi((char*)pData->Data[0]);
#endif
	DWORD dwConnectionIndex = pMessage->dwID;

	USERINFO* pInfo = g_pUserTableForUserID->FindUser(dwConnectionIndex);
	if(pInfo == NULL) return;

	pInfo->nSexKind = result;

	// ?吏?쮮泥??姨먯괩?吏곗찓吏?姨?夷띿㎞吏뱀갹
	MSG_DWORD msg;
	msg.Category = MP_USERCONN;
	msg.Protocol = MP_USERCONN_USER_SEXKIND;
	msg.dwData	 = result;
	g_Network.Send2User(pInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
}
// E 姨뚯쮼夷섏㎏姨뚯㏏?? ??吏몄쭠 added by hseos 2007.06.15

void	RCreateCharacter(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  int result0 = 0;
  if( pData->isnextOK() ){    result0 = pData->getDataINT( 0 );  }
#else
	int result0 = atoi((char*)pData->Data[0]);
#endif
	DWORD dwConnectionIndex = pMessage->dwID;

	switch(result0)
	{
	case 0:
		{
			USERINFO* pInfo = g_pUserTable->FindUser(dwConnectionIndex);
			if(!pInfo)
			{
				MSGBASE msg;
				msg.Category = MP_USERCONN;
				msg.Protocol = MP_USERCONN_CHARACTER_MAKE_NACK;
				g_Network.Send2User(dwConnectionIndex, (char*)&msg, sizeof(msg));
				return;
			}

			ASSERT(pInfo->dwUserID);

			if(pInfo->dwUserID == 0)
			{
				ASSERTMSG(0, "UserID is blank?.");

				MSGBASE msg;
				msg.Category = MP_USERCONN;
				msg.Protocol = MP_USERCONN_CHARACTER_MAKE_NACK;
				g_Network.Send2User(dwConnectionIndex, (char*)&msg, sizeof(msg));
				return;
			}
			
			/// 吏뱀갹夷섏Ł 夷⑹껨姨뚯쮼 姨?????
#ifdef _AGENT00_ 
			DWORD idx = pData->getDataINT(1);
			int job = pData->getDataINT(2);
#else
			DWORD idx = atoi((char*)pData->Data[1]);
			int job = atoi((char*)pData->Data[2]);
#endif
			if( job == 4 )
			{
				WebEvent( pInfo->dwUserID, 4 );
			}
/*			
			int job = atoi((char*)pData->Data[2]);

			switch( job )
			{
			case 1:
				{
					SkillInsertToDB( idx, 1101101, 1 );
					SkillInsertToDB( idx, 1101201, 1 );
				}
				break;
			case 2:
				{
					SkillInsertToDB( idx, 2101001, 1 );
				}
				break;
			case 3:
				{
					SkillInsertToDB( idx, 3200101, 1 );
				}
				break;
			case 4:
				{
					// 091102 ONS 夷띿쮮?夷?吏뱀갹夷섏Ł 姨띿쮼?夷 姨뚯??吏?
					SkillInsertToDB( idx, 6100101, 1 );
				}
			}
*/
			//UserIDXSendAndCharacterBaseInfo(pInfo->dwUserID,pInfo->dwUniqueConnectIdx,dwConnectionIndex);
			pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1].dwCharacterID = idx;
#ifdef _AGENT00_ 
      MAPTYPE dwMapNum = (MAPTYPE)pData->getDataINT( 4);
			pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1].MapNum =  dwMapNum;
			pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1 ].Level = 1 ;
      std::string d0 = pData->getSTR( 3);
			SafeStrCpy(pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1 ].name, &d0[3], 32) ;
#else
			// 090622 ONS 姨?吏??姨?夷?姨???夷? 姨뚯??吏??夷夷띿㎞??吏몄쭠
			MAPTYPE dwMapNum = (MAPTYPE)atoi((char*)pData->Data[4]);
			pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1].MapNum =  dwMapNum;

			// 080430 LYW --- AgentDBMsgParser : ?吏??夷붿콌 姨?姨띿쮼???夷띿쮯? ????, ?夷夷띿㎟?? ??夷띿쭬夷됱쮬 ??吏몄쭠??.
			pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1 ].Level = 1 ;
			SafeStrCpy(pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1 ].name, (char*)pData->Data[3], 32) ;
#endif
			// 080507 LYW --- AgentDBMsgParser : ?吏??夷붿콌 姨?姨띿쮼???夷??吏??, ?吏?泥??吏싳쮼夷띿쮰吏?Dist 姨뚯㎝夷붿쿋姨붿쭠 ??吏몄쭠??夷?.
			ST_CR_USER user ;
			memset(&user, 0, sizeof(ST_CR_USER)) ;

			user.byLevel	= (BYTE)pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1 ].Level ;
			user.byMapNum	= (BYTE)pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1].MapNum ;
			user.dwPlayerID	= pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1].dwCharacterID ;
			user.dwUserID	= pInfo->dwUserID ;

			SafeStrCpy(user.name, pInfo->SelectInfoArray[ MAX_CHARACTER_NUM - 1 ].name, MAX_NAME_LENGTH) ;

			// ?吏?泥??吏싳쮼夷띿쮰吏?Dist夷? 夷됱광夷?姨??吏몄㎏梨? ?吏?泥ъ㎏吏?夷됱광夷? 夷? 夷⑹쿂??夷? 姨뚯찈????夷?.
			if(CHATROOMMGR->RegistPlayer_To_Lobby(&user))
			{
				pInfo->byAddedChatSystem = TRUE ;
			}
			// END

			// 090625 ONS 姨???夷??夷?姨?吏??姨?夷뚯㎏泥?吏뱀갹?夷?姨?夷?夷?吏뱀쮰夷???姨붿ℓ 姨뚯??吏??夷됱쮬夷? 夷?姨뚯찈?泥좎찓吏???吏몄쭠.
			MSG_DWORD2 msg;
			msg.Category = MP_USERCONN;
			msg.Protocol = MP_USERCONN_CHARACTER_MAKE_ACK;
			msg.dwData1 = idx;
			msg.dwData2 = dwMapNum;
			g_Network.Send2User(dwConnectionIndex, (char*)&msg, sizeof(msg));
		}
		break;
	case 1:
		{
			// ???夷?夷?吏?????吏?吏??吏?????吏?夷??.
			MSGBASE msg;
			msg.Category = MP_USERCONN;
			msg.Protocol = MP_USERCONN_CHARACTER_MAKE_NACK;
			g_Network.Send2User(dwConnectionIndex, (char*)&msg, sizeof(msg));
		}
		break;
	case 2:
		{
			// ????夷?吏??? ?????夷?夷?夷?? ?姨??夷?夷?
			MSG_WORD msg;
			msg.Category = MP_USERCONN;
			msg.Protocol = MP_USERCONN_CHARACTER_NAMECHECK_NACK;
			msg.wData = (WORD)result0;
			g_Network.Send2User(dwConnectionIndex, (char*)&msg, sizeof(msg));
		}
		break;
	case 3:
		{
			// ????夷?吏??? NULL????夷?吏?
			MSG_WORD msg;
			msg.Category = MP_USERCONN;
			msg.Protocol = MP_USERCONN_CHARACTER_NAMECHECK_NACK;
			msg.wData = (WORD)result0;
			g_Network.Send2User(dwConnectionIndex, (char*)&msg, sizeof(msg));
		}
		break;
	case 4:
		{
			// ?夷?吏???? ????夷?吏?吏?夷??吏?吏???吏??夷?吏?
			MSG_WORD msg;
			msg.Category = MP_USERCONN;
			msg.Protocol = MP_USERCONN_CHARACTER_NAMECHECK_NACK;
			msg.wData = (WORD)result0;
			g_Network.Send2User(dwConnectionIndex, (char*)&msg, sizeof(msg));
		}
		break;
	default:
		ASSERT(0);
		return;
	}
}
void	RCharacterNameCheck(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
  if(pData->getDataINT( 0)==0)
#else
	if(atoi((char*)pData->Data[0])==0)
#endif
	{
		// ????夷?吏??????夷?夷??姨???夷??
		MSGBASE msg;
		msg.Category = MP_USERCONN;
		msg.Protocol = MP_USERCONN_CHARACTER_NAMECHECK_ACK;
		g_Network.Send2User(pMessage->dwID, (char*)&msg, sizeof(msg));
	}
	else
	{
		// ????夷?吏??? ?????夷?夷?夷?? ?姨??夷?夷?
		MSG_WORD msg;
		msg.Category = MP_USERCONN;
		msg.Protocol = MP_USERCONN_CHARACTER_NAMECHECK_NACK;
		msg.wData = 2;
		g_Network.Send2User(pMessage->dwID, (char*)&msg, sizeof(msg));
	}
}

void RSearchWhisperUserAndSend(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) {}
#else
	DWORD count = pMessage->dwResult;
	if(!count)
	{
		//return;
		ASSERT(0);
	}
#endif
	else
	{
		MSG_CHAT* pMsgChat = g_MsgTable.GetMsg( pMessage->dwID );
		if( pMsgChat == NULL ) return;

		USERINFO* pSenderInfo = g_pUserTableForObjectID->FindUser( pMsgChat->dwObjectID );
		if( !pSenderInfo ) 
		{
			g_MsgTable.RemoveMsg( pMessage->dwID );
			return;
		}
#ifdef _AGENT00_ 
		int nError	= pData->getDataINT( 0);
		int nLenEr	= pData->getSTR( 0 ).size();	//050118 fix Error for ID including '1'
#else
		int nError	= atoi((char*)pData->Data[0]);
		int nLenEr	= strlen((char*)pData->Data[0]);	//050118 fix Error for ID including '1'
#endif
		if( nLenEr == 1 && ( nError == CHATERR_NO_NAME || nError == CHATERR_NOT_CONNECTED ) )
		{
			MSG_BYTE msg;
			msg.Category	= MP_CHAT;
			msg.Protocol	= MP_CHAT_WHISPER_NACK;
			msg.dwObjectID	= pMsgChat->dwObjectID;
			msg.bData		= (BYTE)nError;
			g_Network.Send2User( pSenderInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
		}
		else
		{
#ifdef _AGENT00_ 
      DWORD dwReceiverID = (DWORD)pData->getDataINT( 1);
#else
			DWORD dwReceiverID = (DWORD)atoi((char*)pData->Data[1]);
#endif
			USERINFO* pReceiverInfo = g_pUserTableForObjectID->FindUser( dwReceiverID );
			
			if( pReceiverInfo )	//?夷????夷??夷?吏?夷?夷??? ??? ?姨?吏?夷?夷?姨?吏?????夷?????夷??吏???夷?吏?
			{
				if( pReceiverInfo->GameOption.bNoWhisper && pSenderInfo->UserLevel != eUSERLEVEL_GM )
				{
					MSG_BYTE msg;
					msg.Category	= MP_CHAT;
					msg.Protocol	= MP_CHAT_WHISPER_NACK;
					msg.dwObjectID	= pMsgChat->dwObjectID;	//?夷?夷?夷?姨?夷?吏?夷?夷??姨??????夷?吏?
					msg.bData		= CHATERR_OPTION_NOWHISPER;

					g_Network.Send2User( pSenderInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
				}
				else
				{
					//?夷?夷?夷?姨??夷?吏?夷?夷?姨?吏?吏?? ?夷?夷?夷?夷?吏?吏?
					MSG_CHAT msgToSender = *pMsgChat;
					msgToSender.Category = MP_CHAT;
					msgToSender.Protocol = MP_CHAT_WHISPER_ACK;
					g_Network.Send2User( pSenderInfo->dwConnectionIndex, (char*)&msgToSender, msgToSender.GetMsgLength() );	//CHATMSG 040324

					//?夷???夷?? ?夷?吏?夷?夷?姨?吏?吏?? ?夷?夷?夷?夷?吏?吏?
					MSG_CHAT msgToReceiver = *pMsgChat;
					msgToReceiver.Category = MP_CHAT;
					if( pSenderInfo->UserLevel == eUSERLEVEL_GM )
						msgToReceiver.Protocol = MP_CHAT_WHISPER_GM;
					else{ msgToReceiver.Protocol = MP_CHAT_WHISPER; }
#ifdef _AGENT00_ 
          std::string d0 = pData->getSTR( 0 );
          SafeStrCpy( msgToReceiver.Name, &d0[0], MAX_NAME_LENGTH + 1 );	
#else
					SafeStrCpy( msgToReceiver.Name, (char*)pData->Data[0], MAX_NAME_LENGTH + 1 );	
#endif
          g_Network.Send2User( pReceiverInfo->dwConnectionIndex, (char*)&msgToReceiver, msgToReceiver.GetMsgLength() );
				}
			}
			else
			{
				MSG_WHISPER msgWhisper;
				msgWhisper.Category		= MP_CHAT;
				if( pSenderInfo->UserLevel == eUSERLEVEL_GM )
					msgWhisper.Protocol		= MP_CHAT_WHISPER_GM_SYN;
				else
					msgWhisper.Protocol		= MP_CHAT_WHISPER_SYN;

				msgWhisper.dwObjectID	= pMsgChat->dwObjectID;					//?夷?夷?夷?姨?夷?吏?夷?夷?
#ifdef _AGENT00_ 
        //std::string d1 = pData->getSTR( 1);
        std::string d2 = pData->getSTR( 0);
				msgWhisper.dwReceiverID	= (DWORD)pData->getDataINT( 1);
				SafeStrCpy( msgWhisper.SenderName, &d2[0], MAX_NAME_LENGTH + 1 ); 
#else
				msgWhisper.dwReceiverID	= (DWORD)atoi((char*)pData->Data[1]);	//?夷???夷???夷?吏?夷?夷?
				SafeStrCpy( msgWhisper.SenderName, (char*)pData->Data[0], MAX_NAME_LENGTH + 1 ); //?夷?夷?夷?姨?夷?吏?夷?夷??? ????夷?吏?
#endif
				SafeStrCpy( msgWhisper.ReceiverName, pMsgChat->Name, MAX_NAME_LENGTH + 1 ); //?夷???夷???夷?吏?夷?夷??? ????夷?吏?
				SafeStrCpy( msgWhisper.Msg, pMsgChat->Msg, MAX_CHAT_LENGTH + 1 );	//???吏?????夷?夷?姨?吏?
				g_Network.Broadcast2AgentServerExceptSelf( (char*)&msgWhisper, msgWhisper.GetMsgLength() );	//CHATMSG 040324
			}
		}
	}

	g_MsgTable.RemoveMsg( pMessage->dwID );
}

void RFriendDelFriend(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(pRecverInfo)
	{
#ifdef _AGENT00_ 
		if(pData->getDataINT( eFr_IsSuccess) != 0)
#else
		if(atoi((char*)pData->Data[eFr_IsSuccess]) != 0)
#endif
		{
			MSG_NAME_DWORD msg;
			msg.Category = MP_FRIEND;
			msg.Protocol = MP_FRIEND_DEL_ACK;
#ifdef _AGENT00_ 
      std::string d0 = pData->getSTR( eFr_targetname );
			SafeStrCpy( msg.Name, &d0[0], MAX_NAME_LENGTH + 1 );
			msg.dwData = pData->getDataINT( eFr_IsSuccess ); //ack ????夷?吏?friendidx return
#else
			SafeStrCpy( msg.Name, (char*)pData->Data[eFr_targetname], MAX_NAME_LENGTH + 1 );
			msg.dwData = atoi((char*)pData->Data[eFr_IsSuccess]); //ack ????夷?吏?friendidx return
#endif
			msg.dwObjectID = pMessage->dwID;

			g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(MSG_NAME_DWORD));
		}
		else
		{
			MSG_FRIEND_MEMBER_ADDDELETEID msg;
			msg.Category	= MP_FRIEND;
			msg.Protocol	= MP_FRIEND_DEL_NACK;
			msg.dwObjectID	= pMessage->dwID;
#ifdef _AGENT00_ 
      std::string d2 = pData->getSTR( eFr_targetname);
			SafeStrCpy( msg.Name,&d2[0], MAX_NAME_LENGTH + 1 );
			msg.PlayerID	= pData->getDataINT( eFr_IsSuccess );
#else
			SafeStrCpy( msg.Name, (char*)pData->Data[eFr_targetname], MAX_NAME_LENGTH + 1 );
			msg.PlayerID	= atoi((char*)pData->Data[eFr_IsSuccess]);
#endif
			g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(MSG_FRIEND_MEMBER_ADDDELETEID));
		}
	}
}


void RFriendAddFriend(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	//?夷?吏?夷???夷???姨?吏???夷?夷?? ?夷?吏?夷?夷?
	MSG_FRIEND_MEMBER_ADDDELETEID bmsg;
	bmsg.Category = MP_FRIEND;
#ifdef _AGENT00_ 
  std::string d0 = pData->getSTR( eFr_addFromName );
	SafeStrCpy(bmsg.Name, &d0[0], MAX_NAME_LENGTH+1);
	bmsg.dwObjectID = pData->getDataINT( eFr_addToIDX );
	bmsg.PlayerID = pData->getDataINT( eFr_addFromIDX );
	USERINFO* pToRecverInfo = g_pUserTableForObjectID->FindUser(pData->getDataINT( eFr_addToIDX ));
#else
	SafeStrCpy(bmsg.Name, (char*)pData->Data[eFr_addFromName], MAX_NAME_LENGTH+1);
	bmsg.dwObjectID = atoi((char*)pData->Data[eFr_addToIDX]);
	bmsg.PlayerID = atoi((char*)pData->Data[eFr_addFromIDX]);
	USERINFO* pToRecverInfo = g_pUserTableForObjectID->FindUser(atoi((char*)pData->Data[eFr_addToIDX]));
#endif
	if(pToRecverInfo)
	{
#ifdef _AGENT00_ 
		if(pData->getDataINT( eFr_addToErr ) == 0) //ack
#else
		if(atoi((char*)pData->Data[eFr_addToErr]) == 0) //ack
#endif
			{bmsg.Protocol = MP_FRIEND_ADD_ACCEPT_ACK;}
		else	//nack
		{
#ifdef _AGENT00_ 
			bmsg.PlayerID = pData->getDataINT( eFr_addToErr);
#else
			bmsg.PlayerID = atoi((char*)pData->Data[eFr_addToErr]);
#endif
			bmsg.Protocol = MP_FRIEND_ADD_ACCEPT_NACK;
		}
		g_Network.Send2User(pToRecverInfo->dwConnectionIndex, (char*)&bmsg, sizeof(bmsg));
	}
	else //another agent
	{
#ifdef _AGENT00_ 
		if(pData->getDataINT( eFr_addToErr ) == 0) //ack
#else
		if(atoi((char*)pData->Data[eFr_addToErr]) == 0) //ack
#endif
			{bmsg.Protocol = MP_FRIEND_ADD_ACCEPT_TO_AGENT;}
		else //nack
		{
#ifdef _AGENT00_ 
			bmsg.PlayerID = pData->getDataINT( eFr_addToErr );
#else
			bmsg.PlayerID = atoi((char*)pData->Data[eFr_addToErr]);
#endif
			bmsg.Protocol = MP_FRIEND_ADD_ACCEPT_NACK_TO_AGENT;
		}
		g_Network.Broadcast2AgentServerExceptSelf((char*)&bmsg, sizeof(bmsg));
	}
}

void RFriendIsValidTarget(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	MSG_FRIEND_MEMBER_ADDDELETEID msg;
	memset(&msg, 0, sizeof(msg));

	USERINFO* pSenderInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
#ifdef _AGENT00_ 
  USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pData->getDataINT( eFr_vtTargetid));
#else
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(atoi((char*)pData->Data[eFr_vtTargetid]));
#endif
	if(!pSenderInfo)
		return;
#ifdef _AGENT00_ 
  if(pData->getDataINT( eFr_Err) != 0)
#else
	if(atoi((char*)pData->Data[eFr_Err]) != 0)
#endif
	{		
		//nack 
		msg.Category = MP_FRIEND;
		msg.dwObjectID = pMessage->dwID;
		msg.Protocol = MP_FRIEND_ADD_NACK;
#ifdef _AGENT00_ 
    std::string d0 = pData->getSTR( eFr_vtToname );
		SafeStrCpy( msg.Name, &d0[0], MAX_NAME_LENGTH + 1 );
		msg.PlayerID = pData->getDataINT( eFr_Err );	//errcode insert
#else
		SafeStrCpy( msg.Name, (char*)pData->Data[eFr_vtToname], MAX_NAME_LENGTH + 1 );
		msg.PlayerID = atoi((char*)pData->Data[eFr_Err]);	//errcode insert
#endif
		g_Network.Send2User(pSenderInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
	}
	else
	{
		if(pRecverInfo)
		{
			if(pRecverInfo->GameOption.bNoFriend == TRUE)
			{
				msg.Category = MP_FRIEND;
				msg.dwObjectID = pMessage->dwID;
				msg.Protocol = MP_FRIEND_ADD_NACK;
#ifdef _AGENT00_ 
        std::string d3 = pData->getSTR( eFr_vtToname);
				SafeStrCpy( msg.Name, &d3[0], MAX_NAME_LENGTH + 1 );
#else
				SafeStrCpy( msg.Name, (char*)pData->Data[eFr_vtToname], MAX_NAME_LENGTH + 1 );
#endif
				msg.PlayerID = eFriend_OptionNoFriend;	//errcode insert
				g_Network.Send2User(pSenderInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
			}
			else
			{
				msg.Protocol = MP_FRIEND_ADD_INVITE;
				msg.Category = MP_FRIEND;
#ifdef _AGENT00_ 
        std::string d2 = pData->getSTR( eFr_vtFromname);
				msg.dwObjectID = pData->getDataINT( eFr_vtTargetid);
				SafeStrCpy( msg.Name, &d2[0], MAX_NAME_LENGTH + 1 );
#else
				msg.dwObjectID = atoi((char*)pData->Data[eFr_vtTargetid]);
				SafeStrCpy( msg.Name, (char*)pData->Data[eFr_vtFromname], MAX_NAME_LENGTH + 1 );
#endif
				msg.PlayerID = pMessage->dwID;
				g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
			}
		}
		else
		{
			// ?夷???夷?吏?Agent?姨?吏??姨??????????夷??.
			msg.Category = MP_FRIEND;
			msg.Protocol = MP_FRIEND_ADD_INVITE_TO_AGENT;
			msg.PlayerID = pMessage->dwID;
#ifdef _AGENT00_ 
      std::string d1 = pData->getSTR( eFr_vtFromname);
			SafeStrCpy( msg.Name,&d1[0], MAX_NAME_LENGTH + 1 );
			msg.dwObjectID = pData->getDataINT( eFr_vtTargetid );      
#else
			SafeStrCpy( msg.Name, (char*)pData->Data[eFr_vtFromname], MAX_NAME_LENGTH + 1 );
			msg.dwObjectID = atoi((char*)pData->Data[eFr_vtTargetid]);
#endif
			g_Network.Broadcast2AgentServerExceptSelf((char*)&msg, sizeof(msg));
		}
	}
}

void RFriendDelFriendID(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(pRecverInfo)
	{
		MSG_DWORD_WORD msg;
		msg.Category = MP_FRIEND;
		msg.Protocol = MP_FRIEND_DELID_ACK;
#ifdef _AGENT00_ 
		msg.wData = (WORD)pData->getDataINT( 0); //bLast
		msg.dwData = pData->getDataINT( 1); //targetid
#else
		msg.wData = (WORD)atoi((char*)pData->Data[0]); //bLast
		msg.dwData = atoi((char*)pData->Data[1]); //targetid
#endif
		g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
	}
}

void RFriendNotifyLogintoClient(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	MSG_NAME_DWORD msg;
	msg.Category = MP_FRIEND;
	msg.Protocol = MP_FRIEND_LOGIN_NOTIFY;
#ifdef _AGENT00_ 
  std::string d0 = pData->getSTR( eFr_LLoggedname);
  SafeStrCpy( msg.Name, &d0[0], MAX_NAME_LENGTH + 1 );
#else
	SafeStrCpy( msg.Name, (char*)pData[0].Data[eFr_LLoggedname], MAX_NAME_LENGTH + 1 );
#endif
	msg.dwData = pMessage->dwID;
#ifdef _AGENT00_ 
	for(DWORD i=0; i < 255; ++i)
	{
		USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(  pData->getDataINT( eFr_LTargetID ));
		msg.dwObjectID = pData->getDataINT( eFr_LTargetID );
		if(pRecverInfo)
		{
			MSG_NAME_DWORD msgTemp = msg;
			g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msgTemp, sizeof(msgTemp));
		}
		else
		{
			//?夷???夷?吏??姨?吏?????姨???吏?
			msg.Protocol = MP_FRIEND_LOGIN_NOTIFY_TO_AGENT;
			g_Network.Broadcast2AgentServerExceptSelf((char*)&msg, sizeof(msg));
		}
    if( !pData->isnextOK() ) break;
	}
#else
	for(DWORD i=0; i<pMessage->dwResult; ++i)
	{
		USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(atoi((char*)pData[i].Data[eFr_LTargetID]));
		msg.dwObjectID = atoi((char*)pData[i].Data[eFr_LTargetID]);
		if(pRecverInfo)
		{
			MSG_NAME_DWORD msgTemp = msg;
			g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msgTemp, sizeof(msgTemp));
		}
		else
		{
			//?夷???夷?吏??姨?吏?????姨???吏?
			msg.Protocol = MP_FRIEND_LOGIN_NOTIFY_TO_AGENT;
			g_Network.Broadcast2AgentServerExceptSelf((char*)&msg, sizeof(msg));
		}
	}
#endif
}

void RFriendGetLoginFriends(LPQUERY pData, LPDBMESSAGE pMessage)
{
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(!pRecverInfo)
		return;

	MSG_NAME msg;
	msg.Category = MP_FRIEND;
	msg.Protocol = MP_FRIEND_LOGIN_FRIEND;
	msg.dwObjectID = pMessage->dwID;
#ifdef _AGENT00_ 	
  DWORD ii;
  std::string d0;
  for(DWORD ii=0; ii<MAX_FRIEND_NUM; ii++)
	{
    if( !pData->isnextOK() ) break;
    d0 = pData->getSTR( eFr_LFFriendName );
		SafeStrCpy( msg.Name, &d0[0], MAX_NAME_LENGTH + 1 );
		MSG_NAME msgTemp = msg;
		g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msgTemp, sizeof(msgTemp));
	}
#else
	for(DWORD i=0; i<pMessage->dwResult; ++i)
	{
//		strcpy(msg.Name, (char*)pData[i].Data[eFr_LFFriendName]);
		SafeStrCpy( msg.Name, (char*)pData[i].Data[eFr_LFFriendName], MAX_NAME_LENGTH + 1 );
		
		MSG_NAME msgTemp = msg;
		g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msgTemp, sizeof(msgTemp));
	}
#endif
}

void RFriendGetFriendList(LPQUERY pData, LPDBMESSAGE pMessage)
{
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(!pRecverInfo)
		return;	

	MSG_FRIEND_LIST_DLG msg;
	memset(&msg, 0, sizeof(msg));
	msg.Category = MP_FRIEND;
	msg.Protocol = MP_FRIEND_LIST_ACK;
#ifdef _AGENT00_ 
  int ii = 0;
  std::string d0;
  for( ii = 0; ii < MAX_FRIEND_NUM; ii++){
    if( !pData->isnextOK() ) break;
    msg.FriendList[ii].Id = pData->getDataINT( eFr_FLFriendid );
    msg.FriendList[ii].IsLoggIn = pData->getDataINT( eFr_FLIsLogin );
    d0 = pData->getSTR( eFr_FLFriendname );
		SafeStrCpy( msg.FriendList[ii].Name, &d0[0], MAX_NAME_LENGTH + 1 );
  }
  
  
  msg.count = ii;
#else
	msg.count = pMessage->dwResult <= MAX_FRIEND_NUM ? (BYTE)pMessage->dwResult : MAX_FRIEND_NUM;
	if(pMessage->dwResult > MAX_FRIEND_NUM)	{
		ASSERT(pMessage->dwResult <= MAX_FRIEND_NUM);
		msg.count = MAX_FRIEND_NUM;
	}
	for(DWORD i=0; i< msg.count; ++i)	{
		msg.FriendList[i].Id = atol((char*)pData[i].Data[eFr_FLFriendid]);
		msg.FriendList[i].IsLoggIn = atoi((char*)pData[i].Data[eFr_FLIsLogin]);
		SafeStrCpy( msg.FriendList[i].Name, (char*)pData[i].Data[eFr_FLFriendname], MAX_NAME_LENGTH + 1 );
	}
#endif
	msg.dwObjectID = pMessage->dwID;
	
	g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, msg.GetMsgLength());
}

void RNoteIsNewNote(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(!pRecverInfo)
		return;
#ifdef _AGENT00_ 
  if( pData->getDataINT(0) == 1)
#else
	if(atoi((char*)pData->Data[0]) == 1)
#endif
	{
		MSGBASE msg;
		msg.Category = MP_NOTE;
		msg.Protocol = MP_NOTE_NEW_NOTE;
		g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
	}
}

void RNoteSendtoPlayer(LPLARGEQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	// desc_hseos_夷泥?梨낆찉?姨띿쮼??_01
	// S 夷泥?梨낆찉?姨띿쮼?? ??吏몄쭠 added by hseos 2008.01.18
	// 夷泥?梨????姨?姨? 姨?姨띿쮼?? 夷?姨뚯찈?泥좎쮰吏?夷섏쮰夷夷⑹쮷?夷? ???泥?夷??姨?夷?姨뚯찈?泥좎쮫? 姨먯꺽姨먯광夷됱쮬 夷? 夷됱콬~
	/*
	// ..姨?姨띿쮼?? ???泥?? 吏몄콌姨붿콡 ID 吏몄쭠 0 ??吏몄콬 夷섏쮰夷夷⑹쮫? ??夷띿쭬?? <SYSTEM> ??夷?
	if (pMessage->dwID == 0)
	{
		// 姨?姨띿쮼?? ???泥??泥댁찈??? 姨뚯쮼吏몄꺽??夷띿콝 夷?夷? ??夷뚯쮷??姨먯광姨붿쭠吏?夷띿쮰 姨?夷띿㎏夷?.
		if (atoi((char*)pData->Data[eFr_NErr]) == 0)
		{
			DWORD Toidx = atoi((char*)pData->Data[eFr_NToId]);
			if(Toidx == 0) //?夷???吏???姨???姨?夷??夷?夷????
				return;
			MSGBASE rmsg;
			rmsg.Category = MP_NOTE;
			rmsg.Protocol = MP_NOTE_RECEIVENOTE;
			rmsg.dwObjectID = Toidx;

			USERINFO* pToRecverInfo = g_pUserTableForObjectID->FindUser(Toidx);
			if(pToRecverInfo)
			{
				g_Network.Send2User(pToRecverInfo->dwConnectionIndex, (char*)&rmsg, sizeof(rmsg));
			}
			else //?夷???夷?吏??姨?吏?????姨???吏?姨?吏?????夷??. 
			{
				g_Network.Broadcast2AgentServerExceptSelf( (char*)&rmsg, sizeof(rmsg) );
			}
		}
		return;
	}
	*/
	// E 夷泥?梨낆찉?姨띿쮼?? ??吏몄쭠 added by hseos 2008.01.18

	if(!pRecverInfo)
		return;
#ifdef _AGENT00_ 
  int err_num = pData->getDataINT(0);
  if( err_num == 0 )
#else
	if(atoi((char*)pData->Data[eFr_NErr]) == 0) //success
#endif
	{
		MSG_NAME msg;
		msg.Category = MP_NOTE;
		msg.Protocol = MP_NOTE_SENDNOTE_ACK;
#ifdef _AGENT00_ 

#else
		SafeStrCpy( msg.Name, (char*)pData->Data[eFr_NToName], MAX_NAME_LENGTH + 1 );
#endif
		g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
	}
	else
	{
		MSG_NAME_WORD msg;
		msg.Category = MP_NOTE;
		msg.Protocol = MP_NOTE_SENDNOTE_NACK;
#ifdef _AGENT00_ 
    msg.wData = (WORD)pData->getDataINT( eFr_NErr); // 2:invalid user, 3: full space
    std::string d0 = pData->getSTR( eFr_NToName );
		SafeStrCpy( msg.Name, &d0[0], MAX_NAME_LENGTH + 1 );
#else
		msg.wData = (WORD)atoi((char*)pData->Data[eFr_NErr]); // 2:invalid user, 3: full space
		SafeStrCpy( msg.Name, (char*)pData->Data[eFr_NToName], MAX_NAME_LENGTH + 1 );
#endif
		g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
		return;
	}
#ifdef _AGENT00_ 
  DWORD Toidx = pData->getDataINT( eFr_NToId );
#else
	//???????夷??夷???夷?? ?夷?吏?夷?夷?
	DWORD Toidx = atoi((char*)pData->Data[eFr_NToId]);
#endif
	if(Toidx == 0) //?夷???吏???姨???姨?夷??夷?夷????
		return;
	MSGBASE rmsg;
	rmsg.Category = MP_NOTE;
	rmsg.Protocol = MP_NOTE_RECEIVENOTE;
	rmsg.dwObjectID = Toidx;

	USERINFO* pToRecverInfo = g_pUserTableForObjectID->FindUser(Toidx);
	if(pToRecverInfo)
	{
		g_Network.Send2User(pToRecverInfo->dwConnectionIndex, (char*)&rmsg, sizeof(rmsg));
	}
	else //?夷???夷?吏??姨?吏?????姨???吏?姨?吏?????夷??. 
	{
		g_Network.Broadcast2AgentServerExceptSelf( (char*)&rmsg, sizeof(rmsg) );
	}
}

void RNoteServerSendtoPlayer(LPLARGEQUERY pData, LPDBMESSAGE pMessage)
{	
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(!pRecverInfo)
		return;
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
  int err_num = pData->getDataINT( 0);
  if( err_num == 0)
#else
	if(atoi((char*)pData->Data[eFr_NErr]) == 0) //success
#endif
	{
/*		MSG_NAME msg;
		msg.Category = MP_NOTE;
		msg.Protocol = MP_NOTE_SENDNOTE_ACK;
		SafeStrCpy( msg.Name, (char*)pData->Data[eFr_NToName], MAX_NAME_LENGTH + 1 );
		g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
*/
	}
	else
	{
		MSG_NAME_WORD msg;
		msg.Category = MP_NOTE;
		msg.Protocol = MP_NOTE_SENDNOTE_NACK;
#ifdef _AGENT00_ 
    msg.wData = (WORD)pData->getDataINT( eFr_NErr ); // 2:invalid user, 3: full space
    std::string d0 = pData->getSTR( eFr_NToName );
		SafeStrCpy( msg.Name, &d0[0], MAX_NAME_LENGTH + 1 );
#else
		msg.wData = (WORD)atoi((char*)pData->Data[eFr_NErr]); // 2:invalid user, 3: full space
		SafeStrCpy( msg.Name, (char*)pData->Data[eFr_NToName], MAX_NAME_LENGTH + 1 );
#endif
		g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
		return;

	}
#ifdef _AGENT00_ 
  DWORD Toidx = pData->getDataINT( eFr_NToId );
#else
	//???????夷??夷???夷?? ?夷?吏?夷?夷?
	DWORD Toidx = atoi((char*)pData->Data[eFr_NToId]);
#endif
	if(Toidx == 0) //?夷???吏???姨???姨?夷??夷?夷????
		return;
	MSGBASE rmsg;
	rmsg.Category = MP_NOTE;
	rmsg.Protocol = MP_NOTE_RECEIVENOTE;
	rmsg.dwObjectID = Toidx;

	USERINFO* pToRecverInfo = g_pUserTableForObjectID->FindUser(Toidx);
	if(pToRecverInfo)
	{
		g_Network.Send2User(pToRecverInfo->dwConnectionIndex, (char*)&rmsg, sizeof(rmsg));
	}
	else //?夷???夷?吏??姨?吏?????姨???吏?姨?吏?????夷??. 
	{
		g_Network.Broadcast2AgentServerExceptSelf( (char*)&rmsg, sizeof(rmsg) );
	}
}

void RNoteList(LPMIDDLEQUERY pData, LPDBMESSAGE pMessage )
{	
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(!pRecverInfo)
		return;

	SYSTEMTIME ti;
	GetLocalTime(&ti);

	static MSG_FRIEND_NOTE_LIST msg;
	memset(&msg,0,sizeof(MSG_FRIEND_NOTE_LIST));
	
	msg.Category = MP_NOTE;
	msg.Protocol = MP_NOTE_NOTELIST_ACK;
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) {  }
  else {
    for( DWORD i = 0; i < 50; ++i ){
    std::string d0 = pData->getSTR( eFr_NSentDate );
    std::string d1 = pData->getSTR( eFr_NSender );
    SafeStrCpy( msg.NoteList[i].SendDate, &d0[0], MAX_SENDDATE_LENGTH+1 );		
		SafeStrCpy( msg.NoteList[i].FromName, &d1[0], MAX_NAME_LENGTH + 1 );
		
		msg.NoteList[i].NoteID = pData->getDataINT( eFr_NNoteID );
		msg.NoteList[i].bIsRead = (BYTE)pData->getDataINT( eFr_NbIsRead );
    std::string d2 = pData->getSTR( eFr_NTitle );
		SafeStrCpy( msg.NoteList[i].SendTitle, &d2[0], MAX_NOTE_TITLE + 1 );
		msg.NoteList[i].PackageItemIdx = pData->getDataINT( eFr_NPackageItemIdx );
		msg.NoteList[i].PackageMoney = pData->getDataINT( eFr_NPackageMoney );
		msg.dwObjectID = pMessage->dwID; 
    
    if( !pData->isnextOK() ) break;
    }
  }
#else
	for(DWORD i=0; i<pMessage->dwResult; ++i)
	{
		SafeStrCpy( msg.NoteList[i].SendDate, (char*)pData[i].Data[eFr_NSentDate], MAX_SENDDATE_LENGTH+1 );		
		SafeStrCpy( msg.NoteList[i].FromName, (char*)pData[i].Data[eFr_NSender], MAX_NAME_LENGTH + 1 );
		
		msg.NoteList[i].NoteID = atoi((char*)pData[i].Data[eFr_NNoteID]);
		msg.NoteList[i].bIsRead = (BYTE)atoi((char*)pData[i].Data[eFr_NbIsRead]);
		SafeStrCpy( msg.NoteList[i].SendTitle, (char*)pData[i].Data[eFr_NTitle], MAX_NOTE_TITLE + 1 );
		msg.NoteList[i].PackageItemIdx = atoi((char*)pData[i].Data[eFr_NPackageItemIdx]);
		msg.NoteList[i].PackageMoney = atoi((char*)pData[i].Data[eFr_NPackageMoney]);
		msg.dwObjectID = pMessage->dwID; 
	}
	msg.TotalPage = (BYTE)atoi((char*)pData[0].Data[eFr_NTotalpage]);
	msg.TotalMsgNum = (WORD)atoi((char*)pData[0].Data[eFr_NTotalmsg]);
#endif
	g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));

}

void RNoteRead(LPLARGEQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#else
	if(1 != pMessage->dwResult)
		return;
#endif
  USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(!pRecverInfo)
		return;
#ifndef _AGENT00_ 
	const LARGEQUERYST&	record	= pData[0];
#endif
	DWORD dwPackageItemIdx = 0;
#ifdef _AGENT00_ 
  dwPackageItemIdx = (DWORD)pData->getDataINT(4);
#else
	dwPackageItemIdx = (DWORD)atoi((char*)record.Data[4]);
#endif
	if(dwPackageItemIdx)
	{
		MSG_FRIEND_READ_NOTE_WITH_PACKAGE msg;
		ZeroMemory(&msg.ItemInfo, sizeof(msg.ItemInfo));
		ZeroMemory(&msg.OptionInfo, sizeof(msg.OptionInfo));

		msg.Category = MP_NOTE;
		msg.Protocol = MP_NOTE_READNOTE_WITH_PACKAGE_ACK;
#ifdef _AGENT00_ 
    std::string d0 = pData->getSTR( eFr_NRNSender );
    std::string d1 = pData->getSTR( eFr_NRNNote );
    SafeStrCpy( msg.FromName, &d0[0], MAX_NAME_LENGTH + 1 );
		SafeStrCpy( msg.Note, &d0[1], MAX_NOTE_LENGTH + 1 );
		msg.NoteID = pData->getDataINT( eFr_NRNNoteID );
		msg.ItemIdx = (WORD)pData->getDataINT( eFr_NRNItemIdx );
		msg.PackageItem = pData->getDataINT( eFr_NRNPackageItem );
		msg.PackageMoney = pData->getDataINT( eFr_NRNPackageMoney );
#else
		SafeStrCpy( msg.FromName, (char*)record.Data[eFr_NRNSender], MAX_NAME_LENGTH + 1 );
		SafeStrCpy( msg.Note, (char*)record.Data[eFr_NRNNote], MAX_NOTE_LENGTH + 1 );
		msg.NoteID = atoi((char*)record.Data[eFr_NRNNoteID]);
		msg.ItemIdx = (WORD)atoi((char*)record.Data[eFr_NRNItemIdx]);
		msg.PackageItem = (DWORD)atoi((char*)record.Data[eFr_NRNPackageItem]);
		msg.PackageMoney = (DWORD)atoi((char*)record.Data[eFr_NRNPackageMoney]);
#endif
		ITEMBASE& item = msg.ItemInfo;

		char* pBuf;
		char* pString;
		char tokens[32] = {","};
#ifdef _AGENT00_ 
    std::string d2 = pData->getSTR( eFr_NRNPackageItemInfo );
    pBuf = &d2[0];
#else
		pBuf = (char*)record.Data[eFr_NRNPackageItemInfo];
#endif
		if(0 == pBuf[0])
			return;

		item.dwDBIdx		= atoi( strtok(pBuf, tokens) );
		item.wIconIdx		= atoi( strtok(NULL, ",") );
		item.Position		= POSTYPE( atoi( strtok(NULL, ",") ) );
		pString = strtok(NULL, ",");
		item.Durability		= atoi( strtok(NULL, ",") );
		pString = strtok(NULL, ",");
		item.nSealed		= ITEM_SEAL_TYPE(atoi( strtok(NULL, ",")));
		pString = strtok(NULL, ",");
		item.nRemainSecond	= atoi( strtok(NULL, ",") );

		if ( item.nSealed == eITEM_TYPE_GET_UNSEAL )
			return;

		
		// 姨?姨? 夷?夷됱껀
		{
			ITEM_OPTION& option = msg.OptionInfo;

			{
				ITEM_OPTION::Reinforce& data = option.mReinforce;

				data.mStrength			= atoi( strtok(NULL, ",") );
				data.mDexterity			= atoi( strtok(NULL, ",") );
				data.mVitality			= atoi( strtok(NULL, ",") );
				data.mIntelligence		= atoi( strtok(NULL, ",") );
				data.mWisdom			= atoi( strtok(NULL, ",") );
				data.mLife				= atoi( strtok(NULL, ",") );
				data.mMana				= atoi( strtok(NULL, ",") );
				data.mLifeRecovery		= atoi( strtok(NULL, ",") );
				data.mManaRecovery		= atoi( strtok(NULL, ",") );
				data.mPhysicAttack		= atoi( strtok(NULL, ",") );
				data.mPhysicDefence		= atoi( strtok(NULL, ",") );
				data.mMagicAttack		= atoi( strtok(NULL, ",") );
				data.mMagicDefence		= atoi( strtok(NULL, ",") );
				data.mMoveSpeed			= atoi( strtok(NULL, ",") );
				data.mEvade				= atoi( strtok(NULL, ",") );
				data.mAccuracy			= atoi( strtok(NULL, ",") );
				data.mCriticalRate		= atoi( strtok(NULL, ",") );
				data.mCriticalDamage	= atoi( strtok(NULL, ",") );
				char* pName = strtok(NULL, ",");
				char name[MAX_NAME_LENGTH] = {0,};
				strncpy(name, &pName[1], strlen(pName)-2);
				SafeStrCpy( option.mReinforce.mMadeBy, name, sizeof( option.mReinforce.mMadeBy ) );				
			}

			{
				ITEM_OPTION::Mix& data = option.mMix;

				data.mStrength		= atoi( strtok(NULL, ",") );
				data.mIntelligence	= atoi( strtok(NULL, ",") );
				data.mDexterity		= atoi( strtok(NULL, ",") );
				data.mWisdom		= atoi( strtok(NULL, ",") );
				data.mVitality		= atoi( strtok(NULL, ",") );
				char* pName = strtok(NULL, ",");
				char name[MAX_NAME_LENGTH] = {0,};
				strncpy(name, &pName[1], strlen(pName)-2);
				SafeStrCpy( option.mMix.mMadeBy, name, sizeof( option.mMix.mMadeBy ) );	
			}

			{
				ITEM_OPTION::Enchant& data = option.mEnchant;

				data.mIndex	= BYTE( atoi( strtok(NULL, ",") ) );
				data.mLevel	= BYTE( atoi( strtok(NULL, ",") ) );
				char* pName = strtok(NULL, ",");
				char name[MAX_NAME_LENGTH] = {0,};
				strncpy(name, &pName[1], strlen(pName)-2);
				SafeStrCpy( option.mEnchant.mMadeBy, name, sizeof( option.mEnchant.mMadeBy ) );
			}

			{
				ITEM_OPTION::Drop& data = option.mDrop;

				data.mValue[ 0 ].mKey	= ITEM_OPTION::Drop::Key( atoi( strtok(NULL, ",") ) );
				data.mValue[ 0 ].mValue	= float( atof( strtok(NULL, ",") ) );

				data.mValue[ 1 ].mKey	= ITEM_OPTION::Drop::Key( atoi( strtok(NULL, ",") ) );
				data.mValue[ 1 ].mValue	= float( atof( strtok(NULL, ",") ) );

				data.mValue[ 2 ].mKey	= ITEM_OPTION::Drop::Key( atoi( strtok(NULL, ",") ) );
				data.mValue[ 2 ].mValue	= float( atof( strtok(NULL, ",") ) );

				data.mValue[ 3 ].mKey	= ITEM_OPTION::Drop::Key( atoi( strtok(NULL, ",") ) );
				data.mValue[ 3 ].mValue	= float( atof( strtok(NULL, ",") ) );

				data.mValue[ 4 ].mKey	= ITEM_OPTION::Drop::Key( atoi( strtok(NULL, ",") ) );
				data.mValue[ 4 ].mValue	= float( atof( strtok(NULL, ",") ) );
			}

			msg.OptionInfo.mItemDbIndex = item.dwDBIdx;

			g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, msg.GetMsgLength());
		}
	}
	else
	{
		MSG_FRIEND_READ_NOTE msg;
		msg.Category = MP_NOTE;
		msg.Protocol = MP_NOTE_READNOTE_ACK;
#ifdef _AGENT00_ 
    std::string d3 = pData->getSTR( eFr_NRNSender );
    std::string d4 = pData->getSTR( eFr_NRNNote );
    SafeStrCpy( msg.FromName, &d3[0] , MAX_NAME_LENGTH + 1 );
		SafeStrCpy( msg.Note, &d4[0] , MAX_NOTE_LENGTH + 1 );
		msg.NoteID = pData->getDataINT( eFr_NRNNoteID );
		msg.ItemIdx = (WORD)pData->getDataINT( eFr_NRNItemIdx );
		msg.dwPackageMoney = pData->getDataINT( eFr_NRNPackageMoney );
#else
		SafeStrCpy( msg.FromName, (char*)record.Data[eFr_NRNSender], MAX_NAME_LENGTH + 1 );
		SafeStrCpy( msg.Note, (char*)record.Data[eFr_NRNNote], MAX_NOTE_LENGTH + 1 );
		msg.NoteID = atoi((char*)record.Data[eFr_NRNNoteID]);
		msg.ItemIdx = (WORD)atoi((char*)record.Data[eFr_NRNItemIdx]);
		msg.dwPackageMoney = (DWORD)atoi((char*)record.Data[eFr_NRNPackageMoney]);
#endif
		g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, msg.GetMsgLength());
	}
}

void RNoteDelete(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(!pRecverInfo)
		return;
#ifdef _AGENT00_ 
  int nNoteID = pData->getDataINT(0);
#else
	int nNoteID = atoi((char*)pData->Data[0]);
#endif
	if(nNoteID < 0)
		return;

	MSG_FRIEND_DEL_NOTE msg;
	msg.Category = MP_NOTE;
	msg.Protocol = MP_NOTE_DELNOTE_ACK;
#ifdef _AGENT00_ 
	msg.bLast = pData->getDataINT( eFr_NdbLast );
	msg.NoteID 	= pData->getDataINT( eFr_NdNoteID );
#else
	msg.bLast = atoi((char*)pData->Data[eFr_NdbLast]);
	msg.NoteID 	= atoi((char*)pData->Data[eFr_NdNoteID]);
#endif
	g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
}

void RNoteSave(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	USERINFO* pRecverInfo = g_pUserTableForObjectID->FindUser(pMessage->dwID);
	if(!pRecverInfo)
		return;
#ifdef _AGENT00_ 
  int nNoteID = pData->getDataINT(0);
#else
	int nNoteID = atoi((char*)pData->Data[0]);
#endif
	if(nNoteID < 0)
		return;

	MSG_DWORD2 msg;
	msg.Category = MP_NOTE;
	msg.Protocol = MP_NOTE_DELNOTE_ACK;
#ifdef _AGENT00_ 
	msg.dwData1	= pData->getDataINT(0);
	msg.dwData2 = pData->getDataINT(1);
#else
	msg.dwData1	= atoi((char*)pData->Data[0]);
	msg.dwData2 = atoi((char*)pData->Data[1]);
#endif
	g_Network.Send2User(pRecverInfo->dwConnectionIndex, (char*)&msg, sizeof(msg));
}

void RDeleteCharacter(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
  int dat0 = pData->getDataINT(0);
#endif
	USERINFO* pInfo = g_pUserTable->FindUser( pMessage->dwID );
	if( !pInfo )			return;

	MSG_DWORD msg;
	msg.Category = MP_USERCONN;
#ifdef _AGENT00_ 
  if( dat0 != 0){
		msg.Protocol = MP_USERCONN_CHARACTER_REMOVE_NACK;
    msg.dwData = pData->getDataINT(0);
  }
#else
	if(atoi((char*)pData->Data[0]) != 0)
	{
		msg.Protocol = MP_USERCONN_CHARACTER_REMOVE_NACK;
		msg.dwData = atoi((char*)pData->Data[0]);
	}
#endif
	else
	{
		msg.Protocol = MP_USERCONN_CHARACTER_REMOVE_ACK;
#ifdef _AGENT00_ 
    const DWORD CharacterIdx = pData->getDataINT(1);
#else
		const DWORD CharacterIdx = atoi((char*)pData->Data[1]);
#endif
		for(int i=0; i<MAX_CHARACTER_NUM; ++i)
		{
			if( pInfo->SelectInfoArray[i].dwCharacterID == CharacterIdx )
				memset( &pInfo->SelectInfoArray[i], 0, sizeof(CHARSELECTINFO) );
		}
	}

	g_Network.Send2User(pMessage->dwID, (char*)&msg, sizeof(msg));
}

//---for GM_Tool
void RGM_WhereIsCharacter(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) {}
#else
	DWORD count = pMessage->dwResult;
	if(!count)	{	}
#endif
	else
	{
		//(DWORD)atoi((char*)pData->Data[2])	: ?夷???夷?夷???吏?
		//(DWORD)atoi((char*)pData->Data[1])	: ???吏??夷?objectID

		USERINFO* pSenderInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
		if( !pSenderInfo ) return;
#ifdef _AGENT00_ 
    int nError = pData->getDataINT(0);
    std::string d0 = pData->getSTR(0);
		int nLenEr	= d0.size();
#else
		int nError = atoi((char*)pData->Data[0]);
		int nLenEr	= strlen((char*)pData->Data[0]);	//050118 Error for ID including '1'
#endif
		if( nLenEr && ( nError == CHATERR_NO_NAME || nError == CHATERR_NOT_CONNECTED ) )
		{
			MSG_BYTE msg;
			msg.Category	= MP_CHEAT;
			msg.Protocol	= MP_CHEAT_WHEREIS_NACK;
			msg.dwObjectID	= pMessage->dwID;
			msg.bData		= (BYTE)nError;
			g_Network.Send2User( pSenderInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
		}
		else
		{
#ifdef _AGENT00_ 
			DWORD dwTargetID	= (DWORD)pData->getDataINT(1);
			DWORD dwMapNum		= (DWORD)pData->getDataINT(2);
#else
			DWORD dwTargetID	= (DWORD)atoi((char*)pData->Data[1]);
			DWORD dwMapNum		= (DWORD)atoi((char*)pData->Data[2]);
#endif
//			USERINFO* pTargetInfo = g_pUserTableForObjectID->FindUser( dwTargetID );

			if( dwMapNum > 0 )
			{
				MSG_DWORD msg;
				msg.Category	= MP_CHEAT;
				msg.Protocol	= MP_CHEAT_WHEREIS_SYN;
				msg.dwObjectID	= pMessage->dwID;
				msg.dwData		= dwTargetID;	//???吏??夷??姨??????夷?吏?

				WORD wServerPort = g_pServerTable->GetServerPort( eSK_MAP, (WORD)dwMapNum );
				SERVERINFO* pInfo = g_pServerTable->FindServer( wServerPort );				

				if( pInfo )
					g_Network.Send2Server( pInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
			}
			else
			{
				MSG_WORD msg;
				msg.Category	= MP_CHEAT;
				msg.Protocol	= MP_CHEAT_WHEREIS_ACK;
				msg.dwObjectID	= pMessage->dwID;
				msg.wData		= (WORD)dwMapNum;
				g_Network.Send2User( pSenderInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
			}
		}
	}
}

void RGM_BanCharacter(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) {}
#else
	DWORD count = pMessage->dwResult;
	if(!count){	}
#endif
	else
	{
		//(char*)pData->Data[0]					: ?夷?夷?夷?姨?夷?吏?夷?夷?????夷?吏?
		//(DWORD)atoi((char*)pData->Data[1])	: ???吏??夷?objectID

		USERINFO* pSenderInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
		if( !pSenderInfo ) return;
#ifdef _AGENT00_ 
		int nError = pData->getDataINT(0);
    std::string d0 = pData->getSTR(0);
		int nLenEr	= d0.size();
#else
		int nError = atoi((char*)pData->Data[0]);
		int nLenEr	= strlen((char*)pData->Data[0]);	//050118 Error for ID including '1'
#endif
		if( nLenEr && ( nError == CHATERR_NO_NAME || nError == CHATERR_NOT_CONNECTED ) )
		{
			MSG_BYTE msg;
			msg.Category	= MP_CHEAT;
			msg.Protocol	= MP_CHEAT_BANCHARACTER_NACK;
			msg.dwObjectID	= pMessage->dwID;
			msg.bData		= (BYTE)nError;
			g_Network.Send2User( pSenderInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
		}
		else
		{
#ifdef _AGENT00_ 
      DWORD dwTargetID = (DWORD)pData->getDataINT(1);
#else
			DWORD dwTargetID = (DWORD)atoi((char*)pData->Data[1]);
#endif
			USERINFO* pTargetInfo = g_pUserTableForObjectID->FindUser( dwTargetID );

			if( pTargetInfo )
			{
				DWORD dwConIdx = pTargetInfo->dwConnectionIndex;
				OnDisconnectUser( dwConIdx );
				DisconnectUser( dwConIdx );

				MSGBASE msg;
				msg.Category	= MP_CHEAT;
				msg.Protocol	= MP_CHEAT_BANCHARACTER_ACK;
				msg.dwObjectID	= pMessage->dwID;
				g_Network.Send2User( pSenderInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );

				// 06.09.12 RaMa
				LogGMToolUse( pMessage->dwID, eGMLog_Disconnect_User, MP_CHEAT_BANCHARACTER_ACK, dwTargetID, 0 );
			}
			else
			{
				MSG_DWORD2 msg;
				msg.Category	= MP_CHEAT;
				msg.Protocol	= MP_CHEAT_BANCHARACTER_SYN;
				msg.dwData1		= dwTargetID;
				msg.dwData2		= pMessage->dwID;

				g_Network.Broadcast2AgentServerExceptSelf( (char*)&msg, sizeof(msg) );
			}
		}
	}
}

void RGM_UpdateUserLevel(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  int yum = 0;
  if( !pData->isnextOK() ) yum = 0;
  else yum = pData->getDataINT(0);
#endif
	// pMessage->dwID
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;

	MSGBASE msg;
	msg.Category	= MP_CHEAT;
	msg.dwObjectID	= pMessage->dwID;
#ifdef _AGENT00_ 
  if( yum == 0)
#else
	if(atoi((char*)pData->Data[0])==0)
#endif
	{
		// ?吏???夷?吏?????夷?吏??姨?夷?姨?吏?~
		msg.Protocol = MP_CHEAT_BLOCKCHARACTER_NACK;
	}
	else
	{
		msg.Protocol = MP_CHEAT_BLOCKCHARACTER_ACK;
		// ?姨?夷?夷?吏??????吏??姨?夷?吏?夷?~
#ifdef _AGENT00_ 
    DWORD useridx = pData->getDataINT(1);
		DWORD state = pData->getDataINT(1);
#else
		DWORD useridx = atoi((char*)pData->Data[1]);
		DWORD state = atoi((char*)pData->Data[2]);
#endif
		// 06.09.12 RaMa
		LogGMToolUse( pMessage->dwID, eGMLog_Block, useridx, state, 0 );
	}
	g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
}


void RGM_Login(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  DWORD count = 0;
  if( !pData->isnextOK() ) { count = 1;};
#else
	DWORD count = pMessage->dwResult;
#endif
	DWORD dwConnectionIndex = pMessage->dwID;

	USERINFO* pUserInfo = g_pUserTable->FindUser( dwConnectionIndex );

	if( count == 0 || pUserInfo == NULL ) // ????夷?夷 ?姨??夷?夷?
	{
		MSG_BYTE msg;
		msg.Category	= MP_CHEAT;
		msg.Protocol	= MP_CHEAT_GM_LOGIN_NACK;
		msg.bData		= 0;

		g_Network.Send2User( dwConnectionIndex, (char*)&msg, sizeof(msg) );
		return;
	}
/*
enum eOperInfo
{
	eOI_ErroCode = 0, eOI_OperIdx, eOI_OperID, eOI_OperName, eOI_OperPwd, eOI_OperPower, eOI_Date, eOI_Time, 
	eOI_IPIdx, eOI_IPAdress, eOI_IPDate, eOI_IPTime, 
};
*/
#ifdef _AGENT00_ 
  WORD check = (WORD)pData->getDataINT(0);
#else
	WORD check = (WORD)atoi((char*)pData[0].Data[0]);
#endif
	if( check != 0 ) // ???吏?姨?? ?夷???吏?吏?
	{
		MSG_BYTE msg;
		msg.Category	= MP_CHEAT;
		msg.Protocol	= MP_CHEAT_GM_LOGIN_NACK;
		msg.bData		= 1;

		g_Network.Send2User( dwConnectionIndex, (char*)&msg, sizeof(msg) );
		return;
	}
#ifdef _AGENT00_ 
  int nPower = pData->getDataINT(5);
#else
	int nPower = atoi((char*)pData[0].Data[5]);
#endif
	if( nPower < 0 || nPower >= eGM_POWER_MAX )
	{
		MSG_BYTE msg;
		msg.Category	= MP_CHEAT;
		msg.Protocol	= MP_CHEAT_GM_LOGIN_NACK;
		msg.bData		= 2;

		g_Network.Send2User( dwConnectionIndex, (char*)&msg, sizeof(msg) );
		return;		
	}
#ifdef _AGENT00_ 
  DWORD dwIdx = (DWORD)pData->getDataINT(1);
#else
	DWORD dwIdx = (DWORD)atoi((char*)pData[0].Data[1]);
#endif
	char szName[MAX_NAME_LENGTH+1];
#ifdef _AGENT00_ 
  std::string d0 = pData->getSTR(2);
  SafeStrCpy( szName, &d0[0], MAX_NAME_LENGTH+1 );
#else
	SafeStrCpy( szName, (char*)pData[0].Data[2], MAX_NAME_LENGTH+1 );
#endif
	GMINFO->AddGMList( dwConnectionIndex, nPower, dwIdx, szName );

	MSG_DWORD Msg;
	Msg.Category	= MP_CHEAT;
	Msg.Protocol	= MP_CHEAT_GM_LOGIN_ACK;
	Msg.dwData		= nPower;

	g_Network.Send2User( dwConnectionIndex, (char*)&Msg, sizeof(Msg) );
}


void RGM_GetGMPowerList(LPQUERY pData, LPDBMESSAGE pMessage)
{
/*
	DWORD count = pMessage->dwResult;
	WORD tempIdx = HIWORD(pMessage->dwID);
	WORD connectIdx = LOWORD(pMessage->dwID);

	if( count )
	{
		DWORD dwFlag = atoi((char*)pData[0].Data[0]);
		if( dwFlag == 0 )
			GMINFO->Release();

		GM_POWER pw;
		DWORD startIdx = 0;
		for( DWORD i = 0; i < count; ++i )
		{			
			startIdx = atoi((char*)pData[i].Data[1]);
			SafeStrCpy( pw.GM_ID, (char*)pData[i].Data[2], MAX_NAME_LENGTH+1 );
			pw.dwUserID = 0;
			pw.nPower = atoi((char*)pData[i].Data[5]);

			GMINFO->AddGMList( &pw );
		}
	
		if( count >= 100 )
			GM_GetGMPowerList( startIdx, count );
	}
*/
}


/* --; ?????姨?吏?姨?夷?吏???夷??. ????夷?夷???吏?夷?夷?
void RGM_MoveToCharacter(LPQUERY pData, LPDBMESSAGE pMessage)
{
	DWORD count = pMessage->dwResult;
	if(!count)
	{

	}
	else
	{
		
		//(DWORD)atoi((char*)pData->Data[1])	: ???吏??夷?objectID
		//(char*)pData->Data[0]					: ?夷?夷?夷?姨?夷?吏?夷?夷?????夷?吏?

		USERINFO* pSenderInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
		if( !pSenderInfo ) return;

		int nError = atoi((char*)pData->Data[0]);
		if( nError == CHATERR_NO_NAME || nError == CHATERR_NOT_CONNECTED )
		{
			MSG_BYTE msg;
			msg.Category	= MP_CHEAT;
			msg.Protocol	= MP_CHEAT_MOVETOCHAR_NACK;
			msg.dwObjectID	= pMessage->dwID;
			msg.bData		= nError;
			g_Network.Send2User( pSenderInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );
		}
		else
		{
			DWORD dwTargetID = (DWORD)atoi((char*)pData->Data[1]);
			USERINFO* pTargetInfo = g_pUserTableForObjectID->FindUser( (DWORD)atoi((char*)pData->Data[1]) );

			//????姨?吏?夷?夷?姨?吏?????夷?吏?
			if( pTargetInfo )
			{
				//---?夷?吏?????姨?吏?gm?夷?吏?夷????夷??夷???夷?吏?夷?吏?夷??....
				//obejctid?夷?吏??夷???姨?吏?夷?夷?夷?? ?夷?夷?夷?夷???!

			}
			else
			{

			}
		}


	}
}
*/

void CheckGuildMasterLogin( DWORD dwConnectionIdx, DWORD dwPlayerIdx, char* pSearchName, DWORD dwMoney, BYTE Protocol )
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(IsCharInString(pSearchName, "'"))	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery( eCheckGuildMasterLogin, dwConnectionIdx, "EXEC MP_GUILDFIELDWAR_CHECKMASTERLOGIN %d, \'%s\', %d, %d",
		dwPlayerIdx, pSearchName, dwMoney, Protocol );
}

void RCheckGuildMasterLogin( LPQUERY pData, LPDBMESSAGE pMessage )
{
	DWORD dwConnectionIndex = pMessage->dwID;
#ifdef _AGENT00_ 
  int nFlag = pData->getDataINT(0);
#else
	int nFlag = atoi( (char*)pData->Data[0] );
#endif
	switch( nFlag )
	{
	case 0:		// login
		{
#ifdef _AGENT00_ 
			DWORD dwSenderIdx = (DWORD)pData->getDataINT(1);
			DWORD dwMasterIdx = (DWORD)pData->getDataINT(2);
			DWORD dwMap = (DWORD)pData->getDataINT(3);
			DWORD dwMoney = (DWORD)pData->getDataINT(4);
			BYTE Protocol = (BYTE)pData->getDataINT(5);
#else
			DWORD dwSenderIdx = (DWORD)atoi((char*)pData->Data[1]);
			DWORD dwMasterIdx = (DWORD)atoi((char*)pData->Data[2]);
			DWORD dwMap = (DWORD)atoi((char*)pData->Data[3]);
			DWORD dwMoney = (DWORD)atoi((char*)pData->Data[4]);
			BYTE Protocol = (BYTE)atoi((char*)pData->Data[5]);
#endif
			MSG_DWORD3 Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = Protocol;
			Msg.dwData1 = dwSenderIdx;
			Msg.dwData2 = dwMasterIdx;
			Msg.dwData3 = dwMoney;

			USERINFO* userinfo = (USERINFO*)g_pUserTable->FindUser( dwConnectionIndex );
			if( userinfo == NULL )	return;
			WORD wPort = g_pServerTable->GetServerPort( eSK_MAP, (WORD)dwMap );
			if( !wPort )	return;
			SERVERINFO* pSInfo = g_pServerTable->FindServer( wPort );
			if( !pSInfo )	return;

			if( userinfo->dwMapServerConnectionIndex == pSInfo->dwConnectionIndex )
			{
				g_Network.Send2Server( userinfo->dwMapServerConnectionIndex, (char*)&Msg, sizeof(Msg) );
			}
			else
			{
				g_Network.Send2Server( userinfo->dwMapServerConnectionIndex, (char*)&Msg, sizeof(Msg) );
				g_Network.Send2Server( pSInfo->dwConnectionIndex, (char*)&Msg, sizeof(Msg) );
			}
			/*			
			g_Network.Broadcast2MapServer( (char*)&Msg, sizeof(Msg) );
			{
				SERVERINFO* pSInfo = g_pServerTable->FindServer( wPort );
				g_Network.Send2Server( pSInfo->dwConnectionIndex, (char*)&Msg, sizeof(Msg) );
			}
			MSG_BYTE Wait;
			Wait.Category = MP_GUILD_WAR;
			Wait.Protocol = MP_GUILD_WAR_WAIT;
			Wait.bData = Protocol;						
			g_Network.Send2User( dwConnectionIndex, (char*)&Wait, sizeof(Wait) );
*/			
		}
		break;
	case 1:		// sender is not master
		{
			MSG_BYTE Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_NACK;
			Msg.bData = (BYTE)nFlag;
			g_Network.Send2User( dwConnectionIndex, (char*)&Msg, sizeof(Msg) );			
		}
		break;
	case 2:		// is not guild
		{
			MSG_BYTE Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_NACK;
			Msg.bData = (BYTE)nFlag;
			g_Network.Send2User( dwConnectionIndex, (char*)&Msg, sizeof(Msg) );
		}
		break;
	case 3:		// same guild	
		{
			MSG_BYTE Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_NACK;
			Msg.bData = (BYTE)nFlag;
			g_Network.Send2User( dwConnectionIndex, (char*)&Msg, sizeof(Msg) );
		}
		break;
	case 4:		// not login
		{
			MSG_BYTE Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_NACK;
			Msg.bData = (BYTE)nFlag;
			g_Network.Send2User( dwConnectionIndex, (char*)&Msg, sizeof(Msg) );
		}
		break;
	}
}

void CheckGuildFieldWarMoney( DWORD dwConnectionIndex, DWORD dwSenderIdx, DWORD dwEnemyGuildIdx, DWORD dwMoney )
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery( eCheckGuildFieldWarMoney, dwConnectionIndex, "EXEC dbo.MP_GUILDFIELDWAR_CHECKMONEY %d, %d, %d",
		dwSenderIdx, dwEnemyGuildIdx, dwMoney );
}

void RCheckGuildFieldWarMoney( LPQUERY pData, LPDBMESSAGE pMessage )
{
	DWORD dwConnectionIndex = pMessage->dwID;
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
  int nFlag = pData->getDataINT(0);
#else
	int nFlag = atoi( (char*)pData->Data[0] );
#endif
	switch( nFlag )
	{
	case 0:		// login
		{
#ifdef _AGENT00_ 
      DWORD dwSenderIdx = pData->getDataINT(1);
			DWORD dwEnemyGuildIdx = pData->getDataINT(2);
			DWORD dwMoney = pData->getDataINT(3);
#else
			DWORD dwSenderIdx = (DWORD)atoi((char*)pData->Data[1]);
			DWORD dwEnemyGuildIdx = (DWORD)atoi((char*)pData->Data[2]);
			DWORD dwMoney = (DWORD)atoi((char*)pData->Data[3]);
#endif
			MSG_DWORD2 Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_DECLARE_ACCEPT;
			Msg.dwObjectID = dwSenderIdx;
			Msg.dwData1 = dwEnemyGuildIdx;
			Msg.dwData2 = dwMoney;

			USERINFO* userinfo = (USERINFO*)g_pUserTable->FindUser( dwConnectionIndex );
			if( userinfo == NULL )	return;
			g_Network.Send2Server( userinfo->dwMapServerConnectionIndex, (char*)&Msg, sizeof(Msg) );
		}
		break;
	case 1:		// receiver not login
		{
			MSG_BYTE Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_NACK;
			Msg.bData = 4;
			g_Network.Send2User( dwConnectionIndex, (char*)&Msg, sizeof(Msg) );			
		}
		break;
	case 2:		// receiver money not enough
		{
			// sender
			MSG_BYTE Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_NACK;
			Msg.bData = 5;
			g_Network.Send2User( dwConnectionIndex, (char*)&Msg, sizeof(Msg) );
#ifdef _AGENT00_ 
      DWORD dwReceiverIdx = pData->getDataINT(1);
			DWORD dwMap = pData->getDataINT(2);
#else
			// receiver	
			DWORD dwReceiverIdx = (DWORD)atoi((char*)pData->Data[1]);
			DWORD dwMap = (DWORD)atoi((char*)pData->Data[2]);
#endif
			MSG_BYTE Msg1;
			Msg1.Category = MP_GUILD_WAR;
			Msg1.Protocol = MP_GUILD_WAR_NACK;
			Msg1.dwObjectID = dwReceiverIdx;
			Msg1.bData = 6;			

			WORD wPort = g_pServerTable->GetServerPort( eSK_MAP, (WORD)dwMap );
			if( wPort )
			{
				SERVERINFO* pSInfo = g_pServerTable->FindServer( wPort );
				g_Network.Send2Server( pSInfo->dwConnectionIndex, (char*)&Msg1, sizeof(Msg1) );
			}
		}
		break;
	case 3:		// sender money not enough	
		{
			MSG_BYTE Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_NACK;
			Msg.bData = 6;
			g_Network.Send2User( dwConnectionIndex, (char*)&Msg, sizeof(Msg) );
#ifdef _AGENT00_ 
      DWORD dwReceiverIdx = pData->getDataINT(1);
			DWORD dwMap = pData->getDataINT(2);
#else
			// receiver	
			DWORD dwReceiverIdx = (DWORD)atoi((char*)pData->Data[1]);
			DWORD dwMap = (DWORD)atoi((char*)pData->Data[2]);
#endif
			MSG_BYTE Msg1;
			Msg1.Category = MP_GUILD_WAR;
			Msg1.Protocol = MP_GUILD_WAR_NACK;
			Msg1.dwObjectID = dwReceiverIdx;
			Msg1.bData = 5;			

			WORD wPort = g_pServerTable->GetServerPort( eSK_MAP, (WORD)dwMap );
			if( wPort )
			{
				SERVERINFO* pSInfo = g_pServerTable->FindServer( wPort );
				g_Network.Send2Server( pSInfo->dwConnectionIndex, (char*)&Msg1, sizeof(Msg1) );
			}
		}
		break;
	}
}

void AddGuildFieldWarMoney( DWORD dwConnectionIndex, DWORD dwPlayerIdx, DWORD dwMoney )
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery( eAddGuildFieldWarMoney, dwConnectionIndex, "EXEC dbo.MP_GUILDFIELDWAR_ADDMONEY %d, %d",
		dwPlayerIdx, dwMoney );
}

void RAddGuildFieldWarMoney( LPQUERY pData, LPDBMESSAGE pMessage )
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
  DWORD dwConnectionIndex = pMessage->dwID;
	int nFlag = pData->getDataINT(0);
#else
	DWORD dwConnectionIndex = pMessage->dwID;
	int nFlag = atoi( (char*)pData->Data[0] );
#endif
	switch( nFlag )
	{
	case 0:		// login
		{
#ifdef _AGENT00_ 
			DWORD dwMap = pData->getDataINT(1);
			DWORD dwPlayerIdx = pData->getDataINT(2);
			DWORD dwMoney = pData->getDataINT(3);
#else
			DWORD dwMap = (DWORD)atoi((char*)pData->Data[1]);
			DWORD dwPlayerIdx = (DWORD)atoi((char*)pData->Data[2]);
			DWORD dwMoney = (DWORD)atoi((char*)pData->Data[3]);
#endif
			MSG_DWORD2 Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_ADDMONEY_TOMAP;
			Msg.dwData1 = dwPlayerIdx;
			Msg.dwData2 = dwMoney;

			WORD wPort = g_pServerTable->GetServerPort( eSK_MAP, (WORD)dwMap );
			if( wPort )
			{
				SERVERINFO* pSInfo = g_pServerTable->FindServer( wPort );
				g_Network.Send2Server( pSInfo->dwConnectionIndex, (char*)&Msg, sizeof(Msg) );
			}
		}
		break;
	case 1:		// not login
		{
			MSG_BYTE Msg;
			Msg.Category = MP_GUILD_WAR;
			Msg.Protocol = MP_GUILD_WAR_NACK;
			Msg.bData = 4;
			g_Network.Send2User( dwConnectionIndex, (char*)&Msg, sizeof(Msg) );			
		}
		break;
	}
}

void EventItemUse051108( DWORD dwUserIdx, char* sCharName, DWORD dwServerNum )
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(IsCharInString(sCharName, "'"))	return;

	char txt[128];
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf( txt, "EXEC UP_EVENT051108_INSERT %d, \'%s\', %d", dwUserIdx, sCharName, dwServerNum );
	g_DB.LoginQuery( eQueryType_FreeQuery, eEventItemUse051108, 0, txt);
}

void EventItemUse2( DWORD dwUserIdx, char* sCharName, DWORD dwServerNum )
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(IsCharInString(sCharName, "'"))	return;

	char txt[128];
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf( txt, "EXEC dbo.UP_EVENTITEMUSE2 %d, \'%s\', %d", dwUserIdx, sCharName, dwServerNum );
	g_DB.LoginQuery( eQueryType_FreeQuery, eEventItemUse2, 0, txt);
}

void GM_UpdateUserState(DWORD dwID, DWORD dwServerGroup, char* Charactername, BYTE UserState)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(strlen(Charactername) > MAX_NAME_LENGTH)	return;

	char szBufName[MAX_NAME_LENGTH+1];
	SafeStrCpy(szBufName, Charactername, MAX_NAME_LENGTH+1);
	if(IsCharInString(szBufName, "'"))	return;

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.FreeQuery( eGM_UpdateUserState, dwID, "EXEC dbo.MP_GMTOOL_UPDATEUSERSTATE %d, \'%s\', %d", dwServerGroup, Charactername, UserState );
}

void RGM_UpdateUserState(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	// pMessage->dwID
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;

	MSGBASE msg;
	msg.Category	= MP_CHEAT;
	msg.dwObjectID	= pMessage->dwID;
#ifdef _AGENT00_ 
  if( pData->getDataINT(0) == 0 )
#else
	if(atoi((char*)pData->Data[0])==0)
#endif
	{
		// ?吏???夷?吏?????夷?吏??姨?夷?姨?吏?~
		msg.Protocol = MP_CHEAT_BLOCKCHARACTER_NACK;
	}
	else
	{
		msg.Protocol = MP_CHEAT_BLOCKCHARACTER_ACK;
		// ?姨?夷?夷?吏??????吏??姨?夷?吏?夷?~
	}
	g_Network.Send2User( pUserInfo->dwConnectionIndex, (char*)&msg, sizeof(msg) );

}

void LogGMToolUse( DWORD CharacterIdx, DWORD GMLogtype, DWORD Logkind, DWORD Param1, DWORD Param2 )
{
	char txt[128] = { 0, };
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf( txt, "EXEC dbo.UP_GMTOOLUSELOG %d, %d, %d, %d, %d",
		CharacterIdx,
		GMLogtype,
		Logkind,
		Param1,
		Param2
	);
	g_DB.LogQuery( eQueryType_FreeQuery, eLogGMToolUse, 0, txt );
}

// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
#define STORED_FAMILY_LOAD_INFO				"dbo.MP_FAMILY_LOADINFO"
#define STORED_FAMILY_LOAD_INFO_EMBLEM		"dbo.MP_FAMILY_LOADINFO_EMBLEM"
#define STORED_FAMILY_SAVE_INFO				"dbo.MP_FAMILY_SAVEINFO"
#define STORED_FAMILY_SAVE_INFO_HONORPOINT	"dbo.MP_FAMILY_SAVEINFO_HONORPOINT"
#define STORED_FAMILY_SAVE_INFO_EMBLEM		"dbo.MP_FAMILY_SAVEINFO_EMBLEM"
#define STORED_FAMILY_MEMBER_LOAD_INFO		"dbo.MP_FAMILY_MEMBER_LOADINFO"
#define STORED_FAMILY_MEMBER_LOAD_EXINFO_01	"dbo.MP_FAMILY_MEMBER_LOADEXINFO01"
#define STORED_FAMILY_MEMBER_SAVE_INFO		"dbo.MP_FAMILY_MEMBER_SAVEINFO"
#define STORED_FAMILY_CHECKNAME				"dbo.MP_FAMILY_CHECKNAME"
#define STORED_FAMILY_LEAVE_LOAD_INFO		"dbo.MP_FAMILY_LEAVE_LOADINFO"
#define STORED_FAMILY_LEAVE_SAVE_INFO		"dbo.MP_FAMILY_LEAVE_SAVEINFO"
// 091111 ONS ??夷?夷띿㎞ 夷붿㎞?梨?夷⑹콛?吏???夷?姨??泥???吏몄쭠.
#define STORED_FAMILY_DELETE_EMBLEM			"dbo.MP_FAMILY_DELETE_EMBLEM"

char txt[128];
void Family_SaveInfo(DWORD nMasterID, char* pszFamilyName, int nHonorPoint, BOOL bNicknameON, int nSaveType)
{
	if (nSaveType == 0)
	{
		// ??夷?夷띿㎞ ??夷띿쭬?夷?'' 夷? 姨? 夷붿㎝姨먯광??夷?吏뱀광 1231??夷?夷띿㎞ 姨? 吏몄㎏?夷?姨뚯꺽姨뚯㎝夷? 姨뚯껨?? ??吏??夷??(姨붿쮬夷붿㎞?夷??吏?? 姨? ??夷??姨??夷?夷붿㎞??姨붿㎝夷? ??姨????泥?姨?夷?夷?.
		// SQL姨뚯㎝夷붿쿋姨붿쭠姨뚯㎝ 姨뚯껨??吏몄쭠 夷??泥?夷吏㏃찓?夷띿콝 夷붿㎞??姨붿㎝夷? ??姨????泥?姨?夷? 夷됱콬...
		sprintf(txt, "EXEC  %s '%s', %d, %d, %d", STORED_FAMILY_SAVE_INFO, pszFamilyName, nMasterID, nHonorPoint, bNicknameON);
		g_DB.Query(eQueryType_FreeQuery, eFamily_SaveInfo, nMasterID, txt);
	}
	else if (nSaveType == 1)
	{
		sprintf(txt, "EXEC  %s %d, %d", STORED_FAMILY_SAVE_INFO_HONORPOINT,  nMasterID, nHonorPoint);
		g_DB.Query(eQueryType_FreeQuery, eFamily_SaveInfo, nMasterID, txt);
	}
}

void RFamily_SaveInfo(LPQUERY pData, LPDBMESSAGE pMessage)
{
	// ??夷?夷띿㎞ 夷⑹껨姨뚯쮼 姨? ??夷?夷띿㎞?? ID夷띿쭩 夷?吏뱀갹 ?吏??.. 
	// ..??夷?夷띿㎞夷띿쭩 ?夷?姨?夷⑹껨姨뚯쮼 姨?姨붿쭠夷? DB姨붿쭠 ?泥?梨?? ?? 姨??吏앹쮯? ??夷?夷띿㎞夷띿쭩 夷⑹껨姨뚯쮼??夷?. 夷⑹껨姨뚯쮼 ?? ?泥?梨낆찉?姨붿쭠夷? Update 夷띿쮰 ??吏뱀갹 夷뗭쭬夷붿㎞姨붿쭠 姨붿ℓ吏뱀갹夷? 姨??泥?姨?夷?夷?.
	// ..夷⑹콐姨? ID夷띿쮰 夷?姨?姨뚯㎝ 姨뚯??吏??夷띿콝 夷?夷?夷됱쭨, 夷?夷? 吏뱀콛姨붿쭠 夷띿괩夷됱콐 ?吏싳쮼夷띿쮰吏?夷? 夷?姨?姨뚯㎝ 夷??夷??吏싳쮼夷띿쮯? 姨뚯??吏?!!
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ){}
#else
	if( pMessage->dwResult == 0 )	{	}
#endif
	else
	{
		// ??夷?夷띿㎞ ?吏싳쮼夷?
		CSHFamily::stINFO		stInfo;
		CSHFamily::stINFO_EX	stInfoEx;

		ZeroMemory(&stInfo, sizeof(stInfo));
		ZeroMemory(&stInfoEx, sizeof(stInfoEx));
#ifdef _AGENT00_ 
    stInfo.nID				= pData->getDataINT(0);
    std::string d0 = pData->getSTR(1);
		SafeStrCpy(stInfo.szName, &d0[0], MAX_NAME_LENGTH+1);
		stInfo.nMasterID		= pData->getDataINT(2);
		stInfoEx.nHonorPoint	= pData->getDataINT(3);
		stInfoEx.nNicknameON	= pData->getDataINT(4);
#else
		stInfo.nID				= atoi((char*)pData[0].Data[0]);
		SafeStrCpy(stInfo.szName, (char*)pData[0].Data[1], MAX_NAME_LENGTH+1);
		stInfo.nMasterID		= atoi((char*)pData[0].Data[2]);
		stInfoEx.nHonorPoint	= atoi((char*)pData[0].Data[3]);
		stInfoEx.nNicknameON	= atoi((char*)pData[0].Data[4]);
#endif
		// 夷띿갹夷붿쿋(??姨?) ?吏싳쮼夷?(?吏뽰찈? 夷⑹쿂??)
		CSHFamilyMember::stINFO		stMemberInfo;

		ZeroMemory(&stMemberInfo, sizeof(stMemberInfo));
		stMemberInfo.nID		= pUserInfo->dwCharacterID;
		stMemberInfo.eConState	= CSHFamilyMember::MEMBER_CONSTATE_LOGIN;

		CSHFamilyMember csFamilyMember;
		csFamilyMember.Set(&stMemberInfo);

		// ???姨???夷?夷띿㎞ 夷⑹껨姨뚯쮼
		CSHFamily csFamily;
		csFamily.Set(&stInfo, &stInfoEx);
		g_csFamilyManager.ASRV_CreateFamily(pUserInfo, stInfo.szName, CSHFamilyManager::FCS_COMPLETE, &csFamily);

		// 夷띿쮮姨띿쮼?? ?吏싳쮼夷???吏뱀갹
		Family_Member_LoadInfo(pUserInfo->dwCharacterID, stInfo.nID);
		// 081205 LUJ, 夷?吏?
		InsertLogFamily(
			eLog_FamilyCreate,
			stInfo.nID,
			stInfo.nMasterID,
			stInfo.szName );
	}
}

void Family_SaveEmblemInfo(DWORD nPlayerID, DWORD nFamilyID, char* pcImg)
{
	char buf[CSHFamilyManager::EMBLEM_BUFSIZE*2+256];
	sprintf(buf, "EXEC  %s %d, 0x", STORED_FAMILY_SAVE_INFO_EMBLEM,  nFamilyID);

	int curpos = strlen(buf);
	for(int n=0;n<CSHFamilyManager::EMBLEM_BUFSIZE;++n)
	{
		sprintf(&buf[curpos],"%02x",(BYTE)pcImg[n]);
		curpos += 2;
	}

	g_DB.FreeLargeQuery(NULL, 0, buf);
}

// 091111 ONS ??夷?夷띿㎞ 夷붿㎞?梨?夷⑹콛?吏?
void Family_DeleteEmblem(DWORD nPlayerID, DWORD nFamilyID)
{
	sprintf(txt, "EXEC  %s %d", STORED_FAMILY_DELETE_EMBLEM, nFamilyID);
	g_DB.Query(eQueryType_FreeQuery, eFamily_Delete_Emblem, nPlayerID, txt);
}


void Family_LoadInfo(DWORD nPlayerID)
{
	sprintf(txt, "EXEC  %s %d", STORED_FAMILY_LOAD_INFO, nPlayerID);
	g_DB.Query(eQueryType_FreeQuery, eFamily_LoadInfo, nPlayerID, txt);
}

void RFamily_LoadInfo(LPQUERY pData, LPDBMESSAGE pMessage)
{
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) {}
#else
	if( pMessage->dwResult == 0 )	{	}
#endif
	else
	{
#ifdef _AGENT00_ 
    if(CSHFamily* family = g_csFamilyManager.GetFamily(pData->getDataINT(0) ))
#else
		if(CSHFamily* family = g_csFamilyManager.GetFamily(atoi((char*)pData[0].Data[0])))
#endif
		{
			int nLoginCnt = 0;
			pUserInfo->mFamilyIndex = family->Get()->nID;

			for(UINT i = 0; i < family->Get()->nMemberNum; ++i)
			{
				if (pUserInfo->dwCharacterID == family->GetMember(i)->Get()->nID)
				{
					family->GetMember(i)->Get()->eConState = CSHFamilyMember::MEMBER_CONSTATE_LOGIN;
				}

				if(family->GetMember(i)->Get()->eConState == CSHFamilyMember::MEMBER_CONSTATE_LOGIN)
				{
					nLoginCnt++;
				}
			}

			// ?泥?梨??吏뽰찈??? ??夷? 夷띿갹夷붿쿋吏몄쭠 2夷띿콬?? 夷?夷띿콝 夷띿콬姨붿쮷 ?泥???吏?姨?吏몄쭥?夷?姨뚯??吏??夷?.
			if (nLoginCnt == CSHFamilyManager::HONOR_POINT_CHECK_MEMBER_NUM)
			{
				family->GetEx()->nHonorPointTimeTick = gCurTime;
			}

			g_csFamilyManager.ASRV_SendMemberConToOtherAgent(
				family,
				pUserInfo->dwCharacterID,
				CSHFamilyMember::MEMBER_CONSTATE_LOGIN);
			g_csFamilyManager.ASRV_SendInfoToClient(
				family);
			Family_LoadEmblemInfo(
				pUserInfo->dwCharacterID,
				family->Get()->nID);
			g_csFarmManager.ASRV_RequestFarmUIInfoToMap(
				pUserInfo->dwCharacterID,
				family);
		}
		// ??夷?夷띿㎞ ????夷섏콬姨붿쭠 ??吏몄쭠??夷?.
		else
		{
			// ?吏싳쮼夷?姨뚯??吏?
			CSHFamily::stINFO		stInfo;
			CSHFamily::stINFO_EX	stInfoEx;

			ZeroMemory(&stInfo,		sizeof(stInfo));
			ZeroMemory(&stInfoEx,	sizeof(stInfoEx));
#ifdef _AGENT00_ 
      stInfo.nID				= pData->getDataINT(0);
      std::string d0 = pData->getSTR(1);
			SafeStrCpy(stInfo.szName, d0.c_str(), MAX_NAME_LENGTH+1);
			stInfo.nMasterID		= pData->getDataINT(2);
			stInfoEx.nHonorPoint	= pData->getDataINT(3);
			stInfoEx.nNicknameON	= pData->getDataINT(4);
#else
			stInfo.nID				= atoi((char*)pData[0].Data[0]);
			SafeStrCpy(stInfo.szName, (char*)pData[0].Data[1], MAX_NAME_LENGTH+1);
			stInfo.nMasterID		= atoi((char*)pData[0].Data[2]);
			stInfoEx.nHonorPoint	= atoi((char*)pData[0].Data[3]);
			stInfoEx.nNicknameON	= atoi((char*)pData[0].Data[4]);
#endif
			CSHFamily csFamily;
			csFamily.Set(&stInfo, &stInfoEx);

			family = g_csFamilyManager.AddFamilyToTbl(
				&csFamily);

			if(0 == family)
			{
				return;
			}

			pUserInfo->mFamilyIndex = family->Get()->nID;
			Family_Member_LoadInfo(
				pMessage->dwID,
				stInfo.nID);
			g_csFarmManager.ASRV_RequestFarmUIInfoToMap(
				pUserInfo->dwCharacterID,
				family);
		}
	}
}

void Family_LoadEmblemInfo(DWORD nPlayerID, DWORD nFamilyID)
{
	sprintf(txt, "EXEC  %s %d", STORED_FAMILY_LOAD_INFO_EMBLEM, nFamilyID);
	g_DB.FreeLargeQuery(RFamily_LoadEmblemInfo, nPlayerID, txt);
}

int convertCharToInt(char c)
{
	if('0' <= c && c <= '9')
		return c - '0';
	if('A' <= c && c <= 'F')
		return c - 'A' +10;
	if('a' <= c && c <= 'f')
		return c - 'a' +10;
	return 0;
}

HexToByte(char* pStr)
{
	int n1 = convertCharToInt(pStr[0]);
	int n2 = convertCharToInt(pStr[1]);

	return n1 * 16 + n2;
}

void RFamily_LoadEmblemInfo(LPLARGEQUERY pData, LPDBMESSAGE pMessage)
{
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) {}
#else
	if( pMessage->dwResult == 0 )	{	}
#endif
	else
	{
		char Img[CSHFamilyManager::EMBLEM_BUFSIZE];
#ifdef _AGENT00_ 
    std::string d0 = pData->getSTR(1);
    char *pStr = &d0.at(0);
#else
		char *pStr = (char*)pData->Data[1];
#endif
		char tempBuf[3] = {0,};
		int curpos = 0;
		for(int n=0;n<CSHFamilyManager::EMBLEM_BUFSIZE;++n)
		{
			strncpy(tempBuf,&pStr[curpos],2); // "FF"
			Img[n] = (char)HexToByte(tempBuf);
			curpos += 2;
		}
#ifdef _AGENT00_ 
    g_csFamilyManager.ASRV_RegistEmblem(pUserInfo, pData->getDataINT(0), Img, 1);
#else
		g_csFamilyManager.ASRV_RegistEmblem(pUserInfo, atoi((char*)pData->Data[0]), Img, 1);
#endif
	}
}

void Family_Member_SaveInfo(DWORD nFamilyID, DWORD nMemberID, char* pszMemberNickname)
{
	if (pszMemberNickname)
	{
		sprintf(txt, "EXEC  %s %d, %d, '%s'", STORED_FAMILY_MEMBER_SAVE_INFO, nFamilyID, nMemberID, pszMemberNickname);
	}
	else
	{
		// 姨?夷뚯쭠?? NULL ?夷?吏?夷? ??夷띿㎞姨뚯쿋夷띿쭩 夷??梨??吏뱀갹 ?吏?? ??姨띿쮼?吏??. 姨먯광夷뗭㏈ 吏? 夷?姨먯광夷泥좎쮬夷???夷?姨??泥ъ찓吏뺤찈吏?
		// insert 姨붿쭠夷? 夷?姨붿쮬???泥?姨?夷됱쮬夷? 夷?姨먯광 ???姨?
		sprintf(txt, "EXEC  %s %d, %d, NULL", STORED_FAMILY_MEMBER_SAVE_INFO, nFamilyID, nMemberID);
	}
	g_DB.Query(eQueryType_FreeQuery, eFamily_Member_SaveInfo, 0, txt);
}

void Family_Member_LoadInfo(DWORD nPlayerID, DWORD nFamilyID)
{
	sprintf(txt, "EXEC  %s %d", STORED_FAMILY_MEMBER_LOAD_INFO, nFamilyID);
	g_DB.Query(eQueryType_FreeQuery, eFamily_Member_LoadInfo, nPlayerID, txt);
}

void RFamily_Member_LoadInfo(LPQUERY pData, LPDBMESSAGE pMessage)
{
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ){}
#else
	if( pMessage->dwResult == 0 )	{	}
#endif
	else
	{
		CSHFamily* const family = g_csFamilyManager.GetFamily(
			pUserInfo->mFamilyIndex);

		if(0 == family)
		{
			return;
		}

		// ..夷띿갹夷붿쿋 夷됱쭨???? 姨뚯??吏?
		USERINFO* pMember;
		CSHFamilyMember				csMember;
		CSHFamilyMember::stINFO		stInfo;
#ifdef _AGENT00_ 
    DWORD i=0, ssto = 20;
    while( ssto > 0 )
#else
		for(DWORD i=0; i<pMessage->dwResult; i++)
#endif
		{
			if (i >= family->GetMemberNumMax())
			{
				break;
			}

			ZeroMemory(&stInfo, sizeof(stInfo));
#ifdef _AGENT00_ 
      stInfo.nID = pData->getDataINT(0);
			sprintf(stInfo.szName, "%d", stInfo.nID);
      std::string d0 = pData->getSTR(1);
			SafeStrCpy(stInfo.szNickname, d0.c_str(), MAX_NAME_LENGTH+1);
#else
			stInfo.nID = atoi((char*)pData[i].Data[0]);
			sprintf(stInfo.szName, "%d", stInfo.nID);
			SafeStrCpy(stInfo.szNickname, (char*)pData[i].Data[1], MAX_NAME_LENGTH+1);
#endif
			pMember = g_pUserTableForObjectID->FindUser(stInfo.nID);
			if (pMember)
			{
				stInfo.eConState = CSHFamilyMember::MEMBER_CONSTATE_LOGIN;
			}

			// 夷?夷붿쿋 姨뚯??吏?
			((CSHGroupMember*)&csMember)->Set(&stInfo);
			family->SetMember(
				&csMember,
				i);

			++(family->Get()->nMemberNum);
#ifdef _AGENT00_ 
      ssto--;
      if( !pData->isnextOK() ) break;
#endif
		}
		
		g_csFamilyManager.SetFamily(
			family);

		for(UINT i = 0; i < family->Get()->nMemberNum; ++i)
		{
			Family_Member_LoadExInfo01(
				pUserInfo->dwCharacterID,
				family->GetMember(i)->Get()->nID);
		}
		
		g_csFamilyManager.ASRV_SendMemberConToOtherAgent(
			family,
			pUserInfo->dwCharacterID,
			CSHFamilyMember::MEMBER_CONSTATE_LOGIN);
		Family_LoadEmblemInfo(
			pUserInfo->dwCharacterID,
			family->Get()->nID);
	}
}

void Family_Member_LoadExInfo01(DWORD nPlayerID, DWORD nMemberID)
{
	sprintf(txt, "EXEC  %s %d", STORED_FAMILY_MEMBER_LOAD_EXINFO_01, nMemberID);
	g_DB.Query(eQueryType_FreeQuery, eFamily_Member_LoadExInfo01, nPlayerID, txt);
}


void RFamily_Member_LoadExInfo01(LPQUERY pData, LPDBMESSAGE pMessage)
{
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) {}
#else
	if( pMessage->dwResult == 0 )	{}
#endif
	else
	{
		CSHFamily* const family = g_csFamilyManager.GetFamily(
			pUserInfo->mFamilyIndex);

		if(0 == family) return;
#ifdef _AGENT00_ 
    const DWORD nMemberID = pData->getDataINT(0);
#else
		const DWORD nMemberID = atoi((char*)pData[0].Data[0]);
#endif
		for(UINT i = 0; i < family->Get()->nMemberNum; ++i)
		{
			if (nMemberID == family->GetMember(i)->Get()->nID)
			{
				CSHFamilyMember	csMember;
				CSHFamilyMember::stINFO	stInfo = *family->GetMember(i)->Get();
				CSHFamilyMember::stINFO_EX	stInfoEx = *family->GetMember(i)->GetEx();
#ifdef _AGENT00_ 
        stInfo.nID			= pData->getDataINT(0);
        std::string d0 = pData->getSTR(1);
				SafeStrCpy(stInfo.szName, d0.c_str() , MAX_NAME_LENGTH+1);
				stInfo.nRace		= pData->getDataINT(2);
				stInfo.nSex			= pData->getDataINT(3);
				stInfo.nJobGrade	= pData->getDataINT(4);
				int nJob[6] = {0};
				nJob[0]				= pData->getDataINT(5);
				nJob[1]				= pData->getDataINT(6);
				nJob[2]				= pData->getDataINT(7);
				nJob[3]				= pData->getDataINT(8);
				nJob[4] 			= pData->getDataINT(9);
				nJob[5] 			= pData->getDataINT(10);
				stInfo.nJobFirst	= nJob[0];
				stInfo.nJobCur		= nJob[stInfo.nJobGrade-1];
				stInfo.nLV			= pData->getDataINT(11);
        std::string d1 = pData->getSTR(12);
				SafeStrCpy(stInfoEx.szGuild, d1.c_str() , MAX_NAME_LENGTH+1);
#else
				stInfo.nID			= atoi((char*)pData[0].Data[0]);
				SafeStrCpy(stInfo.szName, (char*)pData[0].Data[1], MAX_NAME_LENGTH+1);
				stInfo.nRace		= atoi((char*)pData[0].Data[2]);
				stInfo.nSex			= atoi((char*)pData[0].Data[3]);
				stInfo.nJobGrade	= atoi((char*)pData[0].Data[4]);
				int nJob[6] = {0};
				nJob[0]				= atoi((char*)pData[0].Data[5]);
				nJob[1]				= atoi((char*)pData[0].Data[6]);
				nJob[2]				= atoi((char*)pData[0].Data[7]);
				nJob[3]				= atoi((char*)pData[0].Data[8]);
				nJob[4] 			= atoi((char*)pData[0].Data[9]);
				nJob[5] 			= atoi((char*)pData[0].Data[10]);
				stInfo.nJobFirst	= nJob[0];
				stInfo.nJobCur		= nJob[stInfo.nJobGrade-1];
				stInfo.nLV			= atoi((char*)pData[0].Data[11]);
				SafeStrCpy(stInfoEx.szGuild, (char*)pData[0].Data[12], MAX_NAME_LENGTH+1);
#endif
				csMember.Set(
					&stInfo,
					&stInfoEx);
				family->SetMember(
					&csMember,
					i);

				if (stInfo.nID == family->Get()->nMasterID)
				{
					SafeStrCpy(
						family->Get()->szMasterName,
						stInfo.szName,
						_countof(family->Get()->szMasterName));
				}

				break;
			}
		}

		for(UINT i = 0; i < family->Get()->nMemberNum; ++i)
		{
			if(family->GetMember(i)->Get()->szName[0] == '@')
			{
				Family_Leave_SaveInfo(
					family->GetMember(i)->Get()->nID,
					CSHFamilyManager::FLK_LEAVE, TRUE);
				family->DelMember(
					family->GetMember(i)->Get()->nID);
				i--;
			}
		}

		g_csFamilyManager.SetFamily(
			family);
		g_csFamilyManager.ASRV_SendInfoToClient(
			family);
	}
}

void Family_CheckName(DWORD nPlayerID, char* pszName)
{
	// ??夷?夷띿㎞ ??夷띿쭬?夷?'' 夷? 姨? 夷붿㎝姨먯광??夷?吏뱀광 1231??夷?夷띿㎞ 姨? 吏몄㎏?夷?姨뚯꺽姨뚯㎝夷? 姨뚯껨?? ??吏??夷??(姨붿쮬夷붿㎞?夷??吏?? 姨? ??夷??姨??夷?夷붿㎞??姨붿㎝夷? ??姨????泥?姨?夷?夷?.
	// SQL姨뚯㎝夷붿쿋姨붿쭠姨뚯㎝ 姨뚯껨??吏몄쭠 夷??泥?夷吏㏃찓?夷띿콝 夷붿㎞??姨붿㎝夷? ??姨????泥?姨?夷? 夷됱콬...
	sprintf(txt, "EXEC  %s '%s'", STORED_FAMILY_CHECKNAME, pszName);
	g_DB.Query(eQueryType_FreeQuery, eFamily_CheckName, nPlayerID, txt);
}

void RFamily_CheckName(LPQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#endif
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;
#ifdef _AGENT00_ 
  std::string d0 = pData->getSTR( 0 );
  if( d0 == "" )
#else
	if( stricmp((char*)pData[0].Data[0], "") == 0 )
#endif
	{
		// ??夷? DB姨붿쭠 ?夷?梨??夷? ??夷띿쭬??夷?..
		g_csFamilyManager.ASRV_CreateFamily(pUserInfo, NULL, CSHFamilyManager::FCS_NAME_ERR);
	}
	else
	{
#ifdef _AGENT00_ 
    g_csFamilyManager.ASRV_CreateFamily(pUserInfo, &d0.at(0), CSHFamilyManager::FCS_NAME_CHECK2);
#else
		// DB姨붿쭠 姨먯꺽夷? ??夷띿쭬. 夷⑹콐姨붿콠?? 姨뚯쿋 ??夷?. 夷?姨? ??夷?夷띿㎞ 夷⑹껨姨뚯쮼 姨?夷됱쮬
		g_csFamilyManager.ASRV_CreateFamily(pUserInfo, (char*)pData[0].Data[0], CSHFamilyManager::FCS_NAME_CHECK2);
#endif
	}
}

void Family_Leave_SaveInfo(DWORD nPlayerID, int nLeaveKind, BOOL bInit, BOOL bBreakUp)
{
	SYSTEMTIME t;
	GetLocalTime(&t);

	DWORD nLeaveDate = (t.wYear-2000)*100000000 + t.wMonth*1000000 + t.wDay*10000 + t.wHour*100 + t.wMinute;
	if (bInit) nLeaveDate = 0;

	sprintf(txt, "EXEC  %s %d, %u, %d, %d", STORED_FAMILY_LEAVE_SAVE_INFO, nPlayerID, nLeaveDate, nLeaveKind, bBreakUp);
	g_DB.Query(eQueryType_FreeQuery, eFamily_Leave_SaveInfo, 0, txt);
}

void Family_Leave_LoadInfo(DWORD nPlayerID)
{
	sprintf(txt, "EXEC  %s %d", STORED_FAMILY_LEAVE_LOAD_INFO, nPlayerID);
	g_DB.Query(eQueryType_FreeQuery, eFamily_Leave_LoadInfo, nPlayerID, txt);
}

void RFamily_Leave_LoadInfo(LPQUERY pData, LPDBMESSAGE pMessage)
{
	USERINFO* pUserInfo = g_pUserTableForObjectID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
  pUserInfo->nFamilyLeaveDate = pData->getDataINT(0);
  pUserInfo->nFamilyLeaveKind = pData->getDataINT(1);
#else
	if( pMessage->dwResult == 0 )	{	}
	else	{
		pUserInfo->nFamilyLeaveDate = atoi((char*)pData[0].Data[0]);
		pUserInfo->nFamilyLeaveKind = atoi((char*)pData[0].Data[1]);
	}
#endif
}

void RFamily_ChangeMaster(LPMIDDLEQUERY pData, LPDBMESSAGE pMessage)
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#else
	if(0 == pMessage->dwResult)	{		return;	}
#endif
	USERINFO* const pUserInfo = g_pUserTableForObjectID->FindUser(
		pMessage->dwID);

	if(0 == pUserInfo)
	{
		return;
	}

	CSHFamily* const family = g_csFamilyManager.GetFamily(
		pUserInfo->mFamilyIndex);

	if(0 == family)
	{
		return;
	}
#ifdef _AGENT00_ 
  const DWORD dwNewMasterID = pData->getDataINT(0);
  std::string mmaster = pData->getSTR(1);
  LPCTSTR masterName = mmaster.c_str();
  const int nFarmZone = pData->getDataINT(2);
  const int nFarmID = pData->getDataINT(3);
#else
	const MIDDLEQUERYST& record = pData[0];
	const DWORD dwNewMasterID = atoi(LPCTSTR(record.Data[0]));
	LPCTSTR masterName = LPCTSTR(record.Data[1]);
	const int nFarmZone = atoi(LPCTSTR(pData[0].Data[2]));
	const int nFarmID = atoi(LPCTSTR(pData[0].Data[3]));
#endif
	MSG_DWORD3_NAME stPacket;
	ZeroMemory(
		&stPacket,
		sizeof(stPacket));
	stPacket.Category	= MP_FAMILY;
	stPacket.Protocol	= MP_FAMILY_TRANSFER_TO_OTHER_AGENT;
	stPacket.dwObjectID	= family->Get()->nID;
	stPacket.dwData1 = dwNewMasterID;
	stPacket.dwData2 = pUserInfo->nFamilyLeaveDate;
	stPacket.dwData3 = pUserInfo->nFamilyLeaveKind;
	SafeStrCpy(
		stPacket.Name,
		masterName,
		_countof(stPacket.Name));
	g_csFamilyManager.ASRV_TransferFromOtherAgent(
		(char*)&stPacket);
	g_Network.Broadcast2AgentServerExceptSelf(
		(char*)&stPacket,
		sizeof(stPacket));

	// 姨붿ℓ夷뚯㎟ 夷泥?梨?夷??? ???夷?姨뚯쿋 ???夷띿쮷?夷? 夷섏콟夷?夷됱콉?夷姨띿쮼????夷?
	{
		MSG_DWORD3 message;
		ZeroMemory(
			&message,
			sizeof(message));
		message.Category = MP_FARM;
		message.Protocol = MP_FARM_SETFARM_CHANGE_OWNER;
		message.dwObjectID = pMessage->dwID;
		message.dwData1 = nFarmZone;
		message.dwData2 = nFarmID;
		message.dwData3 = dwNewMasterID;
		g_Network.Broadcast2MapServer(
			(char*)&message,
			sizeof(message));
	}

	InsertLogFamily(
		eLog_FamilyChangeMaster,
		family->Get()->nID,
		pUserInfo->dwCharacterID );
}

// E ??夷?夷띿㎞ ??吏몄쭠 added by hseos 2007.07.09	2007.07.10	2007.07.14	2007.10.11

// desc_hseos_夷泥?梨낆찉?姨띿쮼??_01
// S 夷泥?梨낆찉?姨띿쮼?? ??吏몄쭠 added by hseos 2008.01.22
void Farm_SendNote_DelFarm(DWORD nFarmOwnerID)
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC  dbo.MP_FARM_SENDNOTE_DELFARM %d", nFarmOwnerID);
	g_DB.Query(eQueryType_FreeQuery, eFarm_SendNote_DelFarm, nFarmOwnerID, txt);
}

void RFarm_SendNote_DelFarm(LPQUERY pData, LPDBMESSAGE pMessage)
{
	// ??夷?夷띿㎞ 夷띿갹夷붿쿋 ??夷띿쭬?夷?姨먯굘姨먯광姨뚯㎝ ???泥좎쮰吏?夷섏쮰夷姨띿쮫?.
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
  int i = 0, sto = 20;
  while( sto > 0 ){
    std::string d0 = pData->getSTR( 0 );
    NoteSendtoPlayer(0, "<SYSTEM>", &d0[0], "<SYSTEM NOTICE>", "61");
    
    sto--;
    if( !pData->isnextOK() ) break;
  }
#else
	for(DWORD i=0; i<pMessage->dwResult; i++)
	{
		NoteSendtoPlayer(0, "<SYSTEM>", (char*)pData[0].Data[0], "<SYSTEM NOTICE>", "61");
	}
#endif
}
// E 夷泥?梨낆찉?姨띿쮼?? ??吏몄쭠 added by hseos 2008.01.22

#ifdef _NPROTECT_
void NProtectBlock(DWORD UserIdx, DWORD CharIdx, char* IP, DWORD BlockType)
{
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	char szBufIp[MAX_IPADDRESS_SIZE];
	SafeStrCpy(szBufIp, IP, MAX_IPADDRESS_SIZE);
	if(IsCharInString(szBufIp, "'"))	return;

    // 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC dbo.UP_NPROTECTBLOCKLOG %d, %d, \'%s\', %d, %d", UserIdx, CharIdx, szBufIp, BlockType, 6 );
	g_DB.LoginQuery( eQueryType_FreeQuery, eNProtectBlock, 0, txt);
}
#endif


void InsertLogFamilyPoint( CSHFamily* family, eFamilyLog type )
{
	if( ! family )
	{
		ASSERT( 0 );
		return;
	}

	const CSHFamily::stINFO_EX*	extendedData	= family->GetEx();
	const CSHFamily::stINFO*	data			= family->Get();

	if( ! data ||
		! extendedData )
	{
		ASSERT( 0 );
		return;
	}

	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	g_DB.LogMiddleQuery( 0, 0, "EXEC dbo.TP_FAMILY_POINT_LOG_INSERT %d, %d, %d, %d, %d, \'""\'",
		data->nID,
		extendedData->nHonorPoint,
		0,
		0,
		type );
}


//---KES PUNISH
void PunishListAdd( DWORD dwUserIdx, int nPunishKind, DWORD dwPunishTime )
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC dbo.MP_PUNISHLIST_ADD %u, %d, %u", dwUserIdx, nPunishKind, dwPunishTime );
	g_DB.LoginQuery( eQueryType_FreeQuery, ePunishList_Add, dwUserIdx, txt);
}

void PunishListLoad( DWORD dwUserIdx )
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC dbo.MP_PUNISHLIST_LOAD %u", dwUserIdx );
	g_DB.LoginQuery( eQueryType_FreeQuery, ePunishList_Load, dwUserIdx, txt);
}

void RPunishListLoad( LPQUERY pData, LPDBMESSAGE pMessage )
{
	USERINFO* pUserInfo = g_pUserTableForUserID->FindUser( pMessage->dwID );
	if( pUserInfo == NULL ) return;
#ifdef _AGENT00_ 
  if(!pData->isnextOK()) return;
  int i = 0 , nPunishTime, sto = 20;
  while( sto > 0 ){
    nPunishTime = pData->getDataINT(1);
    if( nPunishTime > 0 ) 
			PUNISHMGR->AddPunishUnit( pUserInfo->dwUserID, pData->getDataINT(0), nPunishTime );
      
    sto--;
    if(!pData->isnextOK()) break;
  }
  
#else
	int nCount = pMessage->dwResult;
	if( nCount == 0 ) return;
	
	for( int i = 0 ; i < nCount ; ++i )
	{
		int nPunishTime = atoi( (char*)pData[i].Data[1] );
		if( nPunishTime > 0 ) 
			PUNISHMGR->AddPunishUnit( pUserInfo->dwUserID, atoi((char*)pData[i].Data[0]), nPunishTime );
	}
#endif
}

void PunishCountAdd( DWORD dwUserIdx, int nPunishKind, int nPeriodDay )
{
	// 081012 LUJ, ??夷? 夷????夷???夷?姨??泥??吏?李?姨? 夷덉콠姨?夷붿㎞??吏뱀광?泥????吏??姨? ??夷?. 夷?, dbo夷? 姨?夷붿㎞??夷? ??姨???. ??姨붿쭠 夷띿괩夷됱콐 ??夷?姨??泥???夷띿쭬?夷?姨뚯쿋?吏??
	sprintf(txt, "EXEC dbo.MP_PUNISHCOUNT_ADD %u, %d, %d", dwUserIdx, nPunishKind, nPeriodDay );
	g_DB.LoginQuery( eQueryType_FreeQuery, ePunishCount_Add, dwUserIdx, txt);
}

void RPunishCountAdd( LPQUERY pData, LPDBMESSAGE pMessage )
{
#ifdef _AGENT00_ 
	if( !pData->isnextOK() ) return;

	int nPunishKind	= pData->getDataINT(0);
  int nCount			= pData->getDataINT(1);
#else
  if( pMessage->dwResult == NULL ) return;
	int nPunishKind		= atoi((char*)pData[0].Data[0]);
	int nCount			= atoi((char*)pData[0].Data[1]);
#endif
	if( nCount == 0 ) return;

	switch( nPunishKind )
	{
	case ePunishCount_AutoUse:
		{
			PunishListAdd( pMessage->dwID, ePunish_Login, (DWORD)(POW( 2, nCount-1 ) * 1 * 60 * 60) );	//1姨?吏몄쭥夷??? 夷덉쿇夷섏콬夷?!
		}
		break;
	};
}

void GiftEvent( DWORD dwUserIdx )
{
//	sprintf(txt, "EXEC dbo.up_event20080425_attend_check %u, %d", dwUserIdx, g_nServerSetNum );
//	g_DB.LoginQuery( eQueryType_FreeQuery, eGiftEvent, dwUserIdx, txt);
}

void RGiftEvent( LPQUERY pData, LPDBMESSAGE pMessage )
{
#ifdef _AGENT00_ 
  if( !pData->isnextOK() ) return;
#else
	if( pMessage->dwResult == NULL ) return;
#endif
	USERINFO* pUserInfo = g_pUserTableForUserID->FindUser( pMessage->dwID );
	if( !pUserInfo ) return;
#ifdef _AGENT00_ 
  int result = pData->getDataINT(0);
#else
	int result = atoi((char*)pData[0].Data[0]);
#endif
	DWORD eventidx = 0;

	switch( result )
	{
	case 1:
		{
			eventidx = 6;
		}
		break;
	case 2:
		{
			eventidx = 7;
		}
		break;
	case 3:
		{
			eventidx = 8;
		}
		break;
	}

	GIFTMGR->ExcuteEvent( pUserInfo->dwCharacterID, eventidx );
}

//-------------------------------------------------------------------------------------------------
  //	NAME		: RSiegeRecallUpdate
  //	DESC		: 姨??吏깆쮷吏?db ?吏싳쮼夷?姨먯꺼夷됱쭨???吏?吏몄갸吏몄껄 ?夷夷띿㎞ ??吏몄쭠.
  //	PROGRAMMER	: Yongs Lee
  //	DATE		: September 2, 2008
  //-------------------------------------------------------------------------------------------------
  void RSiegeRecallUpdate( LPQUERY pData, LPDBMESSAGE pMessage )
  {
  	SIEGERECALLMGR->RSiegeRecallUpdate( pData, pMessage ) ;
  }
  
  
  //-------------------------------------------------------------------------------------------------
  //	NAME		: RSiegeRecallLoad
  //	DESC		: 姨??吏깆쮷吏?db ?吏싳쮼夷?夷?夷됱콉 ?夷夷띿㎞ ??吏몄쭠.
  //	PROGRAMMER	: Yongs Lee
  //	DATE		: August 13, 2008
  //-------------------------------------------------------------------------------------------------
  void RSiegeRecallLoad( LPQUERY pData, LPDBMESSAGE pMessage )
  {
  	SIEGERECALLMGR->Result_ObjInfo_Syn( pData, pMessage ) ;
  }
  
  
  
  
  
  //-------------------------------------------------------------------------------------------------
  //	NAME		: RSiegeRecallInsert
  //	DESC		: 姨??吏깆쮷吏?db ?吏싳쮼夷???吏몄쭠 ?夷夷띿㎞ ??吏몄쭠.
  //	PROGRAMMER	: Yongs Lee
  //	DATE		: August 31, 2008
  //-------------------------------------------------------------------------------------------------
  void RSiegeRecallInsert(LPQUERY pData, LPDBMESSAGE pMessage ) 
  {
  	SIEGERECALLMGR->RSiegeRecallInsert( pData, pMessage ) ;
  }
  
  
  
  
  
  ////-------------------------------------------------------------------------------------------------
  ////	NAME		: RSiegeRecallRemove
  ////	DESC		: 姨??吏깆쮷吏?db ?吏싳쮼夷?夷⑹콛?吏??夷夷띿㎞ ??吏몄쭠.
  ////	PROGRAMMER	: Yongs Lee
  ////	DATE		: September 7, 2008
  ////-------------------------------------------------------------------------------------------------
  //void RSiegeRecallRemove(LPQUERY pData, LPDBMESSAGE pMessage )
  //{
  //	SIEGERECALLMGR->RSiegeRecallRemove( pData, pMessage ) ;
  //}
  
  
// 081205 LUJ, ??夷?夷띿㎞ ?泥???吏?夷?吏?
void InsertLogFamily( eFamilyLog logType, DWORD familyIndex, DWORD playerIndex, const char* memo )
{
	char buffer[ MAX_NAME_LENGTH + 1 ] = { 0 };
	SafeStrCpy( buffer, memo, sizeof( buffer ) / sizeof( *buffer ) );
	
	// 090325 ONS ????夷띿쮬夷붿㎞???姨?吏?
	if(IsCharInString(buffer, "'"))	return;

	g_DB.LogMiddleQuery(
		0,
		0,
		"EXEC dbo.TP_FAMILY_LOG_INSERT %d, %d, %d, \'%s\'",
		logType,
		familyIndex,
		playerIndex,
		memo );
}

// 090525 ShinJS --- ??夷띿쭬 吏?夷⑹쿋?夷띿쮯? ???姨??夷덉콠 ??吏몄쭠
void SearchCharacterForInvitePartyMember( DWORD dwRequestPlayerID, char* pInvitedName )
{
	sprintf(txt, "EXEC  dbo.MP_SEARCH_FOR_INVITEPARTY \'%s\'", pInvitedName);
	g_DB.Query(eQueryType_FreeQuery, eSearchCharacterForInvitePartyMember, dwRequestPlayerID, txt);
}

void RSearchCharacterForInvitePartyMember( LPQUERY pData, LPDBMESSAGE pMessage )
{
	// ???姨??夷덉콠姨붿콈?夷?Player
	const DWORD dwRequestPlayerID = pMessage->dwID;
	USERINFO* pRequestPlayer = g_pUserTableForObjectID->FindUser( dwRequestPlayerID );
	if( !pRequestPlayer )
		return;
	
	// ??夷띿쭬吏?夷⑹쿋 姨????? 姨뚯??吏?
	pRequestPlayer->bIsSearchingByName = FALSE;

	DWORD dwCheckSearchTime = 0;
#ifdef _AGENT00_
  const DWORD dwResult = pData->getDataINT(0);
#else
	const DWORD dwResult = atoi( (char*)pData->Data[0] );
#endif
	switch( dwResult )
	{
	case 1:
		{
			// ???姨??夷덉콠夷덉콠夷⑹쿂?? ?夷?梨???泥?姨?夷? 吏몄콌姨붿콡

			MSG_DWORD msg;
			msg.Category = MP_PARTY;
			msg.Protocol = MP_PARTY_INVITE_BYNAME_NACK;
			msg.dwData = eErr_Add_NoPlayer;

			// Error ?泥댁찈?
			g_Network.Send2User( pRequestPlayer->dwConnectionIndex, (char*)&msg, sizeof(msg) );

			// ??姨먯꺼 吏?夷⑹콐姨?吏몄쭥 姨뚯??吏?
			dwCheckSearchTime = ePartyInvite_CheckSearchTimeNoPlayer;
		}
		break;
		
	case 2:
		{
			// ???姨??夷덉콠夷덉콠夷⑹쿂?? ?吏뽰찈??????泥?姨??夷?吏몄콌姨붿콡

			MSG_DWORD msg;
			msg.Category = MP_PARTY;
			msg.Protocol = MP_PARTY_INVITE_BYNAME_NACK;
			msg.dwData = eErr_Add_NotConnectedPlayer;

			// Error ?泥댁찈?
			g_Network.Send2User( pRequestPlayer->dwConnectionIndex, (char*)&msg, sizeof(msg) );

			// ??姨먯꺼 吏?夷⑹콐姨?吏몄쭥 姨뚯??吏?
			dwCheckSearchTime = ePartyInvite_CheckSearchTimeNotConnectPlayer;
		}
		break;
	
	case 3:
		{
			// ???姨??夷덉콠夷덉콠夷⑹쿂?? ??夷? 夷?夷띿쭨 ???姨뚯찓吏?姨??? ??夷? 吏몄콌姨붿콡

			MSG_DWORD msg;
			msg.Category = MP_PARTY;
			msg.Protocol = MP_PARTY_INVITE_BYNAME_NACK;
			msg.dwData = eErr_Add_AlreadyinParty;

			// Error ?泥댁찈?
			g_Network.Send2User( pRequestPlayer->dwConnectionIndex, (char*)&msg, sizeof(msg) );

			// ??姨먯꺼 吏?夷⑹콐姨?吏몄쭥 姨뚯??吏?
			dwCheckSearchTime = ePartyInvite_CheckSearchTimeAlreadyInParty;
		}
		break;

	case 4:
		{
			// ???姨??夷덉콠夷덉콠夷⑹쿂?? ?吏뽰찈????? 吏몄콌姨붿콡

			// ??姨먯꺼 吏?夷⑹콐姨?吏몄쭥 姨뚯??吏?
			dwCheckSearchTime = ePartyInvite_CheckSearchTimeSuccess;
#ifdef _AGENT00_
			const DWORD dwInvitedPlayerID = pData->getDataINT(1);
#else
      const DWORD dwInvitedPlayerID = atoi( (char*)pData->Data[1] );
#endif
			USERINFO* pInvitedPlayer = g_pUserTableForObjectID->FindUser( dwInvitedPlayerID );

			// ???姨??夷덉콠夷덉콠夷⑹쿂?? 吏몄㎏?夷?Agent, 吏몄㎏?夷?夷?姨붿쭠 ?夷?梨??夷? 吏몄콌姨붿콡
			if( pInvitedPlayer &&
				pRequestPlayer->dwMapServerConnectionIndex == pInvitedPlayer->dwMapServerConnectionIndex )
			{
				// 吏뱀갹?夷?MSG ??姨붿콠??姨붿ℓ ??夷덉콠?夷夷띿㎞
				MSG_DWORD2 msg;
				msg.Category	= MP_PARTY;
				msg.Protocol	= MP_PARTY_ADD_SYN;
				msg.dwObjectID	= dwRequestPlayerID;
				msg.dwData1		= dwInvitedPlayerID;

				g_Network.Send2Server( pRequestPlayer->dwMapServerConnectionIndex, (char*)&msg, sizeof(msg) );
				break;
				
			}

			// 姨뚯㎝夷? 夷?夷띿쭨 Agent or 夷?夷띿쭨 夷?姨붿쭠 ?夷?梨??夷? 吏몄콌姨붿콡 ???姨뚯㎏吏??吏?姨???泥??吏????夷?
			MSG_DWORD msg;
			msg.Category	= MP_PARTY;
			msg.Protocol	= MP_PARTY_INVITE_BYNAME_SYN;
			msg.dwObjectID	= dwRequestPlayerID;
			msg.dwData		= dwInvitedPlayerID;

            g_Network.Send2Server( pRequestPlayer->dwMapServerConnectionIndex, (char*)&msg, sizeof(msg) );
		}
		break;
	}


	// ??姨먯꺼 ?吏??姨?吏몄쭥 ?吏??
	if( gCurTime < pRequestPlayer->dwInvitePartyByNameLastTime + dwCheckSearchTime )
	{
		// 夷덉ℓ?泥?姨띿찈泥???吏몄쭠
		++pRequestPlayer->nInvitePartyByNameCnt;

		// 夷덉ℓ?泥?姨띿찈泥좎㎏吏???吏몄껄夷? 吏몄콌姨붿콡 ?吏??姨?吏몄쭥 姨뚯??吏?
		if( pRequestPlayer->nInvitePartyByNameCnt >= ePartyInvite_LimitCnt )
		{
			MSG_DWORD2 limitTimeMsg;
			memset( &limitTimeMsg, 0, sizeof(limitTimeMsg) );
			limitTimeMsg.Category = MP_PARTY;
			limitTimeMsg.Protocol = MP_PARTY_INVITE_BYNAME_NACK;
			limitTimeMsg.dwData1 = eErr_SettingLimitTime;

			switch( dwResult )
			{
				// ???姨??夷덉콠夷덉콠夷⑹쿂?? ?夷?梨???泥?姨?夷? 吏몄콌姨붿콡
			case 1:
				limitTimeMsg.dwData2 = pRequestPlayer->dwInvitePartyByNameDelayTime = ePartyInvite_OverCntLimitTimeNoPlayer;
				break;

				// ???姨??夷덉콠夷덉콠夷⑹쿂?? ?吏뽰찈??????泥?姨??夷?吏몄콌姨붿콡
			case 2:
				limitTimeMsg.dwData2 = pRequestPlayer->dwInvitePartyByNameDelayTime = ePartyInvite_OverCntLimitTimeNotConnectPlayer;
				break;

				// ???姨??夷덉콠夷덉콠夷⑹쿂?? ??夷? 夷?夷띿쭨 ???姨뚯찓吏?姨??? ??夷? 吏몄콌姨붿콡
			case 3:
				limitTimeMsg.dwData2 = pRequestPlayer->dwInvitePartyByNameDelayTime = ePartyInvite_OverCntLimitTimeAlreadyInParty;
				break;

				// ???姨??夷덉콠夷덉콠夷⑹쿂?? ?吏뽰찈????? 吏몄콌姨붿콡
			case 4:
				limitTimeMsg.dwData2 = pRequestPlayer->dwInvitePartyByNameDelayTime = ePartyInvite_OverCntLimitTimeSuccess;
				break;
			}

			// 姨뚯??吏싳㎏吏??泥댁찈?
			g_Network.Send2User( pRequestPlayer->dwConnectionIndex, (char*)&limitTimeMsg, sizeof(limitTimeMsg) );
		}
	}

	// ??姨먯꺼姨?吏몄쭡 ?泥?梨?
	pRequestPlayer->dwInvitePartyByNameLastTime = gCurTime;
}

// ?吏??夷섏쭨?吏?
void WebEvent( DWORD dwUserIdx, DWORD type )
{
	sprintf( txt, "EXEC dbo.MP_WEB_EVENT %d, '%d'", dwUserIdx, type );
	g_DB.Query( eQueryType_FreeQuery, eItemInsert, 0, txt, dwUserIdx );
}
