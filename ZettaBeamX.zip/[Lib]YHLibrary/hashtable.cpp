#include "stdafx.h"
#include "hashtable.h"
///////////////////////////////////////////////////////////////////////////
#include <crtdbg.h>
#ifdef _DEBUG
	#define _DEBUG_NEW new( _NORMAL_BLOCK,__FILE__,__LINE__)
#else 
	#define _DEBUG_NEW 
#endif
#ifdef _DEBUG
	#define new _DEBUG_NEW 
#endif
