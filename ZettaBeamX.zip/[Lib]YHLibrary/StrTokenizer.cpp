// StrTokenizer.cpp: implementation of the CStrTokenizer class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx__.h"
//#include <string.h>
#include "StrTokenizer.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CStrTokenizer::CStrTokenizer(char* String,char* Sep)
{
//	ASSERT(strlen(Sep) < MAX_TOKENIZER_SEPARATOR);
	strcpy(m_strSep,Sep);
	m_ReturnData = strtok(String,m_strSep);
}

CStrTokenizer::~CStrTokenizer()
{

}

char* CStrTokenizer::GetNextToken()
{
	char* pRt = m_ReturnData;
	if(m_ReturnData)
	{
		m_ReturnData = strtok(NULL,m_strSep);
	}
	return pRt;
}

char* CStrTokenizer::GetNextTokenUpper()
{
	char* tok = GetNextToken();
	if( tok ){
		//return _strupr( tok );
		char * tcc = tok;
		char pcc;
		while( *tcc != '\0'){
			pcc = *tcc;
			if( pcc >= 'a' && pcc <= 'z'){
				*tcc = pcc - 'a' + 'A';
			}
			++tcc;
		}
		return tok;
	}
	return NULL;
}