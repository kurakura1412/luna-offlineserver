#ifndef __DESC_BASENETWORK_H__INCLUDED
#define __DESC_BASENETWORK_H__INCLUDED
#pragma once
#ifndef _MYLUNA_
#include "stdafx.h"
#endif
//#pragma pack(push,4)
struct DESC_BASENETWORK
{
	WORD		wSockEventWinMsgID;
    void		(*ReceivedMsg)(DWORD dwInex,char* pMsg,DWORD dwLen);
	void		(*OnDisconnect)(DWORD dwInex);
	void		(*OnConnect)(DWORD dwInex);
};

//#pragma pack(pop)
#endif // __DESC_BASENETWORK_H__INCLUDED
