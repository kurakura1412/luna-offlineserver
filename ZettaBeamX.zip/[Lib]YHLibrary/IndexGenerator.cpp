//__CINDEXGENERATOR_H__
#include "IndexGenerator.h"

CIndexGenerator::CIndexGenerator()
{
	m_pIndexTable = nullptr;
	front = 0;
	rear = 0;
	m_dwMaxIndexNum = 0;
	m_dwStartIndex = 0;
}

CIndexGenerator::~CIndexGenerator()
{}

void	CIndexGenerator::Init(DWORD dwMaxIndexNum, DWORD startIdx)
{
	m_dwStartIndex = startIdx;
	m_dwMaxIndexNum = dwMaxIndexNum;
	_vindex.resize(m_dwMaxIndexNum);
	std::fill(_vindex.begin(), _vindex.end(), '0');
}
void	CIndexGenerator::Release()
{
	std::fill(_vindex.begin(), _vindex.end(), '0');
}
DWORD	CIndexGenerator::GenerateIndex()
{
	DWORD aa = 0;
	for( aa = 0; aa < m_dwMaxIndexNum; ++aa ) {
		if( _vindex.at(aa) == '0'){
			_vindex.at(aa) = '1';
			break;
		}
	}
	return aa + m_dwStartIndex;
}
BOOL	CIndexGenerator::ReleaseIndex(DWORD dwIndex)
{
	DWORD aa = dwIndex - m_dwStartIndex;
	if( _vindex.size() < aa  ){
		_vindex.at(aa) = '0';
	}
}