#ifndef __SIEGECOMMAND_H__INCLUDED
#define __SIEGECOMMAND_H__INCLUDED
#pragma once
//-------------------------------------------------------------------------------------------------
//	NAME		: CSiegeCommand.h
//	DESC		: The class to contain object info.
//	PROGRAMMER	: Yongs Lee
//	DATE		: July 25, 2008
//-------------------------------------------------------------------------------------------------





//-------------------------------------------------------------------------------------------------
//		Include part.
//-------------------------------------------------------------------------------------------------
#include <map>





//-------------------------------------------------------------------------------------------------
//		Define some macroinstruction.
//-------------------------------------------------------------------------------------------------
#define MAX_COMMAND_IDX		250





//-------------------------------------------------------------------------------------------------
//		The class CSiegeCommand.
//-------------------------------------------------------------------------------------------------
class CSiegeCommand
{
	BYTE m_byIndex ;
	// 
	typedef std::map< BYTE, st_DIE_RECALL_OBJ >		M_RECALLOBJ ;
	M_RECALLOBJ		m_mRecallObj ;

public:
	CSiegeCommand(void);
	virtual ~CSiegeCommand(void);
	void Set_Index(BYTE byIdx) ;									// The function to setting index.
	BYTE Get_Index() { return m_byIndex ; }							// The function to return index.

	BYTE Get_ChildCount() ;											// The function to return child count.
	BYTE Get_ChildKind(BYTE byIdx) ;								// The function to return child kind.

	st_DIE_RECALL_OBJ* Get_DieRecallObjInfo(BYTE byIdx) ;			// The function to return die recall object info.

	void Add_Die_Recall_Obj(st_DIE_RECALL_OBJ* pInfo) ;				// The function to add recall info when die.


	////////////////////////////////
	// [ ���� �޽��� ó�� ��Ʈ. ] //
	////////////////////////////////

	void Throw_Error(const char* szErr, const char* szCaption) ;							// ���� �޽��� ó���� �ϴ� �Լ�.
	void WriteLog(char* pMsg) ;													// �α׸� ����� ó���� �ϴ� �Լ�.
};

#endif // __SIEGECOMMAND_H__INCLUDED
