//-------------------------------------------------------------------------------------------------
//	NAME		: CSiege_AddObj.cpp
//	DESC		: Implementation part of CSiege_AddObj class.
//	PROGRAMMER	: Yongs Lee
//	DATE		: July 25, 2008
//-------------------------------------------------------------------------------------------------





//-------------------------------------------------------------------------------------------------
//		Include part.
//-------------------------------------------------------------------------------------------------
#include "stdafx.h"																						// An include file for standard system include files

#if defined( _AGENT00_ ) || defined( _MAP00_ )
#include "[lib]yhlibrary/HashTable.h"
//#include "CommonHeader.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "vector.h"
#include "protocol.h"
#include "CommonDefine.h"
#include "CommonGameDefine.h"
#include "ServerGameDefine.h"
#include "CommonStruct.h"
//#include "ServerGameStruct.h"
#include "CommonGameFunc.h"
//#include "ServerSystem.h"
#endif

#include "siege_addobj.h"





//-------------------------------------------------------------------------------------------------
//	NAME		: CSiege_AddObj
//	DESC		: »ý¼ºÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: July 25, 2008
//-------------------------------------------------------------------------------------------------
CSiege_AddObj::CSiege_AddObj(void)
{
	// Initialze variables.
	m_byParentStepIdx = 0 ;

	m_byIdx = 0 ;

	//090812 pdy °ø¼ºÀü Agent¿Í Map¼­¹ö°£ÀÇ ¼ÒÈ¯Obj ÀÎµ¦½º°ü¸®°¡ Àß¸øµÇÀÖ´Â ¹ö±× ¼öÁ¤ 
	m_dwMonsterID = 0 ;

	memset(&m_ObjInfo, 0, sizeof(st_SIEGEOBJ)) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: ~CSiege_AddObj
//	DESC		: ¼Ò¸êÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: July 25, 2008
//-------------------------------------------------------------------------------------------------
CSiege_AddObj::~CSiege_AddObj(void)
{
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_ParentStepIdx
//	DESC		: The function to setting parent step index.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 04, 2008
//-------------------------------------------------------------------------------------------------
void CSiege_AddObj::Set_ParentStepIdx(BYTE byIdx)
{
	// Check index.
	if( byIdx == 0 )
	{
		Throw_Error("Over index limit!!", __FUNCTION__) ;
		return ;
	}


	// Setting parent step index.
	m_byParentStepIdx = byIdx ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_Index
//	DESC		: The function to setting index.
//	PROGRAMMER	: Yongs Lee
//	DATE		: July 30, 2008
//-------------------------------------------------------------------------------------------------
void CSiege_AddObj::Set_Index(BYTE byIndex)
{
	// Check index limit.
	if( byIndex >= MAX_ADDOBJ_IDX )
	{
		Throw_Error("Over index limit!!", __FUNCTION__) ;
		return ;
	}


	// Setting index.
	m_byIdx = byIndex ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Init_ObjInfo
//	DESC		: ¿ÀºêÁ§Æ® Á¤º¸ ¼¼ÆÃ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: July 25, 2008
//-------------------------------------------------------------------------------------------------
//void CSiege_AddObj::Init_ObjInfo(WORD wThemeIdx, MAPTYPE mapNum, BYTE byStepIdx, DWORD dwObjIdx, 
//	float fXpos, float fZpos, BYTE byUseRandomPos, BYTE byRadius, BYTE byComKind, BYTE byComIndex)
void CSiege_AddObj::Init_ObjInfo(st_SIEGEOBJ* pInfo)
{
	// ÇÔ¼ö ÀÎÀÚ È®ÀÎ.
	if( !pInfo )
	{
		Throw_Error("Invalid parameter!!", __FUNCTION__) ;
		return ;
	}

	
	// ¿ÀºêÁ§Æ® Á¤º¸¸¦ º¹»çÇÑ´Ù.
	memcpy(&m_ObjInfo, pInfo, sizeof(st_SIEGEOBJ)) ;


	//// ¿ÀºêÁ§Æ® Á¤º¸¸¦ ¼¼ÆÃÇÑ´Ù.
	//m_ObjInfo.wThemeIdx			= wThemeIdx ;				// Å×¸¶ ÀÎµ¦½º¸¦ ¼¼ÆÃÇÑ´Ù.
	//m_ObjInfo.mapNum			= mapNum ;					// ¿ÀºêÁ§Æ®¸¦ ¼ÒÈ¯ ÇÒ ¸Ê.
	//m_ObjInfo.byStepIdx			= byStepIdx ;				// ½ºÅÜ ÀÎµ¦½º¸¦ ¼¼ÆÃÇÑ´Ù.
	//m_ObjInfo.dwObjectIdx		= dwObjIdx ;				// ¿ÀºêÁ§Æ® ÀÎµ¦½º.
	//m_ObjInfo.fXpos				= fXpos ;					// ¼ÒÈ¯ ÁÂÇ¥.(X)
	//m_ObjInfo.fZpos				= fZpos ;					// ¼ÒÈ¯ ÁÂÇ¥.(Z)
	//m_ObjInfo.byUseRandomPos	= byUseRandomPos ;			// ¼ÒÈ¯ À§Ä¡·Î ºÎÅÍ ·£´ý À§Ä¡¸¦ »ç¿ëÇÒÁö ¿©ºÎ.
	//m_ObjInfo.byRadius			= byRadius ;				// ¼ÒÈ¯ À§Ä¡·Î ºÎÅÍ ·£´ý À§Ä¡ ¹Ý°æ.
	//m_ObjInfo.byComKind			= byComKind ;				// ¸í·É¾î Å¸ÀÔ ÀÔ·Â.
	//m_ObjInfo.byComIndex		= byComIndex ;				// ¸í·É¾î ÀÎµ¦½º ÀÔ·Â.
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Throw_Error
//	DESC		: The function to process error message.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CSiege_AddObj::Throw_Error(const char* szErr, const char* szCaption)
{
#ifdef _CLIENT_

	#ifdef _GMTOOL_
		MessageBox( NULL, szErr, szCaption, MB_OK) ;
	#endif //_GMTOOL_

#else

		// Check parameter of this function.
		if(!szErr || !szCaption) return ;

		// Check err string size.
		if(strlen(szErr) <= 1)
		{
	#ifdef _USE_NPCRECALL_ERRBOX_
			MessageBox( NULL, "Invalid err string size!!", __FUNCTION__, MB_OK ) ;
	#else
			char tempStr[257] = {0, } ;

			SafeStrCpy( tempStr, __FUNCTION__, 256 ) ;
			strcat( tempStr, " - " ) ;
			strcat( tempStr, "Invalid err string size!!" ) ;
			WriteLog( tempStr ) ;
	#endif // _USE_NPCRECALL_ERRBOX_
		}


		// Check caption string size.
		if(strlen(szCaption) <= 1)
		{
	#ifdef _USE_NPCRECALL_ERRBOX_
			MessageBox( NULL, "Invalid caption string size!!", __FUNCTION__, MB_OK ) ;
	#else
			char tempStr[257] = {0, } ;

			SafeStrCpy( tempStr, __FUNCTION__, 256 ) ;
			strcat( tempStr, " - " ) ;
			strcat( tempStr, "Invalid caption string size!!" ) ;
			WriteLog( tempStr ) ;
	#endif // _USE_NPCRECALL_ERRBOX_
		}

		// Print a err message.
	#ifdef _USE_NPCRECALL_ERRBOX_
		MessageBox( NULL, szErr, szCaption, MB_OK) ;
	#else
		char tempStr[257] = {0, } ;

		SafeStrCpy(tempStr, szCaption, 256) ;
		strcat(tempStr, " - ") ;
		strcat(tempStr, szErr) ;
		WriteLog(tempStr) ;
	#endif // _USE_NPCRECALL_ERRBOX_

#endif //_CLIENT_
}





//-------------------------------------------------------------------------------------------------
//	NAME		: WriteLog
//	DESC		: The function to create a error log for siege recall manager.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CSiege_AddObj::WriteLog(char* pMsg)
{
	SYSTEMTIME time ;
	GetLocalTime(&time) ;

	TCHAR szTime[_MAX_PATH] = {0, } ;
	sprintf(szTime, "%04d-%02d-%02d %02d:%02d:%02d", time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute, time.wSecond) ;

	FILE *fp = fopen("Log/Agent-SiegeRecallMgr.log", "a+") ;
	if (fp)
	{
		fprintf(fp, "%s [%s]\n", pMsg,  szTime) ;
		fclose(fp) ;
	}
}















