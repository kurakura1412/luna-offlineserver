//-------------------------------------------------------------------------------------------------
//	NAME		: CNpcRecallMoveable.cpp
//	DESC		: Implementation part of CNpcRecallMoveable class.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------





//-------------------------------------------------------------------------------------------------
//		Include part.
//-------------------------------------------------------------------------------------------------
#include "stdafx.h"																						// An include file for standard system include files

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "NpcRecallMoveable.h"





//-------------------------------------------------------------------------------------------------
//	NAME		: CNpcRecallMoveable
//	DESC		: »ý¼ºÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
CNpcRecallMoveable::CNpcRecallMoveable(void)
{
	// ¸â¹ö ÇÔ¼ö¸¦ ÃÊ±âÈ­ ÇÑ´Ù.
	m_dwRemainTime		= 0 ;

	m_dwMoveTime		= 0 ;

	m_fMoveXpos			= 0.0f ;
	m_fMoveZpos			= 0.0f ;

	m_ChangeMapNum		= 0 ;

	m_fChangeMapXPos	= 0.0f ;
	m_fChangeMapZPos	= 0.0f ;

	m_byMoved			= FALSE ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: ~CNpcRecallMoveable
//	DESC		: ¼Ò¸êÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
CNpcRecallMoveable::~CNpcRecallMoveable(void)
{
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_RemainTime
//	DESC		: NpcÀÇ ¼ÒÈ¯ÀÌ À¯Áö µÉ ½Ã°£À» ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallMoveable::Set_RemainTime(DWORD dwRemainTime)
{
	// ÀÌµ¿ ÇÒ ½Ã°£º¸´Ù ÀÛÀº ¼öÄ¡°¡ µé¾î¿À´ÂÁö È®ÀÎÇÑ´Ù.
	// 081029 LYW --- NpcRecallMoveable : °ø¼º °ÔÀÌÆ® ¼ÒÈ¯µÇÁö ¾Ê´Â ¹ö±× ¼öÁ¤.
	//if( dwRemainTime <= m_dwMoveTime )
	//{
	//	Throw_Error("Invalid remain time!!", __FUNCTION__) ;
	//	return ;
	//}


	// ¼ÒÈ¯ À¯Áö ½Ã°£À» ¼³Á¤ÇÑ´Ù.
	m_dwRemainTime = dwRemainTime ; 
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_MoveTime
//	DESC		: Npc°¡ ÀÌµ¿ÇÒ X/ZÁÂÇ¥¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallMoveable::Set_MoveTime(DWORD dwMoveTime)
{
	// ¼ÒÈ¯ À¯Áö ½Ã°£ º¸´Ù Å« ¼öÄ¡°¡ µé¾î¿À´ÂÁö È®ÀÎÇÑ´Ù.
	if( dwMoveTime == 0 || dwMoveTime >= m_dwRemainTime )
	{
		Throw_Error("Invalid move time!!", __FUNCTION__) ;
		return ;
	}


	// ÀÌµ¿ ÇÒ ½Ã°£À» ¼³Á¤ÇÑ´Ù.
	m_dwMoveTime = dwMoveTime ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_MoveposX
//	DESC		: Npc°¡ ÀÌµ¿ÇÒ XÁÂÇ¥¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallMoveable::Set_MoveposX(float fXpos)
{
	// ÀÌµ¿ÇÒ ÁÂÇ¥ÀÇ À¯È¿¼ºÀ» È®ÀÎÇÑ´Ù.
	if( fXpos <= 0.0f )
	{
		Throw_Error("Invalid move position!!", __FUNCTION__) ;
		return ;
	}


	// ÀÌµ¿ ÇÒ ÁÂÇ¥¸¦ ¼³Á¤ÇÑ´Ù.
	m_fMoveXpos = fXpos ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_MoveposZ
//	DESC		: Npc°¡ ÀÌµ¿ÇÒ ZÁÂÇ¥¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallMoveable::Set_MoveposZ(float fZpos)
{
	// ÀÌµ¿ÇÒ ÁÂÇ¥ÀÇ À¯È¿¼ºÀ» È®ÀÎÇÑ´Ù.
	if( fZpos <= 0.0f )
	{
		Throw_Error("Invalid move position!!", __FUNCTION__) ;
		return ;
	}


	// ÀÌµ¿ ÇÒ ÁÂÇ¥¸¦ ¼³Á¤ÇÑ´Ù.
	m_fMoveZpos = fZpos ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: IsMoveable
//	DESC		: ÀÌµ¿ÀÌ °¡´É ÇÑ »óÅÂÀÎÁö ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
BYTE CNpcRecallMoveable::IsMoveable(DWORD dwCurTime)
{
	// ÀÌµ¿ÀÌ °¡´ÉÇÑ ½Ã°£ÀÌ Áö³µ´ÂÁö È®ÀÎÇÑ´Ù.
	DWORD dwCheckTime = dwCurTime - Get_RecallTime() ;


	// °á°ú¸¦ return ÇÑ´Ù.
	if(dwCheckTime >= m_dwMoveTime) return TRUE ;
	else return FALSE ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: IsEndRemainTime
//	DESC		: ¼ÒÈ¯ À¯Áö ½Ã°£ÀÌ Áö³µ´ÂÁö ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
BYTE CNpcRecallMoveable::IsEndRemainTime(DWORD dwCurTime) 
{
	// ¼ÒÈ¯ À¯Áö ½Ã°£ÀÌ Áö³µ´ÂÁö È®ÀÎÇÑ´Ù.
	DWORD dwCheckTime = dwCurTime - Get_RecallTime() ;


	// °á°ú¸¦ return ÇÑ´Ù.
	if( dwCheckTime >= m_dwRemainTime ) return TRUE ;
	else return FALSE ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_ChangeMapNum
//	DESC		: npc¸¦ ÅëÇØ ÀÌµ¿ÇÒ ¸ÊÀÇ ¸Ê ¹øÈ£¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 21, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallMoveable::Set_ChangeMapNum(MAPTYPE mapNum) 
{
	// ÀÎÀÚ·Î ³Ñ¾î¿À´Â ¸Ê ¹øÈ£¸¦ È®ÀÎÇÑ´Ù.
	if( mapNum == 0 )
	{
		Throw_Error("Invalid map number!!", __FUNCTION__) ;
		return ;
	}


	// ¼ÒÈ¯ ÇÒ ¸Ê ¹øÈ£¸¦ ¼³Á¤ÇÑ´Ù.
	m_ChangeMapNum = mapNum ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_ChangeMapXPos
//	DESC		: npc¸¦ ÅëÇØ ÀÌµ¿ÇÒ ¸ÊÀÇ xÁÂÇ¥¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 21, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallMoveable::Set_ChangeMapXPos(float fXpos) 
{
	// ÀÎÀÚ·Î ³Ò¾î¿À´Â ¼ÒÈ¯ ÁÂÇ¥¸¦ È®ÀÎÇÑ´Ù.
	if( fXpos <= 0.0f )
	{
		Throw_Error("Invalid recall position!!", __FUNCTION__) ;
		return ;
	}


	// ¼ÒÈ¯ ÇÒ ÁÂÇ¥¸¦ ¼³Á¤ÇÑ´Ù.
	m_fChangeMapXPos = fXpos ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_ChangeMapZPos
//	DESC		: npc¸¦ ÅëÇØ ÀÌµ¿ÇÒ ¸ÊÀÇ zÁÂÇ¥¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 21, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallMoveable::Set_ChangeMapZPos(float fZpos) 
{
	// ÀÎÀÚ·Î ³Ò¾î¿À´Â ¼ÒÈ¯ ÁÂÇ¥¸¦ È®ÀÎÇÑ´Ù.
	if( fZpos <= 0.0f )
	{
		Throw_Error("Invalid recall position!!", __FUNCTION__) ;
		return ;
	}


	// ¼ÒÈ¯ ÇÒ ÁÂÇ¥¸¦ ¼³Á¤ÇÑ´Ù.
	m_fChangeMapZPos = fZpos ;
}













