//-------------------------------------------------------------------------------------------------
//	NAME		: CNpcRecallBase.cpp
//	DESC		: Implementation part of CNpcRecallCondition class.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------





//-------------------------------------------------------------------------------------------------
//		Include part.
//-------------------------------------------------------------------------------------------------
#include "stdafx.h"																						// An include file for standard system include files

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "MHFile.h"

#include "NpcRecallBase.h"





//-------------------------------------------------------------------------------------------------
//	NAME		: CNpcRecallBase
//	DESC		: »ý¼ºÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
CNpcRecallBase::CNpcRecallBase(void)
{
	// ¸â¹ö º¯¼ö ÃÊ±âÈ­.
	m_byRecallCodition = eNR_None ;

	m_dwNpcIdx			= 0 ;
	m_wNpcKind			= 0 ;

	m_RecallMapNum		= 0 ;

	m_fXpos				= 0.0f ;
	m_fZpos				= 0.0f ;

	m_byActive			= FALSE ;

	m_dwCreatedIdx		= 0 ;

	m_byReadyToDelete	= FALSE ;

	m_dwRecallTime		= 0 ;

	m_wRecallFailedMsg	= 0 ;

	m_wDir				= 0 ;

	m_dwNpcRecallIdx	= 0 ;

	m_wRecalledChenel	= 0 ;

	ZeroMemory( this, sizeof(char) * ( MAX_NAME_LENGTH+1 ) );

	m_dwParentNpcIdx	= 0 ;
	
	m_byParentType		= eParentNpcType_UnKnown ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: ~CNpcRecallBase
//	DESC		: ¼Ò¸êÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
CNpcRecallBase::~CNpcRecallBase(void)
{
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_RecallCondition
//	DESC		: ¼ÒÈ¯ Á¶°ÇÀ» ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallBase::Set_RecallCondition(BYTE byCondition)
{
	// ÀÎÀÚ·Î ³Ñ¾î¿Â »óÅÂ À¯È¿¸¦ Ã¼Å©ÇÑ´Ù.
	if( byCondition == eNR_None || byCondition >= eNR_NpcRecall_Max )
	{
		Throw_Error("Invalid recall type!!", __FUNCTION__) ;
		return ;
	}


	// ¼ÒÈ¯ Á¶°ÇÀ» ¼³Á¤ÇÑ´Ù.
	m_byRecallCodition = byCondition ;
}


void CNpcRecallBase::Set_NpcRecallIndex(DWORD dwNpcRecallIdx)
{
	if( dwNpcRecallIdx == 0 )
	{
		Throw_Error("Invalid NpcRecall Index!!", __FUNCTION__) ;
		return ;
	}

	m_dwNpcRecallIdx = dwNpcRecallIdx ;
}


//-------------------------------------------------------------------------------------------------
//	NAME		: Set_NpcIndex
//	DESC		: Npc ÀÎµ¦½º¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallBase::Set_NpcIndex(DWORD dwNpcIdx) 
{
	// ÀÎÀÚ·Î ³Ñ¾î¿À´Â npc ÀÎµ¦½º Á¦ÇÑÀ» Ã¼Å©ÇÑ´Ù.
	if( dwNpcIdx >= 65000 )
	{
		Throw_Error("Invalid Npc index!!", __FUNCTION__) ;
		return ;
	}


	// Npc ÀÎµ¦½º¸¦ ¼³Á¤ÇÑ´Ù.
	m_dwNpcIdx = dwNpcIdx ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_NpcKind
//	DESC		: Npc Á¾·ù¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 21, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallBase::Set_NpcKind(WORD wNpcKind) 
{
	// ÀÎÀÚ·Î ³Ñ¾î¿À´Â npc ÀÎµ¦½º Á¦ÇÑÀ» Ã¼Å©ÇÑ´Ù.
	if( wNpcKind >= 65000 || wNpcKind == 0 )
	{
		Throw_Error("Invalid Npc kind!!", __FUNCTION__) ;
		return ;
	}


	// Npc ÀÎµ¦½º¸¦ ¼³Á¤ÇÑ´Ù.
	m_wNpcKind = wNpcKind ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_RecallMap
//	DESC		: NpcÀÇ ¼ÒÈ¯ ¸Ê ¹øÈ£¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallBase::Set_RecallMap(MAPTYPE mapNum) 
{
	// ÀÎÀÚ·Î ³Ñ¾î¿À´Â ¸Ê ¹øÈ£¸¦ È®ÀÎÇÑ´Ù.
	if( mapNum == 0 )
	{
		Throw_Error("Invalid map number!!", __FUNCTION__) ;
		return ;
	}


	// ¼ÒÈ¯ ÇÒ ¸Ê ¹øÈ£¸¦ ¼³Á¤ÇÑ´Ù.
	m_RecallMapNum = mapNum ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_RecallPosX
//	DESC		: NpcÀÇ ¼ÒÈ¯ XÁÂÇ¥¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallBase::Set_RecallPosX(float fXpos) 
{
	// ÀÎÀÚ·Î ³Ò¾î¿À´Â ¼ÒÈ¯ ÁÂÇ¥¸¦ È®ÀÎÇÑ´Ù.
	if( fXpos <= 0.0f )
	{
		Throw_Error("Invalid recall position!!", __FUNCTION__) ;
		return ;
	}


	// ¼ÒÈ¯ ÇÒ ÁÂÇ¥¸¦ ¼³Á¤ÇÑ´Ù.
	m_fXpos = fXpos ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Set_RecallPosZ
//	DESC		: NpcÀÇ ¼ÒÈ¯ ZÁÂÇ¥¸¦ ¼³Á¤ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallBase::Set_RecallPosZ(float fZpos) 
{
	// ÀÎÀÚ·Î ³Ò¾î¿À´Â ¼ÒÈ¯ ÁÂÇ¥¸¦ È®ÀÎÇÑ´Ù.
	if( fZpos <= 0.0f )
	{
		Throw_Error("Invalid recall position!!", __FUNCTION__) ;
		return ;
	}


	// ¼ÒÈ¯ ÇÒ ÁÂÇ¥¸¦ ¼³Á¤ÇÑ´Ù.
	m_fZpos = fZpos ;
}

void CNpcRecallBase::Get_RecallPos(VECTOR3* vOutPut)
{
	if( !vOutPut )
		return; 

	vOutPut->x = m_fXpos ;
	vOutPut->z = m_fZpos;
}

void CNpcRecallBase::Set_RecallDir(WORD wDir) 
{
	// ÀÎÀÚ·Î ³Ò¾î¿À´Â ¼ÒÈ¯ ÁÂÇ¥¸¦ È®ÀÎÇÑ´Ù.
	if( wDir > 360 )
	{
		Throw_Error("Invalid recall Dir!!", __FUNCTION__) ;
		return ;
	}


	// ¼ÒÈ¯ ÇÒ ÁÂÇ¥¸¦ ¼³Á¤ÇÑ´Ù.
	m_wDir = wDir ;

}

void CNpcRecallBase::Set_NpcName(char* pNpcName) 
{
	SafeStrCpy(m_NpcName, pNpcName, MAX_NPC_NAME_LENGTH+1); 
}

void CNpcRecallBase::Set_RecalledChenel(WORD wChenel )
{
	if( wChenel == 0 )
	{
		Throw_Error("Invalid RecalledChenel Index!!", __FUNCTION__) ;
		return ;
	}

	m_wRecalledChenel = wChenel ;
}

void CNpcRecallBase::Set_ParentNpcIndex(DWORD dwIndex) 
{
	// ÀÎÀÚ·Î ³Ò¾î¿À´Â ¼ÒÈ¯ ÁÂÇ¥¸¦ È®ÀÎÇÑ´Ù.
	if( dwIndex == 0 )
	{
		Throw_Error("Invalid ParentNpc Index!!", __FUNCTION__) ;
		return ;
	}

	m_dwParentNpcIdx = dwIndex ;
}

void CNpcRecallBase::Set_ParentNpcType(BYTE byType) 
{
	// ÀÎÀÚ·Î ³Ò¾î¿À´Â ¼ÒÈ¯ ÁÂÇ¥¸¦ È®ÀÎÇÑ´Ù.
	if( byType == eParentNpcType_UnKnown || byType >= eParentNpcType_Max )
	{
		Throw_Error("Invalid ParentNpc Type!!", __FUNCTION__) ;
		return ;
	}

	m_byParentType = byType ;
}


//-------------------------------------------------------------------------------------------------
//	NAME		: Throw_Error
//	DESC		: The function to process error message.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallBase::Throw_Error(const char* szErr, const char* szCaption)
{
#ifdef _CLIENT_

	#ifdef _GMTOOL_
		MessageBox( NULL, szErr, szCaption, MB_OK) ;
	#endif //_GMTOOL_

#else

		// Check parameter of this function.
		if(!szErr || !szCaption) return ;

		// Check err string size.
		if(strlen(szErr) <= 1)
		{
	#ifdef _USE_NPCRECALL_ERRBOX_
			MessageBox( NULL, "Invalid err string size!!", __FUNCTION__, MB_OK ) ;
	#else
			char tempStr[257] = {0, } ;

			SafeStrCpy( tempStr, __FUNCTION__, 256 ) ;
			strcat( tempStr, " - " ) ;
			strcat( tempStr, "Invalid err string size!!" ) ;
			WriteLog( tempStr ) ;
	#endif // _USE_NPCRECALL_ERRBOX_
		}


		// Check caption string size.
		if(strlen(szCaption) <= 1)
		{
	#ifdef _USE_NPCRECALL_ERRBOX_
			MessageBox( NULL, "Invalid caption string size!!", __FUNCTION__, MB_OK ) ;
	#else
			char tempStr[257] = {0, } ;

			SafeStrCpy( tempStr, __FUNCTION__, 256 ) ;
			strcat( tempStr, " - " ) ;
			strcat( tempStr, "Invalid caption string size!!" ) ;
			WriteLog( tempStr ) ;
	#endif // _USE_NPCRECALL_ERRBOX_
		}

		// Print a err message.
	#ifdef _USE_NPCRECALL_ERRBOX_
		MessageBox( NULL, szErr, szCaption, MB_OK) ;
	#else
		char tempStr[257] = {0, } ;

		SafeStrCpy(tempStr, szCaption, 256) ;
		strcat(tempStr, " - ") ;
		strcat(tempStr, szErr) ;
		WriteLog(tempStr) ;
	#endif // _USE_NPCRECALL_ERRBOX_

#endif //_CLIENT_
}





//-------------------------------------------------------------------------------------------------
//	NAME		: WriteLog
//	DESC		: The function to create a error log for siege recall manager.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallBase::WriteLog(char* pMsg)
{
	SYSTEMTIME time ;
	GetLocalTime(&time) ;

	TCHAR szTime[_MAX_PATH] = {0, } ;
	sprintf(szTime, "%04d-%02d-%02d %02d:%02d:%02d", time.wYear, time.wMonth, time.wDay, time.wHour, time.wMinute, time.wSecond) ;

	FILE *fp = NULL ;
#ifdef _AGENTSERVER
	fp = fopen("Log/AgentServer-SiegeRecallMgr.log", "a+") ;
#elif _MAPSERVER_
	fp = fopen("Log/MapServer-SiegeRecallMgr.log", "a+") ;
#endif // _AGENTSERVER_

	if (fp)
	{
		fprintf(fp, "%s [%s]\n", pMsg,  szTime) ; 
		fclose(fp) ;
	}
}




























