#ifndef __NPCRECALLREMAINTIME_H__INCLUDED
#define __NPCRECALLREMAINTIME_H__INCLUDED
#pragma once
//-------------------------------------------------------------------------------------------------
//	NAME		: CNpcRecallRemainTime.h
//	DESC		: ÇÑ¹ø ¼ÒÈ¯ µÈ ÈÄ, ÀÏÁ¤ ½Ã°£ÀÌ Áö³ª¸é, ½º½º·Î ¼Ò¸êµÇ´Â npc Å¬·¡½º.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------





//-------------------------------------------------------------------------------------------------
//		Include part.
//-------------------------------------------------------------------------------------------------
#include "NpcRecallBase.h"





//-------------------------------------------------------------------------------------------------
//		Define some macroinstruction.
//-------------------------------------------------------------------------------------------------





//-------------------------------------------------------------------------------------------------
//		The class CNpcRecallRemainTime.
//-------------------------------------------------------------------------------------------------
class CNpcRecallRemainTime : public CNpcRecallBase
{
	DWORD	m_dwRemainTime ;								// ¼ÒÈ¯ÀÌ À¯Áö µÉ ½Ã°£.
	
public:
	CNpcRecallRemainTime(void);
	virtual ~CNpcRecallRemainTime(void);
	// ¼ÒÈ¯ÀÌ À¯Áö µÉ ½Ã°£À» ¼³Á¤/¹ÝÈ¯ ÇÏ´Â ÇÔ¼ö.
	void Set_RemainTime(DWORD dwRemainTime) { m_dwRemainTime = dwRemainTime ; }
	DWORD Get_RemainTime() { return m_dwRemainTime ; }


	// ¼ÒÈ¯ÀÌ À¯Áö µÉ ½Ã°£ÀÌ Áö³µ´ÂÁö ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
	BYTE IsEndRemainTime(DWORD dwCurTime) ;


	// ¼ÒÈ¯ÀÌ À¯Áö µÉ ½Ã°£À» ÃÊ±âÈ­ ÇÏ´Â ÇÔ¼ö.
	void ClearRemainTime() { m_dwRemainTime = 0 ; }
};

#endif // __NPCRECALLREMAINTIME_H__INCLUDED
