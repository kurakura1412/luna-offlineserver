//-------------------------------------------------------------------------------------------------
//	NAME		: CNpcRecallSelf.cpp
//	DESC		: Implementation part of CNpcRecallSelf class.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------





//-------------------------------------------------------------------------------------------------
//		Include part.
//-------------------------------------------------------------------------------------------------
#include "stdafx.h"																						// An include file for standard system include files

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "NpcRecallSelf.h"





//-------------------------------------------------------------------------------------------------
//	NAME		: CNpcRecallSelf
//	DESC		: »ý¼ºÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
CNpcRecallSelf::CNpcRecallSelf(void)
{
	Set_ParentNpcType( eParentNpcType_OnlySelf ) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: ~CNpcRecallSelf
//	DESC		: ¼Ò¸êÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
CNpcRecallSelf::~CNpcRecallSelf(void)
{
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Insert_TimeTable
//	DESC		: Npc ¼ÒÈ¯/¼Ò¸ê ½Ã°£À» ´ã°í ÀÖ´Â Á¤º¸ Ãß°¡ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
void CNpcRecallSelf::Insert_TimeTable(st_RECALL_TIMETABLE* pInfo)
{
	// ÀÎÀÚ·Î ³Ñ¾î¿Â Á¤º¸ À¯È¿ È®ÀÎ.
	if( !pInfo )
	{
		Throw_Error("Invalid parameter!!", __FUNCTION__) ;
		return ;
	}


	// µ¿ÀÏ ÀÎµ¦½º Å×ÀÌºíÀÌ ÀÖ´ÂÁö È®ÀÎÇÑ´Ù.
	MAP_TIMETABLE::iterator it ;
	for( it = m_mTimeTable.begin() ; it != m_mTimeTable.end() ; ++it )
	{
		if( it->second.byTableIdx == pInfo->byTableIdx )
		{
			Throw_Error("Failed to insert time table!!\\[Same time table index]", __FUNCTION__) ;
			return ;
		}
	}


	// Å×ÀÌºíÀ» Ãß°¡ÇÑ´Ù.
	m_mTimeTable.insert( std::make_pair( pInfo->byTableIdx, *pInfo ) ) ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: Get_TimeTable
//	DESC		: Npc ¼ÒÈ¯/¼Ò¸ê ½Ã°£À» ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
st_RECALL_TIMETABLE* CNpcRecallSelf::Get_TimeTable(BYTE byIdx)
{
	// ÀÏÄ¡ÇÏ´Â Å×ÀÌºíÀÌ ÀÖ´ÂÁö È®ÀÎÇÑ´Ù.
	MAP_TIMETABLE::iterator it ;
	for( it = m_mTimeTable.begin() ; it != m_mTimeTable.end() ; ++it )
	{
		if( it->second.byTableIdx == byIdx )
		{
			return &it->second ;
		}
	}


	// nullÀ» return.
	return NULL ;
}

void CNpcRecallSelf::Copy(CNpcRecallSelf* pSrc)
{
	memcpy(this , pSrc , sizeof( CNpcRecallBase )  ) ;

	MAP_TIMETABLE::iterator it ;
	for( it = pSrc->m_mTimeTable.begin() ; it != pSrc->m_mTimeTable.end() ; ++it )
	{
		this->m_mTimeTable.insert( std::make_pair( it->second.byTableIdx, it->second ) ) ;
	}
}















