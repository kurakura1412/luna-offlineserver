//-------------------------------------------------------------------------------------------------
//	NAME		: CNpcRecallRemainTime.cpp
//	DESC		: Implementation part of CNpcRecallRemainTime class.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------





//-------------------------------------------------------------------------------------------------
//		Include part.
//-------------------------------------------------------------------------------------------------
#include "stdafx.h"																						// An include file for standard system include files

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "NpcRecallRemainTime.h"





//-------------------------------------------------------------------------------------------------
//	NAME		: CNpcRecallRemainTime
//	DESC		: »ý¼ºÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
CNpcRecallRemainTime::CNpcRecallRemainTime(void)
{
	// ¸â¹ö º¯¼ö¸¦ ÃÊ±âÈ­ ÇÑ´Ù.
	m_dwRemainTime	= 0 ;
}





//-------------------------------------------------------------------------------------------------
//	NAME		: ~CNpcRecallRemainTime
//	DESC		: ¼Ò¸êÀÚ ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
CNpcRecallRemainTime::~CNpcRecallRemainTime(void)
{
}





//-------------------------------------------------------------------------------------------------
//	NAME		: IsEndRemainTime
//	DESC		: ¼ÒÈ¯ÀÌ À¯Áö µÉ ½Ã°£ÀÌ Áö³µ´ÂÁö ¹ÝÈ¯ÇÏ´Â ÇÔ¼ö.
//	PROGRAMMER	: Yongs Lee
//	DATE		: August 18, 2008
//-------------------------------------------------------------------------------------------------
BYTE CNpcRecallRemainTime::IsEndRemainTime(DWORD dwCurTime)
{
	// ¼ÒÈ¯ À¯Áö ½Ã°£ÀÌ Áö³µ´ÂÁö È®ÀÎÇÑ´Ù.
	DWORD dwCheckTime = dwCurTime - Get_RecallTime() ;

	if( dwCheckTime > m_dwRemainTime ) return TRUE ;
	else return FALSE ;

	// 1ºÐ ÁÖ±â·Î Remain TimeÀ» DB¿¡ ¾÷µ¥ÀÌÆ® ÇÒ±î?
}















