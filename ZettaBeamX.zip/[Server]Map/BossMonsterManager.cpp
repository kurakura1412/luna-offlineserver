// BossMonsterManager.cpp: implementation of the CBossMonsterManager class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "BossMonsterManager.h"
#include "BossMonster.h"
#include "MHFile.h"
#include "BossMonsterInfo.h"
#include "SummonInfo.h"
#include "AIGroupManager.h"
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


#define MONSTERKIND		"$MONSTERKIND"
	#define REGENTIME		"*REGENTIME"
	#define	SUMMONFILE		"*SUMMONFILENUM"

	#define FIRSTATTACK		"*FIRSTATTACK"
	#define ATTACK			"$ATTACK"
		#define NEXTATTACK	"#NEXTATTACK"

	#define MAXSTATE		"*MAXSTATE"
	#define STATE			"$STATE"
		#define STATECOUNT		"#COUNT"
		#define LIFELESSTHAN	"#LIFELESSTHAN"
		#define ACTION_RECOVER	"#ACTION_RECOVER"
		#define ACTION_SUMMON	"#ACTION_SUMMON"
	
	#define DIESUMMON	"*DIESUMMON"
	#define UNGIVALUE	"*UNGIVALUE"
	#define CHANGETARGETRANGE "*CHANGETARGETRANGE"
	
	/// 06. 08. 2Â÷ º¸½º - ÀÌ¿µÁØ
	/// Å¸°ÙÆÃ ¹æ½Ä
	#define TARGETINGTYPE "*TARGETINGTYPE"

	/// 06. 09. 2Â÷ º¸½º - ÀÌ¿µÁØ
	/// ¼Ò¸ê½Ã°£
	#define DELETETIME "*DELETETIME"


#define MONSTERGROUP		"$GROUP"

CBossMonsterManager::CBossMonsterManager()
{
	Init();	
}

CBossMonsterManager::~CBossMonsterManager()
{
	Release();
}

void CBossMonsterManager::Init()
{
	m_BossMonsterInfoTable.Initialize(2);
	m_SummonInfoTable.Initialize(2);
}

void CBossMonsterManager::Release()
{	
	CBossMonsterInfo* pBossInfo;
	m_BossMonsterInfoTable.SetPositionHead();	
	while((pBossInfo = m_BossMonsterInfoTable.GetData())!= NULL)
	{
		pBossInfo->Release();
		SAFE_DELETE(pBossInfo);
	}
	m_BossMonsterInfoTable.RemoveAll();	

	CSummonInfo* pSummonInfo;
	m_SummonInfoTable.SetPositionHead();
	while((pSummonInfo = m_SummonInfoTable.GetData())!= NULL)
	{
		pSummonInfo->Release();
		SAFE_DELETE(pSummonInfo);
	}
	m_SummonInfoTable.RemoveAll();

	m_BossList.RemoveAll();
}

void CBossMonsterManager::LoadBossMonsterInfoList()
{
	///////////////////////////////////////////////
	//ex)	1	resource/BossMonster1
	//		2	resource/BossMonster2
	///////////////////////////////////////////////
	CMHFile file; 
	file.Init("System/Resource/BossMonsterfileList.bin", "rb");
	if(file.IsInited() == FALSE)
	{
		//MessageBox(0, "BossMonsterfileList.bin is not found!", 0, MB_OK);
		return;
	}
	char BossFilename[256];
	while(1)
	{
		if(file.IsEOF() != FALSE)
			break;
		file.GetInt();
		file.GetString(BossFilename);
		LoadBossMonster(BossFilename);
	}
	
	file.Release();
}

void CBossMonsterManager::LoadBossMonster(char* BossFile)
{
	CMHFile file;
	char tempBuf[256] = {0};
	char bossfilename[256] = {0};
	WORD MonsterKind = 0;
	int MaxStateNum = 0;
	DWORD CurAttackIdx = 0;

	sprintf(bossfilename,"%s.bin",BossFile);
	if(!file.Init(bossfilename,"rb"))
		return ;
	
	CBossMonsterInfo * pInfo = new CBossMonsterInfo;
	while(1)
	{
		file.GetString(tempBuf);
		if(file.IsEOF())
			break;
		if((tempBuf[0] == '}') || (tempBuf[0] == '{'))
			continue;
		else if(tempBuf[0] == '@')
		{
			file.GetLine(tempBuf, 256);
			continue;
		}
		
		CMD_ST(tempBuf)
		CMD_CS(MONSTERKIND)
		{
			MonsterKind = file.GetWord();
			pInfo->SetMonsterKind(MonsterKind);
		}
		CMD_CS(REGENTIME)
		{
			DWORD MinTime = file.GetDword();
			DWORD MaxTime = file.GetDword();
			pInfo->SetRegenDelayTime(MinTime, MaxTime);
		}
		CMD_CS(MAXSTATE)
		{
			MaxStateNum = file.GetInt();
			pInfo->SetMaxStateNum((BYTE)MaxStateNum);
		}
		CMD_CS(STATE)
		{
			int num = file.GetInt() - 1;
			if((num < 0) || (num > MaxStateNum-1))
			{
				ASSERTMSG(0, "BossInfo Error! State Num is abnormal");
				return;
			}
			LoadEventState(num, &file, pInfo->GetEventStateInfo());
		}
		CMD_CS(FIRSTATTACK)
		{
			//pInfo->SetFirstAttackIdx(file.GetWord());
			pInfo->SetFirstAttackIdx(file.GetDword());
		}
		CMD_CS(ATTACK)
		{
			NEXTATTACKINFO* pNewNextAttackInfo = new NEXTATTACKINFO;
			CurAttackIdx = file.GetDword();
			LoadAttackInfo(pNewNextAttackInfo,CurAttackIdx, &file);
			pInfo->AddAttackInfo(CurAttackIdx, pNewNextAttackInfo);
		}
		CMD_CS(SUMMONFILE)
			// summon init 
			pInfo->SetSummonFileNum(file.GetWord());
		CMD_CS(DIESUMMON)
			pInfo->SetDieGroupID(file.GetWord());
		CMD_CS(UNGIVALUE)
			pInfo->SetBossUngijosik(file.GetDword(), file.GetDword(), file.GetFloat());
		CMD_CS(CHANGETARGETRANGE)
			pInfo->SetChangeTargetRange(file.GetFloat(), file.GetFloat());
		///////////////////////////////////////////////////////////
		/// 06. 08. 2Â÷ º¸½º - ÀÌ¿µÁØ
		/// Å¸°ÙÆÃ ¹æ½Ä
		/// 0: ±âÁ¸ ¹æ½Ä 1: ¸Å °ø°Ý½Ã ·£´ýÀ¸·Î Å¸°Ù º¯°æ
		CMD_CS( TARGETINGTYPE )
			pInfo->SetTargetingType( file.GetWord() );
		///////////////////////////////////////////////////////////
		/// 06. 09. 2Â÷ º¸½º - ÀÌ¿µÁØ
		/// ¼Ò¸ê½Ã°£
		CMD_CS( DELETETIME )
			pInfo->SetDeleteTime( file.GetDword() * 60000 );
		CMD_EN
	}

	file.Release();
	
	m_BossMonsterInfoTable.Add(pInfo, pInfo->GetMonsterKind());
}

void CBossMonsterManager::LoadEventState(int num, CMHFile * fp, BOSSEVENTSTATE* pRtBossState)
{
	char buf[256];
	while(1)
	{
		fp->GetString(buf);
		if(buf[0] == '{')
			continue;
		else if(buf[0] == '}')
			break;
		else if(buf[0] == '@')
			fp->GetLineX(buf, 256);
		
		CMD_ST(buf)
		CMD_CS(LIFELESSTHAN)
			pRtBossState[num].Condition = eBOSSCONDITION_LIFE;
			pRtBossState[num].ConditionValue = fp->GetWord();
		CMD_CS(ACTION_RECOVER)
			pRtBossState[num].Action = eBOSSACTION_RECOVER;
			pRtBossState[num].ActionValue = fp->GetWord();
		CMD_CS(ACTION_SUMMON)
			pRtBossState[num].Action = eBOSSACTION_SUMMON;
			pRtBossState[num].ActionValue = fp->GetWord();
		CMD_CS(STATECOUNT)
			pRtBossState[num].Count = fp->GetByte();

		CMD_EN
	}
	
}


void CBossMonsterManager::LoadAttackInfo(NEXTATTACKINFO* pRtNextAttack, DWORD CurAttackIdx, CMHFile * fp)
{
	char buf[256];
	while(1)
	{
		fp->GetString(buf);
		if(buf[0] == '{')
			continue;
		else if(buf[0] == '}')
			break;
		else if(buf[0] == '@')
			fp->GetLineX(buf, 256);
		
		
		CMD_ST(buf)
		CMD_CS(NEXTATTACK)
		{
			pRtNextAttack->AddNextAttack(fp->GetWord(), fp->GetDword());
		}		
		CMD_EN
	}
}

void CBossMonsterManager::SetBossInfo(CBossMonster* pBossMonster)
{
	CBossMonsterInfo * pBossInfo = m_BossMonsterInfoTable.GetData(pBossMonster->GetMonsterKind());
	if(pBossInfo)
	{
		pBossMonster->SetBossInfo(pBossInfo);
		return;
	}
	ASSERT(0);
}

//////////////////////////////////////////////////////////////////////////
//summon
void CBossMonsterManager::LoadSummonInfoList()
{
	CMHFile file;

	file.Init("System/Resource/SummonList.bin", "rb");
	if(!file.IsInited())
	{
		ASSERTMSG(0, "SummonList.bin is not found!");
		return;
	}
	
	int num;
	char summonfile[256];
	while(1)
	{
		if(file.IsEOF())
			break;
		num = file.GetInt();
		file.GetString(summonfile);

		LoadSummonInfo(num, summonfile);
	}
	
	file.Release();
}

void CBossMonsterManager::LoadSummonInfo(int num, char* summonFile)
{
	CMHFile file;
	char summonfilename[256];
	sprintf(summonfilename,"%s.bin",summonFile);
	if(!file.Init(summonfilename,"rb"))
		return ;

	char tempBuf[256];
	CSummonInfo * pSummonInfo = new CSummonInfo;

	while(1)
	{
		file.GetString(tempBuf);
		if(file.IsEOF())
			break;
		if((tempBuf[0] == '}') || (tempBuf[0] == '{'))
			continue;
		else if(tempBuf[0] == '@')
		{
			file.GetLine(tempBuf, 256);
			continue;
		}
		
		CMD_ST(tempBuf)
		CMD_CS(MONSTERGROUP)
		pSummonInfo->GroupInit(&file);
		CMD_EN
	}
	
	m_SummonInfoTable.Add(pSummonInfo , num);
	file.Release();
}

CSummonInfo* CBossMonsterManager::GetSummonInfo(int num)
{
	CSummonInfo* pInfo;
	pInfo = m_SummonInfoTable.GetData(num);
	return pInfo;
}

void CBossMonsterManager::RegenGroup(CBossMonster* pBoss, WORD SummonFileNum, int GroupNum)
{
	CSummonInfo * pInfo = m_SummonInfoTable.GetData(SummonFileNum);
	if(!pInfo)
	{
		ASSERTMSG(0, "No SummonInfo");
		return;
	}
	pInfo->RegenGroup(pBoss, GroupNum);
}

// 080204 KTH -- dwRegenMiliSecond Ãß°¡
void CBossMonsterManager::SetBossRandRegenChannel(WORD MonsterKind, DWORD GridID, WORD MonsterGroupNum, DWORD dwRegenMiliSecond )
{
	CBossMonsterInfo* pBossInfo = m_BossMonsterInfoTable.GetData(MonsterKind);
	if(pBossInfo == 0)
	{
		ASSERTMSG(0, "NO Boss Info.");
		return;
	}
	
	DWORD delaytime;
	
	// 080204 KTH -- dwRegenMiliSecond°¡ 0ÀÌ ¾Æ´Ò °æ¿ì dealytime¿¡ ¸®Á¨ ½Ã°£À» ¼ÂÆÃÇÏ¿© ÁØ´Ù.
	if( dwRegenMiliSecond )
	{
		delaytime = dwRegenMiliSecond;
	}
	else
	{
		delaytime = pBossInfo->CalcRegenDelayTime();
	}
	CAIGroup* pAIGroup = GROUPMGR->GetGroup(MonsterGroupNum, GridID);
	
	if(!pAIGroup) return;
	
	pAIGroup->SetRegenDelayTime(delaytime);
}

void CBossMonsterManager::UserLogOut(DWORD CharacterID, DWORD GridID)
{	
	PTRLISTSEARCHSTART(m_BossList, CBossMonster*, pBoss)
		if( pBoss )
		{
			if(pBoss->GetGridID() == GridID)
				pBoss->DistributeDeleteDamagedPlayer(CharacterID);
		}
	PTRLISTSEARCHEND
}

void CBossMonsterManager::AddBossMonster(CBossMonster* pBoss)
{
	m_BossList.AddTail(pBoss);
}

void CBossMonsterManager::DeleteBossMonster(CBossMonster* pBoss)
{
	m_BossList.Remove((void*)pBoss);
}
