#include "StdAfx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "AIGroupManager.h"

CAIGroupManager::CAIGroupManager()
{}

CAIGroupManager::~CAIGroupManager()
{}

CAIGroup& CAIGroupManager::AddGroup(DWORD groupIndex, DWORD gridIndex)
{ 
	mGroupContainer.erase( 
		GroupIndex(groupIndex, gridIndex));

	CAIGroup& group = mGroupContainer[GroupIndex(groupIndex, gridIndex)];
	group.SetGroupID(groupIndex);
	group.SetGridID(gridIndex);

	return group;
}

CAIGroup* CAIGroupManager::GetGroup(DWORD dwGroupID, DWORD dwGridID)
{
	const GroupContainer::iterator iter = mGroupContainer.find(GroupIndex(dwGroupID, dwGridID));

	return mGroupContainer.end() == iter ? 0 : &(iter->second);
}

void CAIGroupManager::RegenProcess()
{
	for(GroupContainer::iterator iter = mGroupContainer.begin(),
		itend = mGroupContainer.end()
	;		itend != iter;
		++iter)
	{
		CAIGroup& group = iter->second;
		group.RegenProcess();
	}
}

const VECTOR3& CAIGroupManager::GetDomain(DWORD groupIndex, DWORD gridIndex, DWORD regenIndex)
{
	static const VECTOR3 emptyPosition = {0};
	CAIGroup* const aiGroup = GetGroup(
		groupIndex,
		gridIndex);

	if(0 == aiGroup)
	{
		return emptyPosition;
	}

	CAIGroup::Parameter* const parameter = aiGroup->GetRegenObject(regenIndex);

	if(0 == parameter)
	{
		return emptyPosition;
	}

	return parameter->vPos;
}
#ifdef _MYLUNA_
void CAIGroupManager::ReleaseME()
{
	mGroupContainer.clear();
}

void CAIGroupManager::InitME()
{
}
#endif