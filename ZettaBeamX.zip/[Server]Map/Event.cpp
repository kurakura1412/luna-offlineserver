#include "StdAfx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "Event.h"

CEvent::CEvent( CEvent::Type type, eStatusKind targetStatus ) :
mType( type ),
mTargetStatus( targetStatus )
{}

// 080616 LUJ, ´Ù¸¥ ¿ÀºêÁ§Æ®¿¡°Ô ÇÇÇØ¸¦ ÁáÀ» ¶§ ¹ßµ¿µÇ´Â ÀÌº¥Æ®
CGiveDamageEvent::CGiveDamageEvent( CObject* target, const RESULTINFO& result ) :
CEvent( TypeGiveDamage, eStatusKind_None ),
mResult( result ),
mTarget( target )
{}

CGiveDamageEvent::CGiveDamageEvent( CObject* target, const RESULTINFO& result, eStatusKind targetStatus ) :
CEvent( TypeGiveDamage, targetStatus ),
mResult( result ),
mTarget( target )
{}

// 080616 LUJ, ´Ù¸¥ ¿ÀºêÁ§Æ®°¡ ÇÇÇØ¸¦ ¹Þ¾ÒÀ» ¶§ ¹ßµ¿µÇ´Â ÀÌº¥Æ®
CTakeDamageEvent::CTakeDamageEvent( CObject* attacker, RESULTINFO& result ) :
CEvent( TypeTakeDamage, eStatusKind_None ),
mResult( result ),
mAttacker( attacker )
{}

CTakeDamageEvent::CTakeDamageEvent( CObject* attacker, RESULTINFO& result, eStatusKind targetStatus ) :
CEvent( TypeTakeDamage, targetStatus ),
mResult( result ),
mAttacker( attacker )
{}

// 080616 LUJ, ´Ù¸¥ ¿ÀºêÁ§Æ®¿¡°Ô ÇÇ»ìµÉ ¶§ ¹ß»ýÇÏ´Â ÀÌº¥Æ®
// 080708 LUJ, ÇÇÇØÀÚ¸¦ ÀÎÀÚ·Î ¹Þµµ·Ï ÇÔ
CDieEvent::CDieEvent( CObject* killer, CObject* victim ) :
CEvent( TypeDie, eStatusKind_None ),
mKiller( killer ),
mVictim( victim )
{}

// 080616 LUJ, ´Ù¸¥ ¿ÀºêÁ§Æ®¸¦ »ìÇØÇÒ ¶§ ¹ß»ýÇÏ´Â ÀÌº¥Æ®
// 080708 LUJ, CDieEvent¿Í °°Àº ±¸Á¶¸¦ ¾²µµ·Ï ÇÔ
CKillEvent::CKillEvent( CObject* killer, CObject* victim ) :
CDieEvent( killer, victim )
{
	mType = TypeKill;
}