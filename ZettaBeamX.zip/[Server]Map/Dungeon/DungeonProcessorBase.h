#ifndef __DUNGEONPROCESSORBASE_H__INCLUDED
#define __DUNGEONPROCESSORBASE_H__INCLUDED
#pragma once

class CDungeonMgr;
class CObject;
struct stDungeon;
/*
	ÁÖ : ÀÎ´ø ¸Êº°·Î ´øÀüÃ³¸®ÀÚ Å¬·¡½º¸¦ »ý¼ºÇØ¼­ »ç¿ëÇØ¾ß ÇÕ´Ï´Ù.
	´øÀüÃ³¸®ÀÚ Å¬·¡½º´Â CDungeonProcessorBase¸¦ »ó¼Ó¹Þ¾Æ¼­ »ç¿ëÇÏ½Ã¸é µË´Ï´Ù.

	DungeonMgr::Init()¿¡¼­ ´øÀüÃ³¸®ÀÚ¸¦ »ý¼ºÇÏ¸ç,
	DungeonMgr::Process()´Â ¸ðµç ´øÀüÀÇ °øÅë ÇÁ·Î¼¼½º¸¦ Ã³¸®ÇÕ´Ï´Ù.
				´øÀüº°·Î ´Ù¸¥ Ã³¸®´Â ´øÀüÃ³¸®ÀÚÀÇ Process()¿¡¼­ Ã³¸®ÇÏ¿©¾ß ÇÕ´Ï´Ù.
				
				¸ðµç ´øÀü¿¡ °øÅëÀ¸·Î Ã³¸®´Â DungeonMgr¿¡¼­ Ã³¸®ÇÏ¸ç,
				´øÀüº°·Î ´Ù¸¥ºÎºÐÀº ÀÎÅÍÆäÀÌ½º¸¦ Ãß°¡ÇØ¼­ º°µµ·Î Ã³¸®ÇÏ¿©¾ß ÇÕ´Ï´Ù.
*/

class CDungeonProcessorBase
{
public:
	CDungeonProcessorBase(void);
	virtual ~CDungeonProcessorBase(void);

	virtual void	Init(CDungeonMgr* pParent);
	virtual void	Create(stDungeon* pDungeon) = 0;
	virtual void	Process() = 0;

	virtual void	SetSwitch(DWORD dwChannelID, WORD num, BOOL val) = 0;	// ½ºÀ§Ä¡ÀÇ »óÅÂ°¡ º¯°æµÇ¾úÀ» ¶§ Ã³¸®
	virtual void	Info_Syn(CObject* pObject) = 0;							// Å¬¶óÀÌ¾ðÆ®¿¡¼­ MP_DUNGEON_INFO_SYN ÀÌ ¿ÔÀ» ¶§ Ã³¸®
	virtual void	SetBossMonster(stDungeon* pDungeon) = 0;

private:
	CDungeonMgr*		m_pParent;
};

class CDungeonProcessorEmpty : public CDungeonProcessorBase
{
public:
	CDungeonProcessorEmpty(void) {}
	virtual ~CDungeonProcessorEmpty(void) {}

	static CDungeonProcessorBase* Clone()
	{
		return new CDungeonProcessorEmpty;
	}

	virtual void	Create(stDungeon* pDungeon) {}
	virtual void	Process() {}
	virtual void	SetSwitch(DWORD dwChannelID, WORD num, BOOL val) {}
	virtual void	Info_Syn(CObject*) {}
	virtual void	SetBossMonster(stDungeon* pDungeon) {}
};
#endif // __DUNGEONPROCESSORBASE_H__INCLUDED
