#include "stdafx.h"


#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "fieldbossmonster.h"
#include "PackedData.h"
#include "ObjectStateManager.h"

CFieldBossMonster::CFieldBossMonster(void)
{
}

CFieldBossMonster::~CFieldBossMonster(void)
{
}
/*
void CFieldBossMonster::AddStatus(CStatus* pStatus)
{
}
*/
BOOL CFieldBossMonster::Init(EObjectKind kind,DWORD AgentNum, BASEOBJECT_INFO* pBaseObjectInfo)
{
	CMonster::Init(kind, AgentNum, pBaseObjectInfo);
	
	// ºÐ¹è ½Ã½ºÅÛ ÃÊ±âÈ­
	DistributeDamageInit();
	
	return TRUE;
}

void CFieldBossMonster::DoDie(CObject* pAttacker)
{
	// ÇÊµåº¸½º »ç³É½Ã °æÇèÄ¡1, °ñµå1 ºÐ¹èµÇ´Â ¹ö±×
	// 081223 NYJ - CDistributer::Distribute()¿¡¼­ Ã³¸®ÇÏ¹Ç·Î ¿©±â¼­´Â °æÇèÄ¡/°ñµå¸¦ ÁÖÁö ¾Ê´Â´Ù.
	/*
	// ¼ö·ÃÄ¡ °æÇèÄ¡ µ·À» ºÐ¹èÇÑ´Ù
	DistributePerDamage();
	*/
	// ¾ÆÀÌÅÛÀ» ºÐ¹èÇÑ´Ù
	DistributeItemPerDamage();

	// ÀÏ´Ü Å¬¶óÀÌ¾ðÆ®¿¡ Á×À½À» ¿¬ÃâÇØÁØ´Ù
	DWORD AttackerID;
	if(pAttacker == NULL)
		AttackerID = 0;
	else 
		AttackerID = pAttacker->GetID();

	OBJECTSTATEMGR_OBJ->StartObjectState(this,eObjectState_Die,AttackerID);
	OBJECTSTATEMGR_OBJ->EndObjectState(this,eObjectState_Die,MONSTERREMOVE_TIME+3000);
	SetTObject(0);
	RemoveAllAggro();
//-------------------

	// CFieldBossMonsterManager¿¡ Á×¾ú´Ù´Â°ÍÀ» Åëº¸ÇØÁØ´Ù
	FIELDBOSSMONMGR->BossDead(this);

	//CMonster::DoDie(pAttacker);	
}

void CFieldBossMonster::SetLife(DWORD Life,BOOL bSendMsg)
{
	CMonster::SetLife(Life, bSendMsg);	
	
	if(bSendMsg)
	{
		MSG_DWORD3 msg;
		msg.Category = MP_BOSSMONSTER;
		msg.Protocol = MP_FIELD_LIFE_NOTIFY;
		msg.dwData1 = GetLife();
		msg.dwData2 = GetMonsterKind();
		msg.dwData3 = GetID();
		PACKEDDATA_OBJ->QuickSend(this,&msg,sizeof(msg));
	}
}

BOOL CFieldBossMonster::IsBattle()
{
	// ÆòÈ­ ¸ðµå ÀÏ¶§ FALSE ¸®ÅÏ
	if( mStateParamter.stateCur < eMA_PERSUIT )
		return FALSE;

	// ÀüÅõ ¸ðµå ÀÏ¶§ ¼Ò¸ê½Ã°£ Ä«¿îÆ® ¸®¼Â
	m_Info.m_dwCountTime = m_Info.m_dwDistructTime;
	// È¸º¹½Ã°£µµ ¸®¼Â
	m_Info.m_dwPieceTime = gCurTime;

	// TRUE ¸®ÅÏ
	return TRUE;
}

BOOL CFieldBossMonster::IsDistruct()
{
	BOOL rt = FALSE;
	
	// ¸¶Áö¸· Ã¼Å© ½Ã°£ÀÌ 0ÀÏ °æ¿ì ÇöÀç ½Ã°£À¸·Î ¼³Á¤ÇÏ°í FALSE ¸®ÅÏ
	if( m_Info.m_dwLastCheckTime != 0 )
	{
		if( ( gCurTime - m_Info.m_dwLastCheckTime )  <  m_Info.m_dwCountTime )
		{
			m_Info.m_dwCountTime -= ( gCurTime - m_Info.m_dwLastCheckTime );
		}
		else
		{
			m_Info.m_dwCountTime = 0;

			rt = TRUE;
		}
	}

	m_Info.m_dwLastCheckTime = gCurTime;

	return rt;
}

void CFieldBossMonster::Recover()	
{
	if(m_Info.m_dwPieceTime + m_Info.m_dwRecoverStartTime < gCurTime)
	{
		DWORD maxlife = GetMaxLife();
		DWORD curlife = GetLife();
		
		if(gCurTime - m_LifeRecoverTime.lastCheckTime > m_Info.m_dwRecoverDelayTime)
		{
			if(curlife < maxlife)
			{
				DWORD pluslife = (DWORD)(maxlife * m_Info.m_fLifeRate);
				SetLife(curlife + pluslife, TRUE);
				m_LifeRecoverTime.lastCheckTime = gCurTime;

				// Life¸¦ ¸ðµÎ È¸º¹ÇßÀ¸¸é
				if(curlife + pluslife >= maxlife)
					// ºÐ¹è ½Ã½ºÅÛ ÃÊ±âÈ­
					DistributeDamageInit();
			}
		}
	}	
}