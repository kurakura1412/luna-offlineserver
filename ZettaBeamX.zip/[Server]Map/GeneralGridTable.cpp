// GeneralGridTable.cpp: implementation of the CGeneralGridTable class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "GeneralGridTable.h"
#include "Grid.h"
#include "PackedData.h"
#include "ServerTable.h"
#include "Object.h"
#include "GridSystem.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

int TransToGridCoordinate(float val)
{
	return int(val*0.01f);
}

float TransToGridCoordinateFloat(float val)
{
	return val*0.01f;
}
// 0¿¡¼­ 1»çÀÌÀÌ¸é Åë°úÇÑ´Ù.
float IsIntersect(float alp,float pos0,float pos1)
{
	float rt = 1.f + (pos1 - alp) / (pos0 - pos1);
	if(rt > 0 && rt <= 1)
		return rt;
	else
		return 10.f;
}

CGeneralGridTable::CGeneralGridTable()
{
	m_ChannelID = 0;
}

CGeneralGridTable::~CGeneralGridTable()
{
}

void CGeneralGridTable::Init(DWORD GridID,int MaxWidth,int MaxHeight)
{
	m_Kind = eGridType_General;
	int n=0;
	m_ID = GridID;

	//////////////////////////////////////////////////////////////////////////
	// 2ÀÇ Á¦°ö¼ö·Î ±æÀÌ¸¦ ¸ÂÃá´Ù
	m_nMaxLength = my_max(MaxWidth,MaxHeight) - 1;
	
	int exponent = 0;
	while(m_nMaxLength > 0)
	{
		m_nMaxLength = m_nMaxLength >> 1;
		++exponent;
	}

	m_nMaxLength = 1;
	for( n=0;n<exponent;++n)
		m_nMaxLength *= 2;
	//////////////////////////////////////////////////////////////////////////

	m_GridSize = 1;
	for(n=0;n<GRID_BIT;++n)
		m_GridSize *= 2;

	m_GridNum = (m_nMaxLength-1) / m_GridSize + 1;
	
	m_ppGrid = new CGrid*[m_GridNum];
	for(n=0;n<m_GridNum;++n)
	{
		m_ppGrid[n] = new CGrid[m_GridNum];
	}


	//////////////////////////////////////////////////////////////////////////
	// °¢ Grid°¡ ÁÖº¯ GridµéÀ» ±â¾ïÇÏ°Ô ÇÔ
	int nx,nz;
	int temp[16] = {
		-1,-1,
		-1,0,
		-1,1,
		0,-1,
		0,1,
		1,-1,
		1,0,
		1,1,
	};
	CGrid* pCurGrid;
	CGrid* pNeighborGrid;
	for(n=0;n<m_GridNum;++n)
	{
		for(int m=0;m<m_GridNum;++m)
		{
			pCurGrid = &m_ppGrid[n][m];

			for(int tt = 0;tt<8;++tt)
			{
				nx = n+temp[2*tt];
				nz = m+temp[2*tt+1];
				if(nx < 0 || nx >= m_GridNum ||
					nz < 0 || nz >= m_GridNum)
					continue;

				pNeighborGrid = &m_ppGrid[nx][nz];
				pCurGrid->AddNeighborGrid(pNeighborGrid);
			}
		}
	}
}

void CGeneralGridTable::Release()
{	
	if(m_ppGrid)
	{
		for(int n=0;n<m_GridNum;++n)
		{
			delete [] m_ppGrid[n];
		}
		delete [] m_ppGrid;
		m_ppGrid = NULL;
	}
}

void CGeneralGridTable::CalcGridPosition(float x,float z,GridPosition* pOutGridPos)
{
	pOutGridPos->LastX = pOutGridPos->x;
	pOutGridPos->LastZ = pOutGridPos->z;
	pOutGridPos->x = 0;
	pOutGridPos->z = 0;
}

CGrid* CGeneralGridTable::GetGrid(WORD x, WORD z)
{
	if(x >= m_GridNum || z >= m_GridNum)
	{
		//ASSERT(0);
		return NULL;
	}

	return &m_ppGrid[x][z];
}

CObject* CGeneralGridTable::FindPlayerInRange(CObject* pFinder,GridPosition* pGridPosition,VECTOR3* pPos,float Range, BYTE flag)
{
	CGrid* pGrid = GetGrid(pGridPosition->x,pGridPosition->z);
	if(pGrid == NULL)
		return NULL;

	if(flag == FIND_CLOSE)
		return pGrid->FindPlayerInRange(pFinder,pPos,Range);
	else
		return pGrid->FindFirstPlayerInRange(pFinder,pPos,Range);
}
CObject* CGeneralGridTable::FindMonsterInRange(CObject* pFinder,GridPosition* pGridPosition,VECTOR3* pPos,float Range, BYTE flag)
{
	CGrid* pGrid = GetGrid(pGridPosition->x,pGridPosition->z);
	if(pGrid == NULL)
		return NULL;

	if(flag == FIND_CLOSE)
		return pGrid->FindMonsterInRange(pFinder,pPos,Range);
	else
		return pGrid->FindFirstMonsterInRange(pFinder,pPos,Range);
}

WORD CGeneralGridTable::FindMonsterGroupInRange(DWORD* pFriendsList, CObject* pFinder,GridPosition* pGridPosition,VECTOR3* pPos)
{
	CGrid* pGrid = GetGrid(pGridPosition->x,pGridPosition->z);
	if(pGrid == NULL)
		return 0;

	return pGrid->FindMonsterGroupInRange(pFriendsList, pFinder,pPos);
}

void CGeneralGridTable::AddObject(CObject* pObject, VECTOR3* pPos)
{
	int firstx = TransToGridCoordinate(pPos->x);
	int firstz = TransToGridCoordinate(pPos->z);

	int nx;
	int nz;
	
	nx = firstx >> (GRID_BIT);
	nz = firstz >> (GRID_BIT);
	
	CGrid* pGrid = GetGrid( WORD( nx ),WORD( nz ) );
	if(pGrid == NULL)
		return;

	pGrid->AddObject(pObject);
	
	pObject->GridPos.x = WORD( nx );
	pObject->GridPos.z = WORD( nz );
}

void CGeneralGridTable::RemoveObject(CObject* pObject)
{
	CGrid* const pGrid = GetGrid(
		WORD(pObject->GetGridPosition()->x),
		WORD(pObject->GetGridPosition()->z));

	if(0 == pGrid)
	{
		return;
	}

	pGrid->RemoveObject(pObject);
}

void CGeneralGridTable::AddGridToPackedData(GridPosition* pGridPosition,CPackedData* pPackedData)
{
	CGrid* pCurGrid = GetGrid(pGridPosition->x, pGridPosition->z);
	if(pCurGrid == NULL)
		return;

	pCurGrid->AddGridToPackedData(pPackedData);
}

void CGeneralGridTable::AddGridToPackedDataWithoutOne(GridPosition* pGridPosition,DWORD dwID,CPackedData* pPackedData)
{
	CGrid* pCurGrid = GetGrid(pGridPosition->x, pGridPosition->z);
	if(pCurGrid == NULL)
		return;

	pCurGrid->AddGridToPackedDataWithoutOne(dwID,pPackedData);
}

void CGeneralGridTable::AddGridToPackedDataExceptLastGrid(GridPosition* pGridPosition,DWORD ExceptID,CPackedData* pPackedData)
{
	CGrid* pCurGrid = GetGrid(pGridPosition->x, pGridPosition->z);
	CGrid* pLastGrid = GetGrid(pGridPosition->LastX, pGridPosition->LastZ);
	
	if(pCurGrid == NULL || pLastGrid == NULL)
	{
		return;
	}

	pCurGrid->AddGridToPackedDataExceptLastGrid(ExceptID,pLastGrid,pPackedData);
}

void CGeneralGridTable::AddLastGridToPackedDataExceptCurrentGrid(GridPosition* pGridPosition,DWORD ExceptID,CPackedData* pPackedData)
{
	CGridTable::AddLastGridToPackedDataExceptCurrentGrid(pGridPosition, ExceptID, pPackedData);
}

void CGeneralGridTable::ChangeGrid(CObject* pObject, VECTOR3* pPos)
{
	int firstx = TransToGridCoordinate(pPos->x);
	int firstz = TransToGridCoordinate(pPos->z);

	int nx;
	int nz;
	
	nx = firstx >> (GRID_BIT);
	nz = firstz >> (GRID_BIT);

	if(nx >= m_GridNum)		nx = m_GridNum-1;
	if(nz >= m_GridNum)		nz = m_GridNum-1;
	if(nx < 0)		nx = 0;
	if(nz < 0)		nz = 0;
	
	if(nx == pObject->GridPos.x && nz == pObject->GridPos.z)
		return;
	
	RemoveObject(pObject);

	pObject->GridPos.LastX = pObject->GridPos.x;
	pObject->GridPos.LastZ = pObject->GridPos.z;
	
	pObject->GridPos.x = WORD( nx );
	pObject->GridPos.z = WORD( nz );

	//////////////////////////////////////////////////////////////////////////
	// YH2DO
	if(GetGrid(pObject->GridPos.x,pObject->GridPos.z) ==NULL)
	{
		ASSERT(0);
		return;
	}
	//////////////////////////////////////////////////////////////////////////
		
	AddObject(pObject,pPos);

	// 091026 LUJ, ÁøÀÔÇÏ´Â ±×¸®µå ³»ÀÇ ¿ÀºêÁ§Æ®¿¡°Ô ¾Ë·ÁÁØ´Ù
	{
		MSGBASE* message = 0;
		const DWORD messageLength = pObject->SetAddMsg(
			0,
			FALSE,
			message);
		PACKEDDATA_OBJ->Init(
			message,
			WORD(messageLength));
		AddGridToPackedDataExceptLastGrid(
			pObject->GetGridPosition(),
			pObject->GetID(),
			PACKEDDATA_OBJ);
		PACKEDDATA_OBJ->Send();
	}
	
	CGrid* pLastGrid = GetGrid(pObject->GridPos.LastX, pObject->GridPos.LastZ);
	// »õ·Îµé¾î°¥ ±×¸®µå¿¡ ÀÖ´ø ¾ÖµéÀÇ Á¤º¸¸¦ º¸q³»ÁØ´Ù
	CGrid* pCurrentGrid = GetGrid(pObject->GridPos.x,pObject->GridPos.z);
	if(pCurrentGrid)
		pCurrentGrid->SendCurrentObjectInfo(pObject, pLastGrid);
	
	// 091026 LUJ, ÀÌÀü¿¡ ÀÖ´ø ±×¸®µå ³»ÀÇ ¿ÀºêÁ§Æ®¿¡°Ô ¾Ë·ÁÁØ´Ù
	{
		MSGBASE* message = 0;
		const DWORD messageLength = pObject->SetRemoveMsg(
			0,
			message);
		PACKEDDATA_OBJ->Init(
			message,
			WORD(messageLength));
		AddLastGridToPackedDataExceptCurrentGrid(
			pObject->GetGridPosition(),
			pObject->GetID(),
			PACKEDDATA_OBJ);
		PACKEDDATA_OBJ->Send();
	}
	
	CGrid* pCurGrid = GetGrid(pObject->GridPos.x, pObject->GridPos.z);
	// ±âÁ¸¿¡ ÀÖ´ø ¾ÖµéÀ» RemoveÇÏ¶ó´Â ¸Þ¼¼Áö¸¦ º¸³½´Ù.	
	pLastGrid = GetGrid(pObject->GridPos.LastX, pObject->GridPos.LastZ);
	if(pLastGrid)
		pLastGrid->SendRemoveObjectInfo(pObject, pCurGrid);
}

void CGeneralGridTable::SendCurrentObjectInfo(int GridNumX,int GridNumZ,int LastGridNumX,int LastGridNumZ,CObject* pNewObject)
{
	CGrid* pLastGrid = GetGrid( WORD( LastGridNumX), WORD( LastGridNumZ) );
	CGrid* pCurGrid = GetGrid( WORD( GridNumX ), WORD( GridNumZ ) );
	if(pCurGrid)
		pCurGrid->SendCurrentObjectInfo(pNewObject,pLastGrid);
}
void CGeneralGridTable::SendRemoveObjectInfo(int GridNumX,int GridNumZ,int LastGridNumX,int LastGridNumZ,CObject* pLeavedObject)
{
	CGrid* pLastGrid = GetGrid( WORD( LastGridNumX ), WORD( LastGridNumZ ) );
	CGrid* pCurGrid = GetGrid( WORD( GridNumX ), WORD( GridNumZ ) );
	if(pLastGrid)
		pLastGrid->SendRemoveObjectInfo(pLeavedObject,pCurGrid);
}


BOOL CGeneralGridTable::GetGridChangeTime(VECTOR3* pStartPos,VECTOR3* pTargetPos,float MoveSpeed,DWORD& dwChangeTime)
{
	int nx = TransToGridCoordinate(pStartPos->x) >> GRID_BIT;
	int nz = TransToGridCoordinate(pStartPos->z) >> GRID_BIT;

	int nAlp_Left = nx * m_GridSize;
	int nAlp_Right = (nx+1) * m_GridSize;
	int nAlp_Top = nz * m_GridSize;
	int nAlp_Bottom = (nz+1) * m_GridSize;	

	float sx = TransToGridCoordinateFloat(pStartPos->x);
	float sz = TransToGridCoordinateFloat(pStartPos->z);
	float tx = TransToGridCoordinateFloat(pTargetPos->x);
	float tz = TransToGridCoordinateFloat(pTargetPos->z);


	float t_left = IsIntersect(float(nAlp_Left),sx,tx);
	float t_right = IsIntersect(float(nAlp_Right),sx,tx);
	float t_top = IsIntersect(float(nAlp_Top),sz,tz);
	float t_bottom = IsIntersect(float(nAlp_Bottom),sz,tz);

	float t_xmin,t_ymin,t_min;
	t_xmin = my_min(t_left,t_right);
	t_ymin = my_min(t_top,t_bottom);
	t_min = my_min(t_xmin,t_ymin);

	if(t_min >= 0 && t_min <= 1)
	{
		//±×¸®µå º¯È­°¡ ÀÖÀ»°ÍÀÌ´Ù.
		float distance = CalcDistanceXZ(pStartPos,pTargetPos);
		float totalTime = TransToGridCoordinateFloat(distance) / TransToGridCoordinateFloat(MoveSpeed);

		dwChangeTime = (DWORD)(totalTime * t_min * 1000);	// ÃµºÐÀÇ ÀÏÃÊ ´ÜÀ§·Î º¯È¯
		++dwChangeTime;		// ¿ÀÂ÷¿¡ ´ëÇÑ °í·Á

		return TRUE;
	}
	else
		return FALSE;
}

void CGeneralGridTable::OnDelete()
{

}

//////////////////////////////////////////////////////////////////////////
/// 06. 08. 2Â÷ º¸½º - ÀÌ¿µÁØ
/// À¯È¿±×¸®µå³» ·£´ýÀ¸·Î Å¸°Ù ¼³Á¤
CObject* CGeneralGridTable::FindPlayerRandom(CObject* pObject)
{
	CGrid* pGrid = GetGrid(pObject->GridPos.x, pObject->GridPos.z);
	if(pGrid == NULL)
		return NULL;

	return pGrid->FindPlayerRandom();
}
//////////////////////////////////////////////////////////////////////////