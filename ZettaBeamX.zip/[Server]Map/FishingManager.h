#ifndef __FISHINGMANAGER_H__INCLUDED
#define __FISHINGMANAGER_H__INCLUDED
#pragma once

#ifndef _MAP00_
#include "stdafx.h"
#endif
class CPlayer;

#define FISHINGMGR USINGTON(CFishingManager)
#define FISHINGRATE_SCALE		1000.0f							// ¼Ò¼öÁ¡ ÀÌÇÏ 3ÀÚ¸®±îÁö À¯È¿.

#define MAX_FISHINGPLACE		10
#define MAX_FISHITEM			10
#define FISHINGTIME_LATENCY		500								// ³×Æ®¿÷Áö¿¬½Ã°£

enum {
	eFISHINGRATE_ITEM_UNKNOWN	= 0,
	eFISHINGRATE_ITEM_UTILITY	= 1,
	eFISHINGRATE_ITEM_BAIT		= 2,
};

enum {
	eFISHMISSION_STATE_READY	= 0,	// ¹Ì¼ÇÁÖ±âÀü
	eFISHMISSION_STATE_STANDBY	= 1,	// ¹Ì¼ÇÁÖ°í ÀÀ´ä´ë±â
	eFISHMISSION_STATE_NEW		= 2,	// ¹Ì¼ÇÁÖ±â
	eFISHMISSION_STATE_END		= 3,	// ¹Ì¼Ç³¡³»±â
};

struct stFishingMissionInfo;

extern DWORD g_FishingMissionCode[MAX_FISHINGMISSIONCODE];		// ¹°°í±âÄÚµå
extern std::map<DWORD, stFishingMissionInfo> g_mapMissionInfo;	// ¹Ì¼ÇÁ¤º¸

struct stFishItemInfo
{
	DWORD dwItemIndex;											// ¾ÆÀÌÅÛIndex
	float fRate;												// È®·ü
};

struct stFishRateInfo
{
	int   nGrade;												// ¹°°í±âµî±Þ
	float fRate;												// È®·ü
};

struct stFishingMissionInfo
{
	DWORD dwCode;												// ¹Ì¼ÇÄÚµå
	DWORD dwRewardItem;											// º¸»ó¾ÆÀÌÅÛ
	int   dwRewardItemNum;										// º¸»ó¾ÆÀÌÅÛ °³¼ö
};

struct stFishingPlaceInfo
{
	char  cNpcKind;												// NPCLIST.bin¿¡ ÀúÀåµÈ NpcKindÇÊµå
	VECTOR3 vPos;												// À§Ä¡
	DWORD dwLifeTime;											// Áö¼Ó½Ã°£.
	DWORD dwProcessTime;										// °ÔÀÌÁö ÁøÇà½Ã°£. (³­ÀÌµµ)
	int   nRepeatCount;											// °ÔÀÌÁö ¹Ýº¹È½¼ö. (³­ÀÌµµ)
	stFishItemInfo			m_FishItem[MAX_FISHITEM];			// ¹°°í±âÁ¤º¸
	std::vector<stFishItemInfo> m_vecPlaceEff;					// ³¬½ÃÅÍ¿¡ µû¸¥ Àû¿ëÈ¿°ú
	std::vector<stFishItemInfo> m_vecWeatherEff[eWS_Max];		// ³¯¾¾¿¡ µû¸¥ Àû¿ëÈ¿°ú
	DWORD dwBaseDelay;											// »ý¼ºÁÖ±â ±âº»
	DWORD dwRandDelay;											// »ý¼ºÁÖ±â ·£´ý
	char  cFishItemNum;											// ¹°°í±â¾ÆÀÌÅÛ ¼ö
	float fHitAddRate[4];										// [0]°øÅë, [1]ÇÇ¶ó¹Ì, [2]ºØ¾î, [3]À×¾î ; ÄÁÆ®·Ñ ÀûÁß½Ã Ãß°¡È®·ü

	stFishingPlaceInfo()	{Clear();}
	void Clear()
	{
		cNpcKind=cFishItemNum = 0;
		vPos.x=vPos.y=vPos.z=0.0f;
		dwLifeTime=dwProcessTime = 0;
		nRepeatCount = 0;
		memset(m_FishItem, 0, sizeof(stFishItemInfo)*MAX_FISHITEM);
		dwBaseDelay=dwRandDelay = 0;
		m_vecPlaceEff.clear();
		int i;
		for(i=0; i<eWS_Max; i++)
			m_vecWeatherEff[i].clear();

		for(i=0; i<4; i++)
			fHitAddRate[i] = 1.0f;
	}
};

struct stFishingPlaceInst
{
	BYTE  byInfoIndex;											// m_FishingPlaceInfo[]¿¡¼­ ÂüÁ¶ÇÒ index
	DWORD dwObjectIndex;										// g_pUserTable¿¡ µî·ÏµÈ index
	DWORD dwGenTime;											// »ý¼º½Ã°£.
	DWORD dwDelTime;											// ¼Ò¸ê½Ã°£.

	stFishingPlaceInst()	{Clear();}
	void Clear()
	{
		byInfoIndex = 0;
		dwObjectIndex=dwGenTime=dwDelTime = 0;
	}
};

struct stFishingRate
{
	DWORD dwItemIndex;
	stFishRateInfo FishList[MAX_FISHITEM];

	stFishingRate()			{Clear();}
	void Clear()
	{
		dwItemIndex = 0;
		int i;
		for(i=0; i<MAX_FISHITEM; i++)
		{
			FishList[i].nGrade = -1;
			FishList[i].fRate = 0.0f;
		}
	}
};

struct stFishingEvent
{
	BOOL bOnEvent;				// ÀÌº¥Æ®±¸µ¿ ÇÃ·¡±×
	WORD wPoint[3];				// [0]PerfectÈ¯»êÁ¡¼ö, [1]GreatÈ¯»êÁ¡¼ö, [2]GoodÈ¯»êÁ¡¼ö
	WORD wGoalPoint[3];			// ¸ñÇ¥Á¡¼ö
	DWORD dwRewardItemIdx[3];	// º¸»ó¾ÆÀÌÅÛ

	stFishingEvent()
	{
		bOnEvent = FALSE;

		memset(wPoint, 0, sizeof(wPoint));
		memset(wGoalPoint, 0, sizeof(wGoalPoint));
		memset(dwRewardItemIdx, 0, sizeof(dwRewardItemIdx));
	}
};

class CFishingManager
{
public:
	CFishingManager(void);
	virtual ~CFishingManager(void);

	void Init();
	void NetworkMsgParse( BYTE Protocol, void* pMsg, DWORD dwLength );

	void Fishing_Ready_Syn(void* pMsg);
	void Fishing_GetFish_Syn(void* pMsg);
	void Fishing_Cancel_Syn(void* pMsg);
	void Fishing_FPChange_Syn(void* pMsg);

	void Process();

	BOOL				m_bActive;
	BOOL				m_bInit;
	BOOL				m_bUseMission;
	stFishingPlaceInfo	m_FishingPlaceInfo[MAX_FISHINGPLACE];
	stFishingPlaceInst	m_FishingPlaceInst[MAX_CHANNEL_NUM][MAX_FISHINGPLACE];
	CYHHashTable< stFishingPlaceInst*>	m_FishingGabagePlace;	//¸Å ·çÇÁ½Ã ¼Ò¸êµÈ ³¬½ÃÅÍIndex ÀÓ½ÃÀúÀå.

	stFishingEvent		m_FishingEventInfo;

	BOOL AddFishingPlace(stFishingPlaceInfo* pFishingPlaceInfo, DWORD dwChannel, BYTE byInfoIndex);
	void DelFishingPlace(stFishingPlaceInst* pInst);
	void SendGetFish(CPlayer* pPlayer, WORD wResCode, void* pMsg=NULL);

	stFishingPlaceInst* GetFishingPlaceInst(DWORD dwPlaceIndex);
	
	void SetPlaceEffect();
	void SetWeatherEffect();

	DWORD GetItemIdxFromFM_Code(int nCode);	// ³¬½Ã¹Ì¼Ç ÄÚµå·Î ¾ÆÀÌÅÛIndex¾ò±â
	void GetFishCodeFromFM_Code(DWORD dwMissionCode, WORD* pFishCode);	// ³¬½Ã¹Ì¼Ç ÄÚµå·Î ¹°°í±âÄÚµå ¾ò±â
	void SendFishingMissionInfo(CPlayer* pPlayer, BOOL bNew);

	stFishingRate* GetFishingUtilityRate(DWORD dwItemIndex);
	stFishingRate* GetFishingBaitRate(DWORD dwItemIndex);


	BOOL GetActive() {return m_bActive;}
	char CheckMissionState();
	void ChangeMissionState();
	void ProcessPlayer(CPlayer* pPlayer);

private:
	int m_nChannelNum;
	int m_nFishingPlaceNum;

	int m_nPlaceEff[MAX_FISHINGPLACE][eFishItem_Max];
	int m_nWeatherEff[MAX_FISHINGPLACE][eWS_Max][eFishItem_Max];

	char  m_cMissionState;
	DWORD m_dwMissionSendTime;		// ³¬½Ã ½ÃÀÛÈÄ ¹Ì¼Çº¸³»±â±îÁö ´ë±â½Ã°£ (Pulling ±îÁöÀÇ ½Ã°£)
	DWORD m_dwMissionDelayTime;		// ¹Ì¼ÇºÎ¿© °£°Ý
	DWORD m_dwMissionEndTime;		// ¹Ì¼Ç ¿Ï·á¸¦ ±â´Ù¸®´Â ½Ã°£.

	std::map<DWORD, stFishingRate*> m_mapUtilRateList;
	std::map<DWORD, stFishingRate*> m_mapBaitRateList;


public:
	void ReleaseME();
	void InitME();
};

EXTERNGLOBALTON(CFishingManager)
#endif // __FISHINGMANAGER_H__INCLUDED
