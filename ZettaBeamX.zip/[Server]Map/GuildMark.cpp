// GuildMark.cpp: implementation of the CGuildMark class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "GuildMark.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGuildMark::CGuildMark()
{

}

CGuildMark::~CGuildMark()
{

}

void CGuildMark::Init(MARKNAMETYPE MarkName,  char* ImgData)
{
	m_MarkIdx = MarkName;
	memcpy(m_ImgData, ImgData, GUILDMARK_BUFSIZE);
}

char* CGuildMark::GetImgData()
{
	return m_ImgData;
}



CGuildUnionMark::CGuildUnionMark()
{
	m_dwMarkIdx = 0;
	memset( m_ImgData, 0, GUILDUNIONMARK_BUFSIZE );
}

CGuildUnionMark::~CGuildUnionMark()
{
}

void CGuildUnionMark::Init( DWORD dwMarkIdx, char* pImgData )
{
	m_dwMarkIdx = dwMarkIdx;
	memcpy( m_ImgData, pImgData, GUILDUNIONMARK_BUFSIZE );
}