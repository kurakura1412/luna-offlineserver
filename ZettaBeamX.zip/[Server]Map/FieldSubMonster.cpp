#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "fieldsubmonster.h"
#include "PackedData.h"

CFieldSubMonster::CFieldSubMonster(void)
{
}

CFieldSubMonster::~CFieldSubMonster(void)
{
}

void CFieldSubMonster::DoDie(CObject* pAttacker)
{
	CMonster::DoDie(pAttacker);	

	// CFieldBossMonsterManager¿¡ Á×¾ú´Ù´Â°ÍÀ» Åëº¸ÇØÁØ´Ù
	FIELDBOSSMONMGR->SubDead(this);
}

void CFieldSubMonster::SetLife(DWORD Life,BOOL bSendMsg)
{
	CMonster::SetLife(Life, bSendMsg);	
	
	if(bSendMsg)
	{
		MSG_DWORD3 msg;
		msg.Category = MP_BOSSMONSTER;
		msg.Protocol = MP_FIELD_LIFE_NOTIFY;
		msg.dwData1 = GetLife();
		msg.dwData2 = GetMonsterKind();
		msg.dwData3 = GetID();
		PACKEDDATA_OBJ->QuickSend(this,&msg,sizeof(msg));
	}
}

BOOL CFieldSubMonster::IsBattle()
{
	// ÆòÈ­ ¸ðµå ÀÏ¶§ FALSE ¸®ÅÏ
	if( mStateParamter.stateCur < eMA_PERSUIT )
		return FALSE;

	// ÀüÅõ ¸ðµå ÀÏ¶§ ¼Ò¸ê½Ã°£ Ä«¿îÆ® ¸®¼Â
	m_Info.m_dwCountTime = m_Info.m_dwDistructTime;
	// È¸º¹½Ã°£µµ ¸®¼Â
	m_Info.m_dwPieceTime = gCurTime;

	// TRUE ¸®ÅÏ
	return TRUE;
}

BOOL CFieldSubMonster::IsDistruct()
{
	BOOL rt = FALSE;
	
	// ¸¶Áö¸· Ã¼Å© ½Ã°£ÀÌ 0ÀÏ °æ¿ì ÇöÀç ½Ã°£À¸·Î ¼³Á¤ÇÏ°í FALSE ¸®ÅÏ
	if( m_Info.m_dwLastCheckTime != 0 )
	{
		if( ( gCurTime - m_Info.m_dwLastCheckTime )  <  m_Info.m_dwCountTime )
		{
			m_Info.m_dwCountTime -= ( gCurTime - m_Info.m_dwLastCheckTime );
		}
		else
		{
			m_Info.m_dwCountTime = 0;

			rt = TRUE;
		}
	}

	m_Info.m_dwLastCheckTime = gCurTime;

	return rt;
}

void CFieldSubMonster::Recover()	
{
	if(m_Info.m_dwPieceTime + m_Info.m_dwRecoverStartTime < gCurTime)
	{
		DWORD maxlife = GetMaxLife();
		DWORD curlife = GetLife();
		
		if(gCurTime - m_LifeRecoverTime.lastCheckTime > m_Info.m_dwRecoverDelayTime)
		{
			if(curlife < maxlife)
			{
				DWORD pluslife = (DWORD)(maxlife * m_Info.m_fLifeRate);
				SetLife(curlife + pluslife, TRUE);
				m_LifeRecoverTime.lastCheckTime = gCurTime;
			}
		}
	}	
}