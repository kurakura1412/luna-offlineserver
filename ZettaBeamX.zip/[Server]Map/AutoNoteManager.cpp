#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
#include "ServerSystem.h"
#endif

#include "autonotemanager.h"
#include "UserTable.h"
#include "Player.h"
#include "AutoNoteRoom.h"
#include "Network.h"
#include "[CC]ServerModule/DataBase.h"
#include "MapDBMsgParser.h"

CAutoNoteManager::CAutoNoteManager(void)
{
	m_bInited = FALSE;
}

CAutoNoteManager::~CAutoNoteManager(void)
{
}

void CAutoNoteManager::Init()
{
	m_htAutoNoteRoom.Initialize( 100 );
	m_pmpAutoNoteRoom = new CPool< CAutoNoteRoom >;
	m_pmpAutoNoteRoom->Init( 100, 100, "CAutoNoteRoom" );

//---ÀÌ¹ÌÁö·Îµå
	m_pOriRaster[0] = new BYTE[16*16*3];
	m_pOriRaster[1] = new BYTE[16*16*3];
	m_pOriRaster[2] = new BYTE[16*16*3];
	m_pOriRaster[3] = new BYTE[16*16*3];
	m_pBGRaster		= new BYTE[128*32*3];
	m_pNoiseRaster	= new BYTE[16*16*3];
	m_pSendRaster	= new BYTE[128*32*3];

	if( BMP_RasterLoad( "./AutoNoteImage/01Red.bmp", m_pOriRaster[0] ) == FALSE ) return;
	if( BMP_RasterLoad( "./AutoNoteImage/02Yellow.bmp", m_pOriRaster[1] ) == FALSE ) return;
	if( BMP_RasterLoad( "./AutoNoteImage/03Blue.bmp", m_pOriRaster[2] ) == FALSE ) return;
	if( BMP_RasterLoad( "./AutoNoteImage/04Black.bmp", m_pOriRaster[3] ) == FALSE ) return;
	if( BMP_RasterLoad( "./AutoNoteImage/00BG.bmp", m_pBGRaster ) == FALSE ) return;
	if( BMP_RasterLoad( "./AutoNoteImage/00Noise.bmp", m_pNoiseRaster ) == FALSE ) return;

	// --------------------------------------------------
	// 090106 ShinJS --- Àç½ÇÇà/ºÎÀçÁßÆÇ´Ü ½Ã°£ ¼³Á¤ Ãß°¡
	m_dwCanRetryTime		= 300;
	m_dwTargetAbsentTime	= 10;
	// --------------------------------------------------

	//---TEST
//	MakeSendRaster();

	m_bInited = TRUE;

	return;
}

void CAutoNoteManager::Release()
{
	m_pmpAutoNoteRoom->Release();
	delete m_pmpAutoNoteRoom;
	m_htAutoNoteRoom.RemoveAll();

//---ÀÌ¹ÌÁöÇØÁ¦
	delete[] m_pOriRaster[0];
	delete[] m_pOriRaster[1];
	delete[] m_pOriRaster[2];
	delete[] m_pOriRaster[3];
	delete[] m_pBGRaster;
	delete[] m_pNoiseRaster;
	delete[] m_pSendRaster;
}

BOOL CAutoNoteManager::BMP_RasterLoad( char* filename, BYTE* pRaster )
{
	HANDLE hFile = CreateFile( filename, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL );
	if( hFile == INVALID_HANDLE_VALUE )
		return FALSE;

	DWORD dwFileSize = GetFileSize( hFile, NULL );
	BYTE* data = new BYTE[dwFileSize];

	DWORD dwRead;
	ReadFile( hFile, data, dwFileSize, &dwRead, NULL );
	CloseHandle( hFile );

	BITMAPFILEHEADER* fh = (BITMAPFILEHEADER*)data;
	BITMAPINFOHEADER* ih = (BITMAPINFOHEADER*)( data + sizeof(BITMAPFILEHEADER) );

	int RasterSize = ( ih->biWidth * ih->biHeight * ih->biBitCount ) / 8;
	if( RasterSize < 0 ) RasterSize = -RasterSize;

	memcpy( pRaster, data + ((BITMAPFILEHEADER*)fh)->bfOffBits, RasterSize );

	delete[] data;

	return TRUE;
}

void CAutoNoteManager::MakeSendRaster( DWORD* pData )
{
	int x, y, cx, cy, rot;
	float fszx, fszy;

//---Clear
	memset( m_pSendRaster, 0xee, 128*32*3 ); 

//---Background
	fszx = (rand()%5 + 11) / 10.f;	fszy = (rand()%5 + 11) / 10.f;
	BlitImage( m_pSendRaster, m_pBGRaster, 128, 32, 128, 32, 0, 0, fszx, fszy );

//---noise
	for( int i = 0 ; i < 4 ; ++i )
	{
		x = rand()%(128-16);				y = rand()%(32-16);
		fszx = (rand()%10 + 10) / 10.f;		fszy = (rand()%10 + 10) / 10.f;
		cx = rand()%4 + 6;					cy = rand()%4 + 6;
		rot = rand()%41 - 20;
		BlitImage( m_pSendRaster, m_pNoiseRaster, 128, 32, 16, 16, x, y, fszx, fszy, float( rot ), cx, cy );
	}

//---txt
	int firstpos = rand()%32;
	int xrand = ( ( 128 - firstpos ) - 90 ) / 4;
	for( int i = 0 ; i < 4 ; ++i )
	{
		x = rand()%xrand + firstpos + i*24;	//i*32;
		y = rand()%8 + 3;
		fszx = (rand()%5 + 11) / 10.f;		fszy = (rand()%5 + 11) / 10.f;
		cx = rand()%4 + 6;					cy = rand()%4 + 6;
		rot = rand()%61 - 30;
		BlitImage( m_pSendRaster, m_pOriRaster[pData[i]], 128, 32, 16, 16, x, y, fszx, fszy, float( rot ), cx, cy, BIF_RANDOMCOLOR );
	}
}

void CAutoNoteManager::BlitImage( BYTE* pDest, BYTE* pSrc, int dw, int dh, int sw, int sh, int x, int y, float fszw, float fszh, float fRot, int cx, int cy, int Flag )
{
	int lsw = int( sw * fszw );
	int lsh = int( sh * fszh );

	for( int row = 0 ; row < lsh ; ++row )
	{
		for( int col = 0 ; col < lsw ; ++col )
		{
			int osx = int( col / fszw + 0.5f );
			int osy = int( row / fszh + 0.5f );

			if( osx >= sw || osy >= sh )
				continue;

			float fRad = 3.14f * fRot / 180.f;
			int ldx = int( ( col - cx ) * cos( fRad ) - ( row - cy ) * sin( fRad ) + cx );
			int ldy = int( ( col - cx ) * sin( fRad ) + ( row - cy ) * cos( fRad ) + cy );

			if( ldx + x >= dw || ldy + y >= dh )
				continue;

			BYTE Color[3]; 
			Color[0] = *(pSrc + osx * 3 + osy * 3 * sw);
			Color[1] = *(pSrc + osx * 3 + osy * 3 * sw + 1);
			Color[2] = *(pSrc + osx * 3 + osy * 3 * sw + 2);

			if( Color[0] != 255 || Color[1] != 255 || Color[2] != 255 )	//Èò»öÀÌ ¾Æ´Ï¸é
			{
				if( Flag == BIF_RANDOMCOLOR )
				{
					//»ý»ó ·£´ý Á¶Á¤
					Color[0] = BYTE( rand() % 100 );	//255 µÚÁýÇôµµ »ó°ü¾øÀÚ³ª?
					Color[1] = BYTE( rand() % 100 );
					Color[2] = BYTE( rand() % 100 );
				}

				memcpy( pDest + ( ldx + x ) * 3 + ( ldy + y ) * 3 * dw, Color, 3 );
			}
		}
	}
}

void CAutoNoteManager::Process()
{
	m_htAutoNoteRoom.SetPositionHead();
	CAutoNoteRoom* pANRoom = NULL ;
	while( (pANRoom = m_htAutoNoteRoom.GetData() )!= NULL)
	{
		if( pANRoom->IsTimeOver() )
		{
			CPlayer* pAutoPlayer = (CPlayer*)g_pUserTable->FindUser( pANRoom->GetAutoCharacterIdx() );

			if( pANRoom->GetAutoNoteRoomState() == eANRS_WAITANSWER )	//---´äº¯ ÀÔ·ÂÀ» ±â´Ù¸®´Â ÁßÀÌ´Ù. ´äº¯ÀÌ ´Ê¾ú´Ù.
			{
				if( pAutoPlayer )
				{
					MSG_DWORD msg1;
					msg1.Category	= MP_AUTONOTE;
					msg1.Protocol	= MP_AUTONOTE_ANSWER_TIMEOUT;
					msg1.dwData		= pANRoom->GetAutoUserIdx();
					pAutoPlayer->SendMsg( &msg1, sizeof(msg1) );
				}

				//---½Å°íÀÚ¿¡°Ô ½Å°í´ë»óÀÌ Á¦ÀçµÇ¾úÀ½À» ¾Ë¸² (¾îµð¿¡ ÀÖÀ»Áö ¸ð¸£¹Ç·Î ¸ðµç ¿¡ÀÌÀüÆ®·Î º¸³¿)
				MSG_DWORD msg2;
				msg2.Category	= MP_AUTONOTE;
				msg2.Protocol	= MP_AUTONOTE_KILLAUTO;
				msg2.dwData		= pANRoom->GetAskUserIdx();
				g_Network.Broadcast2AgentServer( (char*)&msg2, sizeof(msg2) );

				//---DB ½Å°íÀÚ ¿ÀÅä¸®½ºÆ®¿¡ µî·Ï
				AutoNoteListAdd( pANRoom->GetAskCharacterIdx(), pANRoom->GetAutoCharacterName(), pANRoom->GetAutoCharacterIdx(), pANRoom->GetAutoUserIdx() );

				//---´ë»ó Á¢¼Ó ²÷±â
				MSG_DWORD msg3;
				msg3.Category	= MP_AUTONOTE;
				msg3.Protocol	= MP_AUTONOTE_DISCONNECT;
				msg3.dwData		= pANRoom->GetAutoUserIdx();
				g_Network.Broadcast2AgentServer( (char*)&msg3, sizeof(msg3) );
			}
			else if( pANRoom->GetAutoNoteRoomState() == eANRS_FASTANSWER )
			{
				//---½Å°íÀÚ¿¡°Ô ½Å°í´ë»óÀÌ Á¦ÀçµÇ¾úÀ½À» ¾Ë¸² (¾îµð¿¡ ÀÖÀ»Áö ¸ð¸£¹Ç·Î ¸ðµç ¿¡ÀÌÀüÆ®·Î º¸³¿)
				MSG_DWORD msg2;
				msg2.Category	= MP_AUTONOTE;
				msg2.Protocol	= MP_AUTONOTE_KILLAUTO;
				msg2.dwData		= pANRoom->GetAskUserIdx();
				g_Network.Broadcast2AgentServer( (char*)&msg2, sizeof(msg2) );

				//---DB ½Å°íÀÚ ¿ÀÅä¸®½ºÆ®¿¡ µî·Ï
				AutoNoteListAdd( pANRoom->GetAskCharacterIdx(), pANRoom->GetAutoCharacterName(), pANRoom->GetAutoCharacterIdx(), pANRoom->GetAutoUserIdx() );

				//---´ë»ó Á¢¼Ó ²÷±â
				MSG_DWORD msg3;
				msg3.Category	= MP_AUTONOTE;
				msg3.Protocol	= MP_AUTONOTE_DISCONNECT;
				msg3.dwData		= pANRoom->GetAutoUserIdx();
				g_Network.Broadcast2AgentServer( (char*)&msg3, sizeof(msg3) );
			}

			if( pAutoPlayer )	pAutoPlayer->SetAutoNoteIdx( 0 );
			m_htAutoNoteRoom.Remove( pANRoom->GetAskCharacterIdx() );
			m_pmpAutoNoteRoom->Free( pANRoom );
			break;	//ÇÑ¹ø¿¡ ÇÏ³ª¾¿¸¸ Áö¿ìÀÚ (¾ÈÀüÇÏ°Ô)
		}
	}
}

void CAutoNoteManager::AutoPlayerLogOut( CPlayer* pAutoPlayer )
{
	CAutoNoteRoom* pANRoom = m_htAutoNoteRoom.GetData( pAutoPlayer->GetAutoNoteIdx() );
	if( pANRoom == NULL ) return;

	//---½Å°íÇÑ À¯Àú°¡ ³ª°¡¹ö·È´Ù.
	MSG_DWORD msg;
	msg.Category	= MP_AUTONOTE;
	msg.Protocol	= MP_AUTONOTE_ANSWER_LOGOUT;
	msg.dwData		= pANRoom->GetAutoUserIdx();
	pAutoPlayer->SendMsg( &msg, sizeof(msg) );

	//---½Å°íÀÚ¿¡°Ô ½Å°í´ë»óÀÌ Á¦ÀçµÇ¾úÀ½À» ¾Ë¸² (¾îµð¿¡ ÀÖÀ»Áö ¸ð¸£¹Ç·Î ¸ðµç ¿¡ÀÌÀüÆ®·Î º¸³¿)
	MSG_DWORD msg2;
	msg2.Category	= MP_AUTONOTE;
	msg2.Protocol	= MP_AUTONOTE_KILLAUTO;
	msg2.dwData		= pANRoom->GetAskUserIdx();
	g_Network.Broadcast2AgentServer( (char*)&msg2, sizeof(msg2) );

	//---DB ½Å°íÀÚ ¿ÀÅä¸®½ºÆ®¿¡ µî·Ï
	AutoNoteListAdd( pANRoom->GetAskCharacterIdx(), pANRoom->GetAutoCharacterName(), pANRoom->GetAutoCharacterIdx(), pANRoom->GetAutoUserIdx() );

	//---¿ÀÅä Áú´ä¹æ ÇØÁ¦
	m_htAutoNoteRoom.Remove( pANRoom->GetAskCharacterIdx() );
	m_pmpAutoNoteRoom->Free( pANRoom );
}

void CAutoNoteManager::NetworkMsgParse( BYTE Protocol, void* pMsg, DWORD dwLength )
{
	CPlayer* pAutoPlayer = NULL;
	CAutoNoteRoom* pANRoom = NULL;
	switch(Protocol)
	{
	case MP_AUTONOTE_ASKTOAUTO_SYN:
		{
			MSG_DWORD2* pmsg = (MSG_DWORD2*)pMsg;

            CPlayer* pPlayer = (CPlayer*)g_pUserTable->FindUser( pmsg->dwObjectID );
			if( pPlayer == NULL )	return;

			int error = eAutoNoteError_None;

			if( AUTONOTEMGR->CanUseAutoNote() == FALSE )	//---ÀÌ¹ÌÁö ÀÐ´Â ÃÊ±âÈ­¸¦ ½ÇÆÐÇÏ¿´À¸¹Ç·Î ¿ÀÅä³ëÆ® ±â´ÉÀ» »ç¿ëÇÒ ¼ö ¾ø´Ù.
			{
				goto AutoNoteAskError;
			}

			if( g_pServerSystem->GetMap()->IsAutoNoteAllow() == FALSE )
			{
				error = eAutoNoteError_CantUseMap;				//---»ç¿ëÇÒ ¼ö ¾ø´Â ¸Ê
				goto AutoNoteAskError;				
			}

			// ------------------------------------------------------------------------
			// 090106 ShinJS --- ¿ÀÅä³ëÆ® ¸¶Áö¸· Àû¹ß ½ÇÆÐ ÈÄ ¸¶Áö¸· »ç¿ë½Ã°£ Ã¼Å© Ãß°¡
			if( pPlayer->GetAutoNoteLastExecuteTime() != 0 &&
				gCurTime < pPlayer->GetAutoNoteLastExecuteTime() + m_dwCanRetryTime*1000 )
			{				
				MSG_DWORD msg;
				msg.Category	= MP_AUTONOTE;
				msg.Protocol	= MP_AUTONOTE_PUNISH;
				msg.dwData		= m_dwCanRetryTime*1000 - (gCurTime - pPlayer->GetAutoNoteLastExecuteTime());
				pPlayer->SendMsg( &msg, sizeof(msg) );
				return;
			}
			// ------------------------------------------------------------------------

			if( CAutoNoteRoom* pRoom = m_htAutoNoteRoom.GetData( pPlayer->GetID() ) )
			{
				error = eAutoNoteError_AlreadyAsking;			//---½Å°íÁß(ÇÑ¹ø¿¡ ÇÑÄ³¸¯ÅÍ¸¸ ½Å°íÇÒ ¼ö ÀÖ´Ù)
				goto AutoNoteAskError;
			}

			pAutoPlayer = (CPlayer*)g_pUserTable->FindUser( pmsg->dwData1 );
			if( pAutoPlayer == NULL )
			{
				error = eAutoNoteError_CantFind;				//---»ó´ë°¡ ¾ø´Ù
				goto AutoNoteAskError;
			}

			if( pAutoPlayer->GetAutoNoteIdx() )		
			{
				error = eAutoNoteError_AlreadyAsked;			//---´©°¡ ¹ú½á ½Å°íÇÑ Ä³¸¯ÅÍ´Ù
				goto AutoNoteAskError;
			}

			// 090106 ShinJS --- ºÎÀçÁß ÆÇ´Ü º¯¼ö Àû¿ë(m_dwTargetAbsentTime)
			if( gCurTime > pAutoPlayer->GetLastActionTime() + m_dwTargetAbsentTime*1000 )
			{
				error = eAutoNoteError_NotProperState;			//---»ó´ë°¡ ¸¶Áö¸· ½ºÅ³ »ç¿ë ÈÄ 10ÃÊ°¡ Áö³µ´Ù. ½Å°íÇÒ ¼ö ¾ø´Â »óÅÂ.
				goto AutoNoteAskError;
			}
            
			pANRoom = m_pmpAutoNoteRoom->Alloc();
			if( pANRoom == NULL )								//---¹æ»ý¼º ½ÇÆÐ
			{
				goto AutoNoteAskError;
			}

			m_htAutoNoteRoom.Add( pANRoom, pPlayer->GetID() );

			pANRoom->CreateRoom( pPlayer, pAutoPlayer, pmsg->dwData2 );
			pANRoom->AskToAuto();

			// 090609 ShinJS --- Add Log
			LogAutoNote( eAutoNoteLogKind_Report, pPlayer, pAutoPlayer );
			return;

AutoNoteAskError:
			MSG_DWORD msg;
			msg.Category	= MP_AUTONOTE;
			msg.Protocol	= MP_AUTONOTE_ASKTOAUTO_NACK;
			msg.dwData		= error;
			pPlayer->SendMsg( &msg, sizeof(msg) );
		}
		break;

	case MP_AUTONOTE_ANSWER_SYN:
		{
			MSG_DWORD4* pmsg = (MSG_DWORD4*)pMsg;

			CPlayer* pAutoPlayer = (CPlayer*)g_pUserTable->FindUser( pmsg->dwObjectID );
			if( pAutoPlayer == NULL ) return;

			CAutoNoteRoom* pANRoom = m_htAutoNoteRoom.GetData( pAutoPlayer->GetAutoNoteIdx() );
			if( pANRoom == NULL ) return;	//ACK MSG?

			//---Á¤´ä Ã¼Å©
			BOOL bCorrect = pANRoom->CheckAnswerFromAuto( pmsg->dwData1, pmsg->dwData2, pmsg->dwData3, pmsg->dwData4 );

			if( bCorrect )	//---Á¤´ä
			{
				//---´äº¯½Ã°£ Ã¼Å©
				DWORD dwAnswerTime = pANRoom->GetAnswerTime();
				if( dwAnswerTime <= 2000 ) //2ÃÊ³»·Î ´äº¯À» Çß´Ù. º¸ÅëÀÇ °æ¿ì¿£ ºÒ°¡´É
				{
					//---¿ÀÅä¿¡°Õ ¸ÂÃß¾ú´Ù°í ¾Ë¸®°í ¾È½É½ÃÅ²´Ù.
					//---½Å°í´ë»ó¿¡°Ô ´äº¯À» ¸ÂÃß¾ú´Ù°í ¾Ë¸²
					MSG_DWORD msg;
					msg.Category	= MP_AUTONOTE;
					msg.Protocol	= MP_AUTONOTE_ANSWER_ACK;
					msg.dwData		= pANRoom->GetAskUserIdx();
					pAutoPlayer->SendMsg( &msg, sizeof(msg) );

					pANRoom->FastAnswer();	//Àû´çÇÑ ½Ã°£ÀÌ ÈÄ ¿ÀÅä¸¦ ²÷¾î¹ö¸°´Ù.

					// -------------------------------------------------------
					// 090106 ShinJS --- Àû¹ß ½ÇÆÐ½Ã ¸¶Áö¸· ½ÇÇà½Ã°£ ÀúÀå Ãß°¡
					CPlayer* pAskPlayer = (CPlayer*)g_pUserTable->FindUser( pANRoom->GetAskCharacterIdx() );
					if( pAskPlayer )
						pAskPlayer->SetAutoNoteLastExecuteTime();
					// -------------------------------------------------------
					return;
				}

				//---½Å°íÇÑ »ç¶÷¿¡°Ô ´ë»óÀÌ ¿ÀÅä°¡ ¾Æ´ÔÀ» ¾Ë¸² (´Ù¸¥ ¸ÊÀ¸·Î °¬À» ¼öµµ ÀÖÀ¸´Ï, ¸ðµç ¿¡ÀÌÁ¯Æ®·Î ³¯·ÁÁØ´Ù.)
				MSG_DWORD msg1;
				msg1.Category	= MP_AUTONOTE;
				msg1.Protocol	= MP_AUTONOTE_NOTAUTO;
				msg1.dwData		= pANRoom->GetAskUserIdx();
				g_Network.Broadcast2AgentServer( (char*)&msg1, sizeof(msg1) );

				//---½Å°í´ë»ó¿¡°Ô ´äº¯À» ¸ÂÃß¾ú´Ù°í ¾Ë¸²
				MSG_DWORD msg2;
				msg2.Category	= MP_AUTONOTE;
				msg2.Protocol	= MP_AUTONOTE_ANSWER_ACK;
				msg2.dwData		= pANRoom->GetAskUserIdx();
				pAutoPlayer->SendMsg( &msg2, sizeof(msg2) );

				//---¿ÀÅä Áú´ä¹æ ÇØÁ¦
				pAutoPlayer->SetAutoNoteIdx( 0 );
				m_htAutoNoteRoom.Remove( pANRoom->GetAskCharacterIdx() );
				m_pmpAutoNoteRoom->Free( pANRoom );

				// -------------------------------------------------------
				// 090106 ShinJS --- Àû¹ß ½ÇÆÐ½Ã ¸¶Áö¸· ½ÇÇà½Ã°£ ÀúÀå Ãß°¡
				CPlayer* pAskPlayer = (CPlayer*)g_pUserTable->FindUser( pANRoom->GetAskCharacterIdx() );
				if( pAskPlayer )
					pAskPlayer->SetAutoNoteLastExecuteTime();
				// -------------------------------------------------------
			}
			else	//---¿À´ä
			{
				if( pANRoom->GetChance() <= 0 )							//---3¹ø ¸ðµÎ Æ²·È´Ù.
				{
					//---´ë»ó¿¡°Ô ´äº¯ ½ÇÆÐÇßÀ½À» ¾Ë¸²
					MSG_DWORD msg1;
					msg1.Category	= MP_AUTONOTE;
					msg1.Protocol	= MP_AUTONOTE_ANSWER_FAIL;
					msg1.dwData		= pANRoom->GetAutoUserIdx();
					pAutoPlayer->SendMsg( &msg1, sizeof(msg1) );

					//---´ë»ó Á¢¼Ó ²÷±â
					MSG_DWORD msg2;
					msg2.Category	= MP_AUTONOTE;
					msg2.Protocol	= MP_AUTONOTE_DISCONNECT;
					msg2.dwData		= pANRoom->GetAutoUserIdx();
					pAutoPlayer->SendMsg( &msg2, sizeof(msg2) );	//---¿¡ÀÌÁ¯Æ®·Î º¸³»Áø´Ù

					//---½Å°íÀÚ¿¡°Ô ½Å°í´ë»óÀÌ Á¦ÀçµÇ¾úÀ½À» ¾Ë¸² (¾îµð¿¡ ÀÖÀ»Áö ¸ð¸£¹Ç·Î ¸ðµç ¿¡ÀÌÀüÆ®·Î º¸³¿)
					MSG_DWORD msg3;
					msg3.Category	= MP_AUTONOTE;
					msg3.Protocol	= MP_AUTONOTE_KILLAUTO;
					msg3.dwData		= pANRoom->GetAskUserIdx();
					g_Network.Broadcast2AgentServer( (char*)&msg3, sizeof(msg3) );

					//---DB ½Å°íÀÚ ¿ÀÅä¸®½ºÆ®¿¡ µî·Ï
					AutoNoteListAdd( pANRoom->GetAskCharacterIdx(), pANRoom->GetAutoCharacterName(), pANRoom->GetAutoCharacterIdx(), pANRoom->GetAutoUserIdx() );

					//---¿ÀÅä Áú´ä¹æ ÇØÁ¦
					pAutoPlayer->SetAutoNoteIdx( 0 );
					m_htAutoNoteRoom.Remove( pANRoom->GetAskCharacterIdx() );
					m_pmpAutoNoteRoom->Free( pANRoom );
				}
				else
				{
					MSG_DWORD msg;
					msg.Category	= MP_AUTONOTE;
					msg.Protocol	= MP_AUTONOTE_ANSWER_NACK;
					msg.dwData		= pANRoom->GetChance();
					pAutoPlayer->SendMsg( &msg, sizeof(msg) );
				}
			}
		}
		break;
	}
}