#include "stdafx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
#include "ServerSystem.h"
#endif

#include "Distributer.h"
#include "UserTable.h"
#include "PartyManager.h"
#include "Party.h"
#include "Monster.h"
#include "BossRewardsManager.h"
#include "FieldBossMonsterManager.h"
#include "ItemManager.h"
#include "Player.h"
#include "ItemDrop.h"
#include "hseos/Date/SHDateManager.h"
#include "hseos/Family/SHFamilyManager.h"
#include "petmanager.h"
#include "pet.h"
#include "[CC]ServerModule/DataBase.h"
#include "MapDBMsgParser.h"
#include "GameResourceManager.h"

float gEventRate[eEvent_Max];
float gEventRateFile[eEvent_Max];

CDistributer::CDistributer()																	// »ý¼ºÀÚ ÇÔ¼ö.
{
	m_DamageObjectTableSolo.Initialize(2);
	m_DamageObjectTableParty.Initialize(2);

	m_1stPartyID = 0;
	m_1stPlayerID = 0;
	m_TotalDamage = 0;
	m_FirstDamage = 0;
	m_nTotalKillerCount = 0;
	m_HighLevel = 0;
	m_pKiller = NULL;
	m_pMob = NULL;
	m_dwDropItemID = 0;
	m_dwDropItemRatio = 0;
}

CDistributer::~CDistributer()																	// ¼Ò¸êÀÚ ÇÔ¼ö.
{
	Release();																					// ÇØÁ¦ ÇÔ¼ö¸¦ È£ÃâÇÑ´Ù.
}

void CDistributer::Release()																	// ÇØÁ¦ ÇÔ¼ö.
{
	m_1stPartyID = 0;																			// Ã¹ µ¥¹ÌÁö¸¦ ÁØ ÆÄÆ¼ ¾ÆÀÌµð ÃÊ±âÈ­.
	m_1stPlayerID = 0;																			// Ã¹ µ¥¹ÌÁö¸¦ ÁØ ÇÃ·¹ÀÌ¾î ¾ÆÀÌµð ÃÊ±âÈ­.
	m_TotalDamage = 0;																			// µ¥¹ÌÁö ÇÕ°è ÃÊ±âÈ­.
	m_FirstDamage = 0 ;																			// Ã¹ µ¥¹ÌÁö ÃÊ±âÈ­.
	m_nTotalKillerCount = 0 ;																	// Å³·¯ ¼ö ÃÊ±âÈ­.
	m_HighLevel = 0 ;																			// Å³·¯ µé Áß °¡Àå ·¹º§ÀÌ ³ôÀº Å³·¯ÀÇ ·¹º§.

	DAMAGEOBJ *sobj, *pobj = NULL;																// °³ÀÎ ¹× ÆÄÆ¼ µ¥¹ÌÁö Å×ÀÌºíÀÇ Æ÷ÀÎÅÍ.

	m_DamageObjectTableSolo.SetPositionHead();													// °³ÀÎ µ¥¹ÌÁö Å×ÀÌºíÀ» Çì´õ·Î ¼¼ÆÃÇÑ´Ù.

	while((sobj = m_DamageObjectTableSolo.GetData())!= NULL)												// µ¥¹ÌÁö ¿ÀºêÁ§Æ®°¡ ¾øÀ» ¶§ ±îÁö while.
	{
		delete sobj;																			// µ¥¹ÌÁö ¿ÀºêÁ§Æ®¸¦ »èÁ¦ÇÑ´Ù.
		sobj = NULL ;																			// µ¥¹ÌÁö ¿ÀºêÁ§Æ® NULLÃ³¸®.
	}

	m_DamageObjectTableSolo.RemoveAll();														// µ¥¹ÌÁö ¿ÀºêÁ§Æ®¸¦ ºñ¿î´Ù.				

	m_DamageObjectTableParty.SetPositionHead();													// ÆÄÆ¼ µ¥¹ÌÁö Å×ÀÌºíÀ» Çì´õ·Î ¼¼ÆÃÇÑ´Ù.

	while((pobj = m_DamageObjectTableParty.GetData())!= NULL)											// µ¥¹ÌÁö ¿ÀºêÁ§Æ®°¡ ¾øÀ» ¶§ ±îÁö while.		
	{																							
		delete pobj;																			// µ¥¹ÌÁö ¿ÀºêÁ§Æ®¸¦ »èÁ¦ÇÑ´Ù.
		pobj = NULL ;																			// µ¥¹ÌÁö ¿ÀºêÁ§Æ® NULLÃ³¸®.
	}																							
																								
	m_DamageObjectTableParty.RemoveAll();														// µ¥¹ÌÁö ¿ÀºêÁ§Æ®¸¦ ºñ¿î´Ù.					

	m_pKiller = NULL;
	m_pMob = NULL;
	m_dwDropItemID		= 0 ;																	// µå¶ø ¾ÆÀÌÅÛ ¾ÆÀÌµð¸¦ ´ã´Â º¯¼ö ÃÊ±âÈ­.
	m_dwDropItemRatio	= 0 ;																	// µå¶ø·üÀ» ´ã´Â º¯¼ö ÃÊ±âÈ­.							

    mPlayerIndexContainer.clear();
}

void CDistributer::AddDamageObject(CPlayer* pPlayer, DWORD damage, DWORD plusdamage)
{
	if( pPlayer ) 																				// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
	{
		DoAddDamageObj(
			m_DamageObjectTableSolo,
			pPlayer->GetID(),
			damage + plusdamage);

		//if(plusdamage != 0)																		// Ãß°¡ µ¥¹ÌÁö°¡ ÀÖ´ÂÁö Ã¼Å©ÇÑ´Ù.
		if( m_1stPlayerID == 0 )
		{
			m_1stPlayerID = pPlayer->GetID();													// Ã¹ µ¥¹ÌÁö¸¦ ÁØ ÇÃ·¹ÀÌ¾î ¾ÆÀÌµð¸¦ ¹Þ´Â´Ù.
			m_1stPartyID = pPlayer->GetPartyIdx();												// Ã¹ µ¥¹ÌÁö¸¦ ÁØ ÇÃ·¹ÀÌ¾îÀÇ ÆÄÆ¼ ÀÎµ¦½º¸¦ ¹Þ´Â´Ù.
		}
		
		m_TotalDamage += damage + plusdamage;
	}
}

void CDistributer::DoAddDamageObj(CYHHashTable<DAMAGEOBJ>& pTable, DWORD dwID, DWORD damage)
{
	if(DAMAGEOBJ* pDObj = pTable.GetData(dwID))
	{
		pDObj->dwData += damage;
	}
	else
	{
		pDObj = new DAMAGEOBJ;
		ZeroMemory(
			pDObj,
			sizeof(*pDObj));
		pDObj->dwID = dwID;
		pDObj->dwData = damage;
		
		pTable.Add(
			pDObj,
			dwID);
	}
}


BOOL CDistributer::Chk(CPlayer& pPlayer, DWORD GridID)
{
	if(pPlayer.GetInited())
	{
		if(FALSE == pPlayer.IsShowdown())
		{
			VECTOR3 PlayerPosition = {0};
			pPlayer.GetPosition(
				&PlayerPosition);

			const float fDistance = CalcDistanceXZ(
				&m_pKilledPosition,
				&PlayerPosition);

			if(fDistance <= POINT_VALID_DISTANCE)
			{
				if(pPlayer.GetState() != eObjectState_Die)
				{
					if(pPlayer.GetGridID() == GridID)
					{
						return TRUE;
					}
				}
			}
		}
	}

	return FALSE ;																				// FALSE ¸®ÅÏ.
}

void CDistributer::ChooseOne(const DAMAGEOBJ& pobj, DWORD& pBigDamage, DWORD& pBigID)
{
	if(pBigDamage < pobj.dwData)
	{
		pBigDamage = pobj.dwData;
		pBigID = pobj.dwID;
	}
	else if(pBigDamage == pobj.dwData)
	{
		if(1 == (rand() % 2))
		{
			pBigID = pobj.dwID;
		}
	}
}

void CDistributer::DistributeItemPerDamage(CMonster& pMob)
{
	CPlayer* TargetPlayerTable[100] = {0};
	WORD TargetPos = 0;
	
	if(FIELDBOSSDROPITEMLIST* const pDropItemList = FIELDBOSSMONMGR->GetFieldBossDropItemList(pMob.GetMonsterKind()))													
	{
		for(WORD index = 0; index < MAX_FIELDBOSS_DROPITEM_GROUP_NUM; index++)
		{
			// µå¶ø ¾ÆÀÌÅÛ Á¤º¸°¡ ÀÖ´Â°¡? ¾ø´Ù¸é Á¾·á
			if( pDropItemList->m_ItemList[ index ].m_wItemIndex[0] == 0 )
				break;
	        
			// ¾ÆÀÌÅÛ ±×·ì ³»ÀÇ ¾î¶² ¾ÆÀÌÅÛÀ» ÁÙÁö °áÁ¤
			WORD select = 0;
			{
			WORD dropitemnum = 0;
			for( dropitemnum = 0; dropitemnum < MAX_FIELDBOSS_DROPITEM_NUM; dropitemnum++)
			{
				if(pDropItemList->m_ItemList[ index ].m_wItemIndex[dropitemnum] == 0)
					break;
			}

			select = WORD( rand() % dropitemnum );
			}
			// µå¶øµÉ È½¼ö¸¦ °¡Á®¿Â´Ù
			WORD count = pDropItemList->m_ItemList[ index ].m_wCount;

			for(WORD i = 0; i < count; i++)
			{
				// µå¶ø ÇÒ°ÍÀÎ°¡?
				if( (rand() % 100) < pDropItemList->m_ItemList[ index ].m_wDropRate )
				{
					// º¯¼öÃÊ±âÈ­
					memset( TargetPlayerTable, 0, sizeof(CPlayer*) * 100 );
					TargetPos = 0;

					// °ø°ÝÇÑ »ç¶÷µéÀ» °Ë»öÇØ¼­ ±âÁØÄ¡ ÀÌ»ó µ¥¹ÌÁö¸¦ ÁØ »ç¶÷µé °¡·Á³½´Ù
					m_DamageObjectTableSolo.SetPositionHead();

					while(const DAMAGEOBJ* const obj = m_DamageObjectTableSolo.GetData())
					{
						if(obj->dwData == 0)
							continue;

						CPlayer* const pReceivePlayer = (CPlayer *)g_pUserTable->FindUser(obj->dwID);

						if(!pReceivePlayer)	
							continue;
						if(pReceivePlayer->GetInited())
							continue;
						if(pReceivePlayer->GetGridID() != pMob.GetGridID())
							continue;
						if(pReceivePlayer->GetLevel() > pMob.GetSMonsterList().Level + 8 )
							continue;
						
						// µ¥¹ÌÁö ºñÀ² °è»ê
						WORD DamageRate = (WORD)(((double)obj->dwData / m_TotalDamage) * 100);

						// ±âÁØÄ¡ ÀÌ»ó µ¥¹ÌÁö¸¦ ÁÖ¾ú´Ù¸é
						if( DamageRate >= pDropItemList->m_ItemList[ index ].m_wDamageRate )
						{
							// µ¥¹ÌÁö ºñÀ²¸¸Å­ ´ë»ó Å×ÀÌºí¿¡ µî·ÏÇÑ´Ù
							for(DWORD rate = 0; rate < DamageRate; rate++)
							{
								TargetPlayerTable[ TargetPos++ ] = pReceivePlayer;
							}
						}
					}

					// ´ë»ó Å×ÀÌºí¿¡ µî·ÏµÈ À¯Àú°¡ ÀÖ´Ù¸é
					if( TargetPos > 0 )
					{
						// ·£´ýÀ¸·Î Å×ÀÌºí À§Ä¡¸¦ °áÁ¤ÇÑ´Ù
						WORD TargetIndex = WORD( rand() % TargetPos );

						if(CPlayer* const TargetPlayer = TargetPlayerTable[TargetIndex])
						{
							ITEMMGR->MonsterObtainItem(
								TargetPlayer,
								pDropItemList->m_ItemList[index].m_wItemIndex[select],
								pMob.GetMonsterKind(),
								pDropItemList->m_ItemList[index].m_wItemCount[select]);
						}
					}
				}
			}
		}
	}

	
}

void CDistributer::DistributePerDamage(CMonster& pMob)
{	
	MONEYTYPE MaxMoney = 0;
	DWORDEX MaxExp = 0;

	BOSSREWARDSMGR->GetBossRewardsInfo(
		pMob.GetMonsterKind(),
		MaxExp,
		MaxMoney);

	m_DamageObjectTableSolo.SetPositionHead();

	while(DAMAGEOBJ* const obj = m_DamageObjectTableSolo.GetData())
	{
		if(obj->dwData == 0)
			continue;
		CPlayer* pReceivePlayer = (CPlayer *)g_pUserTable->FindUser(obj->dwID);

		if(!pReceivePlayer)	
			continue;
		if(pReceivePlayer->GetInited())
			continue;
		if(pReceivePlayer->GetGridID() != pMob.GetGridID())
			continue;

		EXPTYPE Exp = (DWORD)(((double)obj->dwData * MaxExp) / m_TotalDamage);
		MONEYTYPE Money = (DWORD)(((double)obj->dwData * MaxMoney) / m_TotalDamage);

		float fBuffExp = pReceivePlayer->GetRateBuffStatus()->GetExp;
		Exp = (DWORDEX)(Exp*gEventRate[eEvent_ExpRate]) ;
		Exp += EXPTYPE(Exp*(fBuffExp/100)) ;

		if(pMob.GetObjectKind() == eObjectKind_FieldBossMonster)
		{
			if(pReceivePlayer->GetLevel() > pMob.GetSMonsterList().Level + 6 )
				continue;

			if(Exp == 0) Exp = 1;
			if(Money == 0) Money = 1;

			pReceivePlayer->AddPlayerExpPoint(Exp);
			AddMoney(
				pReceivePlayer,
				Money,
				pMob.GetMonsterKind());
		}
		else
		{
			if(Exp >= 10000)
				pReceivePlayer->AddPlayerExpPoint(Exp);

			if(Money >= 100000)
				AddMoney(
					pReceivePlayer,
					Money,
					pMob.GetMonsterKind());
		}
	}
}

void CDistributer::DamageInit()
{
	m_1stPartyID = 0;																			// Ã¹ µ¥¹ÌÁö¸¦ ÁØ ÆÄÆ¼ ¾ÆÀÌµð ÃÊ±âÈ­.
	m_1stPlayerID = 0;																			// Ã¹ µ¥¹ÌÁö¸¦ ÁØ ÇÃ·¹ÀÌ¾î ¾ÆÀÌµð ÃÊ±âÈ­.
	m_TotalDamage = 0;																			// µ¥¹ÌÁö ÇÕ°è ÃÊ±âÈ­.
	m_FirstDamage = 0 ;																			// Ã¹ µ¥¹ÌÁö ÃÊ±âÈ­.
	m_nTotalKillerCount = 0 ;																	// Å³·¯ ¼ö ÃÊ±âÈ­.
	m_HighLevel = 0 ;																			// Å³·¯ µé Áß °¡Àå ·¹º§ÀÌ ³ôÀº Å³·¯ÀÇ ·¹º§.

	m_DamageObjectTableSolo.RemoveAll();														// µ¥¹ÌÁö ¿ÀºêÁ§Æ® Å×ÀÌºíÀ» ¸ðµÎ ºñ¿î´Ù.	

	m_pKiller = NULL;
	m_pMob = NULL;
	m_dwDropItemID		= 0 ;																	// µå¶ø ¾ÆÀÌÅÛ ¾ÆÀÌµð¸¦ ´ã´Â º¯¼ö ÃÊ±âÈ­.
	m_dwDropItemRatio	= 0 ;																	// µå¶ø·üÀ» ´ã´Â º¯¼ö ÃÊ±âÈ­.							
}

void CDistributer::DeleteDamagedPlayer(DWORD CharacterID)
{	
	DAMAGEOBJ* pData = NULL ;																	// µ¥¹ÌÁö ¿ÀºêÁ§Æ® Á¤º¸¸¦ ´ãÀ» Æ÷ÀÎÅÍ¸¦ ¼±¾ð ¹× NULL ÃÊ±âÈ­.

	pData = m_DamageObjectTableSolo.GetData( CharacterID );										// ¹ÞÀº ¾ÆÀÌµð·Î µ¥¹ÌÁö Å×ÀÌºí¿¡¼­ µ¥¹ÌÁö ¿ÀºêÁ§Æ® Æ÷ÀÎÅÍ¸¦ ¹Þ´Â´Ù.

	if( pData )																					// µ¥¹ÌÁö ¿ÀºêÁ§Æ® Æ÷ÀÎÅÍ°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
	{
		if( m_TotalDamage >= pData->dwData )													// Æ÷ÀÎÅÍÀÇ µ¥¹ÌÁö°¡ µ¥¹ÌÁö ÇÕ°èº¸´Ù Å©°Å³ª °°À¸¸é,
		{
			m_TotalDamage -= pData->dwData;														// µ¥¹ÌÁö ÇÕ°è¿¡¼­ Æ÷ÀÎÅÍÀÇ µ¥¹ÌÁö ¸¸Å­ »«´Ù.
		}
		else																					// Æ÷ÀÎÅÍÀÇ µ¥¹ÌÁö°¡ µ¥¹ÌÁö ÇÕ°èº¸ÀÚ ÀÛÀ¸¸é
		{
			m_TotalDamage = 0;																	// ÇÕ°è µ¥¹ÌÁö¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.
		}
	} 

	m_DamageObjectTableSolo.Remove(CharacterID);												// µ¥¹ÌÁö ¿ÀºêÁ§Æ® Å×ÀÌºí¿¡¼­ ÁÖ¾îÁø ¾ÆÀÌµðÀÇ µ¥¹ÌÁö ¿ÀºêÁ§Æ®¸¦ ºñ¿î´Ù.
}

void CDistributer::SetInfoToDistribute(DWORD dwKillerID, DWORD DropItemID, DWORD DropItemRatio,CMonster& pMob)
{
	CObject* pKiller = g_pUserTable->FindUser(dwKillerID);

	pMob.GetPosition(
		&m_pKilledPosition);

	if( pKiller->GetObjectKind() == eObjectKind_Player )
	{
		m_pKiller = (CPlayer *)pKiller;
	}
	else if( pKiller->GetObjectKind() == eObjectKind_Pet )
	{
		CObject* const object = g_pUserTable->FindUser(
			pKiller->GetOwnerIndex());

		if(object &&
			eObjectKind_Player == object->GetObjectKind())
		{
			m_pKiller = (CPlayer*)object;
		}
	}
	else if(CObject* const owner = g_pUserTable->FindUser(pKiller->GetOwnerIndex()))
	{
		if(eObjectKind_Player == owner->GetObjectKind())
		{
			m_pKiller = (CPlayer*)owner;
		}
	}

	m_pMob = &pMob;
	m_dwDropItemID = DropItemID;
	m_dwDropItemRatio = DropItemRatio;
}		

// 091111 pdy ÆÄÆ¼ µ¥¹ÌÁö »êÁ¤ ¹æ½ÄÀ» ¸ó½ºÅÍ º¸»ó½Ã¿¡ ÇÑ¹ø °è»ê ÇÏµµ·Ï º¯°æ
void CDistributer::Distribute()
{
	GetAllPartyDamage();
	GetHighLevelOfKillers();
	GetTotalKillerCount();

	if( m_nTotalKillerCount > 1 )																// ¸ó½ºÅÍ¸¦ Ã³Ä¡ ÇÑ ÇÃ·¹ÀÌ¾î°¡ ´Ù¼ö¶ó¸é, 
	{
		DistributeToKillers() ;																	// ´Ù¼ö Ã³¸®¸¦ ÇÑ´Ù.
	}
	else																						// ¸ó½ºÅÍ¸¦ Ã³Ä¡ ÇÑ ÇÃ·¹ÀÌ¾î°¡ ÇÑ¸íÀÌ¶ó¸é, 
	{
		DistributeToKiller() ;																	// °³ÀÎ Ã³¸®¸¦ ÇÑ´Ù.
	}

	Release();																					// µ¥¹ÌÁö Å×ÀÌºí µî ¸ðµç ÂüÁ¶ Á¤º¸¸¦ ÃÊ±âÈ­ ÇÑ´Ù.
}

void CDistributer::DistributeToKillers()
{
	if(!GetFirstDamange())																		// ¼±°ø°ÝÀÚ µ¥¹ÌÁö¸¦ ±¸ÇÑ´Ù.
	{
		if( m_pMob->GetObjectKind() == eObjectKind_BossMonster )
		{
			SYSTEMTIME time;
			char szFile[256] = {0,};
			GetLocalTime( &time );

			sprintf(szFile, "./Log/BossMonsterAssertLog_%02d_%04d%02d%02d.txt", g_pServerSystem->GetMapNum(), time.wYear, time.wMonth, time.wDay );
			FILE* fp;
			fp = fopen(szFile, "a+");
			if (fp)
			{
				fprintf(fp, "BossMonster Not FirstDamage Return\n");
				fclose(fp);
			}
		}
	}

	int nPenaltyType = GetLevelPenaltyToMonster(m_HighLevel);

	MONEYTYPE money = ITEMDROP_OBJ->DropMoney(
		m_pMob->GetSMonsterList(),
		nPenaltyType);

	if( m_pMob->GetObjectKind() == eObjectKind_BossMonster )
	{
		SYSTEMTIME time;
		char szFile[256] = {0,};
		GetLocalTime( &time );

		sprintf(szFile, "./Log/BossMonsterLog_%02d_%04d%02d%02d_%d.txt", g_pServerSystem->GetMapNum(), time.wYear, time.wMonth, time.wDay, m_pMob->GetMonsterKind() );
		FILE* fp;
		fp = fopen(szFile, "a+");
		if (fp)
		{
			fprintf(fp, "Time : [%2d:%2d], HighLevel : %d, Drop Money : %u, nPenaltyType : %d\n", time.wHour, time.wMinute, m_HighLevel, money, nPenaltyType);

			m_DamageObjectTableSolo.SetPositionHead() ;

			while(DAMAGEOBJ* const obj = m_DamageObjectTableSolo.GetData())
			{
				if(CObject* const object = g_pUserTable->FindUser(obj->dwID))
				{
					if(object->GetGridID() == m_pMob->GetGridID())
					{
						fprintf(
							fp,
							"PlayerID : %u,		Damage : %u,	Level : %u,	CharacterName : %s\n",
							obj->dwID,
							obj->dwData,
							object->GetLevel(),
							object->GetObjectName());
					}
				}
			}

			m_DamageObjectTableParty.SetPositionHead();

			while(DAMAGEOBJ* const obj = m_DamageObjectTableParty.GetData())
			{
				CParty* pParty = PARTYMGR->GetParty(obj->dwID) ;
				if( !pParty ) continue;

				fprintf(fp, "\n[PartyIdx : %u][PartyDamage : %u]\n", obj->dwID, obj->dwData);

				for(int i=0; i<MAX_PARTY_LISTNUM; i++)
				{
					if(CObject* const object = g_pUserTable->FindUser(pParty->GetMemberID(i)))
					{
						if(object->GetGridID() == m_pMob->GetGridID())
						{
							fprintf(fp, "[PartyMemberIdx : %d]\n", pParty->GetMemberID(i));
						}
					}
				}
			}

			fclose(fp);
		}
	}

	DistributerToSolo(money) ;																	// °³ÀÎ °æÇèÄ¡¿Í ¸Ó´Ï Ã³¸®¸¦ ÇÑ´Ù.

	DistributeToPartys(money) ;																	// ÆÄÆ¼ °æÇèÄ¡¿Í ¸Ó´Ï Ã³¸®¸¦ ÇÑ´Ù.

	DistributeItemToKillers() ;																	// ¾ÆÀÌÅÛ Ã³¸®¸¦ ÇÑ´Ù.
}

void CDistributer::DistributerToSolo(MONEYTYPE money)
{
	BYTE byPet_ExpPenaltyLevel = PETMGR->GetExpPenaltyLevel() ;

	m_DamageObjectTableSolo.SetPositionHead() ;													// µ¥¹ÌÁö Å×ÀÌºíÀ» ÇØµå·Î ¼¼ÆÃÇÑ´Ù.

	while(const DAMAGEOBJ* const obj = m_DamageObjectTableSolo.GetData())
	{
		if(obj->dwData > 0)																	// µ¥¹ÌÁö°¡ ÀÖ´ÂÁö ¿©ºÎ¸¦ Ã¼Å©ÇÑ´Ù.
		{
			if(CPlayer* const pPlayer = (CPlayer *)g_pUserTable->FindUser(obj->dwID))
			{
				if(pPlayer->GetGridID() != m_pMob->GetGridID())
				{
					continue;
				}
				else if(0 == PARTYMGR->GetParty(pPlayer->GetPartyIdx()))
				{
					if( pPlayer->GetID() == m_1stPlayerID )									// Ã¹ µ¥¹ÌÁö¸¦ ÁØ ÇÃ·¹ÀÌ¾î¶ó¸é, 
					{
						DistributeToFirstKiller(
							*pPlayer,
							obj->dwData);
					}
					else
					{
						DistributeToOtherKiller(
							*pPlayer,
							obj->dwData);
					}

					if(CPet* const pPet = PETMGR->GetPet(pPlayer->GetPetItemDbIndex()))
					{
						if( pPlayer->GetLevel() < m_pMob->GetLevel() + byPet_ExpPenaltyLevel )
						{
							pPet->AddExp() ;
						}
					}

					float fDamageRate = (float)obj->dwData / (float)(m_TotalDamage+(m_FirstDamage*0.3f))  ;		// ÃÑ µ¥¹ÌÁö¿¡¼­ ÇÃ·¹ÀÌ¾îÀÇ µ¥¹ÌÁö ¹éºÐÀ²À» ±¸ÇÑ´Ù.

					float fMoney = money * fDamageRate ;									// ¸ó½ºÅÍ°¡ µå¶øÇÑ ¸Ó´Ï¿¡¼­ µ¥¹ÌÁö ºñÀ²·Î ¸Ó´Ï¸¦ ¹Þ´Â´Ù.

					MONEYTYPE dwMoney = (DWORD)fMoney ;										// ¼Ò¼ö ¹ö¸²À¸·Î ¸Ó´Ï °áÁ¤.
					SendMoneyToPerson(pPlayer, dwMoney) ;									// ¸Ó´Ï¸¦ Àü¼ÛÇÑ´Ù.
				}
			}
		}
	}
}

void CDistributer::DistributeToFirstKiller(CPlayer& pPlayer, DWORD dwMyDamage)
{
	if(pPlayer.GetState() == eObjectState_Die)
	{
		return;
	}

	DWORD dwMonsterExp = CalcObtainExp(
		pPlayer.GetLevel(),
		1);

	if( m_TotalDamage < 1 )																	// ÅäÅ» µ¥¹ÌÁö°¡ 1º¸´Ù ÀÛÀ¸¸é,
	{
		m_TotalDamage = 1 ;																	// ÅäÅ» µ¥¹ÌÁö¸¦ 1·Î ¼¼ÆÃÇÑ´Ù.
	}

	float fExpVal_A = (float)(dwMyDamage * 0.3f) ;											// ÀÚ½ÅÀÇ µ¥¹ÌÁö * 0.3
	float fExpVal_B = (float)(dwMyDamage + fExpVal_A) ;										// ÀÚ½ÅÀÇ µ¥¹ÌÁö + fExpVal_A
	float fExpVal_C = (float)(fExpVal_B / (m_TotalDamage+fExpVal_A)) ;						// fExpVal_B / ¸ðµç À¯ÀúÀÇ µ¥¹ÌÁö ÃÑÇÕ
	float fExpVal_D = (float)(fExpVal_C * dwMonsterExp) ;									// fExpVal_C * ¸ó½ºÅÍ °æÇèÄ¡

	// 080102 LYW --- Distributer : ¼Ö·Î ÇÃ·¹ÀÌ¾î °æÇèÄ¡ Ãß°¡ Ã³¸®.
	DWORD dwCurExp = (DWORD)floor(fExpVal_D) ;
	DWORD dwExp = dwCurExp + (DWORD)(dwCurExp*0.15f) ;												// ¹Ý¿Ã¸² ÇÑ °æÇèÄ¡¸¦ ¹Þ´Â´Ù.

	SendToPersonalExp(
		&pPlayer,
		dwExp);

	if( pPlayer.GetLevel() < m_pMob->GetLevel() + PETMGR->GetExpPenaltyLevel() )
	{
		CPet* const petObject = PETMGR->GetPet(
			pPlayer.GetPetItemDbIndex());

		if(petObject)
		{
			petObject->AddExp();
		}
	}

	g_csFamilyManager.SRV_ProcessHonorPoint(
		&pPlayer,
		dwExp);
}

void CDistributer::DistributeToOtherKiller(CPlayer& pPlayer, DWORD dwMyDamage)
{
	DWORD dwMonsterExp = CalcObtainExp(pPlayer.GetLevel(), 1) ;
	int nKillerCount = 1;

	if(m_nTotalKillerCount > 1)
	{
		nKillerCount = m_nTotalKillerCount-1;
	}

	if( m_TotalDamage < 1 )
	{
		m_TotalDamage = 1;
	}

	float fExpVal_A = (float)(m_FirstDamage * 0.3f) ;										// ¼±°ø°ÝÀÚ µ¥¹ÌÁö * 0.3
	float fExpVal_B = (float)(fExpVal_A / (nKillerCount)) ;									// fExpVal_A / (°ø°ÝÀÚ ÃÑ¼ö - 1)
	if( fExpVal_B <= 1 ) fExpVal_B = 1 ;
	float fExpVal_C = (float)(dwMyDamage - fExpVal_B) ;										// ÀÚ½ÅÀÇ µ¥¹ÌÁö - fExpVal_B
	if( fExpVal_C <= 1 ) fExpVal_C = 1 ;
	float fExpVal_D = (float)(fExpVal_C / (m_TotalDamage+fExpVal_A)) ;									// fExpVal_C / ¸ðµç À¯ÀúÀÇ µ¥¹ÌÁö ÃÑÇÕ
	float fExpVal_E = (float)(fExpVal_D * dwMonsterExp) ;									// fExpVal_D * ¸ó½ºÅÍ °æÇèÄ¡.

	DWORD dwCurExp = (DWORD)floor(fExpVal_E);
	DWORD dwExp = dwCurExp + (DWORD)(dwCurExp*0.15f);

	SendToPersonalExp(
		&pPlayer,
		dwExp);

	if( pPlayer.GetLevel() < m_pMob->GetLevel() + PETMGR->GetExpPenaltyLevel() )
	{
		if(CPet* const petObject = PETMGR->GetPet(pPlayer.GetPetItemDbIndex()))
		{
			petObject->AddExp();
		}
	}

	g_csFamilyManager.SRV_ProcessHonorPoint(
		&pPlayer,
		dwExp);
}

void CDistributer::DistributeToPartys(MONEYTYPE money)
{
	m_DamageObjectTableParty.SetPositionHead();

	while(DAMAGEOBJ* const obj = m_DamageObjectTableParty.GetData())
	{
		if(obj->dwData > 0)																	// µ¥¹ÌÁö°¡ ÀÖ´ÂÁö ¿©ºÎ¸¦ Ã¼Å©ÇÑ´Ù.
		{
			if(CParty* const pParty = PARTYMGR->GetParty(obj->dwID))
			{
				if( pParty->GetPartyIdx() == m_1stPartyID )									// Ã¹ µ¥¹ÌÁö¸¦ ÁØ ÆÄÆ¼¶ó¸é, 
				{
					DistributeToFirstParty(
						*pParty,
						obj->dwData);
				}
				else
				{
					DistributeToOtherParty(
						*pParty,
						obj->dwData);
				}

				float fDamageRate = (float)obj->dwData / (float)(m_TotalDamage+(m_FirstDamage*0.3f))  ;			// ÀüÃ¼ µ¥¹ÌÁö¿¡ ´ëÇÑ ÆÄÆ¼ µ¥¹ÌÁöÀÇ ¹éºÐÀ²À» ±¸ÇÑ´Ù.

				float fMoney = money * fDamageRate ;										// ¸ó½ºÅÍ°¡ µå¶øÇÑ ¸Ó´Ï¿¡¼­ µ¥¹ÌÁö ºñÀ²¸¸Å­ ¸Ó´Ï¸¦ ±¸ÇÑ´Ù.

				SendMoneyToPartys(fMoney) ;													// ÆÄÆ¼·Î ¸Ó´Ï¸¦ Àü¼ÛÇÑ´Ù.
			}
		}
	}
}

void CDistributer::DistributeToFirstParty(CParty& pParty, DWORD dwPartyDamage)
{
	LEVELTYPE highLevel = 0;
	LEVELTYPE totalLevel = 0;

	SaveCandidacy(
		pParty);
	GetPartyLevels(
		pParty,
		highLevel,
		totalLevel);

	DWORD dwMonsterExp = CalcObtainExp(highLevel, mPlayerIndexContainer.size()) ;

	if( m_TotalDamage < 1 )
	{
		m_TotalDamage = 1 ;
	}

	float fExpVal_A = (float)(dwPartyDamage * 0.3f) ;										// ÀÚ½ÅÀÇ ÆÄÆ¼µ¥¹ÌÁö * 0.3
	float fExpVal_B = (float)(dwPartyDamage + fExpVal_A) ;									// ÀÚ½ÅÀÇ ÆÄÆ¼µ¥¹ÌÁö + fExpVal_A
	float fExpVal_C = (float)(fExpVal_B / (m_TotalDamage+fExpVal_A)) ;						// fExpVal_B / ¸ðµç ÆÄÆ¼ÀÇ µ¥¹ÌÁö ÃÑÇÕ
	float fExpVal_D = (float)(fExpVal_C * dwMonsterExp) ;									// fExpVal_C * ¸ó½ºÅÍ °æÇèÄ¡.			

	if(mPlayerIndexContainer.empty())
	{
		return;
	}
	else if(1 == mPlayerIndexContainer.size())
	{
		if(CPlayer* const pMember = (CPlayer*)g_pUserTable->FindUser(*mPlayerIndexContainer.begin()))
		{
			if(pMember->GetGridID() != m_pMob->GetGridID())
			{
				return;
			}

			DWORD dwExp = (DWORD)fExpVal_D;
			g_csFamilyManager.SRV_ProcessHonorPoint(pMember, dwExp);

			DWORD dwCurExp = dwExp + (DWORD)(dwExp*0.15f) ;
			SendToPersonalExp(
				pMember,
				dwCurExp);

			if( pMember->GetLevel() < m_pMob->GetLevel() + PETMGR->GetExpPenaltyLevel() )
			{
				CPet* const petObject = PETMGR->GetPet(
					pMember->GetPetItemDbIndex());

				if(petObject)
				{
					petObject->AddExp();
				}
			}
		}
	}
	// º¸»óÀ» ¹ÞÀ» ´Ù¸¥ ÇÃ·¹ÀÌ¾î°¡ ÀÖÀ¸¸é
	else
	{
		BOOL bLevelPenalty = FALSE ;
		LEVELTYPE memberLevel ;
		LEVELTYPE lowLevel = 150 ;
		float fTotalLvWeight = 0 ;

		GetPartyLevels(
			pParty,
			highLevel,
			totalLevel) ;

		for(IndexContainer::const_iterator iterator = mPlayerIndexContainer.begin();
			mPlayerIndexContainer.end() != iterator;
			++iterator)
		{
			if(CPlayer* pMember = (CPlayer*)g_pUserTable->FindUser(*iterator))
			{
				memberLevel = pMember->GetLevel();
				// ·¹º§ºñÁß	= ( »ó¼ö - ( ÃÖ°í·¹º§ - ÀÚ±â·¹º§ ) ) / »ó¼ö
				fTotalLvWeight += abs( (float)( MAX_CHARACTER_LEVEL_NUM - ( highLevel - memberLevel ) ) / (float)MAX_CHARACTER_LEVEL_NUM );
			}
		}

		if( (highLevel - lowLevel) >= 21 ) bLevelPenalty = TRUE ;

		float applyRate = 0.0f ;

		switch(mPlayerIndexContainer.size())
		{
		case 2 : applyRate = 0.50f ;	break ;
		case 3 : applyRate = 0.86f ;	break ;
		case 4 : applyRate = 1.21f ;	break ;
		case 5 : applyRate = 1.58f ;	break ;
		case 6 : applyRate = 1.98f ;	break ;
		case 7 : applyRate = 2.41f ;	break ;
		}

		if( bLevelPenalty )
		{
			applyRate = 0.0f ;
		}

		for(IndexContainer::const_iterator iterator = mPlayerIndexContainer.begin();
			mPlayerIndexContainer.end() != iterator;
			++iterator)
		{
			if(CPlayer* const pMember = (CPlayer*)g_pUserTable->FindUser(*iterator))
			{
				if(pMember->GetGridID() != m_pMob->GetGridID())
				{
					continue;
				}

				memberLevel = pMember->GetLevel();

				// ·¹º§ºñÁß	= ( ( »ó¼ö - ( ÃÖ°í·¹º§ - ÀÚ±â·¹º§ ) ) / »ó¼ö ) / ¸ðµçÆÄÆ¼¿øÀÇ ·¹º§ºñÁß ÃÑÇÕ )
				float fExpA = ( abs( (float)( MAX_CHARACTER_LEVEL_NUM - ( highLevel - memberLevel ) ) / (float)MAX_CHARACTER_LEVEL_NUM ) ) / fTotalLvWeight;
				float fExpB = (fExpVal_D * ( 1.f + applyRate ));
				float fExp = fExpA * fExpB;

				if(fExp > 0)
				{
					DWORD dwExp = (DWORD)fExp;

					g_csFamilyManager.SRV_ProcessHonorPoint(pMember, dwExp);

					if( (highLevel - memberLevel) >= 21 )
					{
						SendToPersonalExp(pMember,1);
					}
					else
					{
						SendToPersonalExp(pMember,dwExp);
					}

					if(CPet* const pPet = PETMGR->GetPet(pMember->GetPetItemDbIndex()))
					{
						if( pMember->GetLevel() < m_pMob->GetLevel() + PETMGR->GetExpPenaltyLevel() )
						{
							pPet->AddExp() ;
						}
					}
				}
			}
		}
	}
}

void CDistributer::DistributeToOtherParty(CParty& pParty, DWORD dwPartyDamage)
{
	LEVELTYPE highLevel = 0;
	LEVELTYPE totalLevel = 0;

	SaveCandidacy(
		pParty);
	GetPartyLevels(
		pParty,
		highLevel,
		totalLevel);

	DWORD dwMonsterExp = CalcObtainExp(highLevel, mPlayerIndexContainer.size());
	int nKillerCount = 1;

	if( m_nTotalKillerCount > 1 )
	{
		nKillerCount = m_TotalDamage -1;
	}

	if( m_TotalDamage < 1 )
	{
		m_TotalDamage = 1;
	}

	float fExpVal_A = (float)(m_FirstDamage * 0.3f) ;										// ¼±°ø°Ý ÆÄÆ¼ µ¥¹ÌÁö * 0.3
	float fExpVal_B = (float)(fExpVal_A / (nKillerCount)) ;									// fExpVal_A / (ÆÄÆ¼ ÃÑ ¼ö - 1)

	if( fExpVal_B <= 1 ) fExpVal_B = 1 ;													// À½¼ö Ã¼Å©¸¦ ÇÑ´Ù.

	float fExpVal_C = (float)(dwPartyDamage - fExpVal_B) ;									// ÀÚ½ÅÀÇ ÆÄÆ¼ µ¥¹ÌÁö - fExpVal_B

	if( fExpVal_C <= 1 ) fExpVal_C = 1 ;													// À½¼ö Ã¼Å©¸¦ÇÑ´Ù.

	float fExpVal_D = (float)(fExpVal_C / (m_TotalDamage+fExpVal_A)) ;						// fExpVal_C / ¸ðµç ÆÄÆ¼ÀÇ µ¥¹ÌÁö ÃÑÇÕ
	float fExpVal_E = (float)(fExpVal_D * dwMonsterExp) ;

	if(mPlayerIndexContainer.empty())
	{
		return;
	}

	if(1 == mPlayerIndexContainer.size())
	{
		if(CPlayer* pMember = (CPlayer*)g_pUserTable->FindUser(*mPlayerIndexContainer.begin()))
		{
			if(pMember->GetGridID() != m_pMob->GetGridID())
			{
				return;
			}

			DWORD dwExp = (DWORD)fExpVal_E ;
			g_csFamilyManager.SRV_ProcessHonorPoint(
				pMember,
				dwExp);
			SendToPersonalExp(
				pMember,
				dwExp);

			if( pMember->GetLevel() < m_pMob->GetLevel() + PETMGR->GetExpPenaltyLevel() )
			{
				if(CPet* const petObject = PETMGR->GetPet(pMember->GetPetItemDbIndex()))
				{
					petObject->AddExp();
				}
			}
		}
	}
	// º¸»óÀ» ¹ÞÀ» ´Ù¸¥ ÇÃ·¹ÀÌ¾î°¡ ÀÖÀ¸¸é
	else
	{
		BOOL bLevelPenalty = FALSE;
		LEVELTYPE memberLevel;
		LEVELTYPE lowLevel = 150;
		float fTotalLvWeight = 0;

		for(IndexContainer::const_iterator iterator = mPlayerIndexContainer.begin();
			mPlayerIndexContainer.end() != iterator;
			++iterator)
		{
			if(CPlayer* const pMember = (CPlayer*)g_pUserTable->FindUser(*iterator))														// ¸â¹ö Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
			{
				memberLevel = pMember->GetLevel();
				// ·¹º§ºñÁß	= ( »ó¼ö - ( ÃÖ°í·¹º§ - ÀÚ±â·¹º§ ) ) / »ó¼ö
				fTotalLvWeight += abs( (float)( MAX_CHARACTER_LEVEL_NUM - ( highLevel - memberLevel ) ) / (float)MAX_CHARACTER_LEVEL_NUM );
			}
		}

		if( (highLevel - lowLevel) >= 21 ) bLevelPenalty = TRUE ;

		float applyRate = 0.0f;

		switch(mPlayerIndexContainer.size())
		{
		case 2 : applyRate = 0.50f ;	break ;
		case 3 : applyRate = 0.86f ;	break ;
		case 4 : applyRate = 1.21f ;	break ;
		case 5 : applyRate = 1.58f ;	break ;
		case 6 : applyRate = 1.98f ;	break ;
		case 7 : applyRate = 2.41f ;	break ;
		}

		if( bLevelPenalty )
		{
			applyRate = 0.0f ;
		}

		for(IndexContainer::const_iterator iterator = mPlayerIndexContainer.begin();
			mPlayerIndexContainer.end() != iterator;
			++iterator)
		{
			if(CPlayer* const pMember = (CPlayer*)g_pUserTable->FindUser(*iterator))
			{
				if(pMember->GetGridID() != m_pMob->GetGridID())
				{
					continue;
				}

				memberLevel = pMember->GetLevel() ;

				// ·¹º§ºñÁß	= ( ( »ó¼ö - ( ÃÖ°í·¹º§ - ÀÚ±â·¹º§ ) ) / »ó¼ö ) / ¸ðµçÆÄÆ¼¿øÀÇ ·¹º§ºñÁß ÃÑÇÕ )
				float fExpA = ( abs( (float)( MAX_CHARACTER_LEVEL_NUM - ( highLevel - memberLevel ) ) / (float)MAX_CHARACTER_LEVEL_NUM ) ) / fTotalLvWeight;
				float fExpB = (fExpVal_E * ( 1.f + applyRate ));
				float fExp = fExpA * fExpB ;

				if(fExp > 0)
				{
					DWORD dwExp = (DWORD)fExp ;
					g_csFamilyManager.SRV_ProcessHonorPoint(pMember, dwExp);

					if( (highLevel - memberLevel) >= 21 )
					{
						SendToPersonalExp(pMember,1);
					}
					else
					{
						SendToPersonalExp(pMember,dwExp);
					}

					if(CPet* const pPet = PETMGR->GetPet(pMember->GetPetItemDbIndex()))
					{
						if( pMember->GetLevel() < m_pMob->GetLevel() + PETMGR->GetExpPenaltyLevel() )
						{
							pPet->AddExp() ;
						}
					}
				}
			}
		}
	}
}

void CDistributer::SendMoneyToPartys(float ChangeValue)
{
	if(mPlayerIndexContainer.empty())
	{
		return;
	}

	float fMoney = ChangeValue / float(mPlayerIndexContainer.size());
	MONEYTYPE dwMoney = (DWORD)fMoney ;

	if(0 == m_pMob)
	{
		return;
	}

	for(IndexContainer::const_iterator iterator = mPlayerIndexContainer.begin();
		mPlayerIndexContainer.end() != iterator;
		++iterator)
	{
		CPlayer* pMember = (CPlayer*)g_pUserTable->FindUser(*iterator) ;						// ¸â¹ö ¾ÆÀÌµð·Î ¸â¹ö Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pMember )																	// ¸â¹ö Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
		{
			if(pMember->GetGridID() != m_pMob->GetGridID())
			{
				continue;
			}

			if( pMember->SetMoney(dwMoney, MONEY_ADDITION, MF_OBTAIN, eItemTable_Inventory,	// °¢ ¸â¹ö¿¡°Ô ¸Ó´Ï¸¦ Àü¼ÛÇÑ´Ù.
				eMoneyLog_GetMonster, m_pMob->GetMonsterKind()) != dwMoney )
			{
				// error msg º¸³½´Ù. Á¦ÇÑ·® ÃÊ°ú
				MSGBASE msg;
				msg.Category = MP_ITEM;
				msg.Protocol = MP_ITEM_MONEY_ERROR;
				msg.dwObjectID = pMember->GetID();

				pMember->SendMsg(&msg, sizeof(msg));
			}
		}
	}
}





//=========================================================================
//	NAME : DistributeItemToKillers
//	DESC : The function to distribute item to killers. 080114 LYW
//=========================================================================
void CDistributer::DistributeItemToKillers() 
{
	BOOL bNoPlayer = FALSE ;
	BOOL bNoParty  = FALSE ;
	DWORD dwEventRewardItem = 0;
	if(m_pMob->GetObjectKind()==eObjectKind_BossMonster)
		dwEventRewardItem = BOSSREWARDSMGR->GetBossEventRewardItem(m_pMob->GetMonsterKind());
	else
		dwEventRewardItem = GAMERESRCMNGR->GetMonsterEventRewardItem(m_pMob->GetMonsterKind());

	// °³ÀÎ ÇÃ·¹ÀÌ¾î Áß ¾ÆÀÌÅÛ È¹µæ ÈÄº¸¸¦ »Ì´Â´Ù.

	DWORD dwBigPlayerDamage = 0 ;																// °¡Àå Å« °³ÀÎ µ¥¹ÌÁö¸¦ ´ãÀ» º¯¼ö.
	DWORD dwBigPlayerID = 0 ;																	// °¡Àå Å« µ¥¹ÌÁö¸¦ ÁØ ÇÃ·¹ÀÌ¾î ¾ÆÀÌµð¸¦ ´ãÀ» º¯¼ö.

	m_DamageObjectTableSolo.SetPositionHead() ;													// µ¥¹ÌÁö Å×ÀÌºíÀ» ÇØµå·Î ¼¼ÆÃÇÑ´Ù.

	while(const DAMAGEOBJ* const obj = m_DamageObjectTableSolo.GetData())
	{
		CPlayer* const pPlayer = (CPlayer*)g_pUserTable->FindUser(obj->dwID);

		if( !pPlayer ) continue ;																// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.

		if( pPlayer->GetState() == eObjectState_Die ) continue ;								// ÇÃ·¹ÀÌ¾î°¡ Á×¾ú´Ù¸é, ´ë»ó¿¡¼­ Á¦¿Ü ½ÃÅ²´Ù.

		// 090702 - NYJ º¸»ó¾ÆÀÌÅÛÀÌ ÀÖ´Â°æ¿ì ¸ðµÎ¿¡°Ô ÁØ´Ù.
		if(dwEventRewardItem)
			ITEMMGR->ObtainGeneralItem(pPlayer, dwEventRewardItem, 1, eLog_ItemObtainMonster, MP_ITEM_MONSTER_OBTAIN_NOTIFY);

		if(0 == PARTYMGR->GetParty(pPlayer->GetPartyIdx()))
		{
			ChooseOne(
				*obj,
				dwBigPlayerDamage,
				dwBigPlayerID);
		}
	}

	if( dwBigPlayerDamage == 0 ) bNoPlayer = TRUE ;												// ¾ÆÀÌÅÛ ½ÀÆ¯ ÈÄº¸¿¡ °³ÀÎ ÇÃ·¹ÀÌ¾î°¡ ¾ø´Ù.

	// ÆÄÆ¼ Áß ¾ÆÀÌÅÛ È¹µæ ÆÄÆ¼¸¦ »Ì´Â´Ù.

	DWORD dwBigPartyDamage = 0 ;																// °¡Àå Å« ÆÄÆ¼ µ¥¹ÌÁö¸¦ ´ãÀ» º¯¼ö.
	DWORD dwBigPartyID = 0 ;																	// °¡Àå Å« ÆÄÆ¼ Å×¹ÌÁö¸¦ ÁØ ÆÄÅ¸ ¾ÆÀÌµð¸¦ ´ãÀ» º¯¼ö.

	m_DamageObjectTableParty.SetPositionHead() ;												// µ¥¹ÌÁö Å×ÀÌºíÀ» ÇØµå·Î ¼¼ÆÃÇÑ´Ù.

	while(const DAMAGEOBJ* const obj = m_DamageObjectTableParty.GetData())
	{
		ChooseOne(
			*obj,
			dwBigPartyDamage,
			dwBigPartyID);
	}

	if( dwBigPartyDamage == 0 ) bNoParty = TRUE ;

	if( bNoPlayer && bNoParty ) return;

	if( !bNoPlayer && !bNoParty )
	{
		// ÆÄÆ¼¿Í °³ÀÎÀÇ µ¥¹ÌÁö¸¦ ºñ±³ÇÑ´Ù.
		if( dwBigPlayerDamage == dwBigPartyDamage )													// °³ÀÎÀÇ µ¥¹ÌÁö¿Í ÆÄÆ¼ÀÇ µ¥¹ÌÁö°¡ °°´Ù¸é,
		{
			int nResult = random(0, 100) ;															// ·£´ý ¼ö¸¦ ±¸ÇÑ´Ù.

			if( nResult < 50 )																		// ·£´ý ¼ö°¡ 50¹Ì¸¸ÀÌ¸é, 
			{
				dwBigPlayerDamage = 0 ;																// ÆÄÆ¼¿¡°Ô ¾ÆÀÌÅÛÀ» µ¹¸°´Ù.
				dwBigPartyDamage  = 1 ;
			}
			else																					// ·£´ý ¼ö°¡ 50À» ÃÊ°úÇÏ¸é,
			{
				dwBigPlayerDamage = 1 ;																// °³ÀÎ¿¡°Ô ¾ÆÀÌÅÛÀ» µ¹¸°´Ù.
				dwBigPartyDamage  = 0 ;
			}
		}

		if( dwBigPlayerDamage > dwBigPartyDamage )													// °³ÀÎÀÇ µ¥¹ÌÁö°¡ ÆÄÆ¼ÀÇ µ¥¹ÌÁö º¸´Ù Å©¸é,
		{
			if(CPlayer* const pPlayer = (CPlayer*)g_pUserTable->FindUser(dwBigPlayerID))
			{
				SendItemToPerson(pPlayer) ;															// °¡Àå Å« µ¥¹ÌÁö¸¦ ÁØ ÇÃ·¹ÀÌ¾î¿¡°Ô ¾ÆÀÌÅÛÀ» Àü¼ÛÇÑ´Ù.
			}
		}
		else if( dwBigPlayerDamage < dwBigPartyDamage )												// ÆÄÆ¼ µ¥¹ÌÁö°¡ °³ÀÎÀÇ µ¥¹ÌÁö º¸´Ù Å©¸é,
		{
			if(CParty* const pParty = PARTYMGR->GetParty(dwBigPartyID))
			{
				SaveCandidacy(
					*pParty);

				switch(pParty->GetOption())															// ÆÄÆ¼ÀÇ ¾ÆÀÌÅÛ ºÐ¹è ¹æ½ÄÀ» ¹Þ¾Æ¿Â´Ù.
				{
				case ePartyOpt_Sequence : DistribuSequence(*pParty); break;
				case ePartyOpt_Damage :	  DistributeDamage(); break;
				}
			}
		}
	}
	else
	{
		if( bNoPlayer )
		{
			if(CParty* const pParty = PARTYMGR->GetParty(dwBigPartyID))
			{
				SaveCandidacy(
					*pParty);

				switch(pParty->GetOption())															// ÆÄÆ¼ÀÇ ¾ÆÀÌÅÛ ºÐ¹è ¹æ½ÄÀ» ¹Þ¾Æ¿Â´Ù.
				{
				case ePartyOpt_Sequence : DistribuSequence(*pParty); break;
				case ePartyOpt_Damage :	  DistributeDamage(); break;
				}
			}
		}
		else if( bNoParty )
		{
			if(CPlayer* const pPlayer = (CPlayer*)g_pUserTable->FindUser(dwBigPlayerID))
			{
				SendItemToPerson(pPlayer) ;															// °¡Àå Å« µ¥¹ÌÁö¸¦ ÁØ ÇÃ·¹ÀÌ¾î¿¡°Ô ¾ÆÀÌÅÛÀ» Àü¼ÛÇÑ´Ù.
			}
		}
	}	
}

void CDistributer::DistributeToKiller()
{
	if( m_pKiller )																				// Å³·¯ Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
	{
		if(0 == PARTYMGR->GetParty(m_pKiller->GetPartyIdx()))
		{
			DistributeToPerson(
				*m_pKiller);
		}
		else																					// Å³·¯°¡ ÆÄÆ¼¿¡ ¼ÓÇØÀÖ´Ù¸é,
		{
			DistributeToParty(
				*m_pKiller);
		}
	}
}

void CDistributer::DistributeToPerson(CPlayer& pPlayer)
{
	if(m_pMob)
	{
		if(pPlayer.GetGridID() != m_pMob->GetGridID())
		{
			return;
		}
		else if(pPlayer.GetState() == eObjectState_Die)
		{
			return;
		}

		DWORD dwCur = CalcObtainExp(pPlayer.GetLevel(), 1);
		EXPTYPE dwExp = dwCur + (EXPTYPE)(dwCur * 0.15f);
		int nPenaltyType = GetLevelPenaltyToMonster(m_HighLevel);
		MONEYTYPE money = ITEMDROP_OBJ->DropMoney(
			m_pMob->GetSMonsterList(),
			nPenaltyType);

		g_csFamilyManager.SRV_ProcessHonorPoint(
			&pPlayer,
			DWORD(dwExp));
		SendToPersonalExp(
			&pPlayer,
			dwExp);

		if( pPlayer.GetLevel() < m_pMob->GetLevel() + PETMGR->GetExpPenaltyLevel() )
		{
			if(CPet* const petObject = PETMGR->GetPet(pPlayer.GetPetItemDbIndex()))
			{
				petObject->AddExp();
			}
		}

		SendMoneyToPerson(
			&pPlayer,
			money);
		SendItemToPerson(
			&pPlayer);

		if(DWORD dwEventRewardItem = GAMERESRCMNGR->GetMonsterEventRewardItem(m_pMob->GetMonsterKind()))
		{
			ITEMMGR->ObtainGeneralItem(
				&pPlayer,
				dwEventRewardItem,
				1,
				eLog_ItemObtainMonster,
				MP_ITEM_MONSTER_OBTAIN_NOTIFY);
		}

		// 081027 LUJ, Æ¯¼ö ¸ó½ºÅÍÀÏ °æ¿ì È¹µæÇÑ °æÇèÄ¡¸¦ ·Î±×¿¡ ³²±ä´Ù
		switch( m_pMob->GetObjectKind() )
		{
		case eObjectKind_BossMonster:
		case eObjectKind_FieldBossMonster:
		case eObjectKind_FieldSubMonster:
			{
				InsertLogExp(
					eExpLog_Get,
					pPlayer.GetID(),
					pPlayer.GetLevel(),
					dwExp,
					pPlayer.GetPlayerExpPoint(),
					m_pMob->GetMonsterKind(),
					m_pMob->GetObjectKind(),
					0 );
				break;
			}
		}
	}
}

void CDistributer::DistributeToParty(CPlayer& pPlayer)
{	
	if( !m_pMob ) return ;

	if(CParty* pParty = PARTYMGR->GetParty(pPlayer.GetPartyIdx()))
	{
		SaveCandidacy(
			*pParty);

		if(mPlayerIndexContainer.empty())
		{
			return;
		}
		else if(1 == mPlayerIndexContainer.size())
		{
			DistributeToPerson(
				pPlayer);
			return;
		}
		// º¸»óÀ» ¹ÞÀ» ´Ù¸¥ ÇÃ·¹ÀÌ¾î°¡ ÀÖÀ¸¸é
		else
		{
			DWORD dwEventRewardItem = GAMERESRCMNGR->GetMonsterEventRewardItem(m_pMob->GetMonsterKind());
			BOOL bLevelPenalty = FALSE;
			LEVELTYPE highLevel = 0;
			LEVELTYPE totalLevel = 0;
			LEVELTYPE lowLevel = 150;
			LEVELTYPE memberLevel = 0;
			float fTotalLvWeight = 0;

			GetPartyLevels(
				*pParty,
				highLevel,
				totalLevel);

			for(IndexContainer::const_iterator iterator = mPlayerIndexContainer.begin();
				mPlayerIndexContainer.end() != iterator;
				++iterator)
			{
				const DWORD playerIndex = *iterator;

				if(CPlayer* const pMember = (CPlayer*)g_pUserTable->FindUser(playerIndex))
				{
					// 090702 - NYJ º¸»ó¾ÆÀÌÅÛÀÌ ÀÖ´Â°æ¿ì µ¥¹ÌÁö¸¦ ÁØ ÈÄº¸¸¸ ÁØ´Ù.
					if(dwEventRewardItem)
					{
						if(DAMAGEOBJ* const obj = m_DamageObjectTableSolo.GetData(playerIndex))
						{
							ITEMMGR->ObtainGeneralItem(pMember, dwEventRewardItem, 1, eLog_ItemObtainMonster, MP_ITEM_MONSTER_OBTAIN_NOTIFY);
						}
					}

					memberLevel = pMember->GetLevel() ;
					// ·¹º§ºñÁß	= ( »ó¼ö - ( ÃÖ°í·¹º§ - ÀÚ±â·¹º§ ) ) / »ó¼ö
					fTotalLvWeight += abs( (float)( MAX_CHARACTER_LEVEL_NUM - ( highLevel - memberLevel ) ) / (float)MAX_CHARACTER_LEVEL_NUM );
				}
			}

			// 091123 ONS Ã§¸°ÁöÁ¸ °æÇèÄ¡ ºÐ¹è Ã³¸® Ãß°¡ : Ã§¸°ÁöÁ¸ÀÏ°æ¿ì ÆÐ³ÎÆ¼¸¦ ÁÖÁö ¾Ê´Â´Ù.
			BOOL bIsChallengeZone = FALSE;

			if(g_csDateManager.IsChallengeZoneHere())
			{
				bIsChallengeZone = TRUE;
			}

			if( ((highLevel - lowLevel) >= 21) && !bIsChallengeZone ) bLevelPenalty = TRUE ;

			DWORD partyexp = CalcObtainExp(highLevel, mPlayerIndexContainer.size());
			float applyRate = 0.0f;

			switch(mPlayerIndexContainer.size())
			{
			case 2 : applyRate = 0.50f ;	break ;
			case 3 : applyRate = 0.86f ;	break ;
			case 4 : applyRate = 1.21f ;	break ;
			case 5 : applyRate = 1.58f ;	break ;
			case 6 : applyRate = 1.98f ;	break ;
			case 7 : applyRate = 2.41f ;	break ;
			}

			if( bLevelPenalty )
			{
				applyRate = 0.0f ;
			}

			const int nPenaltyType = GetLevelPenaltyToMonster(m_HighLevel);
			const MONEYTYPE money = ITEMDROP_OBJ->DropMoney(
				m_pMob->GetSMonsterList(),
				nPenaltyType);
			const MONEYTYPE ObtainMoney = money / mPlayerIndexContainer.size();

			for(IndexContainer::const_iterator iterator = mPlayerIndexContainer.begin();
				mPlayerIndexContainer.end() != iterator;
				++iterator)
			{
				if(CPlayer* const pMember = (CPlayer*)g_pUserTable->FindUser(*iterator))
				{
					if(pMember->GetGridID() != m_pMob->GetGridID())
					{
						continue;
					}

					float fDistributedExp = 0.0f;

					if( bIsChallengeZone )
					{
						float fExpRate = ((float)pMember->GetChallengeZoneExpRate()) * 0.01f;
						fDistributedExp = (partyexp * ( 1.f + applyRate )) * fExpRate;
					}
					else
					{
						int nPersonPenaltyType = GetLevelPenaltyToMonster(pMember->GetLevel());
						if(nPersonPenaltyType == 3)
						{
							SendToPersonalExp(pMember,1);
							continue;
						}

						memberLevel = pMember->GetLevel();

						// ·¹º§ºñÁß	= ( ( »ó¼ö - ( ÃÖ°í·¹º§ - ÀÚ±â·¹º§ ) ) / »ó¼ö ) / ¸ðµçÆÄÆ¼¿øÀÇ ·¹º§ºñÁß ÃÑÇÕ )
						float fExpA = ( abs( (float)( MAX_CHARACTER_LEVEL_NUM - ( highLevel - memberLevel ) ) / (float)MAX_CHARACTER_LEVEL_NUM ) ) / fTotalLvWeight;
						float fExpB = (partyexp * ( 1.f + applyRate )) ;				// °æÇèÄ¡ Æ÷ÀÎÆ®B¸¦ ±¸ÇÑ´Ù.
						fDistributedExp = fExpA * fExpB ;
					}

					if(fDistributedExp >= 1.0f)
					{
						DWORD dwExp = (DWORD)fDistributedExp;

						if( ((highLevel - memberLevel) >= 21) && !bIsChallengeZone )
						{
							SendToPersonalExp(pMember,1);
						}
						else
						{
							SendToPersonalExp(pMember,dwExp);
						}


						if(CPet* const pPet = PETMGR->GetPet(pMember->GetPetItemDbIndex()))
						{
							if( pMember->GetLevel() < m_pMob->GetLevel() + PETMGR->GetExpPenaltyLevel() )
							{
								pPet->AddExp() ;
							}
						}

						g_csFamilyManager.SRV_ProcessHonorPoint(
							&pPlayer,
							dwExp);
						SendMoneyToPerson(
							pMember,
							ObtainMoney);
					}
				}
			}

			SaveCandidacy(
				*pParty);

			switch(pParty->GetOption())
			{
			case ePartyOpt_Sequence : DistribuSequence(*pParty); break;
			case ePartyOpt_Damage :	  DistributeDamage(); break;
			}
		}
	}
}

void CDistributer::SendMoneyToPerson(CPlayer* pPlayer, MONEYTYPE ChangeValue)
{
	if( pPlayer && m_pMob )																		// ÇÃ·¹ÀÌ¾î¿Í ¸ó½ºÅÍÀÇ Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
	{
		if(pPlayer->GetGridID() != m_pMob->GetGridID())
		{
			return;
		}

		MONEYTYPE eventValue = (MONEYTYPE)(gEventRate[eEvent_MoneyRate] * ChangeValue);

		// ¸Ó´Ï¸¦ ÇÃ·¹ÀÌ¾î¿¡°Ô Àü¼ÛÇÑ´Ù.
		if( pPlayer->SetMoney(eventValue, MONEY_ADDITION, MF_OBTAIN, eItemTable_Inventory, eMoneyLog_GetMonster, m_pMob->GetMonsterKind()) != eventValue )
		{
			// error msg º¸³½´Ù. Á¦ÇÑ·® ÃÊ°ú
			MSGBASE msg;
			msg.Category = MP_ITEM;
			msg.Protocol = MP_ITEM_MONEY_ERROR;
			msg.dwObjectID = pPlayer->GetID();
			
			pPlayer->SendMsg(&msg, sizeof(msg));
		}
	}
}

void CDistributer::SendItemToPerson(CPlayer* pPlayer)
{
	if( !pPlayer || !m_pMob ) return ;															// ÇÃ·¹ÀÌ¾î¿Í ¸ó½ºÅÍ Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.

	if(pPlayer->GetGridID() != m_pMob->GetGridID())
	{
		return;
	}

	int nMaxItemCount = eDROPITEMKIND_MAX-1;
	const BASE_MONSTER_LIST& baseMonsterList = m_pMob->GetSMonsterList();
	BOOL bObtainItem = FALSE;

	if( m_HighLevel <= 0 )																		// È¤½Ã¶óµµ ÃÖ°í·¹º§ÀÇ °ªÀÌ ¹®Á¦°¡ ÀÖ´Ù¸é,
	{
		m_HighLevel = pPlayer->GetMaxLevel() ;													// ÃÖ°í ·¹º§À» ÇÃ·¹ÀÌ¾îÀÇ MAX·¹º§·Î ¼¼ÆÃÇÑ´Ù.
	}

	int nPenaltyType = GetLevelPenaltyToMonster(m_HighLevel) ;									// ¸ó½ºÅÍ¿Í ·¹º§Â÷¿¡ µû¸¥ ÆÐ³ÎÆ¼ °ªÀ» ¹Þ´Â´Ù.

	// 090818 ShinJS --- GM-Tool Monster Regen Item Drop ¼³Á¤½Ã
	if( m_dwDropItemID )
	{
		// ¼³Á¤µÈ È®·ü °Ë»ç
		if( m_dwDropItemRatio > DWORD( rand() % 100 ) )
		{
			ITEMMGR->MonsterObtainItem(
				pPlayer,
				m_dwDropItemID,
				m_pMob->GetMonsterKind(),
				1);
		}

		m_dwDropItemID = 0;
		m_dwDropItemRatio = 0;
	}

	if( nPenaltyType == 3 ) return ;															// ÆÐ³ÎÆ¼ °ªÀÌ 3, 21·¹º§ ÀÌ»ó Â÷ÀÌ³ª¸é ¾ÆÀÌÅÛ µå¶øÀº ¾ø´Ù.

	if( m_pMob->GetObjectKind() == eObjectKind_FieldBossMonster )
	{
		return;
	}

	for( int count = 0 ;  count < nMaxItemCount ; ++count )
	{
		if(ITEMDROP_OBJ->DropItem(
			m_pMob->GetMonsterKind(),
			baseMonsterList.dropItem[count],
			pPlayer,
			nPenaltyType))
		{
			bObtainItem = TRUE;
		}
	}

	if( bObtainItem )																			// ¾ÆÀÌÅÛ ÇÒ´çÀÌ ÀÌ·ç¾î Á³´Ù¸é, 
	{
		CParty* pParty = PARTYMGR->GetParty(pPlayer->GetPartyIdx() ) ;							// ÆÄÆ¼ Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pParty )																			// ÆÄÆ¼ Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
		{
			BYTE winnerIdx = pParty->GetWinnerIdx() ;											// ´çÃ·ÀÚ ¹øÈ£¸¦ ¹Þ´Â´Ù.
			
			if(winnerIdx == MAX_PARTY_LISTNUM-1 )												// ´çÃ· ¹øÈ£ ·çÇÁÀÇ ¸¶Áö¸·ÀÎÁö Ã¼Å©ÇÑ´Ù.
			{
				pParty->SetWinnerIdx(0) ;														// ´çÃ· ¹øÈ£¸¦ Ã³À½À¸·Î ¼¼ÆÃÇÑ´Ù.
			}
			else																				// ·çÇÁÀÇ ¸¶Áö¸·ÀÌ ¾Æ´Ï¸é, 
			{
				pParty->SetWinnerIdx(++winnerIdx) ;												// ´çÃ· ¹øÈ£¸¦ Áõ°¡ÇÑ´Ù.						
			}
		}
	}
}

DWORD CDistributer::CalcObtainExp(LEVELTYPE KillerLevel, int nMemberCount)
{
	if(NULL == m_pMob)
	{
		return 0;
	}

	DWORD dwExp = m_pMob->GetSMonsterList().ExpPoint;

	if(m_pMob->GetObjectKind() == eObjectKind_BossMonster)
	{
		dwExp = (DWORD)BOSSREWARDSMGR->GetExpOfBossMonster(m_pMob->GetMonsterKind());
	}

	const LEVELTYPE MonsterLevel = m_pMob->GetSMonsterList().Level;
	const LEVELTYPE levelGap = (MonsterLevel > KillerLevel ? MonsterLevel - KillerLevel : KillerLevel - MonsterLevel);																// ¸ó½ºÅÍ¿Í ÇÃ·¹ÀÌ¾îÀÇ ·¹º§ Â÷ÀÌ.

	if( MonsterLevel > KillerLevel + 15 )
	{
		if( m_pMob->GetObjectKind() == eObjectKind_BossMonster )
		{
			//if(MonsterLevel > KillerLevel+16)
			if(MonsterLevel > KillerLevel+20)													// ¸ó½ºÅÍ ·¹º§ÀÌ ÇÃ·¹ÀÌ¾î ·¹º§ º¸´Ù 21·¹º§ ÀÌ»óÀÏ ¶§ °æÇèÄ¡ 1 Àû¿ë
				return 1;
			else
				return dwExp ;
		}

		double dwLevel = KillerLevel ;												// ·¹º§ Æ÷ÀÎÆ® ¼¼ÆÃ.
		// 080116 LYW --- Distributer : HP°¡ Àý¹ÝÀÎ ¸ó½ºÅÍ¸¦ Àâ¾ÒÀ» ¶§, È¹µæ °æÇèÄ¡ º¸Á¤ Ã³¸®.
		double dwPenalty = 1.95f ;																// Æä³ÎÆ¼ Æ÷ÀÎÆ® ¼¼ÆÃ.
		double result = pow(dwLevel, dwPenalty) ;												// ·¹º§ Æ÷ÀÎÆ® ^ Æä³ÎÆ¼ Æ÷ÀÎÆ®¸¦ ±¸ÇÑ´Ù.

		float fExp = (float)(result + 15) ;														// ÇÃ·ÎÆ®ÇüÀÇ Å©±â ³»¿¡¼­ °æÇèÄ¡¸¦ ±¸ÇÑ´Ù.

		if( fExp > dwExp )
		{
			return dwExp ;
		}
		else
		{
			return (DWORD)floor(fExp) ;															// °æÇèÄ¡¸¦ ¹Ý¿Ã¸² ÇÏ¿© DWORDÇüÀ¸·Î ¹ÝÈ¯.
		}
	}
	else if( MonsterLevel < KillerLevel )														// ÇÃ·¹ÀÌ¾î ·¹º§ÀÌ ¸ó½ºÅÍ ·¹º§º¸´Ù Å« °æ¿ì.
	{
		float fPenalty = 1.0f ;																	// Æä³ÎÆ¼ Æ÷ÀÎÆ®.
		float fExp     = 0.0f ;																	// ÇÃ·ÎÆ®Çü °æÇèÄ¡.

		// 080116 LYW --- Distributer : µ¥ÀÌÆ® ¸ÅÄª Á¸ÀÏ °æ¿ì¿¡´Â ÆÐ³ÎÆ¼¸¦ ÁÖÁö ¾Ê´Â´Ù.
		if (!g_csDateManager.IsChallengeZoneHere())
		{
			// 091023 pdy ¸ó½ºÅÍ ·¹º§ ÆÐ³ÎÆ¼ ±âÁØ , ÆÄÆ¼ º¸³Ê½º °æÇèÄ¡ ±âÈ¹ º¯°æ
			if( levelGap >= 8 && levelGap <= 15 )												// ÇÃ·¹ÀÌ¾î ·¹º§ÀÌ +8~+15ÀÏ ¶§.
			{
				fPenalty = 0.5f ;																// Æä³ÎÆ¼ Æ÷ÀÎÆ® 50%·Î ¼¼ÆÃ
			}
			else if( levelGap >= 16 && levelGap <= 20 )											// ÇÃ·¹ÀÌ¾î ·¹º§ÀÌ +15~+20ÀÏ ¶§.
			{
				fPenalty = 0.25f ;																// Æä³ÎÆ¼ Æ÷ÀÎÆ® 25%·Î ¼¼ÆÃ.
			}
			else if( levelGap >= 21 )															// ÇÃ·¹ÀÌ¾î ·¹º§ÀÌ +21 ÀÌ»óÀÏ ¶§.
			{
				return 1 ;																		// °æÇèÄ¡´Â ¹«Á¶°Ç 1·Î ¹ÝÈ¯ÇÑ´Ù.
			}
		}

		fExp = (float)(dwExp * fPenalty) ;														// °æÇèÄ¡¸¦ ÇÃ·ÎÆ®ÇüÀ¸·Î ±¸ÇÑ´Ù.

		return (DWORD)floor(fExp) ;																// DWORDÇüÀ¸·Î Æä³ÎÆ¼ °æÇèÄ¡ ¹ÝÈ¯.
	}	
	else																						// ¸ó½ºÅÍ¿Í ÇÃ·¹ÀÌ¾î ·¹º§ÀÌ °°À» ¶§.
	{
		return dwExp ;																			// ÇÃ·¹ÀÌ¾î¿Í ¸ó½ºÅÍÀÇ ·¹º§ÀÌ °°À»°æ¿ì ¸ó½ºÅÍ °æÇèÄ¡ ¹ÝÈ¯.			
	}
}

BOOL CDistributer::GetFirstDamange()
{
	m_FirstDamage = 0 ;																			// Ã¹ µ¥¹ÌÁö º¯¼ö¸¦ 0À¸·Î ¼¼ÆÃÇÑ´Ù.
	
	CPlayer* pPlayer = (CPlayer *)g_pUserTable->FindUser(m_1stPlayerID) ;						// Ã¹ µ¥¹ÌÁö¸¦ ÁØ ÇÃ·¹ÀÌ¾î Á¤º¸¸¦ ¹Þ´Â´Ù.

	if( pPlayer )																				// ÇÃ·¹ÀÌ¾î Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
	{
		DAMAGEOBJ* pDObj = NULL ;																// µ¥¹ÌÁö Á¤º¸¸¦ ´ãÀ» Æ÷ÀÎÅÍ º¯¼ö¸¦ ¼±¾ðÇÑ´Ù.

		CParty* pParty = PARTYMGR->GetParty(pPlayer->GetPartyIdx()) ;							// ÇÃ·¹ÀÌ¾îÀÇ ÆÄÆ¼Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( pParty )																			// ÆÄÆ¼¿¡ ¼ÓÇØÀÖ´Ù¸é,
		{
			pDObj = m_DamageObjectTableParty.GetData(pParty->GetPartyIdx()) ;					// ÆÄÆ¼ÀÇ µ¥¹ÌÁö Á¤º¸¸¦ ¹Þ´Â´Ù.

			if( pDObj )																			// µ¥¹ÌÁö Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
			{
				m_FirstDamage = pDObj->dwData ;													// Ã¹ µ¥¹ÌÁö¸¦ ¼¼ÆÃÇÑ´Ù.

				return TRUE ;																	// ¸®ÅÏ TRUE.
			}
		}
		else																					// ÆÄÆ¼¿¡ ¼ÓÇØÀÖÁö ¾Ê´Ù¸é,
		{
			pDObj = m_DamageObjectTableSolo.GetData(pPlayer->GetID()) ;							// ÇÃ·¹ÀÌ¾îÀÇ µ¥¹ÌÁö Á¤º¸¸¦ ¹Þ´Â´Ù.

			if( pDObj )																			// µ¥¹ÌÁö Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
			{
				m_FirstDamage = pDObj->dwData ;													// Ã¹ µ¥¹ÌÁö¸¦ ¼¼ÆÃÇÑ´Ù.

				return TRUE ;																	// ¸®ÅÏ TRUE.
			}
		}
	}

	return FALSE ;																				// ¸®ÅÏ FALSE.
}

void CDistributer::GetTotalKillerCount()
{
	m_nTotalKillerCount = 0;

	m_DamageObjectTableSolo.SetPositionHead() ;													// °³ÀÎ µ¥¹ÌÁö Å×ÀÌºí Ã¼Å©.

	while(const DAMAGEOBJ* const obj = m_DamageObjectTableSolo.GetData())
	{
		if(obj->dwData > 0)																	// µ¥¹ÌÁö°¡ ÀÖ´ÂÁö ¿©ºÎ¸¦ Ã¼Å©ÇÑ´Ù.
		{
			if(CPlayer* const pPlayer = (CPlayer *)g_pUserTable->FindUser(obj->dwID))
			{
				if(0 == PARTYMGR->GetParty(pPlayer->GetPartyIdx()))
				{
					++m_nTotalKillerCount ;													// ¼Ö·Î ÇÃ·¹ÀÌ¾î ¼ö¸¦ ´Ã¸°´Ù.
				}
			}
			// 091111 pdy ÆÄÆ¼ µ¥¹ÌÁö »êÁ¤ ¹æ½ÄÀ» ¸ó½ºÅÍ º¸»ó½Ã¿¡ ÇÑ¹ø °è»ê ÇÏµµ·Ï º¯°æ
			else
			{
				++m_nTotalKillerCount ;														// Á¢¼ÓÀ» ²÷Àº ÇÃ·¹ÀÌ¾î ÆÄÆ¼¿ø¸ðµÎ ¼Ö·Î ÇÃ·¹ÀÌ¾î·Î °£ÁÖÇÏ°í ¼ö¸¦ ´Ã¸°´Ù.
			}
		}
	}

	m_DamageObjectTableParty.SetPositionHead() ;												// ÆÄÆ¼ Å×ÀÌºí Ã¼Å©.

	while(const DAMAGEOBJ* const obj = m_DamageObjectTableParty.GetData())
	{
		if(obj->dwData > 0)																	// µ¥¹ÌÁö°¡ ÀÖ´ÂÁö ¿©ºÎ¸¦ Ã¼Å©ÇÑ´Ù.
		{
			if(PARTYMGR->GetParty(obj->dwID))
			{
				++m_nTotalKillerCount ;														// ¼Ö·Î ÇÃ·¹ÀÌ¾î ¼ö¸¦ ´Ã¸°´Ù.
			}
		}
	}
}

void CDistributer::GetHighLevelOfKillers()
{
	m_nTotalKillerCount = 0;

	m_DamageObjectTableSolo.SetPositionHead() ;													// °³ÀÎ µ¥¹ÌÁö Å×ÀÌºí Ã¼Å©.

	while(const DAMAGEOBJ* const obj = m_DamageObjectTableSolo.GetData())
	{
		if(obj->dwData > 0)																	// µ¥¹ÌÁö°¡ ÀÖ´ÂÁö ¿©ºÎ¸¦ Ã¼Å©ÇÑ´Ù.
		{
			if(CPlayer* const pPlayer = (CPlayer *)g_pUserTable->FindUser(obj->dwID))
			{
				if(0 == PARTYMGR->GetParty(pPlayer->GetPartyIdx()))
				{
					//090402 pdy ¸ó½ºÅÍ º¸»ó°ü·Ã ·¹º§Ã¼Å© ¼öÁ¤ 
					//LEVELTYPE playerLevel = pPlayer->GetLevel() ;							// ÇÃ·¹ÀÌ¾îÀÇ ·¹º§À» ¹Þ´Â´Ù.
					LEVELTYPE playerLevel = pPlayer->GetMaxLevel() ;

					if( playerLevel > m_HighLevel )											// ÇÃ·¹ÀÌ¾îÀÇ ·¹º§ÀÌ ÃÖ°í ·¹º§º¸´Ù Å©´Ù¸é,
					{
						m_HighLevel = playerLevel ;											// ÃÖ°í ·¹º§¿¡ ÇÃ·¹ÀÌ¾î ·¹º§À» ¼¼ÆÃÇÑ´Ù.
					}
				}
			}
		}
	}

	m_DamageObjectTableParty.SetPositionHead() ;												// ÆÄÆ¼ µ¥¹ÌÁö Å×ÀÌºí Ã¼Å©.

	while(DAMAGEOBJ* const obj = m_DamageObjectTableParty.GetData())
	{
		if(obj->dwData > 0)																	// µ¥¹ÌÁö°¡ ÀÖ´ÂÁö ¿©ºÎ¸¦ Ã¼Å©ÇÑ´Ù.
		{
			if(CParty* const pParty = PARTYMGR->GetParty(obj->dwID))
			{
				LEVELTYPE highLevel = 0 ;													// 
				LEVELTYPE totalLevel = 0 ;

				GetPartyLevels(
					*pParty,
					highLevel,
					totalLevel,
					eGET_MAXLEVEL);

				if( highLevel > m_HighLevel )												// ÇÃ·¹ÀÌ¾îÀÇ ·¹º§ÀÌ ÃÖ°í ·¹º§º¸´Ù Å©´Ù¸é,
				{
					m_HighLevel = highLevel ;												// ÃÖ°í ·¹º§¿¡ ÇÃ·¹ÀÌ¾î ·¹º§À» ¼¼ÆÃÇÑ´Ù.
				}
			}
		}
	}
}

int CDistributer::GetLevelPenaltyToMonster(LEVELTYPE level) 
{

	if (g_csDateManager.IsChallengeZoneHere())
	{
		return 0;
	}

	LEVELTYPE MonsterLevel = m_pMob->GetSMonsterList().Level;
	LEVELTYPE levelGap = 0;
	
	if( MonsterLevel <= level )																	// ¸ó½ºÅÍ ·¹º§ÀÌ ÇÃ·¹ÀÌ¾î º¸´Ù Å« °æ¿ì.
	{
		levelGap = level - MonsterLevel ;														// ·¹º§ Â÷ÀÌ¸¦ ±¸ÇÑ´Ù.
	}

	// 091023 pdy ¸ó½ºÅÍ ·¹º§ ÆÐ³ÎÆ¼ ±âÁØ , ÆÄÆ¼ º¸³Ê½º °æÇèÄ¡ ±âÈ¹ º¯°æ
	if( levelGap > 7 && levelGap < 16 )															// ·¹º§Â÷ÀÌ°¡ 8~15ÀÌ¸é, 
	{
		return 1;
	}
	else if( levelGap > 15 && levelGap < 21 )													// ·¹º§Â÷ÀÌ°¡ 16~20ÀÌ¸é, 
	{
		return 2;
	}
	else if( levelGap > 20 )																	// ·¹º§ Â÷ÀÌ°¡ 20ÀÌ»óÀÌ¸é,
	{
		return 3;
	}

	return 0;
}

void CDistributer::GetPartyLevels(CParty& pParty, LEVELTYPE& pHighLevel, LEVELTYPE& pTotalLevel , eGET_LVTYPE eGetLvType )
{
	LEVELTYPE totallevel = 0;
	LEVELTYPE highlevel = 0;
	LEVELTYPE curlevel = 0;
	
	for(int count = 0 ; count < MAX_PARTY_LISTNUM ; ++count)									// ·Î±×ÀÎ ÁßÀÎ ÆÄÆ¼¿ø ¼ö¿Í ±× Áß ÃÖ°í ·¹º§À» ±¸ÇÑ´Ù.
	{
		if(CPlayer* const pMember = (CPlayer*)g_pUserTable->FindUser(pParty.GetMemberID(count)))																			// ¸â¹ö Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©.
		{
			if(Chk(*pMember, m_pMob->GetGridID()))
			{

				if( eGetLvType == eGET_MAXLEVEL )
					curlevel = pMember->GetMaxLevel();
				else
					curlevel = pMember->GetLevel();

				if(highlevel < curlevel)
				{
					highlevel = curlevel;
				}

				totallevel = LEVELTYPE( totallevel + curlevel);
			}
		}
	}

	pHighLevel = highlevel;
	pTotalLevel = totallevel;
}

// 091111 pdy ÆÄÆ¼ µ¥¹ÌÁö »êÁ¤ ¹æ½ÄÀ» ¸ó½ºÅÍ º¸»ó½Ã¿¡ ÇÑ¹ø °è»ê ÇÏµµ·Ï º¯°æ
void CDistributer::GetAllPartyDamage()
{
	m_DamageObjectTableSolo.SetPositionHead();

	while(const DAMAGEOBJ* const obj = m_DamageObjectTableSolo.GetData())
	{
		if(obj->dwData > 0)																	// µ¥¹ÌÁö°¡ ÀÖ´ÂÁö ¿©ºÎ¸¦ Ã¼Å©ÇÑ´Ù.
		{
			if(CPlayer* const pPlayer = (CPlayer *)g_pUserTable->FindUser(obj->dwID))
			{
				if(pPlayer->GetGridID() != m_pMob->GetGridID())
				{
					continue;
				}
				else if(PARTYMGR->GetParty(pPlayer->GetPartyIdx()))
				{
					DoAddDamageObj(
						m_DamageObjectTableParty,
						pPlayer->GetPartyIdx(),
						obj->dwData);
				}
			}
		}
	}
}

void CDistributer::SaveCandidacy(CParty& pParty)
{
	if(NULL == m_pMob)
	{
		return;
	}

	mPlayerIndexContainer.clear();

	for(int count = 0 ; count < MAX_PARTY_LISTNUM ; ++count)									// ÃÖ´ë ÆÄÆ¼ ¸â¹ö ¼ö ¸¸Å­ Æ÷¹®.
	{
		if(CPlayer* const pMember = (CPlayer*)g_pUserTable->FindUser(pParty.GetMemberID(count)))
		{
			// 071215 LYW --- Distributer : ÆÄÆ¼ ¸â¹ö°¡ Á×Àº »óÅÂ¿¡¼­´Â, º¸»ó¸â¹ö·Î Ãß°¡ÇÏÁö ¾Ê´Â´Ù.
			if( pMember->GetState() == eObjectState_Die ) continue ;

			if(Chk(*pMember, m_pMob->GetGridID()))
			{
				mPlayerIndexContainer.push_back(
					pMember->GetID());
			}
		}
	}
}

void CDistributer::DistribuSequence(CParty& pParty)
{
	if(mPlayerIndexContainer.empty())
	{
		return;
	}

	const size_t nWinnerIdx = size_t(pParty.GetWinnerIdx());
	DWORD playerIndex = 0;

	if( nWinnerIdx >= mPlayerIndexContainer.size())
	{
		pParty.SetWinnerIdx(0);
		playerIndex = *mPlayerIndexContainer.begin();
	}
	else if(nWinnerIdx < mPlayerIndexContainer.size())
	{
		IndexContainer::const_iterator iterator = mPlayerIndexContainer.begin();
		std::advance(
			iterator,
			nWinnerIdx);

		playerIndex = *iterator;
	}

	CPlayer* pMember = (CPlayer*)g_pUserTable->FindUser(
		playerIndex);

	if( pMember )																	// ¸â¹ö Á¤º¸°¡ À¯È¿ÇÑÁ¦ Ã¼Å©ÇÑ´Ù.
	{
		if(pMember->GetGridID() != m_pMob->GetGridID())
		{
			return;
		}

		SendItemToPerson( pMember ) ;												// ¾ÆÀÌÅÛÀ» ¸â¹ö¿¡°Ô Àü¼ÛÇÑ´Ù.
	}
}

void CDistributer::DistributeDamage()
{
	DWORD bigDamage = 0 ;																		// °¡Àå Å« µ¥¹ÌÁö.
	DWORD bigID = 0 ;																			// °¡Àå Å« µ¥¹ÌÁö¸¦ ÁØ ¾ÆÀÌµð.

	for(IndexContainer::const_iterator iterator = mPlayerIndexContainer.begin();
		mPlayerIndexContainer.end() != iterator;
		++iterator)
	{
		DAMAGEOBJ* obj = m_DamageObjectTableSolo.GetData(*iterator) ;								// µ¥¹ÌÁö Å×ÀÌºí¿¡¼­ ¾ÆÀÌµð·Î µ¥¹ÌÁö Á¤º¸¸¦ ¹Þ´Â´Ù.

		if( obj )																		// µ¥¹ÌÁö Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©ÇÑ´Ù.
		{
			if(bigDamage < obj->dwData)													// ÃÖ´ë µ¥¹ÌÁö¿Í ¸â¹öÀÇ µ¥¹ÌÁö ºñ±³.
			{
				bigDamage = obj->dwData ;												// ÃÖ´ë µ¥¹ÌÁö¿¡ ¸â¹öÀÇ µ¥¹ÌÁö¸¦ ´ëÀÔ.
				bigID = obj->dwID ;														// ÃÖ´ë µ¥¹ÌÁö¸¦ ÁØ ¸â¹öÀÇ ¾ÆÀÌµð¸¦ ÀúÀå.				
			}
		}
	}

	if( bigID == 0 ) return ;																	// °¡Àå Å« µ¥¹ÌÁöÀÇ ¸â¹ö ¾ÆÀÌµð¸¦ Ã¼Å©ÇÑ´Ù.

	CPlayer* pPlayer = (CPlayer*)g_pUserTable->FindUser(bigID);									// ¸â¹ö Á¤º¸¸¦ ¹Þ´Â´Ù.

	if( pPlayer )																				// ¸â¹ö Á¤º¸°¡ À¯È¿ÇÑÁö Ã¼Å©.
	{
		if(pPlayer->GetGridID() != m_pMob->GetGridID())
		{
			return;
		}

		SendItemToPerson( pPlayer ) ;															// ¾ÆÀÌÅÛÀ» Àü¼ÛÇÑ´Ù.							
	}
}

void CDistributer::SendToPersonalExp(CPlayer* pReceivePlayer, EXPTYPE Exp)
{
	Exp = (DWORD)(Exp*gEventRate[eEvent_ExpRate]);
	//// 071221 KTH -- °æÇèÄ¡ »ó½Â ¹öÇÁ Àû¿ë
	Exp += EXPTYPE(Exp * (pReceivePlayer->GetRateBuffStatus()->GetExp/100));

	LEVELTYPE PlayerLv = pReceivePlayer->GetLevel();
	DWORD LimitExp = 0;

	if( m_pMob->GetObjectKind() == eObjectKind_BossMonster )
	{
		LEVELTYPE MonsterLv = m_pMob->GetLevel();

		if( abs( int(MonsterLv) - int(PlayerLv) ) >= 21 )	// º¸½º¸ó½ºÅÍÀÏ °æ¿ì 21·¹º§(high/low ¸ðµÎ) ÀÌ»ó Â÷ÀÌ³ª¸é Ã¤Å©ÇÑ´Ù
		{
			double dwLevel = PlayerLv ;																								
			double result = pow(dwLevel, 1.95) ;												
			float fExp = (float)( (result + 15) * 20) ;														
			LimitExp = (DWORD)floor(fExp) ;			

			if( LimitExp < Exp )							// Áö±Þ ¹Þ´Â exp°¡ »óÇÑ¼± º¸´Ù ³ô´Ù¸é »óÇÑ¼± °æÇèÄ¡·Î ¼³Á¤
			{
				Exp = LimitExp ;
			}
		}
	}
	else 
	{
		if(g_csDateManager.IsChallengeZoneHere())
		{
			double dwLevel = PlayerLv ;						// µ¥ÀÌÆ®Á¸ÀÏ°æ¿ì »óÇÑ¼± = ( (·¹º§^1.95) + 15 ) * 10																			
			double result = pow(dwLevel, 1.95) ;												
			float fExp = (float)( (result + 15) * 5) ;														
			LimitExp = (DWORD)floor(fExp) ;			
		}
		else
		{
			double dwLevel = PlayerLv ;						// ÀÏ¹ÝÀÇ °æ¿ì »óÇÑ¼± = ( (·¹º§^1.95) + 15 ) * 20																										
			double result = pow(dwLevel, 1.95) ;												
			float fExp = (float)( (result + 15) * 20) ;														
			LimitExp = (DWORD)floor(fExp) ;					
		}

		if( LimitExp < Exp )							// Áö±Þ ¹Þ´Â exp°¡ »óÇÑ¼± º¸´Ù ³ô´Ù¸é »óÇÑ¼± °æÇèÄ¡·Î ¼³Á¤
		{
			Exp = LimitExp ;
		}
	}

	pReceivePlayer->AddPlayerExpPoint(Exp);
}

void CDistributer::AddMoney(CPlayer* pPlayer, MONEYTYPE Money, WORD MonsterKind)
{
	if( pPlayer->SetMoney(Money, MONEY_ADDITION, MF_OBTAIN, eItemTable_Inventory, eMoneyLog_GetMonster, MonsterKind) != Money )
	{
		MSGBASE msg;
		msg.Category = MP_ITEM;
		msg.Protocol = MP_ITEM_MONEY_ERROR;

		pPlayer->SendMsg(&msg, sizeof(msg));
	}
}