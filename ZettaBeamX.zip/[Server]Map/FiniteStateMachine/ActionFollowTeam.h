#ifndef __ACTIONFOLLOWTEAM_H__INCLUDED
#define __ACTIONFOLLOWTEAM_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionFollowTeam : public CAction
	{
	private:
		const std::string mTeamName;
		const float mDistance;

	public:
		CActionFollowTeam(LPCTSTR teamName, float distance);
		virtual ~CActionFollowTeam() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONFOLLOWTEAM_H__INCLUDED
