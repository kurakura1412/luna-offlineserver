#ifndef __ACTIONHEALTHOFTARGET_H__INCLUDED
#define __ACTIONHEALTHOFTARGET_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionHealthOfTarget : public CAction
	{
	public:
		CActionHealthOfTarget();
		virtual ~CActionHealthOfTarget() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONHEALTHOFTARGET_H__INCLUDED
