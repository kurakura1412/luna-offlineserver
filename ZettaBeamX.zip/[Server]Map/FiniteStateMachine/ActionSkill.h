#ifndef __ACTIONSKILL_H__INCLUDED
#define __ACTIONSKILL_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionSkill : public CAction
	{
	private:
		const DWORD mObjectIndex;
		const DWORD mSkillIndex;

	public:
		CActionSkill(DWORD objectIndex, DWORD skillIndex);
		virtual ~CActionSkill() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONSKILL_H__INCLUDED
