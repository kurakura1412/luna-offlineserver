#ifndef __ACTIONHEALTH_H__INCLUDED
#define __ACTIONHEALTH_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionHealth : public CAction
	{
	private:
		const std::string mAlias;

	public:
		CActionHealth(LPCTSTR alias);
		virtual ~CActionHealth() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONHEALTH_H__INCLUDED
