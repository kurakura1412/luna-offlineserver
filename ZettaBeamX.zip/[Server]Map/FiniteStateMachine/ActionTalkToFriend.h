#ifndef __ACTIONTALKTOFRIEND_H__INCLUDED
#define __ACTIONTALKTOFRIEND_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionTalkToFriend : public CAction
	{
	private:
		const DWORD mSpeechIndex;

	public:
		CActionTalkToFriend(DWORD speechIndex);
		virtual ~CActionTalkToFriend() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONTALKTOFRIEND_H__INCLUDED
