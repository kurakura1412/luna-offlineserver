#ifndef __ACTIONDISTANCE_H__INCLUDED
#define __ACTIONDISTANCE_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionDistance : public CAction
	{
		const std::string mFriendName;

	public:
		CActionDistance(LPCTSTR friendName);
		virtual ~CActionDistance() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONDISTANCE_H__INCLUDED
