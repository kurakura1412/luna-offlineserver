#ifndef __ACTIONTEAMCHIEF_H__INCLUDED
#define __ACTIONTEAMCHIEF_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionTeamChief : public CAction
	{
	private:
		const std::string mTeamName;

	public:
		CActionTeamChief(LPCTSTR teamName);
		virtual ~CActionTeamChief() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONTEAMCHIEF_H__INCLUDED
