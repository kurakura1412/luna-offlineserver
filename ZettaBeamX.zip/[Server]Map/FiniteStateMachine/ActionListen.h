#ifndef __ACTIONLISTEN_H__INCLUDED
#define __ACTIONLISTEN_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionListen : public CAction
	{
	private:
		const DWORD mSpeechIndex;

	public:
		CActionListen(DWORD speechIndex);
		virtual ~CActionListen() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONLISTEN_H__INCLUDED
