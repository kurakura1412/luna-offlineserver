#ifndef __ACTIONTEAM_H__INCLUDED
#define __ACTIONTEAM_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionTeam : public CAction
	{
	private:
		const std::string mTeamName;

	public:
		CActionTeam(LPCTSTR teamName);
		virtual ~CActionTeam() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONTEAM_H__INCLUDED
