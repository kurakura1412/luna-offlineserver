#ifndef __ACTIONTALKTOTEAM_H__INCLUDED
#define __ACTIONTALKTOTEAM_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionTalkToTeam : public CAction
	{
	private:
		const DWORD mSpeechIndex;

	public:
		CActionTalkToTeam(DWORD speechIndex);
		virtual ~CActionTalkToTeam() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONTALKTOTEAM_H__INCLUDED
