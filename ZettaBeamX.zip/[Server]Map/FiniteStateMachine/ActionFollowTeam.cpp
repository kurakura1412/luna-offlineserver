#include "StdAfx.h"

#ifdef _MAP00_
#include "[lib]yhlibrary/yhlibrary.h"
//#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "ServerSystem.h"
#endif

#include "ActionFollowTeam.h"
#include "ActionFollow.h"
#include "Machine.h"
#include "Parser.h"
//#include "Object.h"
#include "UserTable.h"


namespace FiniteStateMachine
{
	namespace
	{
		CAction* Clone(CParser::ParameterContainer& parameterContainer)
		{
			LPCTSTR channel = parameterContainer["channel"].c_str();
			LPCTSTR parameter1 = parameterContainer["parameter1"].c_str();
			LPCTSTR parameter2 = parameterContainer["parameter2"].c_str();

			LPCTSTR alias = CMachine::GetParser().GetAlias(
				parameter1,
				_ttoi(channel));
			const float distance = float(
#ifdef _UNICODE
				_tstof(parameter2)
#else
				atof(parameter2)
#endif
				);

			return new CActionFollowTeam(
				alias,
				distance);
		}

		const BOOL isRegistered = CMachine::GetParser().Register(
			"FollowTeam",
			Clone);
	}

	CActionFollowTeam::CActionFollowTeam(LPCTSTR teamName, float distance) :
	CAction("FollowTeam"),
	mTeamName(teamName),
	mDistance(distance)
	{}

	int CActionFollowTeam::Run(CMachine& machine) const
	{
		const CUserTable::Team& team = g_pUserTable->GetTeam(
			mTeamName.c_str());

		CObject* const object = g_pUserTable->FindUser(
			team.mLeaderObjectIndex);

		if(0 == object)
		{
			return 0;
		}

		CActionFollow action(
			object->GetID(),
			mDistance);
		return action.Run(
			machine);
	}
}