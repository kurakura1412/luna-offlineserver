#include "StdAfx.h"

#ifdef _MAP00_
#include "[lib]yhlibrary/YHLibrary.h"
//#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "ServerSystem.h"
#endif

#include "State.h"
#include "Machine.h"
#include "Action.h"
#include "Memory.h"
#include "Parser.h"

namespace FiniteStateMachine
{
	CState::CState(DWORD index, LPCTSTR name) :
	mName(name),
	mIndex(index)
	{}

	CState::~CState()
	{}

	void CState::Run(CMachine& machine) const
	{
		machine.GetMemory().SetNextState(
			0);
		machine.GetMemory().SetExitState(
			FALSE);

		for(ActionContainer::const_iterator iterator = mActionContainer.begin();
			mActionContainer.end() != iterator;
			++iterator)
		{
			const ActionIndex actionIndex = *iterator;
			machine.Log(
				mIndex,
				actionIndex);

			const CAction& action = machine.GetParser().GetAction(
				actionIndex);
			machine.GetMemory().SetResult(
				action.Run(machine));

			if(machine.GetMemory().IsExitState())
			{
				break;
			}
		}
	}
}