#include "StdAfx.h"

#ifdef _MAP00_
#include "[lib]yhlibrary/yhlibrary.h"
//#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "ServerSystem.h"
#endif

#include "ActionHealth.h"
#include "Machine.h"
#include "Parser.h"
#include "Object.h"
#include "UserTable.h"

namespace FiniteStateMachine
{
	namespace
	{
		CAction* Clone(CParser::ParameterContainer& parameterContainer)
		{
			LPCTSTR channel = parameterContainer["channel"].c_str();
			LPCTSTR parameter1 = parameterContainer["parameter1"].c_str();

			LPCTSTR alias = CMachine::GetParser().GetAlias(
				parameter1,
				_ttoi(channel));

			return new CActionHealth(
				alias);
		}

		const BOOL isRegistered = CMachine::GetParser().Register(
			"Health",
			Clone);
	}

	CActionHealth::CActionHealth(LPCTSTR alias) :
	CAction("Health"),
	mAlias(alias)
	{}

	int CActionHealth::Run(CMachine& machine) const
	{
		CObject* const object = g_pUserTable->FindUser(
			machine.GetObjectIndex(mAlias.c_str()));

		if(0 == object)
		{
			return 0;
		}

		const float healthRate = float(object->GetLife()) / float(object->GetMaxLife());

		return int(healthRate * 100.0f);
	}
}