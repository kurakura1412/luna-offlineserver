#include "StdAfx.h"

#ifdef _MAP00_
#include "[lib]yhlibrary/YHLibrary.h"
//#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "ServerSystem.h"
#endif

#include "ActionPause.h"
#include "Machine.h"
#include "Memory.h"
#include "Parser.h"
#include "Monster.h"
#include "UserTable.h"
#include "StateMachinen.h"

namespace FiniteStateMachine
{
	namespace
	{
		CAction* Clone(CParser::ParameterContainer& parameterContainer)
		{
			LPCTSTR parameter1 = parameterContainer["parameter1"].c_str();			

			return new CActionPause(
				_ttoi(parameter1) * 1000);
		}

		const BOOL isRegistered = CMachine::GetParser().Register(
			"Pause",
			Clone);
	}

	CActionPause::CActionPause(DWORD tick) :
	CAction("Pause"),
	mPausedTick(tick)
	{}

	int CActionPause::Run(CMachine& machine) const
	{
		CMonster* const monsterObject = (CMonster*)g_pUserTable->FindUser(
			machine.GetObjectIndex());

		if(0 == monsterObject)
		{
			return 0;
		}
		else if(FALSE == (eObjectKind_Monster & monsterObject->GetObjectKind()))
		{
			return 0;
		}

		machine.GetMemory().SetVariable(
			"__lastState__",
			monsterObject->mStateParamter.stateCur);
		machine.GetMemory().SetVariable(
			"__tick__",
			mPausedTick);
		GSTATEMACHINE.SetState(
			monsterObject,
			eMA_PAUSE);
		return 1;
	}
}