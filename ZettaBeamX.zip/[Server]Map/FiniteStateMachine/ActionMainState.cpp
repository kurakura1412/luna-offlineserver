#include "StdAfx.h"

#ifdef _MAP00_
#include "[lib]yhlibrary/YHLibrary.h"
//#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
//#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "ServerSystem.h"
#endif

#include "ActionMainState.h"
#include "Machine.h"
#include "Memory.h"
#include "Parser.h"

namespace FiniteStateMachine
{
	namespace
	{
		CAction* Clone(CParser::ParameterContainer& parameterContainer)
		{
			LPCTSTR fileName = parameterContainer["fileName"].c_str();
			LPCTSTR parameter1 = parameterContainer["parameter1"].c_str();

			LPCTSTR stateName = CMachine::GetParser().GetStateName(
				fileName,
				parameter1);
			const DWORD stateIndex = CMachine::GetParser().GetHashCode(
				stateName);

			return new CActionMainState(
				stateIndex);
		}

		const BOOL isRegistered = CMachine::GetParser().Register(
			"MainState",
			Clone);
	}

	CActionMainState::CActionMainState(DWORD stateIndex) :
	CAction("MainState"),
	mStateIndex(stateIndex)
	{}

	int CActionMainState::Run(CMachine& machine) const
	{
		machine.SetMainState(
			mStateIndex);
		machine.GetMemory().SetNextState(
			TRUE);
		return 1;
	}
}