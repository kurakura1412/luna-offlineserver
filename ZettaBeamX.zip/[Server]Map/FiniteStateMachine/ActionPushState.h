#ifndef __ACTIONPUSHSTATE_H__INCLUDED
#define __ACTIONPUSHSTATE_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionPushState : public CAction
	{
	private:
		const DWORD mStateIndex;

	public:
		CActionPushState(DWORD stateIndex);
		virtual ~CActionPushState() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONPUSHSTATE_H__INCLUDED
