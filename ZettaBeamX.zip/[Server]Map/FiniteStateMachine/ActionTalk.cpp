#include "StdAfx.h"

#ifdef _MAP00_
#include "[lib]yhlibrary/YHLibrary.h"
//#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "ServerSystem.h"
#endif

#include "ActionTalk.h"
#include "Machine.h"
#include "Parser.h"
#include "Object.h"
#include "UserTable.h"
#include "PackedData.h"

namespace FiniteStateMachine
{
	namespace
	{
		CAction* Clone(CParser::ParameterContainer& parameterContainer)
		{
			LPCTSTR parameter1 = parameterContainer["parameter1"].c_str();

			return new CActionTalk(
				_ttoi(parameter1));
		}

		const BOOL isRegistered = CMachine::GetParser().Register(
			"Talk",
			Clone);
	}

	CActionTalk::CActionTalk(DWORD speechIndex) :
	CAction("Talk"),
	mSpeechIndex(speechIndex)
	{}

	int CActionTalk::Run(CMachine& machine) const
	{
		CObject* const object = g_pUserTable->FindUser(
			machine.GetObjectIndex());

		if(0 == object)
		{
			return 0;
		}

		MSG_DWORD4 message;
		ZeroMemory(&message, sizeof(message));
		message.Category = MP_CHAT;
		message.Protocol = MP_CHAT_MONSTERSPEECH;
		message.dwData2 = mSpeechIndex;
		message.dwObjectID = machine.GetObjectIndex();
		PACKEDDATA_OBJ->QuickSend(
			object,
			&message,
			sizeof(message));

		return 1;
	}
}