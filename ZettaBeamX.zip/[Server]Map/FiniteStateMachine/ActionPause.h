#ifndef __ACTIONPAUSE_H__INCLUDED
#define __ACTIONPAUSE_H__INCLUDED

#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionPause : public CAction
	{
	private:
		const DWORD mPausedTick;

	public:
		CActionPause(DWORD tick);
		virtual ~CActionPause() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONPAUSE_H__INCLUDED
