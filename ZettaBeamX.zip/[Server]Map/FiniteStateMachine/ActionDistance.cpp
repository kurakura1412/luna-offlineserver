#include "StdAfx.h"

#ifdef _MAP00_
#include "[lib]yhlibrary/yhlibrary.h"
//#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "ServerSystem.h"
#endif

#include "Object.h"
#include "ActionDistance.h"
#include "Machine.h"
#include "Parser.h"
#include "UserTable.h"
#include "CharMove.h"
#include "Nglobal.h"

namespace FiniteStateMachine
{
	namespace
	{
		CAction* Clone(CParser::ParameterContainer& parameterContainer)
		{
			LPCTSTR channel = parameterContainer["channel"].c_str();
			LPCTSTR parameter1 = parameterContainer["parameter1"].c_str();

			LPCTSTR alias = CMachine::GetParser().GetAlias(
				parameter1,
				_ttoi(channel));

			return new CActionDistance(
				alias);
		}

		const BOOL isRegistered = CMachine::GetParser().Register(
			"Distance",
			Clone);
	}

	CActionDistance::CActionDistance(LPCTSTR friendName) :
	CAction("Distance"),
	mFriendName(friendName)
	{}

	int CActionDistance::Run(CMachine& machine) const
	{
		CObject* const friendObject = g_pUserTable->FindUser(
			machine.GetObjectIndex(mFriendName.c_str()));

		if(0 == friendObject)
		{
			return INT_MAX;
		}

		VECTOR3 friendPosition = *(CCharMove::GetPosition(
			friendObject));

		CObject* const object = g_pUserTable->FindUser(
			machine.GetObjectIndex());

		if(0 == object)
		{
			return INT_MAX;
		}

		VECTOR3 objectPosition = *(CCharMove::GetPosition(
			object));

		return int(CalcDistance(&friendPosition, &objectPosition));
	}
}