#include "StdAfx.h"

#ifdef _MAP00_
#include "[lib]yhlibrary/yhlibrary.h"
//#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
//#include "ServerSystem.h"
#endif

#include "ActionHealthOfTarget.h"
#include "Machine.h"
#include "Parser.h"
#include "Monster.h"
#include "UserTable.h"

namespace FiniteStateMachine
{
	namespace
	{
		CAction* Clone(CParser::ParameterContainer& parameterContainer)
		{
			return new CActionHealthOfTarget;
		}

		const BOOL isRegistered = CMachine::GetParser().Register(
			"HealthOfTarget",
			Clone);
	}

	CActionHealthOfTarget::CActionHealthOfTarget() :
	CAction("HealthOfTarget")
	{}

	int CActionHealthOfTarget::Run(CMachine& machine) const
	{
		CMonster* const monsterObject = (CMonster*)g_pUserTable->FindUser(
			machine.GetObjectIndex());

		if(0 == monsterObject)
		{
			return 0;
		}

		CObject* const targetObject = monsterObject->GetTObject();

		if(0 == targetObject)
		{
			return 0;
		}

		const float healthRate = float(targetObject->GetLife()) / targetObject->GetMaxLife();

		return int(healthRate * 100.0f);
	}
}