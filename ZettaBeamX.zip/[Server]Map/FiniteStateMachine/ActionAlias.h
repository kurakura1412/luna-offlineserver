#ifndef __ACTIONALIAS_H__INCLUDED
#define __ACTIONALIAS_H__INCLUDED
#pragma once

#include "Action.h"

namespace FiniteStateMachine
{
	class CActionAlias : public CAction
	{
	private:
		const std::string mAlias;

	public:
		CActionAlias(LPCTSTR);
		virtual ~CActionAlias() {}
		virtual int Run(CMachine&) const;
	};
}

#endif // __ACTIONALIAS_H__INCLUDED
