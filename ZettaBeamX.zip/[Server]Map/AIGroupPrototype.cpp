#include "StdAfx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
//#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "AIGroupPrototype.h"
#include "RegenManager.h"
#include "AISystem.h"
#include "Monster.h"

CAIGroup::CAIGroup() :
m_dwGroupID(0),
m_dwGridID(0)
{}

CAIGroup::~CAIGroup()
{}

void CAIGroup::Die(DWORD id)
{
	ScriptIndexContainer::iterator iter = mScriptIndexContainer.find(id);

	// 100104 LUJ, °íÀ¯ ¹øÈ£°¡ ¹Ù´Ú³ª´Â °ÍÀ» ¸·±â À§ÇØ, ´Ù¸¥ ÇüÅÂÀÇ °íÀ¯ °ªÀÎ
	//			½ºÅ©¸³Æ® ¹øÈ£¸¦ »ç¿ëÇÑ´Ù. ScriptIndexContainer¿¡´Â [Å°]/[°ª]À¸·Î °¢°¢
	//			[¸ó½ºÅÍ °íÀ¯ ¹øÈ£]/[½ºÅ©¸³Æ® ¹øÈ£]°¡ ¼³Á¤µÇ¾î ÀÖ´Ù. ÀÌ ÄÁÅ×ÀÌ³Ê¿¡ 
	//			°ªÀÌ ¾ø´Â °ÍÀº ¸®Á¨ ½ºÅ©¸³Æ®·Î »ý¼ºÇÏÁö ¾Ê¾Ò´Ù´Â ÀÇ¹ÌÀÌ´Ù.
	if(mScriptIndexContainer.end() == iter)
	{
		mRegenIndexContainer.insert(id);
		return;
	}

	const DWORD scriptIndex = iter->second;
	mScriptIndexContainer.erase(iter);

	mRegenIndexContainer.insert(scriptIndex);
}

void CAIGroup::RegenCheck()
{
	const float ratio = float(mScriptIndexContainer.size()) / mParameterContainer.size();

	for(ConditionContainer::iterator iter = mConditionContainer.begin(),
		itend = mConditionContainer.end()
	;itend != iter;
		++iter)
	{
		Condition& condition = *iter;

		if(ratio > condition.mRatio)
		{
			continue;
		}

		condition.mStartTick = gCurTime + condition.mDelayTick;
		condition.mIsRegen = TRUE;
	}
}

void CAIGroup::AddRegenObject(EObjectKind objectKind, WORD monsterKind, const VECTOR3& position, LPCTSTR finiteStateMachine)
{
	const DWORD regenIndex = mParameterContainer.size();

	Parameter& regenObject = mParameterContainer[regenIndex];
	ZeroMemory(
		&regenObject,
		sizeof(regenObject));
	regenObject.ObjectKind = objectKind;
	regenObject.wMonsterKind = monsterKind;
	regenObject.vPos = position;
	SafeStrCpy(
		regenObject.mMachine,
		finiteStateMachine,
		_countof(regenObject.mMachine));

	Die(regenIndex);
}

void CAIGroup::AddCondition(DWORD targetGroup, float ratio, DWORD delayTick, BOOL isRegen, DWORD range)
{
	Condition condition = {0};
	condition.mTargetGroup = targetGroup;
	condition.mRatio = ratio;
	condition.mDelayTick = delayTick;
	condition.mStartTick = gCurTime + delayTick;
	condition.mIsRegen = isRegen;

	mConditionContainer.push_back(condition);
	m_dwRegenRange = range;
}

void CAIGroup::RegenProcess()
{
	for(ConditionContainer::iterator iter = mConditionContainer.begin(),
		itend = mConditionContainer.end()
	;		itend != iter;
		++iter)
	{
		Condition& condition = *iter;

		if(FALSE == condition.mIsRegen)
		{
			continue;
		}
		else if(condition.mStartTick > gCurTime)
		{
			continue;
		}

		condition.mStartTick = gCurTime + condition.mDelayTick;
		condition.mIsRegen = FALSE;

		REGENMGR->RegenGroup(
			condition.mTargetGroup,
			GetGridID());
	}
}

void CAIGroup::ForceRegen()
{
	IndexContainer failedIndexContainer;

	for(IndexContainer::const_iterator iter = mRegenIndexContainer.begin(),
		itend = mRegenIndexContainer.end()
	;	itend != iter;
		++iter)
	{
		const DWORD regenIndex = *iter;

		if(Create(regenIndex))
		{
			continue;
		}

		failedIndexContainer.insert(regenIndex);
	}

	mRegenIndexContainer = failedIndexContainer;

	if(false == mRegenIndexContainer.empty())
	{
		RegenCheck();
	}
}

CAIGroup::Parameter* CAIGroup::GetRegenObject(DWORD regenIndex)
{
	const ParameterContainer::iterator iterator = mParameterContainer.find(regenIndex);

	return mParameterContainer.end() == iterator ? 0 : &(iterator->second);
}

BOOL CAIGroup::Create(DWORD regenIndex)
{
	Parameter* const regenObject = GetRegenObject(regenIndex);

	if(0 == regenObject)
	{
		return FALSE;
	}

	CMonster* const monster = REGENMGR->RegenObject(
		g_pAISystem.GeneraterMonsterID(),
		regenIndex,
		GetGridID(),
		regenObject->ObjectKind,
		regenObject->wMonsterKind,
		&(regenObject->vPos),
		GetGroupID(),
		0,
		100,
		TRUE);

	if(0 == monster)
	{
		return FALSE;
	}

	mScriptIndexContainer.insert(
		std::make_pair(monster->GetID(), regenIndex));
	return TRUE;
}

void CAIGroup::SetRegenDelayTime(DWORD delayTime)
{
	for(ConditionContainer::iterator iterator = mConditionContainer.begin();
		mConditionContainer.end() != iterator;
		++iterator)
	{
		Condition& condition = *iterator;
		condition.mDelayTick = delayTime;
	}
}