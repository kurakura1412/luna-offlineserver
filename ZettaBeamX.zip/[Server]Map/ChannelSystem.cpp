#include "StdAfx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
#include "[CC]Header/CommonGameFunc.h"
#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
#include "ServerSystem.h"
#endif

#include "ChannelSystem.h"
#include "MHFile.h"
#include "BattleSystem_Server.h"
#include "Object.h"
#include "NetWork.h"
#include "QuestMapMgr.h"
#include "hseos/Date/SHDateManager.h"
#include "HousingMgr.h"
#include "Dungeon/DungeonMgr.h"
#include "..\[CC]ServerModule\Console.h"
extern int g_nServerSetNum;

CChannelSystem::CChannelSystem()
{
	
	m_dwCount = 0; 
	m_bQuestMap = FALSE;
	m_nChallengeZoneLastChannelID = 0;
	ZeroMemory(m_nChallengeZoneAllocatedCH,		sizeof(m_nChallengeZoneAllocatedCH));
	ZeroMemory(m_nChallengeZoneAgentChannelID, sizeof(m_nChallengeZoneAgentChannelID));
	m_nChallengeZoneAllocatedCHNum = 0;
	m_nChallengeZonePlayerAgentChannelID= 0;
#ifdef _MYLUNA_
	_AskCh = 0;
	_inited = FALSE;
#endif
}

CChannelSystem::~CChannelSystem()
{
	for(DWORD i=0; i<m_dwCount; ++i)
	{
		if(m_Channel[i])
		{		
			delete m_Channel[i];
			m_Channel[i] = NULL;
		}
	}
}

void CChannelSystem::LoadChannelInfo()
{
#ifdef _MYLUNA_
	if( _inited ) return;
	_inited = TRUE;
	char buf[256];
	char filename0[256];
	sprintf(filename0,"system/MapChannel.bin");
	CMHFile file0;
	int nMapNum;
	int chnum;
	if( file0.Init( filename0,"rb") )
	{
		while( ! file0.IsEOF() )
		{
			file0.GetString( buf );
			if( strcmp( buf, "$MAP_CHANNEL" ) == 0)
			{
				nMapNum = file0.GetWord();
				chnum = file0.GetWord();
				_mychannel[nMapNum] = chnum;
			}
		}
	}
	file0.Release();
#endif
	CMHFile file;  
	BYTE Kind, num = 0; 
	char value[64] = {0,};
	
	char filename[256];
	sprintf(filename,"serverset/%d/ChannelInfo.bin",g_nServerSetNum);

	file.Init(filename, "rb");

	if(file.IsInited() == FALSE)
	{
		MessageBox(NULL,"Can't Open ChannelInfo File", 0, 0);
		return;
	}

	while(1)
	{
		if(file.IsEOF())
			break;
		
		strcpy( value, strupr(file.GetString()) );

		if( strcmp( value,"*CHANNEL" ) == 0 )
		{
			Kind = file.GetByte();
			num = file.GetByte();
			file.GetStringInQuotation( m_ChannelName );
		}
	}
	file.Release();
}

void CChannelSystem::CreateChannel(BYTE Kind, BYTE num)
{
	for(BYTE i=0; i<num; ++i)
	{			
		 DWORD ChannelIDX = BATTLESYSTEM->CreateChannel(); // ±×¸®µå ¾ÆÀÌµð == ChannelIDX
		 m_Channel[i] = new CChannel;
		 m_Channel[i]->SetChannelID(ChannelIDX);
	} 
	
	m_dwCount = num;
	m_bQuestMap = FALSE;
}

void CChannelSystem::IncreasePlayerNum(DWORD ChannelID)
{
	if(HOUSINGMAPNUM == g_pServerSystem->GetMapNum())
	{
		return;
	}
	else if(DungeonMGR->IsDungeon(g_pServerSystem->GetMapNum()))
	{
		return;
	}
	else if(QUESTMAPMGR->IsQuestMap())
	{
		m_QMChannel[ChannelID-1].IncreaseNum();
		return;
	}

	if(ChannelID > m_dwCount)
	{
		return;
	}

	m_Channel[ChannelID-1]->IncreaseNum();
}

void CChannelSystem::DecreasePlayerNum(DWORD ChannelID)
{
	if(HOUSINGMAPNUM == g_pServerSystem->GetMapNum())
	{
		return;
	}
	else if(DungeonMGR->IsDungeon(g_pServerSystem->GetMapNum()))
	{
		return;
	}
	else if(QUESTMAPMGR->IsQuestMap())
	{
		m_QMChannel[ChannelID-1].DecreaseNum();
		return;
	}

	if(ChannelID > m_dwCount)
	{
		return;
	}

	m_Channel[ChannelID-1]->DecreaseNum();
}


void CChannelSystem::SendChannelInfo(MSG_DWORD* pInfo, DWORD dwConnectionIndex)
{
	if(g_pServerSystem->GetStart() == FALSE || m_bQuestMap )
	{
		MSG_BYTE nmsg;
		nmsg.Category = MP_USERCONN;
		nmsg.Protocol = MP_USERCONN_CHANNELINFO_NACK;
		nmsg.bData = 0;
		nmsg.dwObjectID = pInfo->dwObjectID;
#ifdef _MYLUNA_
		g_Network.Send2Server(1,(char*)&nmsg,sizeof(nmsg));
#else
		g_Network.Send2Server(dwConnectionIndex,(char*)&nmsg,sizeof(nmsg));
#endif
		return;
	}

	MSG_CHANNEL_INFO msg;
	memset(&msg, 0, sizeof(MSG_CHANNEL_INFO));
	msg.Category = MP_USERCONN;
	msg.Protocol = MP_USERCONN_CHANNELINFO_ACK;
	SafeStrCpy(msg.ChannelName, m_ChannelName, MAX_CHANNEL_NAME+1);
#ifdef _MYLUNA_
	DWORD mycount = 1;
	if( _mychannel.find(_AskCh) != _mychannel.end()) mycount = _mychannel.at(_AskCh);
	_AskCh = 0;
	for(DWORD i=0; i<mycount; ++i)
	{
		msg.PlayerNum[i] = 0;
	}
	msg.Count = (BYTE)mycount;
#else
	for(DWORD i=0; i<m_dwCount; ++i)
	{
		msg.PlayerNum[i] = m_Channel[i]->GetPlayerNum();
	}
	msg.Count = (BYTE)m_dwCount;
#endif
	msg.dwObjectID = pInfo->dwObjectID;
	msg.dwUniqueIDinAgent = pInfo->dwData;
	
#ifdef _MYLUNA_
	g_Network.Send2Server(1,(char*)&msg,sizeof(msg));
#else
	g_Network.Send2Server(dwConnectionIndex,(char*)&msg,sizeof(msg));
#endif
}

DWORD CChannelSystem::GetChannelID(int num)
{
	if( m_bQuestMap )
	{
		return 0;
	}
	else if(HOUSINGMAPNUM == g_pServerSystem->GetMapNum())
	{
		// ÇÏ¿ìÂ¡Àº ÀÚµ¿»ý¼º Ã¤³ÎÀÌ¹Ç·Î ¸ÊÀÌµ¿ÁÖ¹®¼­¸¦ »ç¿ëÇÒ ¼ö ÀÖµµ·Ï 1À» ¹ÝÈ¯
		return 1;
	}
	else if(DungeonMGR->IsDungeon(g_pServerSystem->GetMapNum()))
	{
		// ÀÎ´øÀº ÀÚµ¿»ý¼º Ã¤³ÎÀÌ¹Ç·Î ¸ÊÀÌµ¿ÁÖ¹®¼­¸¦ »ç¿ëÇÒ ¼ö ÀÖµµ·Ï 1À» ¹ÝÈ¯
		return 1;
	}

	if(((DWORD)num >= m_dwCount) || (num < 0))
	{
		ASSERT(0);
		return 0;
	}
		
	return m_Channel[num]->GetChannelID();
}

void CChannelSystem::SendChannelInfoToMS( DWORD dwConnectionIndex )
{
	if( m_bQuestMap )	return;
	
	MSG_CHANNEL_INFO msg;
	memset(&msg, 0, sizeof(MSG_CHANNEL_INFO));
	msg.Category = MP_MORNITORMAPSERVER;
	msg.Protocol = MP_MORNITORMAPSERVER_QUERY_CHANNELINFO_ACK;
	SafeStrCpy(msg.ChannelName, m_ChannelName, MAX_CHANNEL_NAME+1);
	for(DWORD i=0; i<m_dwCount; ++i)
	{
		msg.PlayerNum[i] = m_Channel[i]->GetPlayerNum();
	}
	msg.Count = (BYTE)m_dwCount;
#ifdef _MYLUNA_
	g_Network.Send2Server(1,(char*)&msg,sizeof(msg));
#else
	g_Network.Send2Server(dwConnectionIndex,(char*)&msg,sizeof(msg));
#endif
}

void CChannelSystem::InitQuestMapChannel()
{
	m_bQuestMap = TRUE;
}

DWORD CChannelSystem::CreateQuestMapChannel(DWORD nFirstEnterPlayerID) 
{
	if( !m_bQuestMap )	return 0;

	if (g_csDateManager.IsChallengeZoneHere())
	{
		// ¿¡ÀÌÀüÆ®¿¡¼­ 1000 ÀÌ»óÀ¸·Î º¸³½´Ù. 1000 ÀÌ¶ó´Â °ªÀº ±âº»À¸·Î ¼³Á¤ÇÑ Ã¤³Î°ú ±¸ºÐÇÏ±â À§ÇÑ ¼öÄ¡ÀÓ.
		if (m_nChallengeZonePlayerAgentChannelID >= 1000)
		{
			// ¿©±â¿¡¼­ÀÇ Ä«¿îÆ® 1000¿¡ ´ëÇØ¼­ ¼³¸í.
			// µ¿½Ã¿¡ 2000¸íÀÌ Ã§¸°Áö Á¸¿¡ ÀÔÀåÇÒ °æ¿ì, 1000¸íÀÌ ¸ÕÀú Ã§¸°Áö Á¸¿¡ µµÂøÇÒ ¼ö ÀÖ´Ù.
			// ±×·¯¸é ³ªÁß¿¡ µé¾î¿À´Â ÇÃ·¹ÀÌ¾î´Â ¸ÕÀú µé¾î¿Â 1000¸íÀÇ ½Äº°ÄÚµå Áß ÀÚ½ÅÀÇ ½Äº°ÄÚµå¿Í ÀÏÄ¡ÇÏ´Â °æ¿ì¿¡
			// ¸ÕÀú µé¾î¿Â ÇÃ·¹ÀÌ¾îÀÇ Ã¤³ÎID¸¦ °øÀ¯ÇÑ´Ù.
			// ÀÏ¹Ý(Á¤»ó)ÀûÀÌ¶ó¸é 2000¸íÀÌ Ã§¸°Áö Á¸¿¡ ÀÔÀåÇÒ °æ¿ì, 2000¸íÀÇ ÀÏºÎ°¡ ¸ÕÀú µé¾î¿À°í, ±× ÀÏºÎÀÇ ÆÄÆ®³Ê°¡ µé¾î¿À°í,
			// ¶Ç ³ª¸ÓÁöÀÇ ÀÏºÎ°¡ µé¾î¿À°í, ±× ÀÏºÎÀÇ ÆÄÆ®³Ê°¡ µé¾î¿À°í ÇÒ ÅÙµ¥, ÃÖ¾ÇÀÇ °æ¿ì´Â
			// È¥ÀÚµé¾î¿Â °æ¿ì¸¸ 1000°ÇÀÌ µÉ ¼ö°¡ ÀÖ´Ù. ÀÌ¿Í °°ÀÌ È¥ÀÚµé¾î¿Â ÃÖ¾ÇÀÇ °æ¿ìÀÇ ¼ö°¡ 1000 ÀÓ.
			DWORD nCnt = 1000;
			if (nCnt > m_nChallengeZoneAllocatedCHNum) nCnt = m_nChallengeZoneAllocatedCHNum;

			for(DWORD i=0; i<nCnt; i++)
			{
				if (m_nChallengeZoneAgentChannelID[i] == m_nChallengeZonePlayerAgentChannelID)
				{
					DWORD nChannel = m_nChallengeZoneAllocatedCH[i][0];

					// Ã§¸°Áö ½ÃÀÛ ¼³Á¤
					g_csDateManager.SetChallengeZoneStart(TRUE);
					g_csDateManager.SetChallengeZoneFirstEnterPlayerID(m_nChallengeZoneAllocatedCH[i][1]);
					if (g_pServerSystem->IsTestServer())
					{
						g_Console.LOG(4, "Share ChallengeZone Channel:%d FirstEnterPlayerID:%d Agent CHID:%d)", nChannel, m_nChallengeZoneAllocatedCH[i][1], m_nChallengeZonePlayerAgentChannelID);
					}
					// ÀØÁö ¸»°í ÃÊ±âÈ­
					m_nChallengeZoneAllocatedCH[i][0]	= 0;
					m_nChallengeZoneAllocatedCH[i][1]	= 0;
					m_nChallengeZoneAgentChannelID[i]	= 0;
					return nChannel;
				}
			}
		}
	}

	DWORD ChannelIDX = BATTLESYSTEM->CreateChannel();
	int ii = 0;
	for( ii = 0; ii < MAX_QUEST_OR_CHALLENGE_CHANNEL_NUM; ++ii )
	{
		if( m_QMChannel[ii].GetChannelID() == 0 )
			break;
	}

	if( ii > MAX_QUEST_OR_CHALLENGE_CHANNEL_NUM-1 )	return 0;

	m_QMChannel[ii].SetChannelID( ChannelIDX );
	
	++m_dwCount;

	if (g_csDateManager.IsChallengeZoneHere())
	{
		for(DWORD i=0; i<1000; i++)
		{
			if (m_nChallengeZoneAllocatedCH[i][0] == 0)
			{
				m_nChallengeZoneAllocatedCH[i][0]	= ChannelIDX;
				m_nChallengeZoneAllocatedCH[i][1]	= nFirstEnterPlayerID;
				m_nChallengeZoneAgentChannelID[i]	= m_nChallengeZonePlayerAgentChannelID;
				m_nChallengeZoneLastChannelID		= ChannelIDX;
				m_nChallengeZoneAllocatedCHNum++;
				// ..ÆÄÆ®³Ê¾øÀÌ È¥ÀÚ Á¢¼ÓµÇ¾úÀ» °æ¿ì¿¡ ´ëºñÇØ¼­ ÀÏÁ¤½Ã°£ ÆÄÆ®³ÊÀÇ Á¢¼ÓÀÌ ¾ø¾î¼­ ÃÊ±âÈ­°¡ µÇÁö ¾ÊÀº Á¤º¸´Â ÃÊ±âÈ­ÇÑ´Ù.
				if (i >= 500)
				{
					m_nChallengeZoneAllocatedCH[i-500][0]	= 0;
					m_nChallengeZoneAllocatedCH[i-500][1]	= 0;
					m_nChallengeZoneAgentChannelID[i-500]	= 0;
				}
				if (g_pServerSystem->IsTestServer())
				{
					g_Console.LOG(4, "Create ChallengeZone Channel:%d ChannelQty(or EnterFreq):%d Agent CHID:%d", ChannelIDX, m_nChallengeZoneAllocatedCHNum, m_nChallengeZonePlayerAgentChannelID);
				}
				break;
			}
		}
	}

	return ChannelIDX;
}

BOOL CChannelSystem::GetChallengeZonePartnerCH(DWORD nChallengeZoneAgentChannelID)
{
	DWORD nCnt = 1000;
	if (nCnt > m_nChallengeZoneAllocatedCHNum) nCnt = m_nChallengeZoneAllocatedCHNum;

	for(DWORD i=0; i<nCnt; i++)
	{
		if (m_nChallengeZoneAgentChannelID[i] == nChallengeZoneAgentChannelID)
		{
			return m_nChallengeZoneAllocatedCH[i][0];
		}
	}

	return 0;
}

void CChannelSystem::DestroyQuestMapChannel( DWORD dwChannel )
{
	if( !m_bQuestMap )	return;

	for( int i = 0; i < MAX_QUEST_OR_CHALLENGE_CHANNEL_NUM; ++i )
	{
		if( m_QMChannel[i].GetChannelID() == dwChannel )
		{
			m_QMChannel[i].SetChannelID( 0 );
			break;
		}
	}
	--m_dwCount;

	BATTLESYSTEM->DestroyChannel( dwChannel );

	// desc_hseos_µ¥ÀÌÆ® Á¸_01
	// S µ¥ÀÌÆ® Á¸ Ãß°¡ added by hseos 2007.11.28
	// ..2¸íÀÇ ÇÃ·¹ÀÌ¾î ÀÔÀå¿¡ »ç¿ëÇÏ´Â Ã¤³Î°ú ÆÄÆ®³ÊID °ªÀ» ÃÊ±âÈ­ÇÑ´Ù.
	// ..ÃÊ±âÈ­ÇÏÁö ¾ÊÀ» °æ¿ì, ¸ÕÀú µé¾î¿Â ÇÃ·¹ÀÌ¾î°¡ Á¢¼ÓÀ» ²÷°í, Ã¤³ÎÀ» Áö¿ü´Âµ¥
	// ..³ªÁß¿¡ µé¾î¿Â ÇÃ·¹ÀÌ¾î°¡ Áö¿î Ã¤³ÎÀ» ÇÒ´ç¹Þ¾Æ¼­ °Å±â·Î µé¾î°£´Ù.
	// ..ÀÌ·² °æ¿ì ¾Æ¸¶ ´Ù¸¥ ÆÀ°ú °°Àº Ã¤³ÎÀ» »ç¿ëÇÏ°Ô µÈ´Ù°Å³ª ¹º°¡ ²¿ÀÌ´Â ÀÏÀÌ ¹ß»ýÇÒ µí..
	if (g_csDateManager.IsChallengeZoneHere())
	{
		if (g_pServerSystem->IsTestServer())
		{
			g_Console.LOG(4, "Delete ChallengeZone Channel:%d", dwChannel);
		}

		DWORD nCnt = 1000;
		if (nCnt > m_nChallengeZoneAllocatedCHNum) nCnt = m_nChallengeZoneAllocatedCHNum;

		for(DWORD i=0; i<nCnt; i++)
		{
			if (m_nChallengeZoneAllocatedCH[i][0] == dwChannel)
			{
				m_nChallengeZoneAllocatedCH[i][0]	= 0;
				m_nChallengeZoneAllocatedCH[i][1]	= 0;
				m_nChallengeZoneAgentChannelID[i]	= 0;
				if (g_pServerSystem->IsTestServer())
				{
					g_Console.LOG(4, "Delete ChallengeZone ChannelInfo(Alone):%d", dwChannel);
				}
				break;
			}
		}
	}
}

void CChannelSystem::Init( WORD wMapNum, WORD wChannelNum )
{
	if( QUESTMAPMGR->Init( wMapNum ) )	return;

	LoadChannelInfo();
	CreateChannel(0, BYTE( wChannelNum ) );
}

DWORD CChannelSystem::GetPlayerNumInChannel(int index)
{
	if(HOUSINGMAPNUM == g_pServerSystem->GetMapNum())
	{
		return HOUSINGMGR->GetPlayerNumInHouse(index);
	}
	else if(DungeonMGR->IsDungeon(g_pServerSystem->GetMapNum()))
	{
		return DungeonMGR->GetPlayerNumInDungeon(index);
	}
	else if(QUESTMAPMGR->IsQuestMap())
	{
		DWORD dwPlayerNum = m_QMChannel[index-1].GetPlayerNum();
		return dwPlayerNum;
	}

	--index;

	if( int(m_dwCount) <= index )
	{
		return 0;
	}

	return m_Channel[index]->GetPlayerNum();
}
#ifdef _MYLUNA_
void CChannelSystem::Release()
{
	for(DWORD i=0; i<m_dwCount; ++i)
	{
		if(m_Channel[i])
		{		
			delete m_Channel[i];
			m_Channel[i] = NULL;
		}
	}
}
#endif
