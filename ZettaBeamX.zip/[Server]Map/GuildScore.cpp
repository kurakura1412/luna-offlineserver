#include "StdAfx.h"

#ifdef _MAP00_
//#include "[lib]yhlibrary/YHLibrary.h"
#include "[lib]yhlibrary/HashTable.h"
#include "[lib]yhlibrary/PtrList.h"
//#include "[lib]yhlibrary/cLooseLinkedList.h"
//#include "[lib]yhlibrary/cLinkedList.h"
//#include "[lib]yhlibrary/IndexGenerator.h"
//#include "[lib]yhlibrary/cConstLinkedList.h"
//#include "[CC]Header/vector.h"
#include "[CC]Header/protocol.h"
#include "[CC]Header/CommonDefine.h"
#include "[CC]Header/CommonGameDefine.h"
#include "[CC]Header/ServerGameDefine.h"
#include "[CC]Header/CommonStruct.h"
#include "[CC]Header/ServerGameStruct.h"
//#include "[CC]Header/CommonGameFunc.h"
//#include "[CC]Header/GameResourceStruct.h"
//#include "[CC]Header/CommonCalcFunc.h"
//#include "[CC]ServerModule/DataBase.h"
//#include "[CC]ServerModule/Console.h"
#include "Object.h"
//#include "ServerSystem.h"
#endif

#include "UserTable.h"
#include "Object.h"
#include "GuildScore.h"


CGuildScore::CGuildScore( DWORD unitTick, float tickScore ) :
mUnitTick( unitTick ),
mTickScore( tickScore ),
mUnitTickScore( tickScore * unitTick )
{
	Reset( GetTickCount() );
}


void CGuildScore::AddPlayer( DWORD playerIndex )
{
	mScore.mPrepareMember[ playerIndex ] = GetTickCount();
}


float CGuildScore::RemovePlayer( DWORD playerIndex )
{
	Score::ReadyMember&		readyMember		= mScore.mReadyMember;
	Score::PrepareMember&	prepareMember	= mScore.mPrepareMember;

	DWORD beginTick;
	
	// ¸¸¾à ´ë±â ¸ñ·Ï¿¡ ÀÖ´Â °æ¿ì ÁøÀÔ ½ÃÁ¡ÀÇ ½Ã°£À» °¨¾ÈÇÏ¿© °è»êÇÑ´Ù	
	if( prepareMember.end() != prepareMember.find( playerIndex ) )
	{
		beginTick = prepareMember[ playerIndex ];

		prepareMember.erase( playerIndex );
	}
	// ÀÏ°ý Ã³¸® ¸â¹ö¿¡ ÀÖÀ» °æ¿ì ÀÏ°ýÃ³¸®µÈ ½Ã°¢À» »ç¿ëÇÑ´Ù.
	else if( readyMember.end() != readyMember.find( playerIndex ) )
	{
		beginTick = mScore.mBeginTick;

		readyMember.erase( playerIndex );
	}
	else
	{
		ASSERT( 0 && "It means class has fault in AddMemeber()" );
		return 0.0f;
	}

	DWORD		tick;
	const DWORD currentTick = GetTickCount();

	// ¿À¹ö ÇÃ·ÎµÈ °æ¿ì ÃÖ´ë ±¸°£À» °¨¾ÈÇÏ¿© Â÷ÀÌ¸¦ °è»êÇØ¾ß ÇÑ´Ù.
	if( currentTick < beginTick )
	{
		tick = UINT_MAX - beginTick + currentTick;
	}
	else
	{
		tick = currentTick - beginTick;
	}

	const float score = float( tick ) / mUnitTick;
	ASSERT( 0 < score );

	return score;
}


BOOL CGuildScore::IsEnableScore( DWORD currentTick ) const
{
	// Æ½Ä«¿îÆ®°¡ ¿À¹öÇÃ·ÎµÈ »óÅÂÀÎ °æ¿ì ½ÃÀÛ°ªº¸´Ù´Â ÀÛ°í ³¡°ªº¸´Ù Æ½Ä«¿îÆ®°¡ Å¬ °æ¿ì Á¡¼ö¸¦ °è»êÇÒ ¼ö ÀÖ´Ù
	if( mScore.mEndTick < mScore.mBeginTick )
	{
		if(	mScore.mBeginTick > currentTick	&&
			mScore.mEndTick	< currentTick )
		{			
			return TRUE;
		}
	}
	// ¿À¹öÇÃ·ÎµÈ »óÅÂ°¡ ¾Æ´Ï¸é ³¡°ªº¸´Ù ÇöÀç Æ½Ä«¿îÆ®°¡ Å©¸é °è»êÇÒ ¼ö ÀÖ´Ù.
	else if( mScore.mEndTick < currentTick )
	{
		return TRUE;
	}

	return FALSE;
}


float CGuildScore::GetScore( DWORD currentTick ) const
{
	// ¿©±â¿¡´Â »ç³É, Å»Åð, Ãß¹æ µîÀ¸·Î ÀÎÇØ º¯°æµÈ Á¡¼ö°¡ ´õÇØÁ® ÀÖ´Ù.
	float score = mScore.mScore;

	// ¸â¹ö¸¶´Ù ´ÜÀ§ Á¡¼ö¸¦ ºÎ¿©
	{
		score += mScore.mReadyMember.size() * mUnitTickScore;
	}

	// 1½Ã°£ ³» °¡ÀÔ/·Î±×ÀÎÇÑ ¸â¹ö Á¡¼ö °è»ê
	for(	Score::PrepareMember::const_iterator it = mScore.mPrepareMember.begin();
			mScore.mPrepareMember.end() != it;
			++it )
	{
		const DWORD addedTick	= it->second;
		DWORD		tick;

		/*
		À¯ÇÑ ¹üÀ§¸¦ °®´Â µÎ °ªÀÇ Â÷ÀÌ¸¦ ±¸ÇÏ´Â ¹æ¹ýÀº µÎ °¡Áö°¡ ÀÖ´Ù.

		(1)		  A    B			(2)	   B   A
				+----+----+				+----+----+

		A ´ÙÀ½¿¡ B°¡ ±â·ÏµÈ´Ù°í ÇØº¸ÀÚ. (1)ÀÇ °æ¿ì´Â ½±°Ô °è»êµÈ´Ù.
		(2)ÀÇ °æ¿ì´Â ÃÖ´ë°ª¿¡¼­ A¸¦ »« Â÷ÀÌ¿¡ B¸¦ ´õÇØ¼­ Â÷ÀÌ¸¦ ¾ò¾î¾ßÇÑ´Ù.
		*/
		if( currentTick < addedTick )
		{
			tick = UINT_MAX - addedTick + currentTick;
		}
		else
		{
			tick = currentTick - addedTick;
		}

		const float memberScore = mTickScore * tick;
		ASSERT( 0 < memberScore );

		score += memberScore;
	}

	return score;
}


void CGuildScore::Reset( DWORD currentTick )
{
	// °³º° Ã³¸® ¸â¹ö¸¦ ÀÏ°ý Ã³¸® ¸â¹ö·Î ÀÌµ¿½ÃÅ²´Ù.
	for(	Score::PrepareMember::const_iterator it = mScore.mPrepareMember.begin();
			mScore.mPrepareMember.end() != it;
			++it )
	{
		const DWORD playerIndex = it->first;

		mScore.mReadyMember.insert( playerIndex );
	}

	// ÃÊ±âÈ­: ÀÌº¥Æ®¸¦ Áö¿ì°í Á¡¼öµµ ÃÊ±âÈ­ÇÑ´Ù.
	// ½Ã°£ À¯´ÖÀ» 1½Ã°£ µÚ·Î º¯°æÇØ³õ°í, ¸®½ºÆ® ¸Ç µÚ¿¡ ³õ´Â´Ù. ¿Ö? 1½Ã°£ÀÌ Áö³ª¸é ´Ù½Ã °è»êÇØ¾ßÇÏ´Ï±î..
	{
		mScore.mScore		= 0;
		mScore.mBeginTick	= currentTick;
		mScore.mEndTick		= currentTick + mUnitTick;

		mScore.mPrepareMember.clear();
	}
}


void CGuildScore::AddScore( float score )
{
	mScore.mScore += score;
}


DWORD CGuildScore::GetPlayerSize() const
{
	return mScore.mPrepareMember.size() + mScore.mReadyMember.size();
}

void CGuildScore::Send( MSGBASE* message, DWORD size ) const
{
	// °³º° Ã³¸® ¸â¹ö µ¥ÀÌÅÍ ¼¼ÆÃ
	for(	Score::PrepareMember::const_iterator it = mScore.mPrepareMember.begin();
			mScore.mPrepareMember.end() != it;
			++it )
	{
		const DWORD playerIndex = it->first;
		CObject*	object		= g_pUserTable->FindUser( playerIndex );

		if( object )
		{
			object->SendMsg( message, size );
		}
	}

	// ÀÏ°ý Ã³¸® ¸â¹ö µ¥ÀÌÅÍ ¼¼ÆÃ
	// °³º° Ã³¸® ¸â¹ö µ¥ÀÌÅÍ ¼¼ÆÃ
	for(	Score::ReadyMember::const_iterator it = mScore.mReadyMember.begin();
			mScore.mReadyMember.end() != it;
			++it )
	{
		const DWORD playerIndex = *it;
		CObject*	object		= g_pUserTable->FindUser( playerIndex );

		if( object )
		{
			object->SendMsg( message, size );
		}
	}	
}