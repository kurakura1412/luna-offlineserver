
#include "MoonLigh.h"
#include "WarpDist.h"
#include "WarpAgent.h"
#include "WarpMap.h"
#include "Protocol.h"
#include <fstream>
//#include <CommonStruct.h>
#include "HeavyLog.h"
#include "nanodbc/nanodbc.h"
#define TO_AGENT 11
#define TO_DIST 13
#define TO_MAP 15
#define DBMEMBER 99
#define DBGAME 44
#define DBLOG	101

void MoonLigh::PushQuery(DWORD dbnum,DWORD dwfromdb, DWORD carryID, 
CB_func cllbck, std::string& querystr)
{
	ZetQue* topush = nullptr;
	DWORD idx = 0;
	/*if( dwfromdb == TO_AGENT){
		idx = _queryagent.size();
		_queryagent.resize(idx + 1 );
		topush = &(_queryagent[idx]);
	} else if( dwfromdb == TO_DIST){
		idx = _querydist.size();
		_querydist.resize(idx + 1 );
		topush = &(_querydist[idx]);
	} else if( dwfromdb == TO_MAP){
		idx = _querymap.size();
		_querymap.resize(idx + 1 );
		topush = &(_querymap[idx]);
	} else { return;}*/
	if( cllbck != nullptr){
		idx = _queryCB.size();
		_queryCB.resize(idx + 1 );
		topush = &(_queryCB[idx]);
	} else {
		idx = _queryNR.size();
		_queryNR.resize(idx + 1 );
		topush = &(_queryNR[idx]);
	}
	if( dbnum == DBMEMBER){
		topush->conn = _dbmember;
	} else if( dbnum == DBGAME){
		topush->conn = _dbgame;
	} else {
		topush->conn = _dblog;
	} 
	topush->dwfromdb = dwfromdb;
	topush->carryId = carryID;
	topush->bufque = querystr;
	topush->cllbck = cllbck;
}
bool MoonLigh::testconn()
{
	std::ifstream ifs("zconf.txt");
	if( !ifs.good() ) return false;
	std::string key,tempstr,gamedsn, gameusr , gamepwd, logdsn, 
		logusr, logpwd, memberdsn, memberusr, memberpwd;
	unsigned int nmn = 0;
	while( !ifs.eof() ){
		ifs >> tempstr;
		//printf("%s\n",tempstr.c_str());
		nmn = tempstr.find("=");
		if( nmn != tempstr.npos){
			key.clear();
			key.assign(&(tempstr[0]),&(tempstr[nmn])  );
			if( key == "*GAMEDB" ){
				gamedsn = &(tempstr[nmn + 1]) ;
			} else if( key == "*GAMEDBUSR" ){
				gameusr = &(tempstr[nmn + 1]) ;
			} else if( key == "*GAMEDBPWD" ){
				gamepwd = &(tempstr[nmn + 1]) ;
			} else if( key == "*LOGDB" ){
				logdsn = &(tempstr[nmn + 1]) ;
			} else if( key == "*LOGDBUSR" ){
				logusr = &(tempstr[nmn + 1]) ;
			} else if( key == "*LOGDBPWD" ){
				logpwd = &(tempstr[nmn + 1]) ;
			} else if( key == "*MEMBERDB" ){
				memberdsn = &(tempstr[nmn + 1]) ;
			} else if( key == "*MEMBERDBUSR" ){
				memberusr = &(tempstr[nmn + 1]) ;
			} else if( key == "*MEMBERDBPWD" ){
				memberpwd = &(tempstr[nmn + 1]) ;
			} 
		}
	}
	_dbmember = new (std::nothrow) nanodbc::connection();
	_dbmember->connect( memberdsn, memberusr, memberpwd);
	if( _dbmember->connected() ){
		printf( "MEMBERDB OK\n" );
	} else { dbdisconn(); }
	_dbgame = new (std::nothrow) nanodbc::connection();
	_dbgame->connect( gamedsn, gameusr, gamepwd);
	if( _dbgame->connected() ){
		printf( "GAMEDB OK\n" );
	} else { dbdisconn(); }
	_dblog = new (std::nothrow) nanodbc::connection();
	_dblog->connect( logdsn, logusr, logpwd);
	if( _dblog->connected() ){
		printf( "LOGDB OK\n" );
	} else { dbdisconn(); }
	return true;
}
void MoonLigh::dbdisconn()
{
	if(_dbmember) {
		_dbmember->disconnect();
		delete _dbmember; _dbmember = nullptr ;} 
	if(_dbgame) {
		_dbgame->disconnect();
		delete _dbgame; _dbgame = nullptr ;} 
	if(_dblog) {
		_dblog->disconnect();
		delete _dblog; _dblog = nullptr ;} 
}
void MoonLigh::dbproca()
{
	if( _queryCB.empty()) return;
	std::vector< ZetQue > vTemp(_queryCB.begin(),_queryCB.end() );
	_queryCB.clear();
	for(std::vector< ZetQue >::iterator it = vTemp.begin(), 
		itend = vTemp.end()
		; it != itend; ++it	){
			ZetQue* pzet = &(*it);
			dbprinter(pzet);
			nanodbc::result resl= nanodbc::execute(*(pzet->conn),pzet->bufque  );
			MYquery terno;
			mydbmessage mmdb;
			mmdb.dwID = pzet->carryId;
			terno.resl = &resl;
			//terno.dwcoll = resl.columns();
			try {
			pzet->cllbck(&terno, &mmdb );
			
			} catch(std::exception & ee){
				printf("ERROR when execute callback.\n%s\n",ee.what());
				printf("sql: %s\n",pzet->bufque.c_str());
				printf("error detected: quitting.\n");
				exit(1);
			}catch(...){
				printf("ERROR when execute callback.\nsql: %s\nerror detected: quitting.\n",pzet->bufque.c_str());
				exit(1);
			}
	}
}
void MoonLigh::dbprocaNoReturn()
{
	if( _queryNR.empty()) return;
	std::vector< ZetQue > vTemp(_queryNR.begin(),_queryNR.end() );
	_queryNR.clear();
	for(std::vector< ZetQue >::iterator it = vTemp.begin(), 
		itend = vTemp.end()
		; it != itend; ++it	){
			ZetQue* pzet = &(*it);
			dbprinter(pzet);
			try {
			nanodbc::execute(*(pzet->conn),pzet->bufque  );
			} catch(std::exception& ee){
				printf("!!!sql failed: %s\nquery: %s\n",ee.what(),pzet->bufque.c_str() );
			} catch (...) {
				printf("!!!sql failed: unknown error.\nquery: %s\n",pzet->bufque.c_str());
			}
	}
}
void MoonLigh::dbprinter(ZetQue* zetta)
{
	std::string tonga;
	unsigned int asds = 0;
	unsigned int tosvr = zetta->dwfromdb;
	if( (asds = zetta->bufque.find(" ", 6)) != zetta->bufque.npos ){
		tonga.clear();
		tonga.assign(&(zetta->bufque[0]),&(zetta->bufque[asds]) );
		if( zetta->cllbck == nullptr ){
			if( tosvr == TO_AGENT)
			printf("-a: %s\n",tonga.c_str());
		if( tosvr == TO_DIST)
			printf("-d: %s\n",tonga.c_str());
		if( tosvr == TO_MAP)
		printf("-m: %s\n",tonga.c_str());
		} else {
		if( tosvr == TO_AGENT)
			printf("aa: %s\n",tonga.c_str());
		if( tosvr == TO_DIST)
			printf("dd: %s\n",tonga.c_str());
		if( tosvr == TO_MAP)
		printf("mm: %s\n",tonga.c_str());
		}
	} else {
		if( zetta->cllbck == nullptr ){
			if( tosvr == TO_AGENT)
			printf("-a: %s\n",zetta->bufque.c_str());
		if( tosvr == TO_DIST)
			printf("-d: %s\n",zetta->bufque.c_str());
		if( tosvr == TO_MAP)
		printf("-m: %s\n",zetta->bufque.c_str());
		} else {
		if( tosvr == TO_AGENT)
			printf("aa: %s\n",zetta->bufque.c_str());
		if( tosvr == TO_DIST)
			printf("dd: %s\n",zetta->bufque.c_str());
		if( tosvr == TO_MAP)
			printf("mm: %s\n",zetta->bufque.c_str());
	}
	}
}
