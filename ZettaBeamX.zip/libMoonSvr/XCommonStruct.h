#ifndef XCOMMON_STRUCT_H
#define XCOMMON_STRUCT_H

typedef unsigned long long DWORDEX;
typedef WORD MAPTYPE;
typedef DWORDEX EXPTYPE;
typedef WORD LEVELTYPE;
typedef DWORD DURTYPE;
typedef WORD POSTYPE;
typedef DWORD ITEMPARAM;
typedef int FAMETYPE;
typedef DWORD MARKNAMETYPE;
typedef DWORD MONEYTYPE;
#define MAXMONEY MAXULONG_PTR // 0xffffffff(4294967295)
#define MAX_JOB_GRADE 6

#endif