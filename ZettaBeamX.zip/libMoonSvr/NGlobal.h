#ifndef NGLOBAL_H
#define NGLOBAL_H

#ifndef _MYLUNA_
#ifndef GLOBAL_FUNC_DLL
#define GLOBAL_FUNC_DLL extern "C" __declspec(dllimport) 
#endif
#else
	#define GLOBAL_FUNC_DLL
#endif

#include "typedef.h"
#include "type.h"
GLOBAL_FUNC_DLL void	__stdcall Normalize(VECTOR3* OUT vn,VECTOR3* IN v);
GLOBAL_FUNC_DLL void	__stdcall VECTOR3_SUB_VECTOR3(VECTOR3* pv3Result,VECTOR3* pv3Arg1,VECTOR3* pv3Arg2);

GLOBAL_FUNC_DLL BOOL	__stdcall SetIdentityMatrix(MATRIX4* pMat);
GLOBAL_FUNC_DLL void	__stdcall SetRotationYMatrix(MATRIX4* pMat, float fRad);
GLOBAL_FUNC_DLL void	__stdcall TransformVector3_VPTR2(VECTOR3* pv3Dest,VECTOR3* pv3Src, MATRIX4* pMat,DWORD dwNum);
GLOBAL_FUNC_DLL float	__stdcall CalcDistance(VECTOR3* pv3Start,VECTOR3* pv3End);

class NGlobal
{
public:
	NGlobal();
	~NGlobal();

};

#endif // NGLOBAL_H
