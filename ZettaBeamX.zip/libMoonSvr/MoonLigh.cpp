#include <windows.h>
#include <winbase.h>

#include "MoonLigh.h"

#include "WarpDist.h"
#include "WarpAgent.h"
#include "WarpMap.h"
#include "Protocol.h"

//#include <CommonStruct.h>
#include "HeavyLog.h"

#define TO_AGENT 11
#define TO_DIST 13
#define TO_MAP 15
#define STARTMAP 19 //// alker village

MoonLigh::MoonLigh()
{
	_meaw = nullptr;
	_hlog = nullptr;
	_dist = nullptr;
	_map0 = nullptr;
	_agent = nullptr;
	_dbmember = nullptr;
	_dbgame = nullptr;
	_dblog = nullptr;
	_states = 0;
	_skipnextupdate = false;
	_alive = false;
}

MoonLigh::~MoonLigh()
{
	if(_agent) {delete _agent; _agent = nullptr ;}
	if(_dist) {delete _dist; _dist = nullptr ;}
	if(_map0) {delete _map0; _map0 = nullptr ;}
	if(_hlog) {delete _hlog; _hlog = nullptr ;} 
}

bool MoonLigh::init()
{
	if(!testconn()) return false;
	//_queryagent.reserve(300);
	//_querydist.reserve(300);
	//_querymap.reserve(300);
	_queryCB.reserve(99);
	_queryNR.reserve(99);
	_hlog = new(std::nothrow) HeavyLog;
	_hlog->init();
	_alive = true;
	_agent = new (std::nothrow) WarpAgent;
	_agent->setNetData(this); 
	if( !_agent->init() ){ return false;	}
	_dist = new (std::nothrow) WarpDist;
	_dist->setNetData(this);
	if( !_dist->init() ){ return false;	}
	_map0 = new (std::nothrow) WarpMap;
	_map0->setNetData(this);
	if( !_map0->init(STARTMAP) ){ return false;	}
	while( !_queryCB.empty() )
	{
		Sleep(30);
		dbproca();
	}
	Sleep(30);
	dbprocaNoReturn();
	return true;
}

void MoonLigh::gprocess()
{
	if( _skipnextupdate ){
		_skipnextupdate = false;
		return;
	}
	dbproca();
	dbprocaNoReturn();
	if( _agent ) _agent->Update();
	if( _dist ) _dist->Update();
	if( _map0 ) _map0->Update();
	
}
void MoonLigh::updatenow()
{
	dbproca();
	dbprocaNoReturn();
	if( _map0 ){ 
		_map0->updatemove();
		_map0->Update();
		};
	_skipnextupdate = true;
}
void MoonLigh::setsendcb( std::function<void(std::vector<unsigned char>&, void * )> cbb,
 void * meawdata )
{
	_sendcb = cbb;
	_meaw = meawdata;
}
void MoonLigh::onfirst()
{
	_dist->onFisrtConnect( 4 );
}

void MoonLigh::toclient(std::vector<unsigned char>& vdat)
{
	//printf("sending...\n");
	_sendcb( vdat, _meaw);
}

void MoonLigh::onrecvdata(std::vector<char> & vdata)
{
	_hlog->atrecv( vdata.at(3), vdata.at(4));
	int gointo = goesToABC(vdata);
	unsigned short iso = *(unsigned short*)&(vdata[0]);
	unsigned int dwlen = iso, flen = vdata.size() - 2;
	
	if( iso < flen ){
		//printf( "[error]data len bigger. %u:%u\n",iso, flen );
		std::vector< char > vtempa;
		
		vtempa.reserve(4096);
		int zzero = 0, abree, treea,remainlen = vdata.size();
		while( remainlen > 1){
			vtempa.clear();
			iso = *(unsigned short*)&(vdata[zzero]);
			treea = iso + 2;
			abree = remainlen - treea;
			if( abree >= 0 ){
				vtempa.assign(&vdata[zzero],&vdata[zzero + treea]  );
			} else {
				//vtempa.assign(&vdata[zzero],&vdata[flen + 1] );
				printf( "[error]uncomplete data.\n" );
				break;
			}
			remainlen -= treea;
			zzero += treea;
			if( !vtempa.empty()){
				gointo = goesToABC(vtempa);
				if( gointo == TO_DIST){
					_dist->parseIN(4,&(vtempa.at(2)),vtempa.size() - 2 );
				} else if( gointo == TO_AGENT ){
					_agent->parseIN(4,&(vtempa.at(2)),vtempa.size() - 2 );
				}
			}
		}
		updatenow();
		return;
	} else if( iso > flen ){
		printf( "[error]need more data. %u:%u\n",iso, flen );
		return;
	}
	if( gointo == TO_DIST){
		_dist->parseIN(4,&(vdata.at(2)),dwlen);
	} else if( gointo == TO_AGENT ){
		_agent->parseIN(4,&(vdata.at(2)),dwlen);
	}
	
	updatenow();
}
int MoonLigh::goesToABC(std::vector< char>& vdat)
{
	return goesToABCD(&(vdat[2]));
}
int MoonLigh::goesToABCD(char* vdat)
{
	BYTE Category = *(vdat + 1);
	BYTE Protocol = *(vdat + 2);
	int ret = TO_AGENT;
	switch(Category){
		case MP_USERCONN:
			switch( Protocol ){
				case MP_USERCONN_LOGIN_DYNAMIC_SYN:
				case MP_USERCONN_LOGIN_SYN:
				case MP_USERCONN_FORCE_DISCONNECT_OVERLAPLOGIN:
				case MP_USERCONN_NOTIFY_USERLOGIN_ACK:
				case MP_USERCONN_NOTIFY_USERLOGIN_NACK:
				case MP_USERCONN_REQUEST_DISTOUT:
				case MP_USERCONN_CONNECTION_CHECK_OK:
				case MP_USERCONN_BILLING_CHECK_ACK:
				case MP_USERCONN_BILLING_CHECK_NACK:
				case MP_USERCONN_BILLING_STOP_SYN:
				ret = TO_DIST;
			}
			break;
		case MP_CHATROOM:
			switch( Protocol ){
				case MP_CHATROOM_ADD_USER_SYN :
				case MP_CHATROOM_FORCE_ADD_USER_SYN :
				case MP_CHATROOM_DEL_USER_SYN :
				case MP_CHATROOM_ROOM_SYN :
				case MP_CHATROOM_CREATE_ROOM_SYN :
				case MP_CHATROOM_JOIN_ROOM_SYN :
				case MP_CHATROOM_OUT_ROOM_SYN :
				case MP_CHATROOM_CHANGE_OPTION_SYN :
				case MP_CHATROOM_CHANGE_OWNER_SYN :
				case MP_CHATROOM_KICK_GUEST_SYN :
				case MP_CHATROOM_REQUEST_FRIEND_SYN :
				case MP_CHATROOM_UPDATE_USERINFO_SYN :
				case MP_CHATROOM_SEARCH_FOR_NAME_SYN :
				case MP_CHATROOM_SEARCH_FOR_TITLE_SYN :
				ret = TO_DIST;
			}
		default: break;
	}
	
	return ret;
}
void MoonLigh::ChangeMap(unsigned int dwmapnum)
{
	_map0->ChangeMap(dwmapnum);
}
void MoonLigh::AskedChannelMap(unsigned int dwmapnum)
{
	_map0->AskChannel(dwmapnum);
}
void MoonLigh::onlibeventdisconnect()
{
	if( _states !=0 && _map0){
		_map0->ondisconnectuser(4);
	}
}
void MoonLigh::EndofWorld()
{
	_alive = false;
	if(_agent) _agent->end();
	if(_dist) _dist->end();
	if(_map0) _map0->end();
	while( !_queryCB.empty() )
	{
		Sleep(30);
		dbproca();
	}
	Sleep(30);
	dbprocaNoReturn();
}
