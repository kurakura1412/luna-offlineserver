
#include "MoonLigh.h"
#include "WarpDist.h"
#include "WarpAgent.h"
#include "WarpMap.h"
#include "Protocol.h"
//#include <CommonStruct.h>
#include "HeavyLog.h"

#define TO_AGENT 11
#define TO_DIST 13
#define TO_MAP 15

void MoonLigh::Send2User(DWORD dwConnectionIndex, char* msg, DWORD size)
{
	std::vector<unsigned char> t_vec;
	t_vec.resize( size + 2 );
	memcpy( &(t_vec.at(2)), msg, size );
	unsigned short * ia = (unsigned short *)&(t_vec.at(0));
	*ia = size;
	_hlog->atsend( t_vec.at(3), t_vec.at(4));
	toclient(t_vec);
}

void MoonLigh::Send2Server(DWORD dwConnectionIndex, char* msg, DWORD size)
{
	if( !_alive ) return;
	switch( dwConnectionIndex ){
		case 1: _agent->parseINSVR(4, msg,size); break;
		case 2: _dist->parseINSVR(4, msg,size); break;
		case 3: _map0->parseINSVR(4, msg,size); break;
		default:
			asm("int3");
			break;
	}
}

void MoonLigh::Send2AgentServer(char* msg, DWORD size)
{
	if( _agent && _alive ){
	//_agent->parseIN(4, msg,size);
	_agent->parseINSVR(4, msg,size);
	}
}

void MoonLigh::Send2SpecificAgentServer(char* msg, DWORD size)
{
}

void MoonLigh::Send2DistributeServer(char* pMsg, DWORD dwLength)
{
	if( _dist ){
		_dist->parseINSVR(4, pMsg,dwLength);
	}
}

void MoonLigh::Send2AgentExceptThis(char* pMsg, DWORD dwLength)
{
}

void MoonLigh::Broadcast2Server(char* msg, DWORD size)
{
	
}

void MoonLigh::Broadcast2User(char* msg, DWORD size)
{
	Send2User(4, msg, size);
}

void MoonLigh::Broadcast2MapServer(char* msg, DWORD size)
{
	SendtoMapServer(4,msg,size  );
}

void MoonLigh::Broadcast2MapServerExceptOne(DWORD dwConnectionIndex, char* msg, DWORD size)
{
}

void MoonLigh::Broadcast2AgentServer(char* msg, DWORD size)
{
	Send2AgentServer(msg, size);
}

void MoonLigh::Broadcast2AgentServerExceptOne(DWORD dwConnectionIndex, char* msg, DWORD size)
{
}

void MoonLigh::Broadcast2AgentServerExceptSelf(char* msg, DWORD size)
{
}

void MoonLigh::DisconnectUser(DWORD dwConnectionIndex)
{
	if( _states == 0){
		_states = 1;
		_agent->acceptplayer(4);
	} else if(_states == 1){
		
		printf("MoonLigh disconnecting...\n");
	}
}

void MoonLigh::SendtoMapServer(DWORD dwConnectionIndex, char* msg, DWORD size)
{ 
	if( _map0 ) _map0->parseINSVR(dwConnectionIndex, msg, size);
}
