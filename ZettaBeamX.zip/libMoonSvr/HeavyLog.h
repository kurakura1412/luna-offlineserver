#ifndef HEAVYLOG_H
#define HEAVYLOG_H

#include <unordered_map>
#include <string>

class HeavyLog
{
public:
	HeavyLog();
	~HeavyLog();
	bool init();
	void atsend(unsigned char cat, unsigned char prot);
	void atrecv(unsigned char cat, unsigned char prot);
private:
	void loaddata();
	bool isOKprint(unsigned char cat, unsigned char prot);
	bool loaded;
	std::unordered_map<int, std::string> _mcat;
	std::unordered_map<int, std::string> _mprt;
	std::string readSTR( std::vector<char>& tvec, unsigned int & seeker);
};

#endif // HEAVYLOG_H
