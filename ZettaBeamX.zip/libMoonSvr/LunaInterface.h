#ifndef __LUNAINTRV__H
#define __LUNAINTRV__H

#include <windef.h>
#include "WNano.h"
//#include <CommonStruct.h>
//typedef std::function<void(LPQUERY,LPDBMESSAGE)> CB_func;
class MoonBase
{
public:
	MoonBase(){};
	virtual ~MoonBase(){};
	virtual void Send2User(DWORD dwConnectionIndex, char * msg, DWORD size)=0;
	virtual void Send2Server(DWORD dwConnectionIndex, char * msg, DWORD size)=0;
	virtual void Send2AgentServer(char * msg, DWORD size)=0;
	virtual void Send2SpecificAgentServer(char * msg, DWORD size)=0;
	virtual void Send2DistributeServer(char* pMsg, DWORD dwLength)=0;
	virtual void Send2AgentExceptThis(char* pMsg, DWORD dwLength)=0;
	virtual void Broadcast2Server(char * msg, DWORD size)=0;
	virtual void Broadcast2User(char * msg, DWORD size)=0;
	virtual void Broadcast2MapServer(char * msg, DWORD size)=0;
	virtual void Broadcast2MapServerExceptOne(DWORD dwConnectionIndex, char * msg, DWORD size)=0;
	virtual void Broadcast2AgentServer(char* msg, DWORD size)=0;
	virtual void Broadcast2AgentServerExceptOne(DWORD dwConnectionIndex, char* msg, DWORD size)=0;
	virtual void Broadcast2AgentServerExceptSelf(char* msg, DWORD size)=0;
	virtual void DisconnectUser(DWORD dwConnectionIndex)=0;
	
	virtual void PushQuery(DWORD dbnum,DWORD dwfromdb, DWORD carryID, CB_func cb, std::string& querystr )=0;
	virtual void ChangeMap(unsigned int dwmapnum)=0;
	virtual void AskedChannelMap(unsigned int dwmapnum)=0;
};


#endif // __LUNAINTRV__H