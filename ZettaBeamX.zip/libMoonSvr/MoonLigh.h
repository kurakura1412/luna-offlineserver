#ifndef __MoonLigh__h
#define __MoonLigh__h

#include <functional>
#include <vector>
#include "LunaInterface.h"

struct ZetQue
{
	nanodbc::connection *conn=nullptr;
	DWORD dwfromdb=0;
	DWORD carryId=0;
	CB_func cllbck;
	std::string bufque;
};

typedef std::vector<char> VCharsd;
class WarpAgent;
class WarpDist;
class WarpMap;
class HeavyLog;
class MoonLigh : public MoonBase
{
public:

	MoonLigh();
	virtual ~MoonLigh();
	void Send2User(DWORD dwConnectionIndex, char* msg, DWORD size);
	void Send2Server(DWORD dwConnectionIndex, char * msg, DWORD size);
	void Send2AgentServer(char * msg, DWORD size);
	void Send2SpecificAgentServer(char * msg, DWORD size);
	void Send2DistributeServer(char* pMsg, DWORD dwLength);
	void Send2AgentExceptThis(char* pMsg, DWORD dwLength);
	void Broadcast2Server(char * msg, DWORD size);
	void Broadcast2User(char * msg, DWORD size);
	void Broadcast2MapServer(char * msg, DWORD size);
	void Broadcast2MapServerExceptOne(DWORD dwConnectionIndex, char * msg, DWORD size);
	void Broadcast2AgentServer(char* msg, DWORD size);
	void Broadcast2AgentServerExceptOne(DWORD dwConnectionIndex, char* msg, DWORD size);
	void Broadcast2AgentServerExceptSelf(char* msg, DWORD size);
	void DisconnectUser(DWORD dwConnectionIndex);
	void SendtoMapServer(DWORD dwConnectionIndex, char* msg, DWORD size);
	void PushQuery(DWORD dbnum,DWORD dwfromdb, DWORD carryID, CB_func cllbck, std::string& querystr );
	void ChangeMap(unsigned int dwmapnum);
	void AskedChannelMap(unsigned int dwmapnum);
	
	bool init();
	void gprocess();
	void setsendcb( std::function<void(std::vector<unsigned char>&, void * )> cbb, void * meawdata );
	void onfirst();
	void onrecvdata(std::vector<char>& vdata );
	void onlibeventdisconnect();
	void EndofWorld();
private:
	void toclient(std::vector<unsigned char>& vdat);
	int goesToABC( std::vector< char>& vdat );
	int goesToABCD( char* vdat );
	bool testconn();
	void dbdisconn();
	void updatenow();
	void dbproca();
	void dbprocaNoReturn();
	void dbprinter(ZetQue* zetta);
	void * _meaw;
	std::function<void(std::vector<unsigned char>&, void *)> _sendcb;
	WarpAgent* _agent;
	WarpDist* _dist;
	WarpMap* _map0;
	HeavyLog* _hlog;
	int _states;
	bool _skipnextupdate;
	bool _alive;
	nanodbc::connection * _dbmember;
	nanodbc::connection * _dbgame;
	nanodbc::connection * _dblog;
	//std::vector< ZetQue > _queryagent;
	//std::vector< ZetQue > _querydist;
	//std::vector< ZetQue > _querymap;
	std::vector< ZetQue > _queryCB;
	std::vector< ZetQue > _queryNR;
} ;
#endif // __MoonLigh__h
