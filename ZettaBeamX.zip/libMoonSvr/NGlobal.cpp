#include "stdafx.h"
#include <math.h>
#include <stdio.h>
#include "NGlobal.h"
GLOBAL_FUNC_DLL void __stdcall Normalize(VECTOR3* OUT vn,VECTOR3* IN v)
{
	float		sqt = (float)sqrt(v->x*v->x + v->y*v->y + v->z*v->z);
	if (sqt == 0.0f)
	{
		*vn = *v; 
		return;
	}
	vn->x = v->x /sqt;
	vn->y = v->y /sqt;
	vn->z = v->z /sqt;
}
GLOBAL_FUNC_DLL void __stdcall VECTOR3_SUB_VECTOR3(VECTOR3* pv3Result,VECTOR3* pv3Arg1,VECTOR3* pv3Arg2)
{
	pv3Result->x = pv3Arg1->x - pv3Arg2->x;
	pv3Result->y = pv3Arg1->y - pv3Arg2->y;
	pv3Result->z = pv3Arg1->z - pv3Arg2->z;
}
GLOBAL_FUNC_DLL BOOL __stdcall SetIdentityMatrix(MATRIX4* pMat)
{
    pMat->_12 = pMat->_13 = pMat->_14 = pMat->_21 = pMat->_23 = pMat->_24 = 0.0f;
    pMat->_31 = pMat->_32 = pMat->_34 = pMat->_41 = pMat->_42 = pMat->_43 = 0.0f;
    pMat->_11 = pMat->_22 = pMat->_33 = pMat->_44 = 1.0f;
	return TRUE;
}
GLOBAL_FUNC_DLL void __stdcall SetRotationYMatrix(MATRIX4* pMat, float fRad)
{

    SetIdentityMatrix(pMat);
    pMat->_11 =  (float)cos( fRad );
    pMat->_13 = -(float)sin( fRad );
    pMat->_31 =  (float)sin( fRad );
    pMat->_33 =  (float)cos( fRad );
}
GLOBAL_FUNC_DLL void __stdcall TransformVector3_VPTR2(VECTOR3* pv3Dest,VECTOR3* pv3Src, MATRIX4* pMat,DWORD dwNum)
{
	for (DWORD i=0; i<dwNum; i++)
	{
		pv3Dest->x = pv3Src->x*pMat->_11 + pv3Src->y*pMat->_21 + pv3Src->z*pMat->_31 + pMat->_41;
		pv3Dest->y = pv3Src->x*pMat->_12 + pv3Src->y*pMat->_22 + pv3Src->z*pMat->_32 + pMat->_42;
		pv3Dest->z = pv3Src->x*pMat->_13 + pv3Src->y*pMat->_23 + pv3Src->z*pMat->_33 + pMat->_43;
		
		pv3Src++;
		pv3Dest++;
	}
}
GLOBAL_FUNC_DLL float __stdcall CalcDistance(VECTOR3* pv3Start,VECTOR3* pv3End)
{
	float	result;

	VECTOR3 v3dist;
	//= *pv3End - *pv3Start;
	VECTOR3_SUB_VECTOR3(&v3dist,pv3End,pv3Start);
	result = (float)sqrt(v3dist.x * v3dist.x + v3dist.y * v3dist.y + v3dist.z * v3dist.z);

	return result;

}

//void OutputFile(char* str)
//{}

NGlobal::NGlobal()
{
}

NGlobal::~NGlobal()
{
}

