#include <fstream>
#include <vector>
#include "HeavyLog.h"
#include "Protocol.h"

#define ULTI 0x49544c55

HeavyLog::HeavyLog()
{
	loaded = false;
}

HeavyLog::~HeavyLog()
{
}

bool HeavyLog::init()
{
	loaddata();
	return true;
}

void HeavyLog::atrecv(unsigned char cat, unsigned char prot)
{
	if(!loaded) return;
	if( !isOKprint(cat,prot) ) return;
	int npt = 1000 * cat + prot;
	bool catb = _mcat.find(cat) != _mcat.end();
	bool prtb = _mprt.find(npt) != _mprt.end();
	if( !catb && !prtb){
		printf("in > %u->%u\n",cat,prot );
	} else if( catb && !prtb){
		printf("in > %s->%u\n",_mcat[cat].c_str(),prot );
	} else if( !catb && prtb){
		printf("in > %u->%s\n",cat,_mprt[npt].c_str() );
	} else {
		printf("in > %s->%s\n",_mcat[cat].c_str(),_mprt[npt].c_str() );
	}
}

void HeavyLog::atsend(unsigned char cat, unsigned char prot)
{
	if(!loaded) return;
	if( !isOKprint(cat,prot) ) return;
	int npt = 1000 * cat + prot;
	bool catb = _mcat.find(cat) != _mcat.end();
	bool prtb = _mprt.find(npt) != _mprt.end();
	if( !catb && !prtb){
		printf("out> %u->%u\n",cat,prot );
	} else if( catb && !prtb){
		printf("out> %s->%u\n",_mcat[cat].c_str(),prot );
	} else if( !catb && prtb){
		printf("out> %u->%s\n",cat,_mprt[npt].c_str() );
	} else {
		printf("out> %s->%s\n",_mcat[cat].c_str(),_mprt[npt].c_str() );
	}
}
void HeavyLog::loaddata()
{
	std::vector<char> tvec;
	{
	std::ifstream ifa("zprotocol.dat", std::ifstream::in | std::ifstream::binary );
	if( ifa.good() ){
		ifa.seekg( 0, std::ifstream::end );
		tvec.resize( ifa.tellg() );
		ifa.seekg( 0, std::ifstream::beg );
		ifa.read(&(tvec[0]),tvec.size());
		int mmgc = *(int*)&(tvec[0]);
		if( mmgc != ULTI){
			return;
		}
	}
	
	}
	if( !tvec.empty() ){
		unsigned int seeker = 4;
		int version = *(int*)&(tvec[seeker]);
		int lsize = *(int*)&(tvec[seeker + 4]);
		int lcount = *(int*)&(tvec[seeker + 8]);
		seeker += 12;
		for( ;lcount >= 1; --lcount ){
			int catnum = *(int*)&(tvec[seeker]);
			int ptcount = *(int*)&(tvec[seeker + 4]);
			unsigned int strcount = *(unsigned int*)&(tvec[seeker + 8]);
			seeker += 12;
			std::string strret( &(tvec.at(seeker)),&(tvec.at(seeker + strcount - 1) ));
			//printf("%s %u %u\n",strret.c_str(),ptcount,lcount);
			_mcat[catnum] = strret;
			seeker += strcount;
			for( int aa = 0;ptcount > 0; --ptcount, ++aa ){
				int strckk = *(int*)&(tvec[seeker]);
				seeker += 4;
				int pindex = (catnum * 1000) + aa;
				std::string strret00( &(tvec.at(seeker)),&(tvec.at(seeker + strckk  - 1) ));
				_mprt[pindex] = strret00;
				seeker += strckk;
			}
		}
	}
	loaded = true;
}
std::string HeavyLog::readSTR(std::vector<char>& tvec, unsigned int& seeker)
{
	unsigned int strcount = *(unsigned int*)&(tvec[seeker]);
	std::string ret( &(tvec.at(seeker + 4)),&(tvec.at(seeker + strcount) ));
	seeker += strcount;
	return ret;
}
bool HeavyLog::isOKprint(unsigned char cat, unsigned char prot)
{
	bool ret = true;
	switch(cat){
		case MP_COOK:
			switch(prot){
				case MP_COOK_UPDATERECIPE: 
					ret = false; 			break;
				default: break;
			}
			break;
		case MP_MOVE:
			switch(prot){
				case MP_MOVE_ONETARGET: 
				case MP_MOVE_STOP:
				case MP_MOVE_MONSTERMOVE_NOTIFY:
				case MP_MOVE_CORRECTION:
					ret = false; 			break;
				default: break;
			}
			break;
		case MP_USERCONN:
			switch(prot){
				case MP_USERCONN_MONSTER_ADD: 
				case MP_USERCONN_OBJECT_REMOVE: 
				case MP_USERCONN_CHARACTER_APPLYEXP_NOTICE:
				case MP_USERCONN_MONSTER_DIE:
					ret = false; 			break;
				default: break;
			}
			break;
		case MP_CHAR:
			switch(prot){
				case MP_CHAR_MAXLIFE_NOTIFY: 
				case MP_CHAR_MANA_ACK:
				case MP_CHAR_MAXMANA_NOTIFY: 
				case MP_CHAR_LIFE_BROADCAST:
				case MP_CHAR_LIFE_GET_SYN:
				case MP_CHAR_LIFE_GET_ACK:
				case MP_CHAR_MONSTERMETER_KILLMONSTER:
				case MP_CHAR_EXPPOINT_ACK:
				
					ret = false; 			break;
				default: break;
			}
			break;
		case MP_CHAT:
			switch(prot){
				case MP_CHAT_MONSTERSPEECH: 
					ret = false; 			break;
				default: break;
			}
			break;
		case MP_SKILL:
			switch(prot){
				case MP_SKILL_START_SYN:
				case MP_SKILL_SKILLOBJECT_ADD: 
				case MP_SKILL_SKILLOBJECT_REMOVE:
				case MP_SKILL_SKILL_RESULT:
				case MP_SKILL_COUNT_NOTIFY:
				case MP_SKILL_DELAY_RESET_NOTIFY:
				case MP_SKILL_UPDATE_TARGET_SYN:
					ret = false; 			break;
				default: break;
			}
			break;
		default: break;
	}
	return ret;
}
